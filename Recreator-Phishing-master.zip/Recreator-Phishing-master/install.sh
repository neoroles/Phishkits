apt-get install wget
pip3 install wget
