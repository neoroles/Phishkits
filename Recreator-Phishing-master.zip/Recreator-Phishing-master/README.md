# Recreator-Phishing

PROFESSIONAL TOOL ORIENTED IN THE RECREATION OF PHISHING WEBSITE SCENARIOS
 
<h3> Mode Of Execution: </h3>

* apt-get install python3

* apt-get install git 

* git clone https://github.com/AngelSecurityTeam/Recreator-Phishing

* cd Recreator-Phishing

* bash install.sh

* python3 ServerInstall.py

* python3 recreator-phishing.py

# TERMUX

* pkg install git

* git clone  https://github.com/AngelSecurityTeam/Recreator-Phishing

* cd Recreator-Phishing

* pkg install python

* pkg install wget

* pip3 install wget

* python3 ServerInstall.py

* python3 recreator-phishing.py


<h3> PHISHING-TOOL PHOTOS </h3>

<img src="https://github.com/AngelSecurityTeam/Recreator-Phishing/blob/master/fotosub4.png">

<img src="https://github.com/AngelSecurityTeam/Recreator-Phishing/blob/master/capv32.png">

<h2> main page not defined </h2>

<img src="https://github.com/AngelSecurityTeam/Recreator-Phishing/blob/master/capv333.png">


<h3> Real Bank Phishing </h3>

<img src="https://github.com/AngelSecurityTeam/Recreator-Phishing/blob/master/cap2.png">

<img src="https://github.com/AngelSecurityTeam/Recreator-Phishing/blob/master/capb2.png">

<img src="https://github.com/AngelSecurityTeam/Recreator-Phishing/blob/master/cap3.png">

<h3> Paypal Donations: </h3>

* https://www.paypal.me/AngelSecurityTeam
