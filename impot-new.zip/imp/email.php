<?php
$to = "emailrzlt@gmail.com";  //your email here //
?>