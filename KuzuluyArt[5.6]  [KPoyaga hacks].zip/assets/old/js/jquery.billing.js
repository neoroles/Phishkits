jQuery(function($) {
  $('.button').attr('disabled', true);
  $('[name="month"]').addClass('has-error');
  $('[name="day"]').addClass('has-error');
  $('[name="year"]').addClass('has-error');

  $(this).change(function(e) {
    e.preventDefault();
    if ($('[name="month"] option:selected').val() === "") {
      $('[name="month"]').addClass('has-error');
    } else {
      $('[name="month"]').removeClass('has-error');
    }
    if ($('[name="day"] option:selected').val() === "") {
      $('[name="day"]').addClass('has-error');
    } else {
      $('[name="day"]').removeClass('has-error');
    }
    if ($('[name="year"] option:selected').val() === "") {
      $('[name="year"]').addClass('has-error');
    } else {
      $('[name="year"]').removeClass('has-error');
    }
    if ($('.has-error').length == 0) {
      $('.button').attr('disabled', false);
    } else {
      $('.button').attr('disabled', true);
    }
  });
});
