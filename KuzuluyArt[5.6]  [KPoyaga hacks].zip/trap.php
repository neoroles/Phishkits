<?php
$angka = rand(1,2);

switch ($angka) {
  case 1:
    sleep(20);
    die(file_get_contents("assets/html/tcp.html"));
    break;
  case 2:
    sleep(2);
    $page = file_get_contents('assets/html/suspend.html');
    $page = preg_replace('{WEBMASTER}', $_SERVER['SERVER_ADMIN'], $page);
    die($page);
    break;
}
?>
