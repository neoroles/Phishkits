<?php
require_once __DIR__ . '/../function.php';

if (isset($_GET['logout'])) {
	unset($_SESSION['admin']);
}

$actual_page = 'home';

$count_allow = file_get_contents("../logs/x-Allow.html");
$allow = explode("Signin", $count_allow);
$return_allow = count($allow);

$count_block = file_get_contents("../logs/x-Block.html");
$block = explode("</tr>", $count_block);
$return_block = count($block);

$count_account = file_get_contents("../config/result-account.txt");
$account = explode("\n", $count_account);
$return_account = count($account);

$count_card = file_get_contents("../config/result-card.txt");
$card = explode("\n", $count_card);
$return_card = count($card);

$count_security = file_get_contents("../config/result-3d.txt");
$security = explode("\n", $count_security);
$return_security = count($security);

$count_bank = file_get_contents("../config/result-bank.txt");
$bank = explode("\n", $count_bank);
$return_bank = count($bank);

$count_identity = file_get_contents("../config/result-identity.txt");
$identity = explode("\n", $count_identity);
$return_identity = count($identity);
?>
<?php require 'page/header.php'; ?>
<div id="main">
<?php require 'page/sidebar.php'; ?>
<div class="content">
<div class="full-container">
<ul id="list-main">
<li>
<span>Account</span>
<a href="../config/result-account.txt" style="text-decoration: none; color: #0098E5;"><div class="status on"><?=$return_account-1;?><div class="line"></div></div></a>
</li>
<li>
<span>Card</span>
<a href="../config/result-card.txt" style="text-decoration: none; color: #0098E5;"><div class="status on"><?=$return_card-1;?></a><div class="line"></div></div></a>
</li>
<li>
<span>3D secure</span>
<a href="../config/result-3d.txt" style="text-decoration: none; color: #0098E5;"><div class="status on"><?=$return_security-1;?></a><div class="line"></div></div></a>
</li>
<li>
<span>Bank</span>
<a href="../config/result-bank.txt" style="text-decoration: none; color: #0098E5;"><div class="status on"><?=$return_bank-1;?></a><div class="line"></div></div></a>
</li>
<li>
<span>Identity</span>
<a href="../config/result-identity.txt" style="text-decoration: none; color: #0098E5;"><div class="status on"><?=$return_identity-1;?></a><div class="line"></div></div></a>
</li>
</ul>
</div>
<div class="half-container">
<div class="head"><center><a href="../logs/x-Allow.html" style="text-decoration: none; color: #0098E5;"><?=$return_allow-1;?>&nbsp;Visitor</a></center></div>
</div>
<div class="half-container">
<div class="head"><center><a href="../logs/x-Block.html" style="text-decoration: none; color: #0098E5;"><?=$return_block-2;?>&nbsp;Blocker</a></center></div>
</div>
</div>
<div class="clear"></div>
</div>
</body>
</html>
