<div class="sidebar">
<ul id="menu">
<?php
if (file_exists($api->dir_config.'/'.$api->general_config)) {
  @eval(file_get_contents($api->dir_config.'/'.$api->general_config));
}

echo ($actual_page == 'home') ? '<li value="home" class="active"><div id="imghome" class="active">Home</div></li>' : '<li value="home"><div id="imghome">Home</div></li>';
echo ($actual_page == 'smtp' || $actual_page == 'general' || $actual_page == 'model') ? '<li value="settings" class="active"><div id="imgsettings" class="active">Settings</div></li>' : '<li value="settings"><div id="imgsettings">Settings</div></li>';
?>
<ul class="submenu">
<?php
echo ($actual_page == 'general') ? '<li value="general" class="active">General</li>' : '<li value="general">General</li>';
if ($config_model == "new"){
  echo ($actual_page == 'model') ? '<li value="'.$config_model.'" class="active">Page</li>' : '<li value="'.$config_model.'">Page</li>';
}
if ($config_smtp == "enable") {
  echo ($actual_page == 'smtp') ? '<li value="smtp" class="active">Smtp</li>' : '<li value="smtp">Smtp</li>';
}
?>
</ul>
<?php echo ($actual_page == 'info') ? '<li value="info" class="active"><div id="imgspam" class="active">Info</div></li>' : '<li value="info"><div id="imgspam">Info</div></li>'; ?>
<li value="logout"><div id="imglogout">Logout</div></li>
</ul>
</div>
