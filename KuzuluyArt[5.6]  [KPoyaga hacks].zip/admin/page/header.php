<?php
require_once __DIR__ . '/../../function.php';

$token = $api->token($_REQUEST['pass']);
$status = $token->status;

if (!empty($token) and $_SESSION['admin'] != "KZLY") {
  if (isset($_REQUEST['pass']) and $status == "success") {
    $_SESSION['admin'] = "KZLY";
    $api->redirect("home");
  } else {
    print "<pre align=center><form method=post>Token: <input type='password' name='pass'><input type='submit' value='>>'></form></pre>";
    exit;
  }
}
?>
<!DOCTYPE html>
<html>

<head>
<title>Admin - KuzuluyArt</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<link rel="shortcut icon" href="../assets/img/favicon.ico">
<link rel="apple-touch-icon" href="../assets/img/apple-touch-icon.png">
<link rel="stylesheet" href="../assets/css/admin_style.css">
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/start.js"></script>
</head>

<body>
  
<div id="header">
<div align="center"><img src="../assets/img/favicon.svg" width="140px"/></div>
</div>
