<?php
require_once __DIR__ . '/../function.php';

$xconfig = false;
$actual_page = 'smtp';

if(isset($_POST['save'])) {
	$a = $_POST['smtphost'];
	$b = $_POST['smtpport'];
	$c = $_POST['smtpsecure'];
	$d = $_POST['smtpuser'];
	$e = $_POST['smtppass'];
	$api->setSMTP(array($a, $b, $c, $d, $e));
  $msg = '<div class="success">Changes have been saved!</div>';
}

if (file_exists($api->dir_config.'/'.$api->smtp_config)) {
  $xconfig = true;
  @eval(file_get_contents($api->dir_config.'/'.$api->smtp_config));
}

if(isset($_POST['connect'])) {
  if ($api->checkSmtp() == true) {
    $msg = '<div class="success">SMTP Connected!</div>';
  } else {
    $msg = '<div class="failed">Connection Failed!</div>';
  }
}
?>
<?php require 'page/header.php'; ?>
<div id="main">
<?php require 'page/sidebar.php'; ?>
<div class="content">
<div class="top-subhead">
<h2>SMTP Settings</h2>
<div class="clear"></div>
</div>
<div class="full-container no-border">
<?php
if (isset($_POST['save'])) {
	echo $msg;
} else if (isset($_POST['connect'])) {
	echo $msg;
}
?>
<form method="post" action="" autocomplete="off">
<ul id="settings">
<li>
<div class="left">SMTP Host</div>
<div class="right">
<input type="text" name="smtphost" <?php if($xconfig == true){ echo "value=\"$config_smtphost\""; } ?> required>
</div>
</li>
<li>
<div class="left">SMTP Port</div>
<div class="right">
<input type="text" name="smtpport" <?php if($xconfig == true){ echo "value=\"$config_smtpport\""; } ?> required>
</div>
</li>
<li>
<div class="left">SMTP Secure</div>
<div class="right">
<select name="smtpsecure">
<?php
if($xconfig == true && $config_smtpsecure == "enable") {
	echo '<option value="enable" selected>Enable</option>
<option value="disable">Disable</option>';
} else {
	echo '<option value="enable">Enable</option>
<option value="disable" selected>Disable</option>';
}
?>
</select>
</div>
</li>
<li>
<div class="left">SMTP User</div>
<div class="right">
<input type="text" name="smtpuser" <?php if($xconfig == true){ echo "value=\"$config_smtpuser\""; } ?> required>
</div>
</li>
<li>
<div class="left">SMTP Pass</div>
<div class="right">
<input type="password" name="smtppass" <?php if($xconfig == true){ echo "value=\"$config_smtppass\""; } ?> required>
</div>
</li>
</ul>
<br>
<input type="submit" name="save" value="Save changes">&nbsp;&nbsp;
<?php
if($xconfig == true){
	echo '<input type="submit" name="connect" value="Test Connect">';
}
?>
</form>
</div>
</div>
<div class="clear"></div>
</div>
</body>
</html>
