<div class="navbar footer" id="bfooter">
<div class="navbar-inner">
<ul class="inline">
<li><a href="?help"><?=$api->transcode("Help");?></a></li>
<li><a href="?contact"><?=$api->transcode("Contact");?></a></li>
<li><a href="?security"><?=$api->transcode("Security");?></a></li>
</ul>
<ul class="inline">
<li class="copyright"><?=$api->transcode("Copyright ©");?> <?=$api->encode(date('Y'));?> <?=$api->transcode("PayPal, Inc. All rights reserved.");?>
</li>
<li><a href="?privacy"><?=$api->transcode("Privacy");?></a></li>
</ul>
</div>
</div>
</div>
</body>
</html>
