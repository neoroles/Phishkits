<?php

header("location: reward.ff.garena");
exit;

?>