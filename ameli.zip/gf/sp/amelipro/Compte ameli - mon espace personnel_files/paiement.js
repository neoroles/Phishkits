// M�thode d'appel dynamique des actions struts (recherche de paiements, afficher derniers paiements)
function ajaxCallRemoteRecherchePaiement(portletContext,actionName) {
		
	var dateDebut = document.getElementById(portletContext+'dateDebut').value;
	var dateFin = document.getElementById(portletContext+'dateFin').value;
	var benefSelectionne = document.getElementById(portletContext+'benefSelectionne').value;
	var afficherReleves = document.getElementById(portletContext+'afficherReleves').checked;
	var afficherIJ = document.getElementById(portletContext+'afficherIJ').checked;
	var afficherPT = document.getElementById(portletContext+'afficherPT').checked;
	var afficherInva = document.getElementById(portletContext+'afficherInva').checked;
	var afficherRentes = document.getElementById(portletContext+'afficherRentes').checked;
	var afficherRS = document.getElementById(portletContext+'afficherRS').checked;
	var indexPaiement = document.getElementById(portletContext+'indexPaiement').value;
	var idNotif = document.getElementById(portletContext+'idNotif').value;
	var commencerRecherche = true;
	
	//D�sactivation et r�initialisation des champs si afficherReleve est � OUI
	if(afficherReleves == true){
		showLoadingPaiement();
		document.getElementById(portletContext+'blocAutresCriteres').className = "inactif";
		
		$(portletContext+'filtre_non_transmis').addClass("inactif");
		
		//R� initialisation de toutes les crit�res	
		reinitialiserCritereDeRecherche(portletContext);
	}
	else{
		$(portletContext+'filtre_non_transmis').removeClass("inactif");
		document.getElementById(portletContext+'blocAutresCriteres').className = "";
	}
	
	
	
	//Pour les recherche de paiements, tester d'abord si l'assur� a saisi des dates avant de continuer
	if(actionName == "Rechercher"){
		commencerRecherche = validerCriteres(portletContext,document.getElementById(portletContext+'dateDebut'), document.getElementById(portletContext+'dateFin'));
	}
	
	if(actionName == "afficherPaiementsComplementaires"){
		//R� initialisation de toutes les crit�res	
		reinitialiserCritereDeRecherche(portletContext);
	}
	
	if(commencerRecherche == true){
		showLoadingPaiement();
	
		var functionActionUrl = '/PortailAS/paiements.do?actionEvt=' + actionName + '&idNoCache=' + new Date().getTime() 
					+ '&DateDebut=' + dateDebut+ '&DateFin=' + dateFin+ '&Beneficiaire=' + benefSelectionne+ '&afficherReleves='+afficherReleves
					+ '&afficherIJ=' + afficherIJ+ '&afficherPT=' + afficherPT + '&afficherInva=' + afficherInva+ '&afficherRentes=' + afficherRentes + '&afficherRS=' + afficherRS
					+ '&indexPaiement=' + indexPaiement+ '&idNotif=' + idNotif;
		
		//
		if (window.XMLHttpRequest)
		{	// Non-IE browsers
			req = new XMLHttpRequest();
			req.onreadystatechange = majPaiements;
			req.open('GET', functionActionUrl, true);
			req.send(null);
		}
		else if (window.ActiveXObject)
		{	// IE
			req = new ActiveXObject('Microsoft.XMLHTTP');
			req.onreadystatechange = majPaiements;
			req.open('GET', functionActionUrl, true);
			req.send();
		}
		else {
			return; // Navigateur non compatible
		}
	}
}

function keyDownRecherchePaiement(portletContext,actionName, e){
  if (e.defaultPrevented) {
    return; // Should do nothing if the default action has been cancelled
  }

  var handled = false;
  if (e.key !== undefined) {
    switch(e.key) {
		case 'Enter':
		case ' ':
			ajaxCallRemoteRecherchePaiement(portletContext,actionName);
			handled = true;
		default:
			break;
	}
  } else if (e.keyIdentifier !== undefined) {
    switch(e.keyIdentifier) {
		case 'Enter':
		case 'U+0020':
			ajaxCallRemoteRecherchePaiement(portletContext,actionName);
			handled = true;
		default:
			break;
	}
  } else if (e.keyCode !== undefined) {
    switch(e.keyCode) {
		case 13:
		case 32:
			ajaxCallRemoteRecherchePaiement(portletContext,actionName);
			handled = true;
		default:
			break;
	}
  }

  if (handled) {
    // Suppress "double action" if event handled
    if(e.preventDefault){
        e.preventDefault();
    } else {
        e.returnValue = false;
    }
  }
}

//Methode montrant le bouton de chargement lors de l'appel � rechercher
function showLoadingPaiement(){
	var image = document.createElement('img');
	image.className="loading";
	image.id = 'loadingPaiementsImg';
	image.alt="Chargement...";
	image.src = "/PortailAS/biblicnam/images/zoneMessage/roue-tempo.gif";
	document.getElementById('liste_paiement').appendChild(image);
}

//Methode de validation des criteres de recherches
function validerCriteres(portletContext,dateDebutId,dateFinId){
	var valid = true;
	
	// regex de validation d'une date
	var reg = /^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((19|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((19|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((19|[2-9]\d)\d{2}))|(29\/02\/((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$/g;
	var regFin = /^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((19|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((19|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((19|[2-9]\d)\d{2}))|(29\/02\/((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$/g;
	
	//les champs de date de d�but et date de fin
	var champDateDebut = document.getElementById(portletContext+'dateDebut');
	var champDateFin = document.getElementById(portletContext+'dateFin');
	
	//Variable dates Date du jour 
	var dateDuJour = new Date();
	var dateMoinsSixMoisChaine = getDateMoinsNMois(5);
	var dateMoinsSixMois = getDate(dateMoinsSixMoisChaine);
	var dateDebut = dateDebutId.value;
	var dateFin = dateFinId.value;
	//alert(" dateDebut "+dateDebut);
	
	//La date de d�but et la date de fin est obligatoire	
	if(!ChampSaisieTag.isEmpty(dateDebutId) &&  !ChampSaisieTag.isEmpty(dateFinId)){
		//on vide les messages d'erreurs
		ChampSaisieTag.champOK(dateDebutId);
		ChampSaisieTag.champOK(dateFinId);
		
		//on controle de nouveaux les dates (format)
		ChampSaisieTag.controleDate(champDateDebut);
		ChampSaisieTag.controleDate(champDateFin);
		if(document.getElementById(champDateDebut.id+ChampSaisieTag.prefixIdZoneMessageErreur).innerHTML === '' 
				&& document.getElementById(champDateFin.id+ChampSaisieTag.prefixIdZoneMessageErreur).innerHTML === ''){
				
			//La date de debut doit �tre ant�rieur � la date de fin
			if(getDate(dateDebut)> getDate(dateFin)){
				valid = false;
				ChampSaisieTag.erreurChamp(champDateFin, " La date de fin doit &ecirc;tre sup&eacute;rieure &agrave; la date de d&eacute;but.");
			}
			
			//La date de debut ne doit pas �tre ant�rieur � plus de 6 mois
			if(getDate(dateDebut) < dateMoinsSixMois){
				valid = false;
				ChampSaisieTag.erreurChamp(champDateDebut, "La date de d&eacute;but ne peut &ecirc;tre ant&eacute;rieure &agrave; "+dateMoinsSixMoisChaine);
			}
		
			//La date de debut ne doit pas �tre sup�rieur � la date du jour
			if(getDate(dateFin) > dateDuJour){
				valid = false;
				ChampSaisieTag.erreurChamp(champDateFin, "La date de fin doit &ecirc;tre ant&eacute;rieure ou &eacute;gale &agrave; la date du jour.");
			}
			//La date de d�but ne peut �tre invalide
			if (reg.test(dateDebut)==false) {
					ChampSaisieTag.erreurChamp(champDateDebut, "La date de d&eacute;but est invalide");
					valid = false;
				}
			
			//La date de fin ne peut �tre invalide
			if (regFin.test(dateFin)==false) {
					ChampSaisieTag.erreurChamp(champDateFin, "La date de fin est invalide");
					valid = false;
				}
		}
	}else{
		//Si le champ date de d�but est vide
		if(ChampSaisieTag.isEmpty(dateDebutId)){
			valid = false;
			ChampSaisieTag.erreurChamp(champDateDebut, "La date de d&eacute;but est obligatoire");
		}
		//Si le champ date de fin est vide
		if(ChampSaisieTag.isEmpty(dateFinId)){
			valid = false;
			ChampSaisieTag.erreurChamp(champDateFin, "La date de fin est obligatoire");
		}
	}

	return valid;
}

function actualiserAffichagePaiementsNonTransmis(event) {

	var showAll = !$(event.target).checked;
	var showInfo = false;
	var allLines = document.querySelectorAll("[id^='lignePaiement']");
	
	if (showAll) {
		for (var index=0; index < allLines.length; index++) { 
			$(allLines[index]).removeClass('invisible');
		}
	}
	// Show only paiement without transmission
	else {
		for (var index=0; index < allLines.length; index++) {
			var line = allLines[index];
			if ($(line).getElement("span.picto-non-transmis")) {
				$(line).removeClass('invisible');
			}
			else 
				$(line).addClass('invisible');
		}
	}
	
	
	return false;
	
}

//Methode d'instanciation d'une date
function getDate(dateString){
	var dtString = dateString.split("/");
	var date = new Date(dtString[2], dtString[1]-1, dtString[0]);
	return date;
}

function getDateMoinsNMois(nombre){
	//Date du jour 
	var today = new Date();
	var dateMoinsSixMois = new Date(today.getFullYear(),today.getMonth()-5,0);
	dateMoinsSixMois.setDate(Math.min(today.getDate(),dateMoinsSixMois.getDate())); 
	
 
 		//date du jour
		var annee = today.getFullYear();
		var moisEnCours = ('0'+(today.getMonth()+1)).slice(-2);
		var jour = ('0'+today.getDate()).slice(-2);
		
		//Le mois il y a 6 mois 
		var moisMoinsSix = ('0'+(dateMoinsSixMois.getMonth()+1)).slice(-2);
		var anneeFin = dateMoinsSixMois.getFullYear();
		var jourSixMois = ('0'+dateMoinsSixMois.getDate()).slice(-2);
		
		
		dateMoinsSixMois = jourSixMois+"/"+moisMoinsSix+"/"+anneeFin;
		
		return dateMoinsSixMois;
}

//Methode pour la r�initialisation des criteres de recherche
function reinitialiserCritereDeRecherche(portletContext){
		//Date du jour 
		var now = new Date();
 
 		//date du jour
		var annee = now.getFullYear();
		var moisEnCours = ('0'+(now.getMonth()+1)).slice(-2);
		var jour = ('0'+now.getDate()).slice(-2);
		
		document.getElementById(portletContext+'dateDebut').value = getDateMoinsNMois(5);
		document.getElementById(portletContext+'dateFin').value = jour+"/"+moisEnCours+"/"+annee;
		
		//enlever les �ventuels erreurs sur les champs
		ChampSaisieTag.champOK(document.getElementById(portletContext+'dateDebut'));
		ChampSaisieTag.champOK(document.getElementById(portletContext+'dateFin'));
		
		document.getElementById(portletContext+'benefSelectionne').value = "tout_selectionner";
		
		//mettre les valeurs des autres champs � false
		document.getElementById(portletContext+'afficherIJ').checked=false;
		document.getElementById(portletContext+'afficherPT').checked=false;
		document.getElementById(portletContext+'afficherInva').checked=false;
		document.getElementById(portletContext+'afficherRentes').checked=false;
		document.getElementById(portletContext+'afficherRS').checked=false;
		document.getElementById(portletContext+'afficherNonTransmis').checked=false;
}


// Methode private qui traite le retour de l'appel de ajaxCallRemoteRecherchePaiement
function majPaiements() {
	if (req.readyState == 4)
	{ 	// Complete
		if (req.status == 200)
		{ 	// OK response
			afficherListePaiements(req);
			var event = {target: 'paiements_1afficherNonTransmis'};
			actualiserAffichagePaiementsNonTransmis(event);
		}
	}
}

//Methode d'affichage de la liste des paiements envoy�s par le service
function afficherListePaiements(req){
	var liste_paiement = document.getElementById('liste_paiement');
	liste_paiement.innerHTML = req.responseText;
}


//Methode appel� pour afficher les paiements compl�mentaires
function addPaiementsComplementaires() {
if (req.readyState == 4)
	{ 	// Complete
		if (req.status == 200)
		{ 	// OK response

		ajouterListePaiements(req);
		 }
	}
}

function ajouterListePaiements(req){
	var liste_paiement = document.getElementById('liste_paiement');
	liste_paiement.innerHTML = req.responseText;
	
	document.getElementById(portletContext+'liste_paiement').className = "liste-paiement";
}

/*Fonction permettant d'ajouter les evts de gestion du bouton de t�l�chargement*/
function ajoutEventListenerTelecharger(nomLien,nomLibelle,indexGroupe,indexPaiement){

	if (document.getElementById(nomLien+indexGroupe+indexPaiement).addEventListener) { // W3C DOM
			//mouseover
  			document.getElementById(nomLien+indexGroupe+indexPaiement).addEventListener( 'mouseover', function(){
				document.getElementById(nomLibelle+indexGroupe+indexPaiement).style.display = "inline-block";
			} );
			//mouseout
			document.getElementById(nomLien+indexGroupe+indexPaiement).addEventListener( 'mouseout', function(){
				document.getElementById(nomLibelle+indexGroupe+indexPaiement).style.display = "none";
			} );
  		}else if (document.getElementById(nomLien+indexGroupe+indexPaiement).attachEvent) { // IE DOM
  			//mouseover
  			document.getElementById(nomLien+indexGroupe+indexPaiement).attachEvent("onmouseover", function(){
				document.getElementById(nomLibelle+indexGroupe+indexPaiement).style.display = "inline-block";
			} );
			//mouseout
			document.getElementById(nomLien+indexGroupe+indexPaiement).attachEvent('onmouseout', function(){
				document.getElementById(nomLibelle+indexGroupe+indexPaiement).style.display = "none";
			} );
	}
	
}

/*Fonction pour annuler les valeurs dans le tableau*/
function resetTableauPaiement(){
	//alert('resetTableauPaiement ');
 	var liste_paiement = document.getElementById('liste_paiement');
 	
	//Supprimer les elts enfants de la liste des paiements
	if(document.getElementById('unordered_list')){
		var ul = document.getElementById('unordered_list');
		liste_paiement.removeChild(ul);
	}
}


/**M�thode pour l'appel de chargement des d�tails du paiement*/
// M�thode d'appel dynamique des actions struts (recherche de paiements, afficher derniers paiements)
function ajaxCallRemoteChargerDetailPaiement(idPaiement,naturePaiement,indexGroupe,indexPaiement) {

	var bpHeader = document.getElementById('lignePaiement'+indexGroupe+indexPaiement);
	
	if(document.getElementById("detailPaiement"+indexGroupe+indexPaiement).innerHTML !== ""){
		var blocDetail = document.getElementById("detailPaiement"+indexGroupe+indexPaiement);
		if(bpHeader.get('aria-expanded') === 'false'){
			//montrer le d�tail
			displayDetail(bpHeader, blocDetail);
			
			//Gestion de ouvrir/fermer
			showDetails(indexGroupe,indexPaiement);
			
			//Cacher les autres
			cacherAutreDetails('detailPaiement'+indexGroupe+indexPaiement);
		}else{
			//cacher le d�tail
			hideDetail(bpHeader, blocDetail, "false");
			
			//style CSS
			closeDetails(bpHeader);
		}
	}else{
		loading('lignePaiement'+indexGroupe+indexPaiement,indexGroupe,indexPaiement);
		var functionActionUrl2 = '/PortailAS/paiements.do?actionEvt=chargerDetailPaiements&idNoCache=' + new Date().getTime() + '&idPaiement='+ idPaiement+ '&naturePaiement='+ naturePaiement+ '&indexGroupe='+ indexGroupe+ '&indexPaiement='+ indexPaiement;
		
		//
		if (window.XMLHttpRequest)
		{	// Non-IE browsers
			req2 = new XMLHttpRequest();
			req2.onreadystatechange = majDetails;
			req2.open('GET', functionActionUrl2, true);
			req2.send(null);
			
		}
		else if (window.ActiveXObject)
		{	// IE
			req2 = new ActiveXObject('Microsoft.XMLHTTP');
			req2.onreadystatechange = majDetails;
			req2.open('GET', functionActionUrl2, true);
			req2.send();
			
		}
		else {
			return; // Navigateur non compatible
		}
	}
}

/**M�thode pour l'appel de chargement des d�tails du paiement AU CLAVIER*/
// M�thode d'appel dynamique des actions struts (recherche de paiements, afficher derniers paiements)
function keyDownChargerDetailPaiement(idPaiement,naturePaiement,indexGroupe,indexPaiement,e) {
  if (e.defaultPrevented) {
    return; // Should do nothing if the default action has been cancelled
  }

  var handled = false;
  if (e.key !== undefined) {
    switch(e.key) {
		case 'Enter':
		case ' ':
			ajaxCallRemoteChargerDetailPaiement(idPaiement,naturePaiement,indexGroupe,indexPaiement);
			handled = true;
		default:
			break;
	}
  } else if (e.keyIdentifier !== undefined) {
    switch(e.keyIdentifier) {
		case 'Enter':
		case 'U+0020':
			ajaxCallRemoteChargerDetailPaiement(idPaiement,naturePaiement,indexGroupe,indexPaiement);
			handled = true;
		default:
			break;
	}
  } else if (e.keyCode !== undefined) {
    switch(e.keyCode) {
		case 13:
		case 32:
			ajaxCallRemoteChargerDetailPaiement(idPaiement,naturePaiement,indexGroupe,indexPaiement);
			handled = true;
		default:
			break;
	}
  }

  if (handled) {
    // Suppress "double action" if event handled
    if(e.preventDefault){
        e.preventDefault();
    } else {
        e.returnValue = false;
    }
  }
}

//Methode pour montrer une image de chargement
function loading(idElement,indexGroupe,indexPaiement){
	var lignePaiementCible = document.getElementById(idElement);
	//changer de style � l'ouverture
	lignePaiementCible.className+= ' open';
	
	var blocChargement = document.getElementById('detailPaiement'+indexGroupe+indexPaiement);
	var image = document.createElement('img');
	image.className="loading";
	image.id = 'loading'+indexGroupe+indexPaiement;
	image.alt="Chargement...";
	image.src = "/PortailAS/biblicnam/images/zoneMessage/roue-tempo.gif";
	blocChargement.appendChild(image);
	
	//Cacher le d�tail
	blocChargement.style.overflow="hidden";
	blocChargement.style.height="auto";
	blocChargement.style.display="none";
	
	displayDetail(lignePaiementCible, blocChargement);
	
	
	
}

// Methode private qui traite le retour de l'appel de ajaxCallRemoteRecherchePaiement
function majDetails() {
	if (req2.readyState == 4)
	{ 	// Complete
		if (req2.status == 200)
		{ 	// OK response
		 afficherDetailPaiement(req2);
		 }
	}
}

/*fonction pour l'affichage du bloc de d�tail */
function afficherDetailPaiement(req){

	var reponseXML2 = req.responseXML;
	var reponseText = req.responseText;
	
	//alert("reponseText "+reponseText);
	
	//R�cup�rer l'objet d�tail
	var detailPaiement = reponseXML2.getElementsByTagName('detailPaiement');
	var nombreDetail = detailPaiement.length;
		
	
	for(var itDetail=0; itDetail<nombreDetail; itDetail++){
	
		var indexGroupe = detailPaiement[itDetail].getAttribute("indexGroupe");
		var indexPaiment = detailPaiement[itDetail].getAttribute("indexPaiment");
		
		
		
		var lignePaiementCible = document.getElementById('lignePaiement'+indexGroupe+indexPaiment);
		
		var blocDetail = document.getElementById('detailPaiement'+indexGroupe+indexPaiment);
		blocDetail.innerHTML = reponseText;
		
		//construction du footer du d�tail
		constructionFooter(indexGroupe,indexPaiment);
		displayDetail(lignePaiementCible, blocDetail);
		
		//Cacher les autres
		cacherAutreDetails('detailPaiement'+indexGroupe+indexPaiment);
		
		//Cacher le loading
		if(document.getElementById("loading"+indexGroupe+indexPaiment)){
			document.getElementById("loading"+indexGroupe+indexPaiment).style.display ="none";
		}
	}
}

/**Fonction permettant de construire le footer du d�tail des paiements*/
function constructionFooter(indexGroupe,indexPaiment){

	var blocDetailPaiement = document.getElementById('detailPaiement'+indexGroupe+indexPaiment); 
	
	//---Bloc Footer container
	var blocFooter = document.createElement('div');
	blocFooter.id = 'footer'+indexGroupe+indexPaiment;
	blocFooter.className = 'detailfooter container';
	blocDetailPaiement.appendChild(blocFooter);
	
	//var ligneInfos = document.createElement('p');
	//blocFooter.appendChild(ligneInfos);
	
	//---Texte 1
	//var infosText = document.createTextNode(document.getElementById('libPlusdInfos').innerHTML+" "); 
	//ligneInfos.appendChild(infosText);
	
	//--- Lien
	//var infosLien = document.createElement('a');
	//infosLien.href = document.getElementById('lienInfos').innerHTML;
	//infosLien.title = document.getElementById('titleLien').innerHTML;
	//infosLien.target = "_blank";	
	//infosLien.innerHTML = document.getElementById('texteLien').innerHTML;
	//ligneInfos.appendChild(infosLien);
	
	////event listener on liensInfo : stopPropagation
	//if (infosLien.addEventListener) { // W3C DOM
			////mouseover
  			//infosLien.addEventListener( 'click', function(event){
			//	stopPropagation(event);
			//} );
  		//}else if (infosLien.attachEvent) { // IE DOM
  		//	//mouseover
  			//infosLien.attachEvent("onclick", function(event){
			//	stopPropagation(event);
			//} );
	//}
	
	
	//--- Fermer
	var blocFermer = document.createElement('div');
	blocFermer.className = 'fermer';
	blocDetailPaiement.appendChild(blocFermer);
	
	var lienFermer = document.createElement('a');
	lienFermer.className = '';
	lienFermer.tabIndex=0;
	blocFermer.appendChild(lienFermer);
	
	var spanLibFermer = document.createElement('span');
	spanLibFermer.innerHTML = document.getElementById('libFermer').innerHTML+" ";
	lienFermer.appendChild(spanLibFermer);
}

/*Methode de la gestion de l'ouverture/fermeture du bloc D�tails*/
function showDetails(indexGroupe,indexPaiement) {
	//rajouter le style "open" � chaque ligne
	var classLigne = document.getElementById('lignePaiement'+indexGroupe+indexPaiement).className;
	
	listeClassName = classLigne.split(' ');
	 
	if(document.getElementById("detailPaiement"+indexGroupe+indexPaiement).innerHTML !== ""){
		
		//rajouter le style open � la ligne paiement
		if(classLigne.search('open')==-1){
			document.getElementById('lignePaiement'+indexGroupe+indexPaiement).className = classLigne+" open";
		}
	}
}

function closeDetails(bpHeader){
	//remettre le style de la ligne paiement
	var classLigne = bpHeader.className;
	var listeClassName = classLigne.split(' ');
	bpHeader.className = listeClassName[0]+' '+listeClassName[1];
}

//fonction pour montrer un bloc en mode accord�on
function displayDetail(blocHeader, blocDetail){
		blocHeader.setAttribute('aria-expanded', 'true');
		
			var myFxTween = new Fx.Tween(blocDetail, {
					duration: 500,
					transition: Fx.Transitions.Quad.easeInOut,
					property: 'height',
					onComplete: function () {		
						blocDetail.setAttribute('aria-hidden', 'false');
						blocDetail.style.height="auto";
						blocDetail.style.overflow="visible";
						
					}
				});
				
			 myFxTween.start("0", blocDetail.getDimensions().y);
			
			(function () {
				this.setStyle('display', 'block');
			}).delay(50, blocDetail);
}

//fonction pour cacher un bloc en mode accord�on
function hideDetail(blocHeader, blocDetail,ariaexp){

		blocHeader.setAttribute('aria-expanded', ariaexp);
		blocHeader.focus();
		blocDetail.style.overflow="hidden";
			
		var myFxTweencl = new Fx.Tween(blocDetail, {
			duration: 500,
			transition: Fx.Transitions.Quad.easeInOut,
			property: 'height',
			onComplete: function () {
					blocDetail.setAttribute('aria-hidden', 'true');
					blocDetail.style.height="auto";
					blocDetail.style.display="none";
			}
		});
		
		myFxTweencl.start(blocDetail.getDimensions().y, "0");
}

//function pour cocher ou d�cocher checkbox remboursement de soins
function cocherDecocherRS(portletContext){
	if(document.getElementById(portletContext+'afficherRS').checked){
		document.getElementById(portletContext+'afficherRS').checked = false;
	}else{
		document.getElementById(portletContext+'afficherRS').checked = true;
	}
}

//function de gestion des clicks : stopProgation
function stopPropagation(e){
    if (!e)
      e = window.event;

    //IE9 & Other Browsers
    if (e.stopPropagation) {
      e.stopPropagation();
    }
    //IE8 and Lower
    else {
      e.cancelBubble = true;
    }
}

//fonction pour r�cup�rer les �lements ayant la m�me classe
function getElementsByClassName (className, elmt){
   var selection = [];
 
   // le second argument, facultatif
   if(!elmt)
   {
      elmt = document;
   }
   else if(typeof elmt == "string")
   {
      elmt = document.getElementById(elmt);
   }
    
   // on s�lectionne les �l�ments ayant la bonne classe
   var elmts = elmt.getElementsByTagName("*");
   for(var i=0; i<elmts.length; i++)
   {
      if(elmts[i].className==className)
         {
         selection.push(elmts[i]);
         }
   }
   return selection;
}

//function pour cacher les autres divs de details
//qui sont ouverts au moment d'en ouvrir un nouveau
function cacherAutreDetails(idDetailEnCours){
	var eltsDetail = getElementsByClassName('detail','');
    var  lengthDetail = eltsDetail.length;
    //on modifie les elements recuperer dans le tableau
    for(var i=0; i < lengthDetail; i++){
    
     	var idElement = eltsDetail[i].id;
     	if(idElement!=idDetailEnCours){
     	
	     	var lignePaiement = document.getElementById(eltsDetail[i].getAttribute("aria-labelledby"));
	     	
	     	//fermeture du bloc ouvert trouv�
	     	if(lignePaiement.get('aria-expanded') === 'true'){
				//montrer le d�tail
				hideDetail(lignePaiement, eltsDetail[i], "false");
				
				//Gestion de ouvrir/fermer
				closeDetails(lignePaiement);
			}
     	}    	       
    }
}


//function pour l'affichage de l'aide bulle
function afficheBulle(portletContext,index){

 
     if(document.getElementById(portletContext+'idAideRemboursement').hasClass("invisible")){	
		       
			  Fenetre.components[portletContext+'idAideRemboursement'].open();
			 
			 //position de l'aide bulle 
			 var x = $('AideRemboursement'+index).getPosition().x + $('AideRemboursement'+index).getComputedSize().totalWidth; 	
			if(document.getElementById(portletContext+'idAideRemboursement').getComputedSize().totalWidth + x < $(document.body).getSize().x) {
				// largeur suffisante, positionnement � droite
				$(portletContext+'idAideRemboursement').position({relativeTo: 'AideRemboursement'+index, position: 'upperRight', edge: 'upperLeft'});
			} else {
				// largeur insuffisante, positionnement en dessous
				$(portletContext+'idAideRemboursement').position({relativeTo: 'AideRemboursement'+index, position: 'bottomRight', edge: 'upperRight'});
			}
		    
		} else {		
		   Fenetre.components[portletContext+'idAideRemboursement'].close();
		    }                  	
    }

