
/**
 * Function permettant de contr�ler le format d'un num�ro de telephone fran�ais.
 * Elle formate �galement le num�ro sous la forme 01.23.45.67.89
 */
ChampSaisieTag.controleTel = function(champ, regex, msgErr) {
	var telSaisie = champ.value;

	// regex de validation d'un num. tel. fran�ais (s�parateur -. et espace
	// admis)
	var regExpFormatTel = new RegExp(regex, "g");

	if (regExpFormatTel.test(telSaisie)) {
		// on enl�ve les �ventuels s�parateurs
		telSaisie = telSaisie.replace(/[-. ]/g, '');

		// on ajoute le s�parateur
		var telComplet = telSaisie.substr(0, 2) + ChampSaisieTag.separateurTelephone;
		telComplet += telSaisie.substr(2, 2) + ChampSaisieTag.separateurTelephone;
		telComplet += telSaisie.substr(4, 2) + ChampSaisieTag.separateurTelephone;
		telComplet += telSaisie.substr(6, 2) + ChampSaisieTag.separateurTelephone;
		telComplet += telSaisie.substr(8, 2);

		ChampSaisieTag.champOK(champ);
		champ.value = telComplet;
		return true;
	} else {
		if (telSaisie.length === 0) {
			ChampSaisieTag.champOK(champ);
			return true;
		} else {
			ChampSaisieTag.erreurChamp(champ, msgErr);
			return false;
		}
	}
};

/**
 * Function permettant de contr�ler le format d'un num�ro de telephone fixe fran�ais.
 * Elle formate �galement le num�ro sous la forme 01.23.45.67.89
 */
ChampSaisieTag.controleTelFixe = function(champ) {
	return ChampSaisieTag.controleTel(champ, "^0[123459]([-. ]?[0-9]{2}){4}$", "Le format du num&eacute;ro de t&eacute;l&eacute;phone fixe est incorrect.");
}

/**
 * Function permettant de contr�ler le format d'un num�ro de telephone portable fran�ais.
 * Elle formate �galement le num�ro sous la forme 06.23.45.67.89
 */
ChampSaisieTag.controleTelPortable = function(champ) {
	return ChampSaisieTag.controleTel(champ, "^0[67]([-. ]?[0-9]{2}){4}$", "Le format du num&eacute;ro de t&eacute;l&eacute;phone portable est incorrect.");
}

/**
 * Function permettant de contr�ler le format d'une adresse email.
 */

ChampSaisieTag.controlEmail = function(champ, regMail){
	var mailSaisie = champ.value;

	// regex de validation d'une adresse email
	var regExpFormatEmail = new RegExp(regMail, "g");
	if (regExpFormatEmail.test(mailSaisie)) {
		ChampSaisieTag.champOK(champ);
		return true;
	} else {
		if (mailSaisie.length === 0) {
			ChampSaisieTag.champOK(champ);
		} else {
			ChampSaisieTag.erreurChamp(champ, "Le format de l'adresse email n'est pas valide.");
		}
		return false;
	}
};



/**
 * Function permettant de contr�ler le format d'un nir.
 */
ChampSaisieTag.controleNir = function(champ) {
	var nirSaisie = champ.value;

	// regex de validation d'un nir
	var regExpFormatNir = new RegExp("^[0-9]{6}[0-9ABab][0-9]{6}$", "g");
                                                                  
	if (regExpFormatNir.test(nirSaisie)) {
		ChampSaisieTag.champOK(champ);
	} else {
		if (nirSaisie.length === 0) {
			ChampSaisieTag.champOK(champ);
		} else {
			ChampSaisieTag.erreurChamp(champ, "Le num&eacute;ro de s&eacute;curit&eacute; sociale n'a pas un format correct.");
		}
	}
};

/**
 * Function permettant de contr�ler le format d'un montant d�cimal (00000,00)
 */
ChampSaisieTag.controleMontant = function(champ) {
	var montantSaisie = champ.value;
	var montantFormate;
	
	// regex de validation d'un montant
	var regExpFormatMontant = new RegExp("^[0-9]*([-, ]?[0-9]{2})$", "g");
	
	
	//Si le montant saisie contient un '.'
	if(montantSaisie.indexOf('.') != -1){
		var montantspt = montantSaisie.split(".");
		var apresVirgule;
		if(montantspt[1].length >= 2){
			apresVirgule = montantspt[1].substring(0,2);
		}else{
			apresVirgule = montantspt[1]+'0';
		}
		montantFormate = montantspt[0]+','+apresVirgule;
	}else{
		//Si le montant saisi contient une virgule
		if(montantSaisie.indexOf(',') != -1){
			var montantspt = montantSaisie.split(",");
			var apresVirgule;
			if(montantspt[1].length >= 2){
				apresVirgule = montantspt[1].substring(0,2);
			}else{
				apresVirgule = montantspt[1]+'0';
			}
			montantFormate = montantspt[0]+','+apresVirgule;
		}else{
			//Si la saisie est vide
			if(montantSaisie == ''){
				montantFormate ='0,00';
			}else{
			//Si c'est un nombre entier
			montantFormate = montantSaisie+',00';
			}		
		}
	}

	if (regExpFormatMontant.test(montantFormate)) {
		ChampSaisieTag.champOK(champ);
		champ.value = montantFormate;
	} else {
		if (montantSaisie.length === 0) {
			ChampSaisieTag.champOK(champ);
		} else {
			ChampSaisieTag.erreurChamp(champ, "Le montant saisi n'a pas un format correct.");
		}
	}
};

/**
 * Fonction permettant de contr�ler qu'une date est ant�rieure � celle du jour
 */
ChampSaisieTag.controlePast = function(champ, message) {
		Date.defineParser('%d/%m/%Y');
		var valeur = new Date().parse(champ.value);
		if(ChampSaisieTag.isEmpty(champ) || !valeur.isValid() || valeur>(new Date())) {
			ChampSaisieTag.erreurChamp(champ, message);
			return false;
		}
		return true;
	}

/**
 * Fonction permettant de contr�ler qu'une date est post�rieure � celle du jour
 */
ChampSaisieTag.controleFuture = function(champ, message) {
		Date.defineParser('%d/%m/%Y');
		var valeur = new Date().parse(champ.value);
		if(ChampSaisieTag.isEmpty(champ) || !valeur.isValid() || valeur<(new Date())) {
			ChampSaisieTag.erreurChamp(champ, message);
			return false;
		}
		return true;
	}

/**
 * Function permettant de contr�ler la date de d�but et la date de fin.
 */
ChampSaisieTag.controleDateDebutFin = function(champ1, champ2) {
	//on verifie que les champs sont remplis
	if(!ChampSaisieTag.isEmpty(champ2) 
		&&  !ChampSaisieTag.isEmpty(champ1)){
		//on vide les messages d'erreurs
		ChampSaisieTag.champOK(champ1);
		ChampSaisieTag.champOK(champ2);
		//on controle de nouveaux les dates (format)
		ChampSaisieTag.controleDate(champ1);
		ChampSaisieTag.controleDate(champ2);
		
		//si il n'y a pas d'erreur sur le format, on compare les dates
		if (document.getElementById(champ1.id+ChampSaisieTag.prefixIdZoneMessageErreur).innerHTML === '' 
				&& document.getElementById(champ2.id+ChampSaisieTag.prefixIdZoneMessageErreur).innerHTML === ''){
				
			var dtdebspt = champ1.value.split("/");
			var dtdeb = new Date(dtdebspt[2], dtdebspt[1]-1, dtdebspt[0]);
			var dtfinspt = champ2.value.split("/");
			var dtfin = new Date(dtfinspt[2], dtfinspt[1]-1, dtfinspt[0]);
			
			if(dtdeb>dtfin){
				ChampSaisieTag.erreurChamp(champ2, "La date de fin ne peut &ecirc;tre ant&eacute;rieure &agrave; la date de d&eacute;but."); 
			}
			
		}
	}
};

/**
 * Function permettant de contr�ler que la valeur est un entier positif
 */
ChampSaisieTag.controleEntierPositif = function(champ) {
	if(!ChampSaisieTag.isEmpty(champ)){
		if(champ.value==Math.abs(parseInt(champ.value)) && Math.abs(parseInt(champ.value))>0){
			ChampSaisieTag.champOK(champ);
		} else {
			ChampSaisieTag.erreurChamp(champ, "La valeur doit &ecirc;tre un nombre entier et sup&eacute;rieur &agrave; 0."); 
		}
	}
};

/**
 * Patch pour le bug de la DDS CNAM_00173473 + FT 192829
 * Auteur : DDST le 20/11/14
 * Version concernees : IH070500P
 * PATCH A SUPPRIMER SI LA VERSION DE BIBLICNAM UTILISEE EST DIFFERENTE, 
 * NE PAS SUPPRIMER LA CORRECTION DE LA FT 192829
 */
	Fenetre.ModaleAS = new Class({
	Extends: Fenetre.Modale,
	
	/**
	 * FT 192829 : fermeture de la fenetre uniquement par le bouton (et pas le titre)
	 */
	getCloseElement: function() {
		return this.element.getElement('.fenetre-button');
	},
	
	close: function() {
	this.triggerElement=null;
	this.parent();
	this.element.fireEvent('close');
	}
	
	});
	
	Fenetre.initModale = function(elementId, options) {
	// return new Fenetre.Modale(elementId, options);
	return new Fenetre.ModaleAS(elementId, options);
};  
/**
 * FIN DU PATCH DDS CNAM_00173473
 */
 function changerStyleErreur(idChamp, idErreurChamp){	
	if(document.getElementById(idChamp).value != "") {
		/*on enleve le picto*/
		if(document.getElementById(idErreurChamp) != null) {
			document.getElementById(idErreurChamp).className="";
		}		
		/*on vide le message d'erreur du fichier*/
		if(document.getElementById(idErreurChamp+'_messageErreur') != null) {
			document.getElementById(idErreurChamp+'_messageErreur').innerHTML="";
		}
	}
}	

	
	/**
 */
	Fenetre.BulleAS = new Class({
	Extends: Fenetre.Bulle,
	
	close: function() {
	this.parent();
	this.element.fireEvent('close');
	},
	
	open: function(){
		$$("div.bulle").each(function(item){
			Fenetre.components[item.id].close();
		});
		this.parent();
	}
	
	});
	
	Fenetre.initBulle = function(elementId, options) {
	// return new Fenetre.Modale(elementId, options);
	return new Fenetre.BulleAS(elementId, options);
};  