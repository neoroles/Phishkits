// M�thode d'appel dynamique de l'action struts de mesure de satisfaction
function ajaxCallRemoteNotationAction(actionName, voteObj) {	 
	//alert('here '+actionName);
	var functionActionUrl = '/PortailAS/mesureSatisfaction.do?method=' + actionName + '&idNoCache=' + new Date().getTime();
	var emplacementQuestionnaire = document.getElementById('emplacementQuestionnaire').value;
	var typeQuestionnaire = document.getElementById('typeQuestionnaire').value;
	var notation = voteObj.current;
	
	//
	if (window.XMLHttpRequest)
	{	// Non-IE browsers
		req = new XMLHttpRequest();
		req.onreadystatechange = traiterRetourEB;
		req.open('GET', functionActionUrl, true);
		testEtAffecteAttributsRequete(req, notation, emplacementQuestionnaire, typeQuestionnaire);
		req.send(null);
	}
	else if (window.ActiveXObject)
	{	// IE
		req = new ActiveXObject('Microsoft.XMLHTTP');
		req.onreadystatechange = traiterRetourEB;
		req.open('GET', functionActionUrl, true);
		testEtAffecteAttributsRequete(req, notation, emplacementQuestionnaire, typeQuestionnaire);
		req.send();
	}
	else {
		return; // Navigateur non compatible
	}
};

function traiterRetourEB(){
	if (req.readyState == 4)
	{ 	// Complete
		if (req.status == 200)
		{ 	// OK response
			if(req.responseText.contains('initialiserNotation')) {
				initialiserQuestionnaireNotation(req.responseText);
			}
			else if(req.responseText.contains('envoyerNotation;')){
				document.getElementById('acc_reception').className="accuse";
				document.getElementById('portletInstance_2idVote').vote.setReadOnly(true);				
				return true;
			}
		}
	}
}

function initialiserQuestionnaireNotation(responseText){
	var charSeparator = ':-:';

	var dataList = responseText.split(';');
	
	dataList.each( function(item, index) {
	 	var fieldList = item.split(charSeparator);	 	
	 	var fieldBalise = fieldList[0]; 
	 	var fieldValue = fieldList[1];
	 	var fieldVote = fieldList[2];
	 	
	 	 switch(fieldBalise) {
	 	 	case 'initialiserNotation':
	 	 		if(fieldValue==="voteEffectue"){
					document.getElementById('portletInstance_2idVote').vote.setCurrent(fieldVote);
	 	 			document.getElementById('portletInstance_2idVote').vote.setReadOnly(true);
	 	 			document.getElementById('acc_reception').className="accuse";
	 	 		}
	 	 	break;
	 	 	case 'divQuestNotation_QuestOuv':
	 	 		document.getElementById(fieldBalise).innerHTML = fieldValue;	
	 	 	break;	
	 	 	 	 	
	 	 	default:
	 	 	break;
	 	 } 
	
	});
	
}