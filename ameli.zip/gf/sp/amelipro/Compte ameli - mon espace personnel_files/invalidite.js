//Au chargement du portlet, si le javascript est activ�, masquer tout les blocs d�tails
function masquerBlocDetailsInfosPerso(portletCtx, sejourEtranger,situatFamilChanger){
	/**masquer d�tails de s�jours*/
	if(sejourEtranger == "" || sejourEtranger == "false"){
		document.getElementById(portletCtx+'detailsSejour').style.display = "none";
	}else if(sejourEtranger == "true"){
		document.getElementById(portletCtx+'detailsSejour').style.display = "block";
	}
	/**masquer d�tails de situation familiale*/
	if(situatFamilChanger == "" || situatFamilChanger == "false"){
		document.getElementById(portletCtx+'detailsSituationFam').style.display = "none";
	}else if(situatFamilChanger == "true"){
		document.getElementById(portletCtx+'detailsSituationFam').style.display = "block";
	}

}

function masquerBlocDetailsRetraite(portletCtx){
	//on masque le bloc de d�tails de demande de retraite
	if(document.getElementById(portletCtx+'retraiteDemande')){
		var isRetraiteDemande = document.getElementById(portletCtx+'retraiteDemande').value;
		if(isRetraiteDemande == "" || isRetraiteDemande == "false"){
			document.getElementById(portletCtx+'idDetailRetraite').style.display = "none";
		}else if(isRetraiteDemande == "true"){
			document.getElementById(portletCtx+'idDetailRetraite').style.display = "block";
		}
	}else{
		document.getElementById(portletCtx+'idDetailRetraite').style.display = "none";
	}
}

//Fonction pour masquer les d�tails MTP
function masquerDetailsMTP(portletCtx){
	//on masque le bloc de d�tails de MTP 
	if(document.getElementById(portletCtx+'majorationTP')){
		var isMTP = document.getElementById(portletCtx+'majorationTP').value;
		if(isMTP == "" || isMTP == "false"){
			document.getElementById(portletCtx+'idDetailMTP').style.display = "none";
		}else if(isMTP == "true"){
			document.getElementById(portletCtx+'idDetailMTP').style.display = "block";
		}
	}else{
		document.getElementById(portletCtx+'idDetailMTP').style.display = "none";
	}
}


//fonction pour masquer les ASI
function masquerDetailsASI(portletCtx,nbASI){
//on masque les blocs de d�tails des Alloc. Supll�mentaires d'invalidite
	for(k=0; k < nbASI ; k++){
		if(document.getElementById(portletCtx+'cocheASI'+k)){
		var iScocheASI = document.getElementById(portletCtx+'cocheASI'+k).value;
			if(iScocheASI == "" || iScocheASI == "false"){
				document.getElementById(portletCtx+'idDetailsASI'+k).style.display = "none";
			}else if(iScocheASI == "true"){
				document.getElementById(portletCtx+'idDetailsASI'+k).style.display = "block";
			}
		}else{
			document.getElementById(portletCtx+'idDetailsASI'+k).style.display = "none";
		}
	}
}

//on masque les blocs de d�tails des Activit�s professionelles 
//(soit tous, soit juste qui ne l'ont pas �t�)
function masquerDetailsActivite(portletCtx,nbActivite,nbRevenu){
	for(i=0; i < nbActivite ; i++){
		if(document.getElementById(portletCtx+'cocheActPro'+i)){
		var cocheActPro = document.getElementById(portletCtx+'cocheActPro'+i).value;
		if(cocheActPro == "" || cocheActPro == "false"){
			document.getElementById(portletCtx+'idDetailsActivite'+i).style.display = "none";
			}
			else if(cocheActPro == "true"){ 
				var tailleRevenu = document.getElementById(portletCtx+'tailleListeRevenus'+i).value;
				var indexDernier = tailleRevenu-1;
				document.getElementById(portletCtx+'idDetailsActivite'+i).style.display = "block";
				//cacherChampMontant(portletCtx,i,tailleRevenu);
				//alert('tailleRevenu '+tailleRevenu);
				for(j=0; j < tailleRevenu ; j++){
					if(document.getElementById(portletCtx+'idRevenu'+i+'Periode'+j)){
						document.getElementById(portletCtx+'idRevenu'+i+'Periode'+j).style.display = "block";
					}
					desactiverBouton(portletCtx,'IdAjout'+i+'revenu','IdSuppression'+i+'revenu',j);
				}
				
				for(j=tailleRevenu; j < nbRevenu ; j++){
					if(document.getElementById(portletCtx+'idRevenu'+i+'Periode'+j)){
						document.getElementById(portletCtx+'idRevenu'+i+'Periode'+j).style.display = "none";
					}
					//desactiverBouton(portletCtx,'IdAjout'+i+'revenu','IdSuppression'+i+'revenu',j);
				}
				activerBouton(portletCtx,'IdAjout'+i+'revenu','IdSuppression'+i+'revenu',indexDernier);
			}
		}else{
		if(document.getElementById(portletCtx+'idDetailsActivite'+i)){
			document.getElementById(portletCtx+'idDetailsActivite'+i).style.display = "none";
			}
		}
	}
	
}

//on masque les blocs de d�tails des Prestation
//(soit tous, soit juste qui ne l'ont pas �t�)
function masquerDetailsPrestations(portletCtx,nbPrestation){
	for(j=0; j < nbPrestation ; j++){
	
		if(document.getElementById(portletCtx+'cochePrestation'+j)){
		var cochePrestation = document.getElementById(portletCtx+'cochePrestation'+j).value;
		/*alert('cochePrestation '+j+cochePrestation);*/
			if(cochePrestation == "" || cochePrestation == "false"){
				document.getElementById(portletCtx+'idDetailsPrestations'+j).style.display = "none";
			}
			else if(cochePrestation == "true"){
				document.getElementById(portletCtx+'idDetailsPrestations'+j).style.display = "block";
			}
		}else{
			document.getElementById(portletCtx+'idDetailsPrestations'+j).style.display = "none";
		}
	}
}

//fonction pour la gestion du bloc sejour � l'�tranger
function gererBlocSejour(portletCtx,champ){
	var lastChar = champ.id.substring(champ.id.length-1,champ.id.length);
	if (lastChar == '0') {
		document.getElementById(portletCtx+'detailsSejour').style.display = "block";
	}
	if (lastChar == '1') {
		document.getElementById(portletCtx+'detailsSejour').style.display = "none";
		document.getElementById(portletCtx+'dateDebutSejour').value = '';
		document.getElementById(portletCtx+'dateFinSejour').value = '';
		
		ChampSaisieTag.champOK(document.getElementById(portletCtx+'dateDebutSejour'));
		ChampSaisieTag.champOK(document.getElementById(portletCtx+'dateFinSejour'));
	}
}

//fonction d'ajout revenu
function ajoutRevenu(portletCtx,nbRevenu,objet,indexActivite){
	for(i=0; i<nbRevenu ; i++){
		var j=i+1;
		if(document.getElementById(portletCtx+'idRevenu'+indexActivite+'Periode'+i).style.display == "block" && document.getElementById(portletCtx+'idRevenu'+indexActivite+'Periode'+j).style.display == "none"){ 
			var indexAdeployer=j;
			var indexBtACacher = j-1;
			break;
		}
	}
	document.getElementById(portletCtx+'idRevenu'+indexActivite+'Periode'+indexAdeployer).style.display = "block";
	document.getElementById(portletCtx+'tailleListeRevenus'+indexActivite).value = indexAdeployer+1;
	desactiverBouton(portletCtx,'IdAjout'+indexActivite+'revenu','IdSuppression'+indexActivite+'revenu',indexBtACacher);
	activerBouton(portletCtx,'IdAjout'+indexActivite+'revenu','IdSuppression'+indexActivite+'revenu',indexAdeployer);
}

//fonction d'ajout revenu
function suppressionRevenu(portletCtx,index,indexActivite){
	var indexPrecedent = index-1;
	/*Vider les champs date d�but et date fin*/
	document.getElementById(portletCtx+'dateDebRevenu'+indexActivite+'mois'+index).value = '';
	document.getElementById(portletCtx+'dateFinRevenu'+indexActivite+'mois'+index).value = '';
	document.getElementById(portletCtx+'montantActPro'+indexActivite+'mois'+index).value = '';
	
	/*Cacher le bloc de saisie sur la ligne */
	document.getElementById(portletCtx+'idRevenu'+indexActivite+'Periode'+index).style.display = "none";
	
	/*Masquer les boutons d'ajout et de suppression de la ligne courante*/
	desactiverBouton(portletCtx,'IdAjout'+indexActivite+'revenu','IdSuppression'+indexActivite+'revenu',index);
	
	/*Mettre � jour la longueur de la liste*/
	document.getElementById(portletCtx+'tailleListeRevenus'+indexActivite).value = index;
	
	/*Faire apparaitre les boutons d'ajout et de suppression de la ligne pr�cedent*/
	activerBouton(portletCtx,'IdAjout'+indexActivite+'revenu','IdSuppression'+indexActivite+'revenu',indexPrecedent);
	
	//enlever les erreurs sur les lignes s'il y en a 
	if(document.getElementById(portletCtx+'idErreur'+indexActivite+'Ligne'+index)){
		document.getElementById(portletCtx+'idErreur'+indexActivite+'Ligne'+index).className= "";
	}
	//vider et cacher le msg d'erreur de la ligne
	if(document.getElementById(portletCtx+'idErreur'+indexActivite+'Ligne'+index+'_messageErreur')){
		document.getElementById(portletCtx+'idErreur'+indexActivite+'Ligne'+index+'_messageErreur').style.display = "none";
	}
	//vider les messages d'erreurs
	if(document.getElementById(portletCtx+'dateDebRevenu'+indexActivite+'mois'+index)){
		ChampSaisieTag.champOK(document.getElementById(portletCtx+'dateDebRevenu'+indexActivite+'mois'+index));
	}
	if(document.getElementById(portletCtx+'dateFinRevenu'+indexActivite+'mois'+index)){
		ChampSaisieTag.champOK(document.getElementById(portletCtx+'dateFinRevenu'+indexActivite+'mois'+index));
	}
	if(document.getElementById(portletCtx+'montantActPro'+indexActivite+'mois'+index)){
		ChampSaisieTag.champOK(document.getElementById(portletCtx+'montantActPro'+indexActivite+'mois'+index));
	}

	
}

//fonction pour la gestion des d�ploiement de bloc simple
function gererBlocSimple(portletCtx,champ,idDetails,index,tailleListe){

	var lastChar = champ.id.substring(champ.id.length-1,champ.id.length);
	if (lastChar == '0') {
		document.getElementById(portletCtx+idDetails).style.display = "block";
		
		//gestion des blocs revenu et d�tails
		if(idDetails.search('idDetailsActivite') != -1){
			var lastChar = champ.id.substring(champ.id.length-1,champ.id.length);
			if (lastChar == '0') {
					document.getElementById(portletCtx+'tailleListeRevenus'+index).value = 1;
	
				//document.getElementById(portletCtx+'detailsSejour').style.display = "block";
				//deployer la saisie du premier revenu
				if(document.getElementById(portletCtx+'IdAjout'+index+'revenu0')){
				document.getElementById(portletCtx+'IdAjout'+index+'revenu0').style.display = "block";
				}
				if(document.getElementById(portletCtx+'idRevenu'+index+'Periode0')){
				document.getElementById(portletCtx+'idRevenu'+index+'Periode0').style.display = "block";
				}
				
				//masquer le reste des revenus
				for(i=1; i<tailleListe ; i++){
					if(document.getElementById(portletCtx+'idRevenu'+index+'Periode'+i)){
					document.getElementById(portletCtx+'idRevenu'+index+'Periode'+i).style.display = "none";
					}
				}
				
			}	
		}
	}
	if (lastChar == '1') {
		document.getElementById(portletCtx+idDetails).style.display = "none";
		
		//vider en plus les champs qui ont �t� saisie
		if(idDetails == 'detailsSituationFam'){
			resetSituationFamiliale(portletCtx);
			ChampSaisieTag.champOK(document.getElementById(portletCtx+'dateChangementSituatFam'));
			/*on enleve le picto*/
			if(document.getElementById(portletCtx+'idErreurNlleSituation') != null) {
				document.getElementById(portletCtx+'idErreurNlleSituation').className="";
			}		
			/*on vide le message d'erreur du fichier*/
			if(document.getElementById(portletCtx+'idErreurNlleSituation'+'_messageErreur') != null) {
				document.getElementById(portletCtx+'idErreurNlleSituation'+'_messageErreur').innerHTML="";
			}
		}
		
		//gestion des champs pour les activites professionnelles
		if(idDetails.search('idDetailsActivite') != -1){
			//vider les champs qui ont pu �tre saisies
			resetActiviteProfessionnelle(portletCtx,index);
		}
		
		//gestion des champs pour les prestations
		if(idDetails.search('idDetailsPrestations') != -1){
			resetPrestation(portletCtx,index);
		}
		
		//gestion des champs du bloc demande retraite
		if(idDetails == 'idDetailRetraite'){
			document.getElementById(portletCtx+'dateDemandeRetraite').value = '';
			ChampSaisieTag.champOK(document.getElementById(portletCtx+'dateDemandeRetraite'));
		}
		
		//gestion des champs du bloc MTP
		if(idDetails == 'idDetailMTP'){
			//Mettre la valeur de hospitalis� � ''
			if(document.getElementById(portletCtx+'hospitalise')){
				document.getElementById(portletCtx+'hospitalise').value = '';
			}
			//document.getElementById(portletCtx+'radio120').checked="";
			//document.getElementById(portletCtx+'radio121').checked="";
			
			//D�sactiver les deux boutons (oui et non) pour hospitalis�
			//document.getElementById(portletCtx+'imgradio120').src = document.getElementById(portletCtx+'imgradio120').src.replace('radio_on', 'radio_off');
			//document.getElementById(portletCtx+'imgradio121').src = document.getElementById(portletCtx+'imgradio121').src.replace('radio_on', 'radio_off');
			resetInfosMTP(portletCtx);
		}
		
		//gestion des champs du bloc ASI
		if(idDetails.search('idDetailsASI') != -1){
			resetInfosASI(portletCtx,index);
		}
	}
}

//fonction de reset Prestation
function resetPrestation(portletCtx,index){
	if(document.getElementById(portletCtx+'naturePrestation'+index)){
		document.getElementById(portletCtx+'naturePrestation'+index).value = '';
	}
	document.getElementById(portletCtx+'montantPrestation'+index).value = '';
	ChampSaisieTag.champOK(document.getElementById(portletCtx+'montantPrestation'+index));
}

//fonction de reset des ASI
function resetInfosASI(portletCtx,index){
	document.getElementById(portletCtx+'montantAssure'+index).value = '';
	document.getElementById(portletCtx+'montantBenef'+index).value = '';
	ChampSaisieTag.champOK(document.getElementById(portletCtx+'montantAssure'+index));
	ChampSaisieTag.champOK(document.getElementById(portletCtx+'montantBenef'+index));
	
}

//fonction de reset des infos MTP
function resetInfosMTP(portletCtx){
	document.getElementById(portletCtx+'dateDebutHosp').value = '';
	document.getElementById(portletCtx+'dateFinHosp').value = '';
	ChampSaisieTag.champOK(document.getElementById(portletCtx+'dateDebutHosp'));
	ChampSaisieTag.champOK(document.getElementById(portletCtx+'dateFinHosp'));
	document.getElementById(portletCtx+'nomHopital').value = '';
}

//fonction de reset des situations Familiales
function resetSituationFamiliale(portletCtx){
	document.getElementById(portletCtx+'dateChangementSituatFam').value = '';
	ChampSaisieTag.champOK(document.getElementById(portletCtx+'dateChangementSituatFam'));
	document.getElementById(portletCtx+'nouvelleSituatFam').value = '';
}

//fonction de reset des activites professionnelles
function resetActiviteProfessionnelle(portletCtx,index){
	var tailleRevenu = document.getElementById(portletCtx+'tailleListeRevenus'+index).value;
	if(document.getElementById(portletCtx+'natureAct'+index)){
		document.getElementById(portletCtx+'natureAct'+index).value = '';
	}
	
	if(document.getElementById(portletCtx+'organismePayeur'+index)){
		document.getElementById(portletCtx+'organismePayeur'+index).value = '';
	}
	document.getElementById(portletCtx+'dateRepriseActPro'+index).value = '';
	document.getElementById(portletCtx+'dateCessationActPro'+index).value = '';
	
		
	for(j=0; j<=tailleRevenu ; j++){
		document.getElementById(portletCtx+'dateDebRevenu'+index+'mois'+j).value = '';
		document.getElementById(portletCtx+'dateFinRevenu'+index+'mois'+j).value = '';
		document.getElementById(portletCtx+'montantActPro'+index+'mois'+j).value = '';
		
		//enlever les erreurs sur les lignes s'il y en a 
		if(document.getElementById(portletCtx+'idErreur'+index+'Ligne'+j)){
			document.getElementById(portletCtx+'idErreur'+index+'Ligne'+j).className= "";
		}
		//vider et cacher le msg d'erreur de la ligne
		if(document.getElementById(portletCtx+'idErreur'+index+'Ligne'+j+'_messageErreur')){
			document.getElementById(portletCtx+'idErreur'+index+'Ligne'+j+'_messageErreur').style.display = "none";
		}
		
		//vider les messages d'erreurs
		if(document.getElementById(portletCtx+'dateDebRevenu'+index+'mois'+j)){
			ChampSaisieTag.champOK(document.getElementById(portletCtx+'dateDebRevenu'+index+'mois'+j));
		}
		if(document.getElementById(portletCtx+'dateFinRevenu'+index+'mois'+index)){
			ChampSaisieTag.champOK(document.getElementById(portletCtx+'dateFinRevenu'+index+'mois'+j));
		}
		if(document.getElementById(portletCtx+'montantActPro'+index+'mois'+index)){
			ChampSaisieTag.champOK(document.getElementById(portletCtx+'montantActPro'+index+'mois'+j));
		}
		
		document.getElementById(portletCtx+'idRevenu'+index+'Periode'+j).style.display = "block";
		ChampSaisieTag.champOK(document.getElementById(portletCtx+'montantActPro'+index+'mois'+j));
	}
	document.getElementById(portletCtx+'tailleListeRevenus'+index).value ='0';
}

//function ajouter une autre activit� professionelle
function ajoutActivite(portletCtx,nbActivite){
	for(i=3; i<nbActivite ; i++){
		var j=i+1;
		if(document.getElementById(portletCtx+'idDetailsActivite'+i).style.display == "block" && document.getElementById(portletCtx+'idDetailsActivite'+j).style.display == "none"){ 
			var indexAdeployer=j
			var indexBtACacher = j-1;
			break;
		}
	}
	document.getElementById(portletCtx+'idDetailsActivite'+indexAdeployer).style.display = "block";
	document.getElementById(portletCtx+'nombreActiviteProfessionelle').value = indexAdeployer+1;
	document.getElementById(portletCtx+'cocheActPro'+indexAdeployer).value = "true";
	
	/*Montrer les boutons du suivant*/
	activerBouton(portletCtx,'IdAjoutAP','IdSuppressionAP',indexAdeployer);
	
	/*Cacher les boutons du pr�cedent*/
	desactiverBouton(portletCtx,'IdAjoutAP','IdSuppressionAP',indexBtACacher);
}

//fonction d'activation de bouton
function activerBouton(portletCtx,idBoutonAjout,idBoutonSuppr,index){
	if(document.getElementById(portletCtx+idBoutonAjout+index)){
		document.getElementById(portletCtx+idBoutonAjout+index).style.display = "block";
	}
	if(document.getElementById(portletCtx+idBoutonSuppr+index)){
	document.getElementById(portletCtx+idBoutonSuppr+index).style.display = "block";
	}
}

//fonction de d�sactivation de bouton
function desactiverBouton(portletCtx,idBoutonAjout,idBoutonSuppr,index){
	if(document.getElementById(portletCtx+idBoutonAjout+index)){
		document.getElementById(portletCtx+idBoutonAjout+index).style.display = "none";
	}
	if(document.getElementById(portletCtx+idBoutonSuppr+index)){
	document.getElementById(portletCtx+idBoutonSuppr+index).style.display = "none";
	}
}

//fonction permettant de supprimer les erreurs sur une ligne de revenu
function resetErreurRevenu(portletCtx,indexActivite,indexPeriode){
	/*on vide le message d'erreur du fichier*/
	if(document.getElementById(portletCtx+'idErreur'+indexActivite+'Ligne'+indexPeriode+'_messageErreur') != null) {
		document.getElementById(portletCtx+'idErreur'+indexActivite+'Ligne'+indexPeriode+'_messageErreur').innerHTML="";
	}
	
}
function plierRecapitulatif(portletCtx){
	if(document.getElementById(portletCtx+'fenetreResumeDeclaration')){
		document.getElementById(portletCtx+'fenetreResumeDeclaration').style.display = "none";
	}
}