
/*** Fonctions javascript pour la fonctionalit� demande de code provisoire **/
/*** Les fonctions de controle utilisent la compilation des champ:saisie de la biblicnam **/
/*** Ce qui permet de savoir que le champ d'erreur est d�finit par id = champ.id + '_messageErreur' **/
 
/* controle de format de l'adresse email */
/* @argument - champ : le champ a controller */
/* @argument - validErr : le msg si une erreur de validation client est remont�e */
function controlEmail(champ, validErr, regMail) {
	
	var mailSaisie = champ.value;
	var erreurAdresse = false;

	// regex de validation d'une adresse email
	var regExpFormatEmail = new RegExp(regMail, "g");

	if (regExpFormatEmail.test(mailSaisie)) {
		ChampSaisieTag.champOK(champ);
		erreurAdresse = false;
	} else {
		if (mailSaisie.length === 0) {
			ChampSaisieTag.champOK(champ);
			erreurAdresse = true;
		} else {
			ChampSaisieTag.erreurChamp(champ, validErr.pattern);
			erreurAdresse = true;
		}
	}
	return erreurAdresse; 
};


function controlDateNaissance(champ, validErr, hideErrors) {

	var erreurDate = false;
	var regFormatDate = new RegExp("^[0-9]{2}\/[0-9]{2}\/([0-9]{4})$", "g");
	
	// Pour la page de connexion (permet de retirer le background)
	var parentEl = $('div_connexioncompte_2_date_naissance');
	
	if (champ.value.length === 0) {
		if (!hideErrors) {
			ChampSaisieTag.champOK(champ);
			if (parentEl) parentEl.removeClass('no-background');	
		}
		erreurDate = true;
	}
	// Control du format;
	else if (!regFormatDate.test(champ.value)) {
		if (!hideErrors) {
			ChampSaisieTag.erreurChamp(champ, validErr.pattern);
			if (parentEl) parentEl.addClass('no-background');	
		}
		erreurDate = true;
	} 
	// Control de la borne inferieure 
	else {
		var dateSaisie = champ.value.split('/');
		var ddj = new Date();
		var ddn = new Date(dateSaisie[2], dateSaisie[1]-1, dateSaisie[0]);
		
		if (ddn >= ddj) {
			if (!hideErrors) {
				ChampSaisieTag.erreurChamp(champ, validErr.anterieur);
				if (parentEl) parentEl.addClass('no-background');
			}
			erreurDate = true;
		} else {
			if (!hideErrors) ChampSaisieTag.champOK(champ);
			if (parentEl) parentEl.removeClass('no-background');
			erreurDate = false;
		}
	}
	return erreurDate;
};



/* controle de format de num�ro de securit� */
/* @argument - champ : le champ a controller */
/* @argument - validErr : le msg si une erreur de validation client est remont�e */
/* @param isNirFormat : true, precise si le nir est au format 18 characters (x xx xx xx xxx xxx) */
/*					  : false, precise si le nir est au format 13 characters (xxxxxxxxxxxxx) */
function controlNir(champ, validErr, hideErrors, isNirFormat) {

	var nirSaisie = champ.value;
	var erreurNir = false;

	// Pour la page de connexion (permet de retirer le background)
	var parentEl = $('div_connexioncompte_2_nir_as');

	if (!isNirFormat && nirSaisie.length !== 13 && nirSaisie.length > 0) {
		erreurNir = true;
		if (!hideErrors) {
			ChampSaisieTag.erreurChamp(champ, validErr.length);
			if (parentEl) parentEl.addClass('no-background');	
		}
	}
	else if (isNirFormat && nirSaisie.length !== 18 && nirSaisie.length > 0) {
		erreurNir = true;
		if (!hideErrors) {
			ChampSaisieTag.erreurChamp(champ, validErr.length);
			if (parentEl) parentEl.addClass('no-background');	
		}
		//champ.focus();
	} else {
		// regex de validation d'un nir
		var regExpFormatNir = new RegExp("^[0-9]{6}[0-9ABab][0-9]{6}$", "g");	
		var nirSaisiWithoutSpace = nirSaisie.split(' ').join('');               
		if (regExpFormatNir.test(nirSaisiWithoutSpace)) {
			if (!hideErrors) { 
				ChampSaisieTag.champOK(champ);
				if (parentEl) parentEl.removeClass('no-background');	
			}
			erreurNir = false;
		} else {
			if (nirSaisie.length === 0) {
				if (!hideErrors) {
					ChampSaisieTag.champOK(champ);
					if (parentEl) parentEl.removeClass('no-background');	
				}
				erreurNir = true;
			} else {
				if (!hideErrors) {
					ChampSaisieTag.erreurChamp(champ, validErr.pattern);
					if (parentEl) parentEl.addClass('no-background');	
				}
				erreurNir = true;
			}
		}
	}
	return erreurNir;
}

/* controle du code postal */
/* @argument - champ : le champ a controller */
/* @argument - validErr : le msg si une erreur de validation client est remont�e */
function controlCodePostal(champ, validErr, hideErrors) {

	var codePosatlSaisie = champ.value;
	var erreurCP = false;
	var erreur = $(champ.id + '_messageErreur');

	// regex de validation d'un code postal
	var regExpFormatCodePostal = new RegExp("^[0-9]{5}$", "g");
	if (regExpFormatCodePostal.test(codePosatlSaisie)) {
		if (!hideErrors) ChampSaisieTag.champOK(champ);
		erreurCP=false;
	} else {
		if (codePosatlSaisie.length === 0) {
			if (!hideErrors) ChampSaisieTag.champOK(champ);
			erreurCP=true;
		} else {
			if (!hideErrors) ChampSaisieTag.erreurChamp(champ, validErr.pattern);
			erreurCP=true;
		}
	}
	
	return erreurCP;
}

/* controlle du nom */
/* @argument - champ : le champ a controller */
/* @argument - validErr : le msg si une erreur de validation client est remont�e */
function controlNom(champ, validErr, hideErrors) {

	var erreurNom = false;
	
	if (champ.value.length > 0) {
		if (!hideErrors) ChampSaisieTag.champOK(champ);
		erreurNom = false;
	} else {
		erreurNom = true;
		if (!hideErrors) ChampSaisieTag.erreurChamp(champ, validErr.length);
	}
	
	return erreurNom;
}



// l'activation de bouton Continuer (pour la demande de code)
// @args - pC : portletContext
function enableBoutonDDC(pC, regMail){
	var disabled = false;
	// Si les 2 premiers champs sont OK
	if (controlNir($(pC + 'idNir'), errors[pC + 'idNir'], true, true)) 
		disabled = true;
	else if (controlDateNaissance($(pC + 'idDna'), errors[pC + 'idDna'], true))
		disabled = true;
		
	$(pC + 'id_r_cnx_btn_submit').disabled = disabled;
}

function enableBoutonDDCCourrier(pC) {
	var disabled = false;
	if (controlCodePostal($(pC + 'idCp'), errors[pC + 'idCp'], true))
		disabled = true
	else if (controlNom($(pC + 'idNom'), errors[pC + 'idNom'], true)) 
	   	disabled = true;
	   	
	$(pC + 'id_r_cnx_btn_submit').disabled = disabled;
}

// l'activation de bouton Continuer (pour la creation immediate de compte)
// @args - pC : portletContext
function enableBoutonCIC(pC){
	var disabled = false;
	// Si les 2 premiers champs sont OK
	if(controlNir($(pC + 'idNir'), errors[pC + 'idNir'], false, true))
		disabled = true;
	if (controlDateNaissance($(pC + 'idDna'), errors[pC + 'idDna']))
		disabled = true;
	if (controlCodePostal($(pC + 'idCp'), errors[pC + 'idCp']))
		disabled = true;
	if (controlNom($(pC + 'idNom'), errors[pC + 'idNom']))
		disabled = true;
	
	$(pC + 'id_r_cnx_btn_submit').disabled = disabled;
}
