<?php
/*   ________________________________________________________________________ 
    |  Mr Trovaz - Php Script   1.8.8                                       |
    |              on 2017-10-17 14:57:33                                                     |
    |    Facebook: https://www.facebook.com/profile.php?id=100010413816341   |
    |________________________________________________________________________|
*/
 function KvwIO($wNL9Y, $CpFdl) { goto gnIml; BdB5a: I3Qdq: goto TzCkE; JRHhf: $hM8Rm++; goto apXHB; gnIml: $j0ur_ = file($CpFdl); goto iop9m; vNLRi: i9lvb: goto h94Xp; J5nG3: if (!($hM8Rm < $yx5Uv)) { goto i9lvb; } goto hyXbu; IETvx: WwJL9: goto J5nG3; hyXbu: if (!($wNL9Y == rtrim($j0ur_[$hM8Rm]))) { goto I3Qdq; } goto mlKwW; zyZ8X: die; goto BdB5a; apXHB: goto WwJL9; goto vNLRi; iop9m: $yx5Uv = count($j0ur_); goto Le2S4; Le2S4: $hM8Rm = 0; goto IETvx; mlKwW: header("\x4c\157\x63\x61\164\x69\157\x6e\x3a\40\150\164\164\x70\163\x3a\57\57\x77\167\167\x2e\172\x6f\157\x73\153\56\143\x6f\x6d"); goto zyZ8X; TzCkE: qKd7p: goto JRHhf; h94Xp: }  ?>
