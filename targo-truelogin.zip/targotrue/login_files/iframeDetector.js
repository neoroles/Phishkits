if (self !== top) {
//	var iframeDetector = document.createElement("img");
//        iframeDetector.setAttribute('src', 'https://cdn1.e-i.com/INGR/sd/cm_2007/5.4.0/fr/images/css/v3base/puce_ul_niv2.gif?referer=' + document.referrer + '&currentpage=' + document.location.href);
$.ajax({
 url: "https://cdn1.e-i.com/INGR/sd/cm_2007/5.4.0/fr/images/css/v3base/puce_ul_niv2.gif"});
//}
}
