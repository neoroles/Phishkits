<?php
error_reporting(0);
require 'core.php';
header("X-Robots-Tag: noindex, nofollow");
$code = $_GET['p'];
if(!file_exists("db/url/$code.ini")) {
    header("location: error.html");
    exit();
}
$setting = parse_ini_file("db/url/$code.ini");
$url = $setting['url'];
$alternative = $setting['alternative'];

if(check_down($url) == "online") {
    tulis_file("logs/$code-real.txt","$ip|$hostname|$isp|$br|$os|$country|$ccode");
    tulis_file("logs/$code-visitor.txt","$ip|$hostname|$isp|$br|$os|$country|$ccode|Real");
    header("location: $url");
}else{
    tulis_file("logs/$code-real.txt","$ip|$hostname|$isp|$br|$os|$country|$ccode");
    tulis_file("logs/$code-visitor.txt","$ip|$hostname|$isp|$br|$os|$country|$ccode|Real");
    header("location: $alternative");
}
