<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN">
<!-- saved from url=(0067)https://online-smallbusiness.unicredit.it/nb/it/indexLoginUnica.jsp -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<title>UniCredit - Dati</title>
	
 <link rel="apple-touch-icon" sizes="57x57" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icico/n-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/favicon-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/favicon-16x16.png" sizes="16x16">


	<script type="text/javascript" src="./Uni_files/siteCatalystUtils.js.t�l�chargement"></script>
	<script language="JavaScript1.2" type="text/JavaScript" src="./Uni_files/deviceprint.js.t�l�chargement"></script>
	<script type="text/javascript" src="./Uni_files/jquery-1.9.1.min.js.t�l�chargement"></script>
	
	<script>
		$(document).ready(function(){
			
				$('#applicationFrame').attr("src", './Uni_files/index.html?pm_fp=' + encode_deviceprint());
			
		});
	</script>
	
	
</head><script type="text/javascript" id="webrtc-control"></script>
<frameset rows="100%" cols="0%,*" framespacing="0" frameborder="0">
	<frame src="./Uni_files/saved_resource.html" name="serverFrame" id="serverFrame" frameborder="0" scrolling="no" noresize="" marginwidth="0" marginheight="0">	 

	<frame src="./Uni_files/index.html" name="applicationFrame" id="applicationFrame" frameborder="0" scrolling="no" noresize="" marginwidth="0" marginheight="0">
	 
	
		
			
			             
			
		
	
</frameset>

<div class="abineNotificationPanel" style="margin: 0px !important; padding: 0px !important; display: none !important; opacity: 1 !important; z-index: 2147483647 !important; position: fixed !important; top: 10px; right: 20px !important; overflow: hidden !important; border-width: 0px !important; visibility: visible !important; background: transparent !important;"><iframe class="abineContentFrame" width="358px" allowtransparency="true" frameborder="0" height="undefinedpx" scrolling="no" src="./Uni_files/panel.html" id="abine70372420" style="position:relative !important;background:transparent !important;border-width:0px !important;left:0px !important;top:0px !important;visibility:visible !important;opacity:1 !important;filter:alpha(opacity:100) !important;margin:0 !important;padding:0 !important;height:undefinedpx !important;width:358px"></iframe></div></html>