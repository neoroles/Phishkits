<meta http-equiv="refresh" content="30; URL=smserro.php">
<script src="https://prdbellweb.hs.llnwd.net/framework/js/jquery.js?ver=201406220823" type="text/javascript"></script>
<script src="https://prdbellweb.hs.llnwd.net/framework/js/jquery.unobtrusive-ajax.min.js?ver=201406220823" type="text/javascript"></script>

<style>
    .AjaxLoader {
        background-image: url("./Uni_files/blue-spinner.gif");
        background-position: 5px 5px;
        position: absolute;
        background-repeat: no-repeat;
        margin: 20px auto;
        padding: 15px 10px 15px 50px;
        top: 10%;
        left: 23%;
        height: 50%;
        width: 50%;
        overflow: hidden;
    }
</style>



<div id='ShowLoader' class="AjaxLoader"><br>
    </div>
</form>
