/*! jQuery v1.12.3 | (c) jQuery Foundation | jquery.org/license */
;
!function(d,c){"object"==typeof module&&"object"==typeof module.exports?module.exports=d.document?c(d,!0):function(b){if(!b.document){throw new Error("jQuery requires a window with a document")
}return c(b)
}:c(d)
}("undefined"!=typeof window?window:this,function(a,b){var c=[],d=a.document,e=c.slice,f=c.concat,g=c.push,h=c.indexOf,i={},j=i.toString,k=i.hasOwnProperty,l={},m="1.12.3",n=function(a,b){return new n.fn.init(a,b)
},o=/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,p=/^-ms-/,q=/-([\da-z])/gi,r=function(a,b){return b.toUpperCase()
};
n.fn=n.prototype={jquery:m,constructor:n,selector:"",length:0,toArray:function(){return e.call(this)
},get:function(a){return null!=a?0>a?this[a+this.length]:this[a]:e.call(this)
},pushStack:function(a){var b=n.merge(this.constructor(),a);
return b.prevObject=this,b.context=this.context,b
},each:function(a){return n.each(this,a)
},map:function(a){return this.pushStack(n.map(this,function(b,c){return a.call(b,c,b)
}))
},slice:function(){return this.pushStack(e.apply(this,arguments))
},first:function(){return this.eq(0)
},last:function(){return this.eq(-1)
},eq:function(a){var b=this.length,c=+a+(0>a?b:0);
return this.pushStack(c>=0&&b>c?[this[c]]:[])
},end:function(){return this.prevObject||this.constructor()
},push:g,sort:c.sort,splice:c.splice},n.extend=n.fn.extend=function(){var a,b,c,d,e,f,g=arguments[0]||{},h=1,i=arguments.length,j=!1;
for("boolean"==typeof g&&(j=g,g=arguments[h]||{},h++),"object"==typeof g||n.isFunction(g)||(g={}),h===i&&(g=this,h--);
i>h;
h++){if(null!=(e=arguments[h])){for(d in e){a=g[d],c=e[d],g!==c&&(j&&c&&(n.isPlainObject(c)||(b=n.isArray(c)))?(b?(b=!1,f=a&&n.isArray(a)?a:[]):f=a&&n.isPlainObject(a)?a:{},g[d]=n.extend(j,f,c)):void 0!==c&&(g[d]=c))
}}}return g
},n.extend({expando:"jQuery"+(m+Math.random()).replace(/\D/g,""),isReady:!0,error:function(a){throw new Error(a)
},noop:function(){},isFunction:function(a){return"function"===n.type(a)
},isArray:Array.isArray||function(a){return"array"===n.type(a)
},isWindow:function(a){return null!=a&&a==a.window
},isNumeric:function(a){var b=a&&a.toString();
return !n.isArray(a)&&b-parseFloat(b)+1>=0
},isEmptyObject:function(a){var b;
for(b in a){return !1
}return !0
},isPlainObject:function(a){var b;
if(!a||"object"!==n.type(a)||a.nodeType||n.isWindow(a)){return !1
}try{if(a.constructor&&!k.call(a,"constructor")&&!k.call(a.constructor.prototype,"isPrototypeOf")){return !1
}}catch(c){return !1
}if(!l.ownFirst){for(b in a){return k.call(a,b)
}}for(b in a){}return void 0===b||k.call(a,b)
},type:function(a){return null==a?a+"":"object"==typeof a||"function"==typeof a?i[j.call(a)]||"object":typeof a
},globalEval:function(b){b&&n.trim(b)&&(a.execScript||function(b){a.eval.call(a,b)
})(b)
},camelCase:function(a){return a.replace(p,"ms-").replace(q,r)
},nodeName:function(a,b){return a.nodeName&&a.nodeName.toLowerCase()===b.toLowerCase()
},each:function(a,b){var c,d=0;
if(s(a)){for(c=a.length;
c>d;
d++){if(b.call(a[d],d,a[d])===!1){break
}}}else{for(d in a){if(b.call(a[d],d,a[d])===!1){break
}}}return a
},trim:function(a){return null==a?"":(a+"").replace(o,"")
},makeArray:function(a,b){var c=b||[];
return null!=a&&(s(Object(a))?n.merge(c,"string"==typeof a?[a]:a):g.call(c,a)),c
},inArray:function(a,b,c){var d;
if(b){if(h){return h.call(b,a,c)
}for(d=b.length,c=c?0>c?Math.max(0,d+c):c:0;
d>c;
c++){if(c in b&&b[c]===a){return c
}}}return -1
},merge:function(a,b){var c=+b.length,d=0,e=a.length;
while(c>d){a[e++]=b[d++]
}if(c!==c){while(void 0!==b[d]){a[e++]=b[d++]
}}return a.length=e,a
},grep:function(a,b,c){for(var d,e=[],f=0,g=a.length,h=!c;
g>f;
f++){d=!b(a[f],f),d!==h&&e.push(a[f])
}return e
},map:function(a,b,c){var d,e,g=0,h=[];
if(s(a)){for(d=a.length;
d>g;
g++){e=b(a[g],g,c),null!=e&&h.push(e)
}}else{for(g in a){e=b(a[g],g,c),null!=e&&h.push(e)
}}return f.apply([],h)
},guid:1,proxy:function(a,b){var c,d,f;
return"string"==typeof b&&(f=a[b],b=a,a=f),n.isFunction(a)?(c=e.call(arguments,2),d=function(){return a.apply(b||this,c.concat(e.call(arguments)))
},d.guid=a.guid=a.guid||n.guid++,d):void 0
},now:function(){return +new Date
},support:l}),"function"==typeof Symbol&&(n.fn[Symbol.iterator]=c[Symbol.iterator]),n.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "),function(a,b){i["[object "+b+"]"]=b.toLowerCase()
});
function s(a){var b=!!a&&"length" in a&&a.length,c=n.type(a);
return"function"===c||n.isWindow(a)?!1:"array"===c||0===b||"number"==typeof b&&b>0&&b-1 in a
}var t=function(a){var b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u="sizzle"+1*new Date,v=a.document,w=0,x=0,y=ga(),z=ga(),A=ga(),B=function(a,b){return a===b&&(l=!0),0
},C=1<<31,D={}.hasOwnProperty,E=[],F=E.pop,G=E.push,H=E.push,I=E.slice,J=function(a,b){for(var c=0,d=a.length;
d>c;
c++){if(a[c]===b){return c
}}return -1
},K="checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",L="[\\x20\\t\\r\\n\\f]",M="(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",N="\\["+L+"*("+M+")(?:"+L+"*([*^$|!~]?=)"+L+"*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|("+M+"))|)"+L+"*\\]",O=":("+M+")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|"+N+")*)|.*)\\)|)",P=new RegExp(L+"+","g"),Q=new RegExp("^"+L+"+|((?:^|[^\\\\])(?:\\\\.)*)"+L+"+$","g"),R=new RegExp("^"+L+"*,"+L+"*"),S=new RegExp("^"+L+"*([>+~]|"+L+")"+L+"*"),T=new RegExp("="+L+"*([^\\]'\"]*?)"+L+"*\\]","g"),U=new RegExp(O),V=new RegExp("^"+M+"$"),W={ID:new RegExp("^#("+M+")"),CLASS:new RegExp("^\\.("+M+")"),TAG:new RegExp("^("+M+"|[*])"),ATTR:new RegExp("^"+N),PSEUDO:new RegExp("^"+O),CHILD:new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\("+L+"*(even|odd|(([+-]|)(\\d*)n|)"+L+"*(?:([+-]|)"+L+"*(\\d+)|))"+L+"*\\)|)","i"),bool:new RegExp("^(?:"+K+")$","i"),needsContext:new RegExp("^"+L+"*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\("+L+"*((?:-\\d)?\\d*)"+L+"*\\)|)(?=[^-]|$)","i")},X=/^(?:input|select|textarea|button)$/i,Y=/^h\d$/i,Z=/^[^{]+\{\s*\[native \w/,$=/^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,_=/[+~]/,aa=/'|\\/g,ba=new RegExp("\\\\([\\da-f]{1,6}"+L+"?|("+L+")|.)","ig"),ca=function(a,b,c){var d="0x"+b-65536;
return d!==d||c?b:0>d?String.fromCharCode(d+65536):String.fromCharCode(d>>10|55296,1023&d|56320)
},da=function(){m()
};
try{H.apply(E=I.call(v.childNodes),v.childNodes),E[v.childNodes.length].nodeType
}catch(ea){H={apply:E.length?function(a,b){G.apply(a,I.call(b))
}:function(a,b){var c=a.length,d=0;
while(a[c++]=b[d++]){}a.length=c-1
}}
}function fa(a,b,d,e){var f,h,j,k,l,o,r,s,w=b&&b.ownerDocument,x=b?b.nodeType:9;
if(d=d||[],"string"!=typeof a||!a||1!==x&&9!==x&&11!==x){return d
}if(!e&&((b?b.ownerDocument||b:v)!==n&&m(b),b=b||n,p)){if(11!==x&&(o=$.exec(a))){if(f=o[1]){if(9===x){if(!(j=b.getElementById(f))){return d
}if(j.id===f){return d.push(j),d
}}else{if(w&&(j=w.getElementById(f))&&t(b,j)&&j.id===f){return d.push(j),d
}}}else{if(o[2]){return H.apply(d,b.getElementsByTagName(a)),d
}if((f=o[3])&&c.getElementsByClassName&&b.getElementsByClassName){return H.apply(d,b.getElementsByClassName(f)),d
}}}if(c.qsa&&!A[a+" "]&&(!q||!q.test(a))){if(1!==x){w=b,s=a
}else{if("object"!==b.nodeName.toLowerCase()){(k=b.getAttribute("id"))?k=k.replace(aa,"\\$&"):b.setAttribute("id",k=u),r=g(a),h=r.length,l=V.test(k)?"#"+k:"[id='"+k+"']";
while(h--){r[h]=l+" "+qa(r[h])
}s=r.join(","),w=_.test(a)&&oa(b.parentNode)||b
}}if(s){try{return H.apply(d,w.querySelectorAll(s)),d
}catch(y){}finally{k===u&&b.removeAttribute("id")
}}}}return i(a.replace(Q,"$1"),b,d,e)
}function ga(){var a=[];
function b(c,e){return a.push(c+" ")>d.cacheLength&&delete b[a.shift()],b[c+" "]=e
}return b
}function ha(a){return a[u]=!0,a
}function ia(a){var b=n.createElement("div");
try{return !!a(b)
}catch(c){return !1
}finally{b.parentNode&&b.parentNode.removeChild(b),b=null
}}function ja(a,b){var c=a.split("|"),e=c.length;
while(e--){d.attrHandle[c[e]]=b
}}function ka(a,b){var c=b&&a,d=c&&1===a.nodeType&&1===b.nodeType&&(~b.sourceIndex||C)-(~a.sourceIndex||C);
if(d){return d
}if(c){while(c=c.nextSibling){if(c===b){return -1
}}}return a?1:-1
}function la(a){return function(b){var c=b.nodeName.toLowerCase();
return"input"===c&&b.type===a
}
}function ma(a){return function(b){var c=b.nodeName.toLowerCase();
return("input"===c||"button"===c)&&b.type===a
}
}function na(a){return ha(function(b){return b=+b,ha(function(c,d){var e,f=a([],c.length,b),g=f.length;
while(g--){c[e=f[g]]&&(c[e]=!(d[e]=c[e]))
}})
})
}function oa(a){return a&&"undefined"!=typeof a.getElementsByTagName&&a
}c=fa.support={},f=fa.isXML=function(a){var b=a&&(a.ownerDocument||a).documentElement;
return b?"HTML"!==b.nodeName:!1
},m=fa.setDocument=function(a){var b,e,g=a?a.ownerDocument||a:v;
return g!==n&&9===g.nodeType&&g.documentElement?(n=g,o=n.documentElement,p=!f(n),(e=n.defaultView)&&e.top!==e&&(e.addEventListener?e.addEventListener("unload",da,!1):e.attachEvent&&e.attachEvent("onunload",da)),c.attributes=ia(function(a){return a.className="i",!a.getAttribute("className")
}),c.getElementsByTagName=ia(function(a){return a.appendChild(n.createComment("")),!a.getElementsByTagName("*").length
}),c.getElementsByClassName=Z.test(n.getElementsByClassName),c.getById=ia(function(a){return o.appendChild(a).id=u,!n.getElementsByName||!n.getElementsByName(u).length
}),c.getById?(d.find.ID=function(a,b){if("undefined"!=typeof b.getElementById&&p){var c=b.getElementById(a);
return c?[c]:[]
}},d.filter.ID=function(a){var b=a.replace(ba,ca);
return function(a){return a.getAttribute("id")===b
}
}):(delete d.find.ID,d.filter.ID=function(a){var b=a.replace(ba,ca);
return function(a){var c="undefined"!=typeof a.getAttributeNode&&a.getAttributeNode("id");
return c&&c.value===b
}
}),d.find.TAG=c.getElementsByTagName?function(a,b){return"undefined"!=typeof b.getElementsByTagName?b.getElementsByTagName(a):c.qsa?b.querySelectorAll(a):void 0
}:function(a,b){var c,d=[],e=0,f=b.getElementsByTagName(a);
if("*"===a){while(c=f[e++]){1===c.nodeType&&d.push(c)
}return d
}return f
},d.find.CLASS=c.getElementsByClassName&&function(a,b){return"undefined"!=typeof b.getElementsByClassName&&p?b.getElementsByClassName(a):void 0
},r=[],q=[],(c.qsa=Z.test(n.querySelectorAll))&&(ia(function(a){o.appendChild(a).innerHTML="<a id='"+u+"'></a><select id='"+u+"-\r\\' msallowcapture=''><option selected=''></option></select>",a.querySelectorAll("[msallowcapture^='']").length&&q.push("[*^$]="+L+"*(?:''|\"\")"),a.querySelectorAll("[selected]").length||q.push("\\["+L+"*(?:value|"+K+")"),a.querySelectorAll("[id~="+u+"-]").length||q.push("~="),a.querySelectorAll(":checked").length||q.push(":checked"),a.querySelectorAll("a#"+u+"+*").length||q.push(".#.+[+~]")
}),ia(function(a){var b=n.createElement("input");
b.setAttribute("type","hidden"),a.appendChild(b).setAttribute("name","D"),a.querySelectorAll("[name=d]").length&&q.push("name"+L+"*[*^$|!~]?="),a.querySelectorAll(":enabled").length||q.push(":enabled",":disabled"),a.querySelectorAll("*,:x"),q.push(",.*:")
})),(c.matchesSelector=Z.test(s=o.matches||o.webkitMatchesSelector||o.mozMatchesSelector||o.oMatchesSelector||o.msMatchesSelector))&&ia(function(a){c.disconnectedMatch=s.call(a,"div"),s.call(a,"[s!='']:x"),r.push("!=",O)
}),q=q.length&&new RegExp(q.join("|")),r=r.length&&new RegExp(r.join("|")),b=Z.test(o.compareDocumentPosition),t=b||Z.test(o.contains)?function(a,b){var c=9===a.nodeType?a.documentElement:a,d=b&&b.parentNode;
return a===d||!(!d||1!==d.nodeType||!(c.contains?c.contains(d):a.compareDocumentPosition&&16&a.compareDocumentPosition(d)))
}:function(a,b){if(b){while(b=b.parentNode){if(b===a){return !0
}}}return !1
},B=b?function(a,b){if(a===b){return l=!0,0
}var d=!a.compareDocumentPosition-!b.compareDocumentPosition;
return d?d:(d=(a.ownerDocument||a)===(b.ownerDocument||b)?a.compareDocumentPosition(b):1,1&d||!c.sortDetached&&b.compareDocumentPosition(a)===d?a===n||a.ownerDocument===v&&t(v,a)?-1:b===n||b.ownerDocument===v&&t(v,b)?1:k?J(k,a)-J(k,b):0:4&d?-1:1)
}:function(a,b){if(a===b){return l=!0,0
}var c,d=0,e=a.parentNode,f=b.parentNode,g=[a],h=[b];
if(!e||!f){return a===n?-1:b===n?1:e?-1:f?1:k?J(k,a)-J(k,b):0
}if(e===f){return ka(a,b)
}c=a;
while(c=c.parentNode){g.unshift(c)
}c=b;
while(c=c.parentNode){h.unshift(c)
}while(g[d]===h[d]){d++
}return d?ka(g[d],h[d]):g[d]===v?-1:h[d]===v?1:0
},n):n
},fa.matches=function(a,b){return fa(a,null,null,b)
},fa.matchesSelector=function(a,b){if((a.ownerDocument||a)!==n&&m(a),b=b.replace(T,"='$1']"),c.matchesSelector&&p&&!A[b+" "]&&(!r||!r.test(b))&&(!q||!q.test(b))){try{var d=s.call(a,b);
if(d||c.disconnectedMatch||a.document&&11!==a.document.nodeType){return d
}}catch(e){}}return fa(b,n,null,[a]).length>0
},fa.contains=function(a,b){return(a.ownerDocument||a)!==n&&m(a),t(a,b)
},fa.attr=function(a,b){(a.ownerDocument||a)!==n&&m(a);
var e=d.attrHandle[b.toLowerCase()],f=e&&D.call(d.attrHandle,b.toLowerCase())?e(a,b,!p):void 0;
return void 0!==f?f:c.attributes||!p?a.getAttribute(b):(f=a.getAttributeNode(b))&&f.specified?f.value:null
},fa.error=function(a){throw new Error("Syntax error, unrecognized expression: "+a)
},fa.uniqueSort=function(a){var b,d=[],e=0,f=0;
if(l=!c.detectDuplicates,k=!c.sortStable&&a.slice(0),a.sort(B),l){while(b=a[f++]){b===a[f]&&(e=d.push(f))
}while(e--){a.splice(d[e],1)
}}return k=null,a
},e=fa.getText=function(a){var b,c="",d=0,f=a.nodeType;
if(f){if(1===f||9===f||11===f){if("string"==typeof a.textContent){return a.textContent
}for(a=a.firstChild;
a;
a=a.nextSibling){c+=e(a)
}}else{if(3===f||4===f){return a.nodeValue
}}}else{while(b=a[d++]){c+=e(b)
}}return c
},d=fa.selectors={cacheLength:50,createPseudo:ha,match:W,attrHandle:{},find:{},relative:{">":{dir:"parentNode",first:!0}," ":{dir:"parentNode"},"+":{dir:"previousSibling",first:!0},"~":{dir:"previousSibling"}},preFilter:{ATTR:function(a){return a[1]=a[1].replace(ba,ca),a[3]=(a[3]||a[4]||a[5]||"").replace(ba,ca),"~="===a[2]&&(a[3]=" "+a[3]+" "),a.slice(0,4)
},CHILD:function(a){return a[1]=a[1].toLowerCase(),"nth"===a[1].slice(0,3)?(a[3]||fa.error(a[0]),a[4]=+(a[4]?a[5]+(a[6]||1):2*("even"===a[3]||"odd"===a[3])),a[5]=+(a[7]+a[8]||"odd"===a[3])):a[3]&&fa.error(a[0]),a
},PSEUDO:function(a){var b,c=!a[6]&&a[2];
return W.CHILD.test(a[0])?null:(a[3]?a[2]=a[4]||a[5]||"":c&&U.test(c)&&(b=g(c,!0))&&(b=c.indexOf(")",c.length-b)-c.length)&&(a[0]=a[0].slice(0,b),a[2]=c.slice(0,b)),a.slice(0,3))
}},filter:{TAG:function(a){var b=a.replace(ba,ca).toLowerCase();
return"*"===a?function(){return !0
}:function(a){return a.nodeName&&a.nodeName.toLowerCase()===b
}
},CLASS:function(a){var b=y[a+" "];
return b||(b=new RegExp("(^|"+L+")"+a+"("+L+"|$)"))&&y(a,function(a){return b.test("string"==typeof a.className&&a.className||"undefined"!=typeof a.getAttribute&&a.getAttribute("class")||"")
})
},ATTR:function(a,b,c){return function(d){var e=fa.attr(d,a);
return null==e?"!="===b:b?(e+="","="===b?e===c:"!="===b?e!==c:"^="===b?c&&0===e.indexOf(c):"*="===b?c&&e.indexOf(c)>-1:"$="===b?c&&e.slice(-c.length)===c:"~="===b?(" "+e.replace(P," ")+" ").indexOf(c)>-1:"|="===b?e===c||e.slice(0,c.length+1)===c+"-":!1):!0
}
},CHILD:function(a,b,c,d,e){var f="nth"!==a.slice(0,3),g="last"!==a.slice(-4),h="of-type"===b;
return 1===d&&0===e?function(a){return !!a.parentNode
}:function(b,c,i){var j,k,l,m,n,o,p=f!==g?"nextSibling":"previousSibling",q=b.parentNode,r=h&&b.nodeName.toLowerCase(),s=!i&&!h,t=!1;
if(q){if(f){while(p){m=b;
while(m=m[p]){if(h?m.nodeName.toLowerCase()===r:1===m.nodeType){return !1
}}o=p="only"===a&&!o&&"nextSibling"
}return !0
}if(o=[g?q.firstChild:q.lastChild],g&&s){m=q,l=m[u]||(m[u]={}),k=l[m.uniqueID]||(l[m.uniqueID]={}),j=k[a]||[],n=j[0]===w&&j[1],t=n&&j[2],m=n&&q.childNodes[n];
while(m=++n&&m&&m[p]||(t=n=0)||o.pop()){if(1===m.nodeType&&++t&&m===b){k[a]=[w,n,t];
break
}}}else{if(s&&(m=b,l=m[u]||(m[u]={}),k=l[m.uniqueID]||(l[m.uniqueID]={}),j=k[a]||[],n=j[0]===w&&j[1],t=n),t===!1){while(m=++n&&m&&m[p]||(t=n=0)||o.pop()){if((h?m.nodeName.toLowerCase()===r:1===m.nodeType)&&++t&&(s&&(l=m[u]||(m[u]={}),k=l[m.uniqueID]||(l[m.uniqueID]={}),k[a]=[w,t]),m===b)){break
}}}}return t-=e,t===d||t%d===0&&t/d>=0
}}
},PSEUDO:function(a,b){var c,e=d.pseudos[a]||d.setFilters[a.toLowerCase()]||fa.error("unsupported pseudo: "+a);
return e[u]?e(b):e.length>1?(c=[a,a,"",b],d.setFilters.hasOwnProperty(a.toLowerCase())?ha(function(a,c){var d,f=e(a,b),g=f.length;
while(g--){d=J(a,f[g]),a[d]=!(c[d]=f[g])
}}):function(a){return e(a,0,c)
}):e
}},pseudos:{not:ha(function(a){var b=[],c=[],d=h(a.replace(Q,"$1"));
return d[u]?ha(function(a,b,c,e){var f,g=d(a,null,e,[]),h=a.length;
while(h--){(f=g[h])&&(a[h]=!(b[h]=f))
}}):function(a,e,f){return b[0]=a,d(b,null,f,c),b[0]=null,!c.pop()
}
}),has:ha(function(a){return function(b){return fa(a,b).length>0
}
}),contains:ha(function(a){return a=a.replace(ba,ca),function(b){return(b.textContent||b.innerText||e(b)).indexOf(a)>-1
}
}),lang:ha(function(a){return V.test(a||"")||fa.error("unsupported lang: "+a),a=a.replace(ba,ca).toLowerCase(),function(b){var c;
do{if(c=p?b.lang:b.getAttribute("xml:lang")||b.getAttribute("lang")){return c=c.toLowerCase(),c===a||0===c.indexOf(a+"-")
}}while((b=b.parentNode)&&1===b.nodeType);
return !1
}
}),target:function(b){var c=a.location&&a.location.hash;
return c&&c.slice(1)===b.id
},root:function(a){return a===o
},focus:function(a){return a===n.activeElement&&(!n.hasFocus||n.hasFocus())&&!!(a.type||a.href||~a.tabIndex)
},enabled:function(a){return a.disabled===!1
},disabled:function(a){return a.disabled===!0
},checked:function(a){var b=a.nodeName.toLowerCase();
return"input"===b&&!!a.checked||"option"===b&&!!a.selected
},selected:function(a){return a.parentNode&&a.parentNode.selectedIndex,a.selected===!0
},empty:function(a){for(a=a.firstChild;
a;
a=a.nextSibling){if(a.nodeType<6){return !1
}}return !0
},parent:function(a){return !d.pseudos.empty(a)
},header:function(a){return Y.test(a.nodeName)
},input:function(a){return X.test(a.nodeName)
},button:function(a){var b=a.nodeName.toLowerCase();
return"input"===b&&"button"===a.type||"button"===b
},text:function(a){var b;
return"input"===a.nodeName.toLowerCase()&&"text"===a.type&&(null==(b=a.getAttribute("type"))||"text"===b.toLowerCase())
},first:na(function(){return[0]
}),last:na(function(a,b){return[b-1]
}),eq:na(function(a,b,c){return[0>c?c+b:c]
}),even:na(function(a,b){for(var c=0;
b>c;
c+=2){a.push(c)
}return a
}),odd:na(function(a,b){for(var c=1;
b>c;
c+=2){a.push(c)
}return a
}),lt:na(function(a,b,c){for(var d=0>c?c+b:c;
--d>=0;
){a.push(d)
}return a
}),gt:na(function(a,b,c){for(var d=0>c?c+b:c;
++d<b;
){a.push(d)
}return a
})}},d.pseudos.nth=d.pseudos.eq;
for(b in {radio:!0,checkbox:!0,file:!0,password:!0,image:!0}){d.pseudos[b]=la(b)
}for(b in {submit:!0,reset:!0}){d.pseudos[b]=ma(b)
}function pa(){}pa.prototype=d.filters=d.pseudos,d.setFilters=new pa,g=fa.tokenize=function(a,b){var c,e,f,g,h,i,j,k=z[a+" "];
if(k){return b?0:k.slice(0)
}h=a,i=[],j=d.preFilter;
while(h){c&&!(e=R.exec(h))||(e&&(h=h.slice(e[0].length)||h),i.push(f=[])),c=!1,(e=S.exec(h))&&(c=e.shift(),f.push({value:c,type:e[0].replace(Q," ")}),h=h.slice(c.length));
for(g in d.filter){!(e=W[g].exec(h))||j[g]&&!(e=j[g](e))||(c=e.shift(),f.push({value:c,type:g,matches:e}),h=h.slice(c.length))
}if(!c){break
}}return b?h.length:h?fa.error(a):z(a,i).slice(0)
};
function qa(a){for(var b=0,c=a.length,d="";
c>b;
b++){d+=a[b].value
}return d
}function ra(a,b,c){var d=b.dir,e=c&&"parentNode"===d,f=x++;
return b.first?function(b,c,f){while(b=b[d]){if(1===b.nodeType||e){return a(b,c,f)
}}}:function(b,c,g){var h,i,j,k=[w,f];
if(g){while(b=b[d]){if((1===b.nodeType||e)&&a(b,c,g)){return !0
}}}else{while(b=b[d]){if(1===b.nodeType||e){if(j=b[u]||(b[u]={}),i=j[b.uniqueID]||(j[b.uniqueID]={}),(h=i[d])&&h[0]===w&&h[1]===f){return k[2]=h[2]
}if(i[d]=k,k[2]=a(b,c,g)){return !0
}}}}}
}function sa(a){return a.length>1?function(b,c,d){var e=a.length;
while(e--){if(!a[e](b,c,d)){return !1
}}return !0
}:a[0]
}function ta(a,b,c){for(var d=0,e=b.length;
e>d;
d++){fa(a,b[d],c)
}return c
}function ua(a,b,c,d,e){for(var f,g=[],h=0,i=a.length,j=null!=b;
i>h;
h++){(f=a[h])&&(c&&!c(f,d,e)||(g.push(f),j&&b.push(h)))
}return g
}function va(a,b,c,d,e,f){return d&&!d[u]&&(d=va(d)),e&&!e[u]&&(e=va(e,f)),ha(function(f,g,h,i){var j,k,l,m=[],n=[],o=g.length,p=f||ta(b||"*",h.nodeType?[h]:h,[]),q=!a||!f&&b?p:ua(p,m,a,h,i),r=c?e||(f?a:o||d)?[]:g:q;
if(c&&c(q,r,h,i),d){j=ua(r,n),d(j,[],h,i),k=j.length;
while(k--){(l=j[k])&&(r[n[k]]=!(q[n[k]]=l))
}}if(f){if(e||a){if(e){j=[],k=r.length;
while(k--){(l=r[k])&&j.push(q[k]=l)
}e(null,r=[],j,i)
}k=r.length;
while(k--){(l=r[k])&&(j=e?J(f,l):m[k])>-1&&(f[j]=!(g[j]=l))
}}}else{r=ua(r===g?r.splice(o,r.length):r),e?e(null,g,r,i):H.apply(g,r)
}})
}function wa(a){for(var b,c,e,f=a.length,g=d.relative[a[0].type],h=g||d.relative[" "],i=g?1:0,k=ra(function(a){return a===b
},h,!0),l=ra(function(a){return J(b,a)>-1
},h,!0),m=[function(a,c,d){var e=!g&&(d||c!==j)||((b=c).nodeType?k(a,c,d):l(a,c,d));
return b=null,e
}];
f>i;
i++){if(c=d.relative[a[i].type]){m=[ra(sa(m),c)]
}else{if(c=d.filter[a[i].type].apply(null,a[i].matches),c[u]){for(e=++i;
f>e;
e++){if(d.relative[a[e].type]){break
}}return va(i>1&&sa(m),i>1&&qa(a.slice(0,i-1).concat({value:" "===a[i-2].type?"*":""})).replace(Q,"$1"),c,e>i&&wa(a.slice(i,e)),f>e&&wa(a=a.slice(e)),f>e&&qa(a))
}m.push(c)
}}return sa(m)
}function xa(a,b){var c=b.length>0,e=a.length>0,f=function(f,g,h,i,k){var l,o,q,r=0,s="0",t=f&&[],u=[],v=j,x=f||e&&d.find.TAG("*",k),y=w+=null==v?1:Math.random()||0.1,z=x.length;
for(k&&(j=g===n||g||k);
s!==z&&null!=(l=x[s]);
s++){if(e&&l){o=0,g||l.ownerDocument===n||(m(l),h=!p);
while(q=a[o++]){if(q(l,g||n,h)){i.push(l);
break
}}k&&(w=y)
}c&&((l=!q&&l)&&r--,f&&t.push(l))
}if(r+=s,c&&s!==r){o=0;
while(q=b[o++]){q(t,u,g,h)
}if(f){if(r>0){while(s--){t[s]||u[s]||(u[s]=F.call(i))
}}u=ua(u)
}H.apply(i,u),k&&!f&&u.length>0&&r+b.length>1&&fa.uniqueSort(i)
}return k&&(w=y,j=v),t
};
return c?ha(f):f
}return h=fa.compile=function(a,b){var c,d=[],e=[],f=A[a+" "];
if(!f){b||(b=g(a)),c=b.length;
while(c--){f=wa(b[c]),f[u]?d.push(f):e.push(f)
}f=A(a,xa(e,d)),f.selector=a
}return f
},i=fa.select=function(a,b,e,f){var i,j,k,l,m,n="function"==typeof a&&a,o=!f&&g(a=n.selector||a);
if(e=e||[],1===o.length){if(j=o[0]=o[0].slice(0),j.length>2&&"ID"===(k=j[0]).type&&c.getById&&9===b.nodeType&&p&&d.relative[j[1].type]){if(b=(d.find.ID(k.matches[0].replace(ba,ca),b)||[])[0],!b){return e
}n&&(b=b.parentNode),a=a.slice(j.shift().value.length)
}i=W.needsContext.test(a)?0:j.length;
while(i--){if(k=j[i],d.relative[l=k.type]){break
}if((m=d.find[l])&&(f=m(k.matches[0].replace(ba,ca),_.test(j[0].type)&&oa(b.parentNode)||b))){if(j.splice(i,1),a=f.length&&qa(j),!a){return H.apply(e,f),e
}break
}}}return(n||h(a,o))(f,b,!p,e,!b||_.test(a)&&oa(b.parentNode)||b),e
},c.sortStable=u.split("").sort(B).join("")===u,c.detectDuplicates=!!l,m(),c.sortDetached=ia(function(a){return 1&a.compareDocumentPosition(n.createElement("div"))
}),ia(function(a){return a.innerHTML="<a href='#'></a>","#"===a.firstChild.getAttribute("href")
})||ja("type|href|height|width",function(a,b,c){return c?void 0:a.getAttribute(b,"type"===b.toLowerCase()?1:2)
}),c.attributes&&ia(function(a){return a.innerHTML="<input/>",a.firstChild.setAttribute("value",""),""===a.firstChild.getAttribute("value")
})||ja("value",function(a,b,c){return c||"input"!==a.nodeName.toLowerCase()?void 0:a.defaultValue
}),ia(function(a){return null==a.getAttribute("disabled")
})||ja(K,function(a,b,c){var d;
return c?void 0:a[b]===!0?b.toLowerCase():(d=a.getAttributeNode(b))&&d.specified?d.value:null
}),fa
}(a);
n.find=t,n.expr=t.selectors,n.expr[":"]=n.expr.pseudos,n.uniqueSort=n.unique=t.uniqueSort,n.text=t.getText,n.isXMLDoc=t.isXML,n.contains=t.contains;
var u=function(a,b,c){var d=[],e=void 0!==c;
while((a=a[b])&&9!==a.nodeType){if(1===a.nodeType){if(e&&n(a).is(c)){break
}d.push(a)
}}return d
},v=function(a,b){for(var c=[];
a;
a=a.nextSibling){1===a.nodeType&&a!==b&&c.push(a)
}return c
},w=n.expr.match.needsContext,x=/^<([\w-]+)\s*\/?>(?:<\/\1>|)$/,y=/^.[^:#\[\.,]*$/;
function z(a,b,c){if(n.isFunction(b)){return n.grep(a,function(a,d){return !!b.call(a,d,a)!==c
})
}if(b.nodeType){return n.grep(a,function(a){return a===b!==c
})
}if("string"==typeof b){if(y.test(b)){return n.filter(b,a,c)
}b=n.filter(b,a)
}return n.grep(a,function(a){return n.inArray(a,b)>-1!==c
})
}n.filter=function(a,b,c){var d=b[0];
return c&&(a=":not("+a+")"),1===b.length&&1===d.nodeType?n.find.matchesSelector(d,a)?[d]:[]:n.find.matches(a,n.grep(b,function(a){return 1===a.nodeType
}))
},n.fn.extend({find:function(a){var b,c=[],d=this,e=d.length;
if("string"!=typeof a){return this.pushStack(n(a).filter(function(){for(b=0;
e>b;
b++){if(n.contains(d[b],this)){return !0
}}}))
}for(b=0;
e>b;
b++){n.find(a,d[b],c)
}return c=this.pushStack(e>1?n.unique(c):c),c.selector=this.selector?this.selector+" "+a:a,c
},filter:function(a){return this.pushStack(z(this,a||[],!1))
},not:function(a){return this.pushStack(z(this,a||[],!0))
},is:function(a){return !!z(this,"string"==typeof a&&w.test(a)?n(a):a||[],!1).length
}});
var A,B=/^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,C=n.fn.init=function(a,b,c){var e,f;
if(!a){return this
}if(c=c||A,"string"==typeof a){if(e="<"===a.charAt(0)&&">"===a.charAt(a.length-1)&&a.length>=3?[null,a,null]:B.exec(a),!e||!e[1]&&b){return !b||b.jquery?(b||c).find(a):this.constructor(b).find(a)
}if(e[1]){if(b=b instanceof n?b[0]:b,n.merge(this,n.parseHTML(e[1],b&&b.nodeType?b.ownerDocument||b:d,!0)),x.test(e[1])&&n.isPlainObject(b)){for(e in b){n.isFunction(this[e])?this[e](b[e]):this.attr(e,b[e])
}}return this
}if(f=d.getElementById(e[2]),f&&f.parentNode){if(f.id!==e[2]){return A.find(a)
}this.length=1,this[0]=f
}return this.context=d,this.selector=a,this
}return a.nodeType?(this.context=this[0]=a,this.length=1,this):n.isFunction(a)?"undefined"!=typeof c.ready?c.ready(a):a(n):(void 0!==a.selector&&(this.selector=a.selector,this.context=a.context),n.makeArray(a,this))
};
C.prototype=n.fn,A=n(d);
var D=/^(?:parents|prev(?:Until|All))/,E={children:!0,contents:!0,next:!0,prev:!0};
n.fn.extend({has:function(a){var b,c=n(a,this),d=c.length;
return this.filter(function(){for(b=0;
d>b;
b++){if(n.contains(this,c[b])){return !0
}}})
},closest:function(a,b){for(var c,d=0,e=this.length,f=[],g=w.test(a)||"string"!=typeof a?n(a,b||this.context):0;
e>d;
d++){for(c=this[d];
c&&c!==b;
c=c.parentNode){if(c.nodeType<11&&(g?g.index(c)>-1:1===c.nodeType&&n.find.matchesSelector(c,a))){f.push(c);
break
}}}return this.pushStack(f.length>1?n.uniqueSort(f):f)
},index:function(a){return a?"string"==typeof a?n.inArray(this[0],n(a)):n.inArray(a.jquery?a[0]:a,this):this[0]&&this[0].parentNode?this.first().prevAll().length:-1
},add:function(a,b){return this.pushStack(n.uniqueSort(n.merge(this.get(),n(a,b))))
},addBack:function(a){return this.add(null==a?this.prevObject:this.prevObject.filter(a))
}});
function F(a,b){do{a=a[b]
}while(a&&1!==a.nodeType);
return a
}n.each({parent:function(a){var b=a.parentNode;
return b&&11!==b.nodeType?b:null
},parents:function(a){return u(a,"parentNode")
},parentsUntil:function(a,b,c){return u(a,"parentNode",c)
},next:function(a){return F(a,"nextSibling")
},prev:function(a){return F(a,"previousSibling")
},nextAll:function(a){return u(a,"nextSibling")
},prevAll:function(a){return u(a,"previousSibling")
},nextUntil:function(a,b,c){return u(a,"nextSibling",c)
},prevUntil:function(a,b,c){return u(a,"previousSibling",c)
},siblings:function(a){return v((a.parentNode||{}).firstChild,a)
},children:function(a){return v(a.firstChild)
},contents:function(a){return n.nodeName(a,"iframe")?a.contentDocument||a.contentWindow.document:n.merge([],a.childNodes)
}},function(a,b){n.fn[a]=function(c,d){var e=n.map(this,b,c);
return"Until"!==a.slice(-5)&&(d=c),d&&"string"==typeof d&&(e=n.filter(d,e)),this.length>1&&(E[a]||(e=n.uniqueSort(e)),D.test(a)&&(e=e.reverse())),this.pushStack(e)
}
});
var G=/\S+/g;
function H(a){var b={};
return n.each(a.match(G)||[],function(a,c){b[c]=!0
}),b
}n.Callbacks=function(a){a="string"==typeof a?H(a):n.extend({},a);
var b,c,d,e,f=[],g=[],h=-1,i=function(){for(e=a.once,d=b=!0;
g.length;
h=-1){c=g.shift();
while(++h<f.length){f[h].apply(c[0],c[1])===!1&&a.stopOnFalse&&(h=f.length,c=!1)
}}a.memory||(c=!1),b=!1,e&&(f=c?[]:"")
},j={add:function(){return f&&(c&&!b&&(h=f.length-1,g.push(c)),function d(b){n.each(b,function(b,c){n.isFunction(c)?a.unique&&j.has(c)||f.push(c):c&&c.length&&"string"!==n.type(c)&&d(c)
})
}(arguments),c&&!b&&i()),this
},remove:function(){return n.each(arguments,function(a,b){var c;
while((c=n.inArray(b,f,c))>-1){f.splice(c,1),h>=c&&h--
}}),this
},has:function(a){return a?n.inArray(a,f)>-1:f.length>0
},empty:function(){return f&&(f=[]),this
},disable:function(){return e=g=[],f=c="",this
},disabled:function(){return !f
},lock:function(){return e=!0,c||j.disable(),this
},locked:function(){return !!e
},fireWith:function(a,c){return e||(c=c||[],c=[a,c.slice?c.slice():c],g.push(c),b||i()),this
},fire:function(){return j.fireWith(this,arguments),this
},fired:function(){return !!d
}};
return j
},n.extend({Deferred:function(a){var b=[["resolve","done",n.Callbacks("once memory"),"resolved"],["reject","fail",n.Callbacks("once memory"),"rejected"],["notify","progress",n.Callbacks("memory")]],c="pending",d={state:function(){return c
},always:function(){return e.done(arguments).fail(arguments),this
},then:function(){var a=arguments;
return n.Deferred(function(c){n.each(b,function(b,f){var g=n.isFunction(a[b])&&a[b];
e[f[1]](function(){var a=g&&g.apply(this,arguments);
a&&n.isFunction(a.promise)?a.promise().progress(c.notify).done(c.resolve).fail(c.reject):c[f[0]+"With"](this===d?c.promise():this,g?[a]:arguments)
})
}),a=null
}).promise()
},promise:function(a){return null!=a?n.extend(a,d):d
}},e={};
return d.pipe=d.then,n.each(b,function(a,f){var g=f[2],h=f[3];
d[f[1]]=g.add,h&&g.add(function(){c=h
},b[1^a][2].disable,b[2][2].lock),e[f[0]]=function(){return e[f[0]+"With"](this===e?d:this,arguments),this
},e[f[0]+"With"]=g.fireWith
}),d.promise(e),a&&a.call(e,e),e
},when:function(a){var b=0,c=e.call(arguments),d=c.length,f=1!==d||a&&n.isFunction(a.promise)?d:0,g=1===f?a:n.Deferred(),h=function(a,b,c){return function(d){b[a]=this,c[a]=arguments.length>1?e.call(arguments):d,c===i?g.notifyWith(b,c):--f||g.resolveWith(b,c)
}
},i,j,k;
if(d>1){for(i=new Array(d),j=new Array(d),k=new Array(d);
d>b;
b++){c[b]&&n.isFunction(c[b].promise)?c[b].promise().progress(h(b,j,i)).done(h(b,k,c)).fail(g.reject):--f
}}return f||g.resolveWith(k,c),g.promise()
}});
var I;
n.fn.ready=function(a){return n.ready.promise().done(a),this
},n.extend({isReady:!1,readyWait:1,holdReady:function(a){a?n.readyWait++:n.ready(!0)
},ready:function(a){(a===!0?--n.readyWait:n.isReady)||(n.isReady=!0,a!==!0&&--n.readyWait>0||(I.resolveWith(d,[n]),n.fn.triggerHandler&&(n(d).triggerHandler("ready"),n(d).off("ready"))))
}});
function J(){d.addEventListener?(d.removeEventListener("DOMContentLoaded",K),a.removeEventListener("load",K)):(d.detachEvent("onreadystatechange",K),a.detachEvent("onload",K))
}function K(){(d.addEventListener||"load"===a.event.type||"complete"===d.readyState)&&(J(),n.ready())
}n.ready.promise=function(b){if(!I){if(I=n.Deferred(),"complete"===d.readyState||"loading"!==d.readyState&&!d.documentElement.doScroll){a.setTimeout(n.ready)
}else{if(d.addEventListener){d.addEventListener("DOMContentLoaded",K),a.addEventListener("load",K)
}else{d.attachEvent("onreadystatechange",K),a.attachEvent("onload",K);
var c=!1;
try{c=null==a.frameElement&&d.documentElement
}catch(e){}c&&c.doScroll&&!function f(){if(!n.isReady){try{c.doScroll("left")
}catch(b){return a.setTimeout(f,50)
}J(),n.ready()
}}()
}}}return I.promise(b)
},n.ready.promise();
var L;
for(L in n(l)){break
}l.ownFirst="0"===L,l.inlineBlockNeedsLayout=!1,n(function(){var a,b,c,e;
c=d.getElementsByTagName("body")[0],c&&c.style&&(b=d.createElement("div"),e=d.createElement("div"),e.style.cssText="position:absolute;border:0;width:0;height:0;top:0;left:-9999px",c.appendChild(e).appendChild(b),"undefined"!=typeof b.style.zoom&&(b.style.cssText="display:inline;margin:0;border:0;padding:1px;width:1px;zoom:1",l.inlineBlockNeedsLayout=a=3===b.offsetWidth,a&&(c.style.zoom=1)),c.removeChild(e))
}),function(){var a=d.createElement("div");
l.deleteExpando=!0;
try{delete a.test
}catch(b){l.deleteExpando=!1
}a=null
}();
var M=function(a){var b=n.noData[(a.nodeName+" ").toLowerCase()],c=+a.nodeType||1;
return 1!==c&&9!==c?!1:!b||b!==!0&&a.getAttribute("classid")===b
},N=/^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,O=/([A-Z])/g;
function P(a,b,c){if(void 0===c&&1===a.nodeType){var d="data-"+b.replace(O,"-$1").toLowerCase();
if(c=a.getAttribute(d),"string"==typeof c){try{c="true"===c?!0:"false"===c?!1:"null"===c?null:+c+""===c?+c:N.test(c)?n.parseJSON(c):c
}catch(e){}n.data(a,b,c)
}else{c=void 0
}}return c
}function Q(a){var b;
for(b in a){if(("data"!==b||!n.isEmptyObject(a[b]))&&"toJSON"!==b){return !1
}}return !0
}function R(a,b,d,e){if(M(a)){var f,g,h=n.expando,i=a.nodeType,j=i?n.cache:a,k=i?a[h]:a[h]&&h;
if(k&&j[k]&&(e||j[k].data)||void 0!==d||"string"!=typeof b){return k||(k=i?a[h]=c.pop()||n.guid++:h),j[k]||(j[k]=i?{}:{toJSON:n.noop}),"object"!=typeof b&&"function"!=typeof b||(e?j[k]=n.extend(j[k],b):j[k].data=n.extend(j[k].data,b)),g=j[k],e||(g.data||(g.data={}),g=g.data),void 0!==d&&(g[n.camelCase(b)]=d),"string"==typeof b?(f=g[b],null==f&&(f=g[n.camelCase(b)])):f=g,f
}}}function S(a,b,c){if(M(a)){var d,e,f=a.nodeType,g=f?n.cache:a,h=f?a[n.expando]:n.expando;
if(g[h]){if(b&&(d=c?g[h]:g[h].data)){n.isArray(b)?b=b.concat(n.map(b,n.camelCase)):b in d?b=[b]:(b=n.camelCase(b),b=b in d?[b]:b.split(" ")),e=b.length;
while(e--){delete d[b[e]]
}if(c?!Q(d):!n.isEmptyObject(d)){return
}}(c||(delete g[h].data,Q(g[h])))&&(f?n.cleanData([a],!0):l.deleteExpando||g!=g.window?delete g[h]:g[h]=void 0)
}}}n.extend({cache:{},noData:{"applet ":!0,"embed ":!0,"object ":"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"},hasData:function(a){return a=a.nodeType?n.cache[a[n.expando]]:a[n.expando],!!a&&!Q(a)
},data:function(a,b,c){return R(a,b,c)
},removeData:function(a,b){return S(a,b)
},_data:function(a,b,c){return R(a,b,c,!0)
},_removeData:function(a,b){return S(a,b,!0)
}}),n.fn.extend({data:function(a,b){var c,d,e,f=this[0],g=f&&f.attributes;
if(void 0===a){if(this.length&&(e=n.data(f),1===f.nodeType&&!n._data(f,"parsedAttrs"))){c=g.length;
while(c--){g[c]&&(d=g[c].name,0===d.indexOf("data-")&&(d=n.camelCase(d.slice(5)),P(f,d,e[d])))
}n._data(f,"parsedAttrs",!0)
}return e
}return"object"==typeof a?this.each(function(){n.data(this,a)
}):arguments.length>1?this.each(function(){n.data(this,a,b)
}):f?P(f,a,n.data(f,a)):void 0
},removeData:function(a){return this.each(function(){n.removeData(this,a)
})
}}),n.extend({queue:function(a,b,c){var d;
return a?(b=(b||"fx")+"queue",d=n._data(a,b),c&&(!d||n.isArray(c)?d=n._data(a,b,n.makeArray(c)):d.push(c)),d||[]):void 0
},dequeue:function(a,b){b=b||"fx";
var c=n.queue(a,b),d=c.length,e=c.shift(),f=n._queueHooks(a,b),g=function(){n.dequeue(a,b)
};
"inprogress"===e&&(e=c.shift(),d--),e&&("fx"===b&&c.unshift("inprogress"),delete f.stop,e.call(a,g,f)),!d&&f&&f.empty.fire()
},_queueHooks:function(a,b){var c=b+"queueHooks";
return n._data(a,c)||n._data(a,c,{empty:n.Callbacks("once memory").add(function(){n._removeData(a,b+"queue"),n._removeData(a,c)
})})
}}),n.fn.extend({queue:function(a,b){var c=2;
return"string"!=typeof a&&(b=a,a="fx",c--),arguments.length<c?n.queue(this[0],a):void 0===b?this:this.each(function(){var c=n.queue(this,a,b);
n._queueHooks(this,a),"fx"===a&&"inprogress"!==c[0]&&n.dequeue(this,a)
})
},dequeue:function(a){return this.each(function(){n.dequeue(this,a)
})
},clearQueue:function(a){return this.queue(a||"fx",[])
},promise:function(a,b){var c,d=1,e=n.Deferred(),f=this,g=this.length,h=function(){--d||e.resolveWith(f,[f])
};
"string"!=typeof a&&(b=a,a=void 0),a=a||"fx";
while(g--){c=n._data(f[g],a+"queueHooks"),c&&c.empty&&(d++,c.empty.add(h))
}return h(),e.promise(b)
}}),function(){var a;
l.shrinkWrapBlocks=function(){if(null!=a){return a
}a=!1;
var b,c,e;
return c=d.getElementsByTagName("body")[0],c&&c.style?(b=d.createElement("div"),e=d.createElement("div"),e.style.cssText="position:absolute;border:0;width:0;height:0;top:0;left:-9999px",c.appendChild(e).appendChild(b),"undefined"!=typeof b.style.zoom&&(b.style.cssText="-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:1px;width:1px;zoom:1",b.appendChild(d.createElement("div")).style.width="5px",a=3!==b.offsetWidth),c.removeChild(e),a):void 0
}
}();
var T=/[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,U=new RegExp("^(?:([+-])=|)("+T+")([a-z%]*)$","i"),V=["Top","Right","Bottom","Left"],W=function(a,b){return a=b||a,"none"===n.css(a,"display")||!n.contains(a.ownerDocument,a)
};
function X(a,b,c,d){var e,f=1,g=20,h=d?function(){return d.cur()
}:function(){return n.css(a,b,"")
},i=h(),j=c&&c[3]||(n.cssNumber[b]?"":"px"),k=(n.cssNumber[b]||"px"!==j&&+i)&&U.exec(n.css(a,b));
if(k&&k[3]!==j){j=j||k[3],c=c||[],k=+i||1;
do{f=f||".5",k/=f,n.style(a,b,k+j)
}while(f!==(f=h()/i)&&1!==f&&--g)
}return c&&(k=+k||+i||0,e=c[1]?k+(c[1]+1)*c[2]:+c[2],d&&(d.unit=j,d.start=k,d.end=e)),e
}var Y=function(a,b,c,d,e,f,g){var h=0,i=a.length,j=null==c;
if("object"===n.type(c)){e=!0;
for(h in c){Y(a,b,h,c[h],!0,f,g)
}}else{if(void 0!==d&&(e=!0,n.isFunction(d)||(g=!0),j&&(g?(b.call(a,d),b=null):(j=b,b=function(a,b,c){return j.call(n(a),c)
})),b)){for(;
i>h;
h++){b(a[h],c,g?d:d.call(a[h],h,b(a[h],c)))
}}}return e?a:j?b.call(a):i?b(a[0],c):f
},Z=/^(?:checkbox|radio)$/i,$=/<([\w:-]+)/,_=/^$|\/(?:java|ecma)script/i,aa=/^\s+/,ba="abbr|article|aside|audio|bdi|canvas|data|datalist|details|dialog|figcaption|figure|footer|header|hgroup|main|mark|meter|nav|output|picture|progress|section|summary|template|time|video";
function ca(a){var b=ba.split("|"),c=a.createDocumentFragment();
if(c.createElement){while(b.length){c.createElement(b.pop())
}}return c
}!function(){var a=d.createElement("div"),b=d.createDocumentFragment(),c=d.createElement("input");
a.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",l.leadingWhitespace=3===a.firstChild.nodeType,l.tbody=!a.getElementsByTagName("tbody").length,l.htmlSerialize=!!a.getElementsByTagName("link").length,l.html5Clone="<:nav></:nav>"!==d.createElement("nav").cloneNode(!0).outerHTML,c.type="checkbox",c.checked=!0,b.appendChild(c),l.appendChecked=c.checked,a.innerHTML="<textarea>x</textarea>",l.noCloneChecked=!!a.cloneNode(!0).lastChild.defaultValue,b.appendChild(a),c=d.createElement("input"),c.setAttribute("type","radio"),c.setAttribute("checked","checked"),c.setAttribute("name","t"),a.appendChild(c),l.checkClone=a.cloneNode(!0).cloneNode(!0).lastChild.checked,l.noCloneEvent=!!a.addEventListener,a[n.expando]=1,l.attributes=!a.getAttribute(n.expando)
}();
var da={option:[1,"<select multiple='multiple'>","</select>"],legend:[1,"<fieldset>","</fieldset>"],area:[1,"<map>","</map>"],param:[1,"<object>","</object>"],thead:[1,"<table>","</table>"],tr:[2,"<table><tbody>","</tbody></table>"],col:[2,"<table><tbody></tbody><colgroup>","</colgroup></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],_default:l.htmlSerialize?[0,"",""]:[1,"X<div>","</div>"]};
da.optgroup=da.option,da.tbody=da.tfoot=da.colgroup=da.caption=da.thead,da.th=da.td;
function ea(a,b){var c,d,e=0,f="undefined"!=typeof a.getElementsByTagName?a.getElementsByTagName(b||"*"):"undefined"!=typeof a.querySelectorAll?a.querySelectorAll(b||"*"):void 0;
if(!f){for(f=[],c=a.childNodes||a;
null!=(d=c[e]);
e++){!b||n.nodeName(d,b)?f.push(d):n.merge(f,ea(d,b))
}}return void 0===b||b&&n.nodeName(a,b)?n.merge([a],f):f
}function fa(a,b){for(var c,d=0;
null!=(c=a[d]);
d++){n._data(c,"globalEval",!b||n._data(b[d],"globalEval"))
}}var ga=/<|&#?\w+;/,ha=/<tbody/i;
function ia(a){Z.test(a.type)&&(a.defaultChecked=a.checked)
}function ja(a,b,c,d,e){for(var f,g,h,i,j,k,m,o=a.length,p=ca(b),q=[],r=0;
o>r;
r++){if(g=a[r],g||0===g){if("object"===n.type(g)){n.merge(q,g.nodeType?[g]:g)
}else{if(ga.test(g)){i=i||p.appendChild(b.createElement("div")),j=($.exec(g)||["",""])[1].toLowerCase(),m=da[j]||da._default,i.innerHTML=m[1]+n.htmlPrefilter(g)+m[2],f=m[0];
while(f--){i=i.lastChild
}if(!l.leadingWhitespace&&aa.test(g)&&q.push(b.createTextNode(aa.exec(g)[0])),!l.tbody){g="table"!==j||ha.test(g)?"<table>"!==m[1]||ha.test(g)?0:i:i.firstChild,f=g&&g.childNodes.length;
while(f--){n.nodeName(k=g.childNodes[f],"tbody")&&!k.childNodes.length&&g.removeChild(k)
}}n.merge(q,i.childNodes),i.textContent="";
while(i.firstChild){i.removeChild(i.firstChild)
}i=p.lastChild
}else{q.push(b.createTextNode(g))
}}}}i&&p.removeChild(i),l.appendChecked||n.grep(ea(q,"input"),ia),r=0;
while(g=q[r++]){if(d&&n.inArray(g,d)>-1){e&&e.push(g)
}else{if(h=n.contains(g.ownerDocument,g),i=ea(p.appendChild(g),"script"),h&&fa(i),c){f=0;
while(g=i[f++]){_.test(g.type||"")&&c.push(g)
}}}}return i=null,p
}!function(){var b,c,e=d.createElement("div");
for(b in {submit:!0,change:!0,focusin:!0}){c="on"+b,(l[b]=c in a)||(e.setAttribute(c,"t"),l[b]=e.attributes[c].expando===!1)
}e=null
}();
var ka=/^(?:input|select|textarea)$/i,la=/^key/,ma=/^(?:mouse|pointer|contextmenu|drag|drop)|click/,na=/^(?:focusinfocus|focusoutblur)$/,oa=/^([^.]*)(?:\.(.+)|)/;
function pa(){return !0
}function qa(){return !1
}function ra(){try{return d.activeElement
}catch(a){}}function sa(a,b,c,d,e,f){var g,h;
if("object"==typeof b){"string"!=typeof c&&(d=d||c,c=void 0);
for(h in b){sa(a,h,c,d,b[h],f)
}return a
}if(null==d&&null==e?(e=c,d=c=void 0):null==e&&("string"==typeof c?(e=d,d=void 0):(e=d,d=c,c=void 0)),e===!1){e=qa
}else{if(!e){return a
}}return 1===f&&(g=e,e=function(a){return n().off(a),g.apply(this,arguments)
},e.guid=g.guid||(g.guid=n.guid++)),a.each(function(){n.event.add(this,b,e,d,c)
})
}n.event={global:{},add:function(a,b,c,d,e){var f,g,h,i,j,k,l,m,o,p,q,r=n._data(a);
if(r){c.handler&&(i=c,c=i.handler,e=i.selector),c.guid||(c.guid=n.guid++),(g=r.events)||(g=r.events={}),(k=r.handle)||(k=r.handle=function(a){return"undefined"==typeof n||a&&n.event.triggered===a.type?void 0:n.event.dispatch.apply(k.elem,arguments)
},k.elem=a),b=(b||"").match(G)||[""],h=b.length;
while(h--){f=oa.exec(b[h])||[],o=q=f[1],p=(f[2]||"").split(".").sort(),o&&(j=n.event.special[o]||{},o=(e?j.delegateType:j.bindType)||o,j=n.event.special[o]||{},l=n.extend({type:o,origType:q,data:d,handler:c,guid:c.guid,selector:e,needsContext:e&&n.expr.match.needsContext.test(e),namespace:p.join(".")},i),(m=g[o])||(m=g[o]=[],m.delegateCount=0,j.setup&&j.setup.call(a,d,p,k)!==!1||(a.addEventListener?a.addEventListener(o,k,!1):a.attachEvent&&a.attachEvent("on"+o,k))),j.add&&(j.add.call(a,l),l.handler.guid||(l.handler.guid=c.guid)),e?m.splice(m.delegateCount++,0,l):m.push(l),n.event.global[o]=!0)
}a=null
}},remove:function(a,b,c,d,e){var f,g,h,i,j,k,l,m,o,p,q,r=n.hasData(a)&&n._data(a);
if(r&&(k=r.events)){b=(b||"").match(G)||[""],j=b.length;
while(j--){if(h=oa.exec(b[j])||[],o=q=h[1],p=(h[2]||"").split(".").sort(),o){l=n.event.special[o]||{},o=(d?l.delegateType:l.bindType)||o,m=k[o]||[],h=h[2]&&new RegExp("(^|\\.)"+p.join("\\.(?:.*\\.|)")+"(\\.|$)"),i=f=m.length;
while(f--){g=m[f],!e&&q!==g.origType||c&&c.guid!==g.guid||h&&!h.test(g.namespace)||d&&d!==g.selector&&("**"!==d||!g.selector)||(m.splice(f,1),g.selector&&m.delegateCount--,l.remove&&l.remove.call(a,g))
}i&&!m.length&&(l.teardown&&l.teardown.call(a,p,r.handle)!==!1||n.removeEvent(a,o,r.handle),delete k[o])
}else{for(o in k){n.event.remove(a,o+b[j],c,d,!0)
}}}n.isEmptyObject(k)&&(delete r.handle,n._removeData(a,"events"))
}},trigger:function(b,c,e,f){var g,h,i,j,l,m,o,p=[e||d],q=k.call(b,"type")?b.type:b,r=k.call(b,"namespace")?b.namespace.split("."):[];
if(i=m=e=e||d,3!==e.nodeType&&8!==e.nodeType&&!na.test(q+n.event.triggered)&&(q.indexOf(".")>-1&&(r=q.split("."),q=r.shift(),r.sort()),h=q.indexOf(":")<0&&"on"+q,b=b[n.expando]?b:new n.Event(q,"object"==typeof b&&b),b.isTrigger=f?2:3,b.namespace=r.join("."),b.rnamespace=b.namespace?new RegExp("(^|\\.)"+r.join("\\.(?:.*\\.|)")+"(\\.|$)"):null,b.result=void 0,b.target||(b.target=e),c=null==c?[b]:n.makeArray(c,[b]),l=n.event.special[q]||{},f||!l.trigger||l.trigger.apply(e,c)!==!1)){if(!f&&!l.noBubble&&!n.isWindow(e)){for(j=l.delegateType||q,na.test(j+q)||(i=i.parentNode);
i;
i=i.parentNode){p.push(i),m=i
}m===(e.ownerDocument||d)&&p.push(m.defaultView||m.parentWindow||a)
}o=0;
while((i=p[o++])&&!b.isPropagationStopped()){b.type=o>1?j:l.bindType||q,g=(n._data(i,"events")||{})[b.type]&&n._data(i,"handle"),g&&g.apply(i,c),g=h&&i[h],g&&g.apply&&M(i)&&(b.result=g.apply(i,c),b.result===!1&&b.preventDefault())
}if(b.type=q,!f&&!b.isDefaultPrevented()&&(!l._default||l._default.apply(p.pop(),c)===!1)&&M(e)&&h&&e[q]&&!n.isWindow(e)){m=e[h],m&&(e[h]=null),n.event.triggered=q;
try{e[q]()
}catch(s){}n.event.triggered=void 0,m&&(e[h]=m)
}return b.result
}},dispatch:function(a){a=n.event.fix(a);
var b,c,d,f,g,h=[],i=e.call(arguments),j=(n._data(this,"events")||{})[a.type]||[],k=n.event.special[a.type]||{};
if(i[0]=a,a.delegateTarget=this,!k.preDispatch||k.preDispatch.call(this,a)!==!1){h=n.event.handlers.call(this,a,j),b=0;
while((f=h[b++])&&!a.isPropagationStopped()){a.currentTarget=f.elem,c=0;
while((g=f.handlers[c++])&&!a.isImmediatePropagationStopped()){a.rnamespace&&!a.rnamespace.test(g.namespace)||(a.handleObj=g,a.data=g.data,d=((n.event.special[g.origType]||{}).handle||g.handler).apply(f.elem,i),void 0!==d&&(a.result=d)===!1&&(a.preventDefault(),a.stopPropagation()))
}}return k.postDispatch&&k.postDispatch.call(this,a),a.result
}},handlers:function(a,b){var c,d,e,f,g=[],h=b.delegateCount,i=a.target;
if(h&&i.nodeType&&("click"!==a.type||isNaN(a.button)||a.button<1)){for(;
i!=this;
i=i.parentNode||this){if(1===i.nodeType&&(i.disabled!==!0||"click"!==a.type)){for(d=[],c=0;
h>c;
c++){f=b[c],e=f.selector+" ",void 0===d[e]&&(d[e]=f.needsContext?n(e,this).index(i)>-1:n.find(e,this,null,[i]).length),d[e]&&d.push(f)
}d.length&&g.push({elem:i,handlers:d})
}}}return h<b.length&&g.push({elem:this,handlers:b.slice(h)}),g
},fix:function(a){if(a[n.expando]){return a
}var b,c,e,f=a.type,g=a,h=this.fixHooks[f];
h||(this.fixHooks[f]=h=ma.test(f)?this.mouseHooks:la.test(f)?this.keyHooks:{}),e=h.props?this.props.concat(h.props):this.props,a=new n.Event(g),b=e.length;
while(b--){c=e[b],a[c]=g[c]
}return a.target||(a.target=g.srcElement||d),3===a.target.nodeType&&(a.target=a.target.parentNode),a.metaKey=!!a.metaKey,h.filter?h.filter(a,g):a
},props:"altKey bubbles cancelable ctrlKey currentTarget detail eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),fixHooks:{},keyHooks:{props:"char charCode key keyCode".split(" "),filter:function(a,b){return null==a.which&&(a.which=null!=b.charCode?b.charCode:b.keyCode),a
}},mouseHooks:{props:"button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),filter:function(a,b){var c,e,f,g=b.button,h=b.fromElement;
return null==a.pageX&&null!=b.clientX&&(e=a.target.ownerDocument||d,f=e.documentElement,c=e.body,a.pageX=b.clientX+(f&&f.scrollLeft||c&&c.scrollLeft||0)-(f&&f.clientLeft||c&&c.clientLeft||0),a.pageY=b.clientY+(f&&f.scrollTop||c&&c.scrollTop||0)-(f&&f.clientTop||c&&c.clientTop||0)),!a.relatedTarget&&h&&(a.relatedTarget=h===a.target?b.toElement:h),a.which||void 0===g||(a.which=1&g?1:2&g?3:4&g?2:0),a
}},special:{load:{noBubble:!0},focus:{trigger:function(){if(this!==ra()&&this.focus){try{return this.focus(),!1
}catch(a){}}},delegateType:"focusin"},blur:{trigger:function(){return this===ra()&&this.blur?(this.blur(),!1):void 0
},delegateType:"focusout"},click:{trigger:function(){return n.nodeName(this,"input")&&"checkbox"===this.type&&this.click?(this.click(),!1):void 0
},_default:function(a){return n.nodeName(a.target,"a")
}},beforeunload:{postDispatch:function(a){void 0!==a.result&&a.originalEvent&&(a.originalEvent.returnValue=a.result)
}}},simulate:function(a,b,c){var d=n.extend(new n.Event,c,{type:a,isSimulated:!0});
n.event.trigger(d,null,b),d.isDefaultPrevented()&&c.preventDefault()
}},n.removeEvent=d.removeEventListener?function(a,b,c){a.removeEventListener&&a.removeEventListener(b,c)
}:function(a,b,c){var d="on"+b;
a.detachEvent&&("undefined"==typeof a[d]&&(a[d]=null),a.detachEvent(d,c))
},n.Event=function(a,b){return this instanceof n.Event?(a&&a.type?(this.originalEvent=a,this.type=a.type,this.isDefaultPrevented=a.defaultPrevented||void 0===a.defaultPrevented&&a.returnValue===!1?pa:qa):this.type=a,b&&n.extend(this,b),this.timeStamp=a&&a.timeStamp||n.now(),void (this[n.expando]=!0)):new n.Event(a,b)
},n.Event.prototype={constructor:n.Event,isDefaultPrevented:qa,isPropagationStopped:qa,isImmediatePropagationStopped:qa,preventDefault:function(){var a=this.originalEvent;
this.isDefaultPrevented=pa,a&&(a.preventDefault?a.preventDefault():a.returnValue=!1)
},stopPropagation:function(){var a=this.originalEvent;
this.isPropagationStopped=pa,a&&!this.isSimulated&&(a.stopPropagation&&a.stopPropagation(),a.cancelBubble=!0)
},stopImmediatePropagation:function(){var a=this.originalEvent;
this.isImmediatePropagationStopped=pa,a&&a.stopImmediatePropagation&&a.stopImmediatePropagation(),this.stopPropagation()
}},n.each({mouseenter:"mouseover",mouseleave:"mouseout",pointerenter:"pointerover",pointerleave:"pointerout"},function(a,b){n.event.special[a]={delegateType:b,bindType:b,handle:function(a){var c,d=this,e=a.relatedTarget,f=a.handleObj;
return e&&(e===d||n.contains(d,e))||(a.type=f.origType,c=f.handler.apply(this,arguments),a.type=b),c
}}
}),l.submit||(n.event.special.submit={setup:function(){return n.nodeName(this,"form")?!1:void n.event.add(this,"click._submit keypress._submit",function(a){var b=a.target,c=n.nodeName(b,"input")||n.nodeName(b,"button")?n.prop(b,"form"):void 0;
c&&!n._data(c,"submit")&&(n.event.add(c,"submit._submit",function(a){a._submitBubble=!0
}),n._data(c,"submit",!0))
})
},postDispatch:function(a){a._submitBubble&&(delete a._submitBubble,this.parentNode&&!a.isTrigger&&n.event.simulate("submit",this.parentNode,a))
},teardown:function(){return n.nodeName(this,"form")?!1:void n.event.remove(this,"._submit")
}}),l.change||(n.event.special.change={setup:function(){return ka.test(this.nodeName)?("checkbox"!==this.type&&"radio"!==this.type||(n.event.add(this,"propertychange._change",function(a){"checked"===a.originalEvent.propertyName&&(this._justChanged=!0)
}),n.event.add(this,"click._change",function(a){this._justChanged&&!a.isTrigger&&(this._justChanged=!1),n.event.simulate("change",this,a)
})),!1):void n.event.add(this,"beforeactivate._change",function(a){var b=a.target;
ka.test(b.nodeName)&&!n._data(b,"change")&&(n.event.add(b,"change._change",function(a){!this.parentNode||a.isSimulated||a.isTrigger||n.event.simulate("change",this.parentNode,a)
}),n._data(b,"change",!0))
})
},handle:function(a){var b=a.target;
return this!==b||a.isSimulated||a.isTrigger||"radio"!==b.type&&"checkbox"!==b.type?a.handleObj.handler.apply(this,arguments):void 0
},teardown:function(){return n.event.remove(this,"._change"),!ka.test(this.nodeName)
}}),l.focusin||n.each({focus:"focusin",blur:"focusout"},function(a,b){var c=function(a){n.event.simulate(b,a.target,n.event.fix(a))
};
n.event.special[b]={setup:function(){var d=this.ownerDocument||this,e=n._data(d,b);
e||d.addEventListener(a,c,!0),n._data(d,b,(e||0)+1)
},teardown:function(){var d=this.ownerDocument||this,e=n._data(d,b)-1;
e?n._data(d,b,e):(d.removeEventListener(a,c,!0),n._removeData(d,b))
}}
}),n.fn.extend({on:function(a,b,c,d){return sa(this,a,b,c,d)
},one:function(a,b,c,d){return sa(this,a,b,c,d,1)
},off:function(a,b,c){var d,e;
if(a&&a.preventDefault&&a.handleObj){return d=a.handleObj,n(a.delegateTarget).off(d.namespace?d.origType+"."+d.namespace:d.origType,d.selector,d.handler),this
}if("object"==typeof a){for(e in a){this.off(e,b,a[e])
}return this
}return b!==!1&&"function"!=typeof b||(c=b,b=void 0),c===!1&&(c=qa),this.each(function(){n.event.remove(this,a,c,b)
})
},trigger:function(a,b){return this.each(function(){n.event.trigger(a,b,this)
})
},triggerHandler:function(a,b){var c=this[0];
return c?n.event.trigger(a,b,c,!0):void 0
}});
var ta=/ jQuery\d+="(?:null|\d+)"/g,ua=new RegExp("<(?:"+ba+")[\\s/>]","i"),va=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:-]+)[^>]*)\/>/gi,wa=/<script|<style|<link/i,xa=/checked\s*(?:[^=]|=\s*.checked.)/i,ya=/^true\/(.*)/,za=/^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,Aa=ca(d),Ba=Aa.appendChild(d.createElement("div"));
function Ca(a,b){return n.nodeName(a,"table")&&n.nodeName(11!==b.nodeType?b:b.firstChild,"tr")?a.getElementsByTagName("tbody")[0]||a.appendChild(a.ownerDocument.createElement("tbody")):a
}function Da(a){return a.type=(null!==n.find.attr(a,"type"))+"/"+a.type,a
}function Ea(a){var b=ya.exec(a.type);
return b?a.type=b[1]:a.removeAttribute("type"),a
}function Fa(a,b){if(1===b.nodeType&&n.hasData(a)){var c,d,e,f=n._data(a),g=n._data(b,f),h=f.events;
if(h){delete g.handle,g.events={};
for(c in h){for(d=0,e=h[c].length;
e>d;
d++){n.event.add(b,c,h[c][d])
}}}g.data&&(g.data=n.extend({},g.data))
}}function Ga(a,b){var c,d,e;
if(1===b.nodeType){if(c=b.nodeName.toLowerCase(),!l.noCloneEvent&&b[n.expando]){e=n._data(b);
for(d in e.events){n.removeEvent(b,d,e.handle)
}b.removeAttribute(n.expando)
}"script"===c&&b.text!==a.text?(Da(b).text=a.text,Ea(b)):"object"===c?(b.parentNode&&(b.outerHTML=a.outerHTML),l.html5Clone&&a.innerHTML&&!n.trim(b.innerHTML)&&(b.innerHTML=a.innerHTML)):"input"===c&&Z.test(a.type)?(b.defaultChecked=b.checked=a.checked,b.value!==a.value&&(b.value=a.value)):"option"===c?b.defaultSelected=b.selected=a.defaultSelected:"input"!==c&&"textarea"!==c||(b.defaultValue=a.defaultValue)
}}function Ha(a,b,c,d){b=f.apply([],b);
var e,g,h,i,j,k,m=0,o=a.length,p=o-1,q=b[0],r=n.isFunction(q);
if(r||o>1&&"string"==typeof q&&!l.checkClone&&xa.test(q)){return a.each(function(e){var f=a.eq(e);
r&&(b[0]=q.call(this,e,f.html())),Ha(f,b,c,d)
})
}if(o&&(k=ja(b,a[0].ownerDocument,!1,a,d),e=k.firstChild,1===k.childNodes.length&&(k=e),e||d)){for(i=n.map(ea(k,"script"),Da),h=i.length;
o>m;
m++){g=k,m!==p&&(g=n.clone(g,!0,!0),h&&n.merge(i,ea(g,"script"))),c.call(a[m],g,m)
}if(h){for(j=i[i.length-1].ownerDocument,n.map(i,Ea),m=0;
h>m;
m++){g=i[m],_.test(g.type||"")&&!n._data(g,"globalEval")&&n.contains(j,g)&&(g.src?n._evalUrl&&n._evalUrl(g.src):n.globalEval((g.text||g.textContent||g.innerHTML||"").replace(za,"")))
}}k=e=null
}return a
}function Ia(a,b,c){for(var d,e=b?n.filter(b,a):a,f=0;
null!=(d=e[f]);
f++){c||1!==d.nodeType||n.cleanData(ea(d)),d.parentNode&&(c&&n.contains(d.ownerDocument,d)&&fa(ea(d,"script")),d.parentNode.removeChild(d))
}return a
}n.extend({htmlPrefilter:function(a){return a.replace(va,"<$1></$2>")
},clone:function(a,b,c){var d,e,f,g,h,i=n.contains(a.ownerDocument,a);
if(l.html5Clone||n.isXMLDoc(a)||!ua.test("<"+a.nodeName+">")?f=a.cloneNode(!0):(Ba.innerHTML=a.outerHTML,Ba.removeChild(f=Ba.firstChild)),!(l.noCloneEvent&&l.noCloneChecked||1!==a.nodeType&&11!==a.nodeType||n.isXMLDoc(a))){for(d=ea(f),h=ea(a),g=0;
null!=(e=h[g]);
++g){d[g]&&Ga(e,d[g])
}}if(b){if(c){for(h=h||ea(a),d=d||ea(f),g=0;
null!=(e=h[g]);
g++){Fa(e,d[g])
}}else{Fa(a,f)
}}return d=ea(f,"script"),d.length>0&&fa(d,!i&&ea(a,"script")),d=h=e=null,f
},cleanData:function(a,b){for(var d,e,f,g,h=0,i=n.expando,j=n.cache,k=l.attributes,m=n.event.special;
null!=(d=a[h]);
h++){if((b||M(d))&&(f=d[i],g=f&&j[f])){if(g.events){for(e in g.events){m[e]?n.event.remove(d,e):n.removeEvent(d,e,g.handle)
}}j[f]&&(delete j[f],k||"undefined"==typeof d.removeAttribute?d[i]=void 0:d.removeAttribute(i),c.push(f))
}}}}),n.fn.extend({domManip:Ha,detach:function(a){return Ia(this,a,!0)
},remove:function(a){return Ia(this,a)
},text:function(a){return Y(this,function(a){return void 0===a?n.text(this):this.empty().append((this[0]&&this[0].ownerDocument||d).createTextNode(a))
},null,a,arguments.length)
},append:function(){return Ha(this,arguments,function(a){if(1===this.nodeType||11===this.nodeType||9===this.nodeType){var b=Ca(this,a);
b.appendChild(a)
}})
},prepend:function(){return Ha(this,arguments,function(a){if(1===this.nodeType||11===this.nodeType||9===this.nodeType){var b=Ca(this,a);
b.insertBefore(a,b.firstChild)
}})
},before:function(){return Ha(this,arguments,function(a){this.parentNode&&this.parentNode.insertBefore(a,this)
})
},after:function(){return Ha(this,arguments,function(a){this.parentNode&&this.parentNode.insertBefore(a,this.nextSibling)
})
},empty:function(){for(var a,b=0;
null!=(a=this[b]);
b++){1===a.nodeType&&n.cleanData(ea(a,!1));
while(a.firstChild){a.removeChild(a.firstChild)
}a.options&&n.nodeName(a,"select")&&(a.options.length=0)
}return this
},clone:function(a,b){return a=null==a?!1:a,b=null==b?a:b,this.map(function(){return n.clone(this,a,b)
})
},html:function(a){return Y(this,function(a){var b=this[0]||{},c=0,d=this.length;
if(void 0===a){return 1===b.nodeType?b.innerHTML.replace(ta,""):void 0
}if("string"==typeof a&&!wa.test(a)&&(l.htmlSerialize||!ua.test(a))&&(l.leadingWhitespace||!aa.test(a))&&!da[($.exec(a)||["",""])[1].toLowerCase()]){a=n.htmlPrefilter(a);
try{for(;
d>c;
c++){b=this[c]||{},1===b.nodeType&&(n.cleanData(ea(b,!1)),b.innerHTML=a)
}b=0
}catch(e){}}b&&this.empty().append(a)
},null,a,arguments.length)
},replaceWith:function(){var a=[];
return Ha(this,arguments,function(b){var c=this.parentNode;
n.inArray(this,a)<0&&(n.cleanData(ea(this)),c&&c.replaceChild(b,this))
},a)
}}),n.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(a,b){n.fn[a]=function(a){for(var c,d=0,e=[],f=n(a),h=f.length-1;
h>=d;
d++){c=d===h?this:this.clone(!0),n(f[d])[b](c),g.apply(e,c.get())
}return this.pushStack(e)
}
});
var Ja,Ka={HTML:"block",BODY:"block"};
function La(a,b){var c=n(b.createElement(a)).appendTo(b.body),d=n.css(c[0],"display");
return c.detach(),d
}function Ma(a){var b=d,c=Ka[a];
return c||(c=La(a,b),"none"!==c&&c||(Ja=(Ja||n("<iframe frameborder='0' width='0' height='0'/>")).appendTo(b.documentElement),b=(Ja[0].contentWindow||Ja[0].contentDocument).document,b.write(),b.close(),c=La(a,b),Ja.detach()),Ka[a]=c),c
}var Na=/^margin/,Oa=new RegExp("^("+T+")(?!px)[a-z%]+$","i"),Pa=function(a,b,c,d){var e,f,g={};
for(f in b){g[f]=a.style[f],a.style[f]=b[f]
}e=c.apply(a,d||[]);
for(f in b){a.style[f]=g[f]
}return e
},Qa=d.documentElement;
!function(){var b,c,e,f,g,h,i=d.createElement("div"),j=d.createElement("div");
if(j.style){j.style.cssText="float:left;opacity:.5",l.opacity="0.5"===j.style.opacity,l.cssFloat=!!j.style.cssFloat,j.style.backgroundClip="content-box",j.cloneNode(!0).style.backgroundClip="",l.clearCloneStyle="content-box"===j.style.backgroundClip,i=d.createElement("div"),i.style.cssText="border:0;width:8px;height:0;top:0;left:-9999px;padding:0;margin-top:1px;position:absolute",j.innerHTML="",i.appendChild(j),l.boxSizing=""===j.style.boxSizing||""===j.style.MozBoxSizing||""===j.style.WebkitBoxSizing,n.extend(l,{reliableHiddenOffsets:function(){return null==b&&k(),f
},boxSizingReliable:function(){return null==b&&k(),e
},pixelMarginRight:function(){return null==b&&k(),c
},pixelPosition:function(){return null==b&&k(),b
},reliableMarginRight:function(){return null==b&&k(),g
},reliableMarginLeft:function(){return null==b&&k(),h
}});
function k(){var k,l,m=d.documentElement;
m.appendChild(i),j.style.cssText="-webkit-box-sizing:border-box;box-sizing:border-box;position:relative;display:block;margin:auto;border:1px;padding:1px;top:1%;width:50%",b=e=h=!1,c=g=!0,a.getComputedStyle&&(l=a.getComputedStyle(j),b="1%"!==(l||{}).top,h="2px"===(l||{}).marginLeft,e="4px"===(l||{width:"4px"}).width,j.style.marginRight="50%",c="4px"===(l||{marginRight:"4px"}).marginRight,k=j.appendChild(d.createElement("div")),k.style.cssText=j.style.cssText="-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:0",k.style.marginRight=k.style.width="0",j.style.width="1px",g=!parseFloat((a.getComputedStyle(k)||{}).marginRight),j.removeChild(k)),j.style.display="none",f=0===j.getClientRects().length,f&&(j.style.display="",j.innerHTML="<table><tr><td></td><td>t</td></tr></table>",k=j.getElementsByTagName("td"),k[0].style.cssText="margin:0;border:0;padding:0;display:none",f=0===k[0].offsetHeight,f&&(k[0].style.display="",k[1].style.display="none",f=0===k[0].offsetHeight)),m.removeChild(i)
}}}();
var Ra,Sa,Ta=/^(top|right|bottom|left)$/;
a.getComputedStyle?(Ra=function(b){var c=b.ownerDocument.defaultView;
return c&&c.opener||(c=a),c.getComputedStyle(b)
},Sa=function(a,b,c){var d,e,f,g,h=a.style;
return c=c||Ra(a),g=c?c.getPropertyValue(b)||c[b]:void 0,""!==g&&void 0!==g||n.contains(a.ownerDocument,a)||(g=n.style(a,b)),c&&!l.pixelMarginRight()&&Oa.test(g)&&Na.test(b)&&(d=h.width,e=h.minWidth,f=h.maxWidth,h.minWidth=h.maxWidth=h.width=g,g=c.width,h.width=d,h.minWidth=e,h.maxWidth=f),void 0===g?g:g+""
}):Qa.currentStyle&&(Ra=function(a){return a.currentStyle
},Sa=function(a,b,c){var d,e,f,g,h=a.style;
return c=c||Ra(a),g=c?c[b]:void 0,null==g&&h&&h[b]&&(g=h[b]),Oa.test(g)&&!Ta.test(b)&&(d=h.left,e=a.runtimeStyle,f=e&&e.left,f&&(e.left=a.currentStyle.left),h.left="fontSize"===b?"1em":g,g=h.pixelLeft+"px",h.left=d,f&&(e.left=f)),void 0===g?g:g+""||"auto"
});
function Ua(a,b){return{get:function(){return a()?void delete this.get:(this.get=b).apply(this,arguments)
}}
}var Va=/alpha\([^)]*\)/i,Wa=/opacity\s*=\s*([^)]*)/i,Xa=/^(none|table(?!-c[ea]).+)/,Ya=new RegExp("^("+T+")(.*)$","i"),Za={position:"absolute",visibility:"hidden",display:"block"},$a={letterSpacing:"0",fontWeight:"400"},_a=["Webkit","O","Moz","ms"],ab=d.createElement("div").style;
function bb(a){if(a in ab){return a
}var b=a.charAt(0).toUpperCase()+a.slice(1),c=_a.length;
while(c--){if(a=_a[c]+b,a in ab){return a
}}}function cb(a,b){for(var c,d,e,f=[],g=0,h=a.length;
h>g;
g++){d=a[g],d.style&&(f[g]=n._data(d,"olddisplay"),c=d.style.display,b?(f[g]||"none"!==c||(d.style.display=""),""===d.style.display&&W(d)&&(f[g]=n._data(d,"olddisplay",Ma(d.nodeName)))):(e=W(d),(c&&"none"!==c||!e)&&n._data(d,"olddisplay",e?c:n.css(d,"display"))))
}for(g=0;
h>g;
g++){d=a[g],d.style&&(b&&"none"!==d.style.display&&""!==d.style.display||(d.style.display=b?f[g]||"":"none"))
}return a
}function db(a,b,c){var d=Ya.exec(b);
return d?Math.max(0,d[1]-(c||0))+(d[2]||"px"):b
}function eb(a,b,c,d,e){for(var f=c===(d?"border":"content")?4:"width"===b?1:0,g=0;
4>f;
f+=2){"margin"===c&&(g+=n.css(a,c+V[f],!0,e)),d?("content"===c&&(g-=n.css(a,"padding"+V[f],!0,e)),"margin"!==c&&(g-=n.css(a,"border"+V[f]+"Width",!0,e))):(g+=n.css(a,"padding"+V[f],!0,e),"padding"!==c&&(g+=n.css(a,"border"+V[f]+"Width",!0,e)))
}return g
}function fb(b,c,e){var f=!0,g="width"===c?b.offsetWidth:b.offsetHeight,h=Ra(b),i=l.boxSizing&&"border-box"===n.css(b,"boxSizing",!1,h);
if(d.msFullscreenElement&&a.top!==a&&b.getClientRects().length&&(g=Math.round(100*b.getBoundingClientRect()[c])),0>=g||null==g){if(g=Sa(b,c,h),(0>g||null==g)&&(g=b.style[c]),Oa.test(g)){return g
}f=i&&(l.boxSizingReliable()||g===b.style[c]),g=parseFloat(g)||0
}return g+eb(b,c,e||(i?"border":"content"),f,h)+"px"
}n.extend({cssHooks:{opacity:{get:function(a,b){if(b){var c=Sa(a,"opacity");
return""===c?"1":c
}}}},cssNumber:{animationIterationCount:!0,columnCount:!0,fillOpacity:!0,flexGrow:!0,flexShrink:!0,fontWeight:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,widows:!0,zIndex:!0,zoom:!0},cssProps:{"float":l.cssFloat?"cssFloat":"styleFloat"},style:function(a,b,c,d){if(a&&3!==a.nodeType&&8!==a.nodeType&&a.style){var e,f,g,h=n.camelCase(b),i=a.style;
if(b=n.cssProps[h]||(n.cssProps[h]=bb(h)||h),g=n.cssHooks[b]||n.cssHooks[h],void 0===c){return g&&"get" in g&&void 0!==(e=g.get(a,!1,d))?e:i[b]
}if(f=typeof c,"string"===f&&(e=U.exec(c))&&e[1]&&(c=X(a,b,e),f="number"),null!=c&&c===c&&("number"===f&&(c+=e&&e[3]||(n.cssNumber[h]?"":"px")),l.clearCloneStyle||""!==c||0!==b.indexOf("background")||(i[b]="inherit"),!(g&&"set" in g&&void 0===(c=g.set(a,c,d))))){try{i[b]=c
}catch(j){}}}},css:function(a,b,c,d){var e,f,g,h=n.camelCase(b);
return b=n.cssProps[h]||(n.cssProps[h]=bb(h)||h),g=n.cssHooks[b]||n.cssHooks[h],g&&"get" in g&&(f=g.get(a,!0,c)),void 0===f&&(f=Sa(a,b,d)),"normal"===f&&b in $a&&(f=$a[b]),""===c||c?(e=parseFloat(f),c===!0||isFinite(e)?e||0:f):f
}}),n.each(["height","width"],function(a,b){n.cssHooks[b]={get:function(a,c,d){return c?Xa.test(n.css(a,"display"))&&0===a.offsetWidth?Pa(a,Za,function(){return fb(a,b,d)
}):fb(a,b,d):void 0
},set:function(a,c,d){var e=d&&Ra(a);
return db(a,c,d?eb(a,b,d,l.boxSizing&&"border-box"===n.css(a,"boxSizing",!1,e),e):0)
}}
}),l.opacity||(n.cssHooks.opacity={get:function(a,b){return Wa.test((b&&a.currentStyle?a.currentStyle.filter:a.style.filter)||"")?0.01*parseFloat(RegExp.$1)+"":b?"1":""
},set:function(a,b){var c=a.style,d=a.currentStyle,e=n.isNumeric(b)?"alpha(opacity="+100*b+")":"",f=d&&d.filter||c.filter||"";
c.zoom=1,(b>=1||""===b)&&""===n.trim(f.replace(Va,""))&&c.removeAttribute&&(c.removeAttribute("filter"),""===b||d&&!d.filter)||(c.filter=Va.test(f)?f.replace(Va,e):f+" "+e)
}}),n.cssHooks.marginRight=Ua(l.reliableMarginRight,function(a,b){return b?Pa(a,{display:"inline-block"},Sa,[a,"marginRight"]):void 0
}),n.cssHooks.marginLeft=Ua(l.reliableMarginLeft,function(a,b){return b?(parseFloat(Sa(a,"marginLeft"))||(n.contains(a.ownerDocument,a)?a.getBoundingClientRect().left-Pa(a,{marginLeft:0},function(){return a.getBoundingClientRect().left
}):0))+"px":void 0
}),n.each({margin:"",padding:"",border:"Width"},function(a,b){n.cssHooks[a+b]={expand:function(c){for(var d=0,e={},f="string"==typeof c?c.split(" "):[c];
4>d;
d++){e[a+V[d]+b]=f[d]||f[d-2]||f[0]
}return e
}},Na.test(a)||(n.cssHooks[a+b].set=db)
}),n.fn.extend({css:function(a,b){return Y(this,function(a,b,c){var d,e,f={},g=0;
if(n.isArray(b)){for(d=Ra(a),e=b.length;
e>g;
g++){f[b[g]]=n.css(a,b[g],!1,d)
}return f
}return void 0!==c?n.style(a,b,c):n.css(a,b)
},a,b,arguments.length>1)
},show:function(){return cb(this,!0)
},hide:function(){return cb(this)
},toggle:function(a){return"boolean"==typeof a?a?this.show():this.hide():this.each(function(){W(this)?n(this).show():n(this).hide()
})
}});
function gb(a,b,c,d,e){return new gb.prototype.init(a,b,c,d,e)
}n.Tween=gb,gb.prototype={constructor:gb,init:function(a,b,c,d,e,f){this.elem=a,this.prop=c,this.easing=e||n.easing._default,this.options=b,this.start=this.now=this.cur(),this.end=d,this.unit=f||(n.cssNumber[c]?"":"px")
},cur:function(){var a=gb.propHooks[this.prop];
return a&&a.get?a.get(this):gb.propHooks._default.get(this)
},run:function(a){var b,c=gb.propHooks[this.prop];
return this.options.duration?this.pos=b=n.easing[this.easing](a,this.options.duration*a,0,1,this.options.duration):this.pos=b=a,this.now=(this.end-this.start)*b+this.start,this.options.step&&this.options.step.call(this.elem,this.now,this),c&&c.set?c.set(this):gb.propHooks._default.set(this),this
}},gb.prototype.init.prototype=gb.prototype,gb.propHooks={_default:{get:function(a){var b;
return 1!==a.elem.nodeType||null!=a.elem[a.prop]&&null==a.elem.style[a.prop]?a.elem[a.prop]:(b=n.css(a.elem,a.prop,""),b&&"auto"!==b?b:0)
},set:function(a){n.fx.step[a.prop]?n.fx.step[a.prop](a):1!==a.elem.nodeType||null==a.elem.style[n.cssProps[a.prop]]&&!n.cssHooks[a.prop]?a.elem[a.prop]=a.now:n.style(a.elem,a.prop,a.now+a.unit)
}}},gb.propHooks.scrollTop=gb.propHooks.scrollLeft={set:function(a){a.elem.nodeType&&a.elem.parentNode&&(a.elem[a.prop]=a.now)
}},n.easing={linear:function(a){return a
},swing:function(a){return 0.5-Math.cos(a*Math.PI)/2
},_default:"swing"},n.fx=gb.prototype.init,n.fx.step={};
var hb,ib,jb=/^(?:toggle|show|hide)$/,kb=/queueHooks$/;
function lb(){return a.setTimeout(function(){hb=void 0
}),hb=n.now()
}function mb(a,b){var c,d={height:a},e=0;
for(b=b?1:0;
4>e;
e+=2-b){c=V[e],d["margin"+c]=d["padding"+c]=a
}return b&&(d.opacity=d.width=a),d
}function nb(a,b,c){for(var d,e=(qb.tweeners[b]||[]).concat(qb.tweeners["*"]),f=0,g=e.length;
g>f;
f++){if(d=e[f].call(c,b,a)){return d
}}}function ob(a,b,c){var d,e,f,g,h,i,j,k,m=this,o={},p=a.style,q=a.nodeType&&W(a),r=n._data(a,"fxshow");
c.queue||(h=n._queueHooks(a,"fx"),null==h.unqueued&&(h.unqueued=0,i=h.empty.fire,h.empty.fire=function(){h.unqueued||i()
}),h.unqueued++,m.always(function(){m.always(function(){h.unqueued--,n.queue(a,"fx").length||h.empty.fire()
})
})),1===a.nodeType&&("height" in b||"width" in b)&&(c.overflow=[p.overflow,p.overflowX,p.overflowY],j=n.css(a,"display"),k="none"===j?n._data(a,"olddisplay")||Ma(a.nodeName):j,"inline"===k&&"none"===n.css(a,"float")&&(l.inlineBlockNeedsLayout&&"inline"!==Ma(a.nodeName)?p.zoom=1:p.display="inline-block")),c.overflow&&(p.overflow="hidden",l.shrinkWrapBlocks()||m.always(function(){p.overflow=c.overflow[0],p.overflowX=c.overflow[1],p.overflowY=c.overflow[2]
}));
for(d in b){if(e=b[d],jb.exec(e)){if(delete b[d],f=f||"toggle"===e,e===(q?"hide":"show")){if("show"!==e||!r||void 0===r[d]){continue
}q=!0
}o[d]=r&&r[d]||n.style(a,d)
}else{j=void 0
}}if(n.isEmptyObject(o)){"inline"===("none"===j?Ma(a.nodeName):j)&&(p.display=j)
}else{r?"hidden" in r&&(q=r.hidden):r=n._data(a,"fxshow",{}),f&&(r.hidden=!q),q?n(a).show():m.done(function(){n(a).hide()
}),m.done(function(){var b;
n._removeData(a,"fxshow");
for(b in o){n.style(a,b,o[b])
}});
for(d in o){g=nb(q?r[d]:0,d,m),d in r||(r[d]=g.start,q&&(g.end=g.start,g.start="width"===d||"height"===d?1:0))
}}}function pb(a,b){var c,d,e,f,g;
for(c in a){if(d=n.camelCase(c),e=b[d],f=a[c],n.isArray(f)&&(e=f[1],f=a[c]=f[0]),c!==d&&(a[d]=f,delete a[c]),g=n.cssHooks[d],g&&"expand" in g){f=g.expand(f),delete a[d];
for(c in f){c in a||(a[c]=f[c],b[c]=e)
}}else{b[d]=e
}}}function qb(a,b,c){var d,e,f=0,g=qb.prefilters.length,h=n.Deferred().always(function(){delete i.elem
}),i=function(){if(e){return !1
}for(var b=hb||lb(),c=Math.max(0,j.startTime+j.duration-b),d=c/j.duration||0,f=1-d,g=0,i=j.tweens.length;
i>g;
g++){j.tweens[g].run(f)
}return h.notifyWith(a,[j,f,c]),1>f&&i?c:(h.resolveWith(a,[j]),!1)
},j=h.promise({elem:a,props:n.extend({},b),opts:n.extend(!0,{specialEasing:{},easing:n.easing._default},c),originalProperties:b,originalOptions:c,startTime:hb||lb(),duration:c.duration,tweens:[],createTween:function(b,c){var d=n.Tween(a,j.opts,b,c,j.opts.specialEasing[b]||j.opts.easing);
return j.tweens.push(d),d
},stop:function(b){var c=0,d=b?j.tweens.length:0;
if(e){return this
}for(e=!0;
d>c;
c++){j.tweens[c].run(1)
}return b?(h.notifyWith(a,[j,1,0]),h.resolveWith(a,[j,b])):h.rejectWith(a,[j,b]),this
}}),k=j.props;
for(pb(k,j.opts.specialEasing);
g>f;
f++){if(d=qb.prefilters[f].call(j,a,k,j.opts)){return n.isFunction(d.stop)&&(n._queueHooks(j.elem,j.opts.queue).stop=n.proxy(d.stop,d)),d
}}return n.map(k,nb,j),n.isFunction(j.opts.start)&&j.opts.start.call(a,j),n.fx.timer(n.extend(i,{elem:a,anim:j,queue:j.opts.queue})),j.progress(j.opts.progress).done(j.opts.done,j.opts.complete).fail(j.opts.fail).always(j.opts.always)
}n.Animation=n.extend(qb,{tweeners:{"*":[function(a,b){var c=this.createTween(a,b);
return X(c.elem,a,U.exec(b),c),c
}]},tweener:function(a,b){n.isFunction(a)?(b=a,a=["*"]):a=a.match(G);
for(var c,d=0,e=a.length;
e>d;
d++){c=a[d],qb.tweeners[c]=qb.tweeners[c]||[],qb.tweeners[c].unshift(b)
}},prefilters:[ob],prefilter:function(a,b){b?qb.prefilters.unshift(a):qb.prefilters.push(a)
}}),n.speed=function(a,b,c){var d=a&&"object"==typeof a?n.extend({},a):{complete:c||!c&&b||n.isFunction(a)&&a,duration:a,easing:c&&b||b&&!n.isFunction(b)&&b};
return d.duration=n.fx.off?0:"number"==typeof d.duration?d.duration:d.duration in n.fx.speeds?n.fx.speeds[d.duration]:n.fx.speeds._default,null!=d.queue&&d.queue!==!0||(d.queue="fx"),d.old=d.complete,d.complete=function(){n.isFunction(d.old)&&d.old.call(this),d.queue&&n.dequeue(this,d.queue)
},d
},n.fn.extend({fadeTo:function(a,b,c,d){return this.filter(W).css("opacity",0).show().end().animate({opacity:b},a,c,d)
},animate:function(a,b,c,d){var e=n.isEmptyObject(a),f=n.speed(b,c,d),g=function(){var b=qb(this,n.extend({},a),f);
(e||n._data(this,"finish"))&&b.stop(!0)
};
return g.finish=g,e||f.queue===!1?this.each(g):this.queue(f.queue,g)
},stop:function(a,b,c){var d=function(a){var b=a.stop;
delete a.stop,b(c)
};
return"string"!=typeof a&&(c=b,b=a,a=void 0),b&&a!==!1&&this.queue(a||"fx",[]),this.each(function(){var b=!0,e=null!=a&&a+"queueHooks",f=n.timers,g=n._data(this);
if(e){g[e]&&g[e].stop&&d(g[e])
}else{for(e in g){g[e]&&g[e].stop&&kb.test(e)&&d(g[e])
}}for(e=f.length;
e--;
){f[e].elem!==this||null!=a&&f[e].queue!==a||(f[e].anim.stop(c),b=!1,f.splice(e,1))
}!b&&c||n.dequeue(this,a)
})
},finish:function(a){return a!==!1&&(a=a||"fx"),this.each(function(){var b,c=n._data(this),d=c[a+"queue"],e=c[a+"queueHooks"],f=n.timers,g=d?d.length:0;
for(c.finish=!0,n.queue(this,a,[]),e&&e.stop&&e.stop.call(this,!0),b=f.length;
b--;
){f[b].elem===this&&f[b].queue===a&&(f[b].anim.stop(!0),f.splice(b,1))
}for(b=0;
g>b;
b++){d[b]&&d[b].finish&&d[b].finish.call(this)
}delete c.finish
})
}}),n.each(["toggle","show","hide"],function(a,b){var c=n.fn[b];
n.fn[b]=function(a,d,e){return null==a||"boolean"==typeof a?c.apply(this,arguments):this.animate(mb(b,!0),a,d,e)
}
}),n.each({slideDown:mb("show"),slideUp:mb("hide"),slideToggle:mb("toggle"),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"},fadeToggle:{opacity:"toggle"}},function(a,b){n.fn[a]=function(a,c,d){return this.animate(b,a,c,d)
}
}),n.timers=[],n.fx.tick=function(){var a,b=n.timers,c=0;
for(hb=n.now();
c<b.length;
c++){a=b[c],a()||b[c]!==a||b.splice(c--,1)
}b.length||n.fx.stop(),hb=void 0
},n.fx.timer=function(a){n.timers.push(a),a()?n.fx.start():n.timers.pop()
},n.fx.interval=13,n.fx.start=function(){ib||(ib=a.setInterval(n.fx.tick,n.fx.interval))
},n.fx.stop=function(){a.clearInterval(ib),ib=null
},n.fx.speeds={slow:600,fast:200,_default:400},n.fn.delay=function(b,c){return b=n.fx?n.fx.speeds[b]||b:b,c=c||"fx",this.queue(c,function(c,d){var e=a.setTimeout(c,b);
d.stop=function(){a.clearTimeout(e)
}
})
},function(){var a,b=d.createElement("input"),c=d.createElement("div"),e=d.createElement("select"),f=e.appendChild(d.createElement("option"));
c=d.createElement("div"),c.setAttribute("className","t"),c.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",a=c.getElementsByTagName("a")[0],b.setAttribute("type","checkbox"),c.appendChild(b),a=c.getElementsByTagName("a")[0],a.style.cssText="top:1px",l.getSetAttribute="t"!==c.className,l.style=/top/.test(a.getAttribute("style")),l.hrefNormalized="/a"===a.getAttribute("href"),l.checkOn=!!b.value,l.optSelected=f.selected,l.enctype=!!d.createElement("form").enctype,e.disabled=!0,l.optDisabled=!f.disabled,b=d.createElement("input"),b.setAttribute("value",""),l.input=""===b.getAttribute("value"),b.value="t",b.setAttribute("type","radio"),l.radioValue="t"===b.value
}();
var rb=/\r/g,sb=/[\x20\t\r\n\f]+/g;
n.fn.extend({val:function(a){var b,c,d,e=this[0];
if(arguments.length){return d=n.isFunction(a),this.each(function(c){var e;
1===this.nodeType&&(e=d?a.call(this,c,n(this).val()):a,null==e?e="":"number"==typeof e?e+="":n.isArray(e)&&(e=n.map(e,function(a){return null==a?"":a+""
})),b=n.valHooks[this.type]||n.valHooks[this.nodeName.toLowerCase()],b&&"set" in b&&void 0!==b.set(this,e,"value")||(this.value=e))
})
}if(e){return b=n.valHooks[e.type]||n.valHooks[e.nodeName.toLowerCase()],b&&"get" in b&&void 0!==(c=b.get(e,"value"))?c:(c=e.value,"string"==typeof c?c.replace(rb,""):null==c?"":c)
}}}),n.extend({valHooks:{option:{get:function(a){var b=n.find.attr(a,"value");
return null!=b?b:n.trim(n.text(a)).replace(sb," ")
}},select:{get:function(a){for(var b,c,d=a.options,e=a.selectedIndex,f="select-one"===a.type||0>e,g=f?null:[],h=f?e+1:d.length,i=0>e?h:f?e:0;
h>i;
i++){if(c=d[i],(c.selected||i===e)&&(l.optDisabled?!c.disabled:null===c.getAttribute("disabled"))&&(!c.parentNode.disabled||!n.nodeName(c.parentNode,"optgroup"))){if(b=n(c).val(),f){return b
}g.push(b)
}}return g
},set:function(a,b){var c,d,e=a.options,f=n.makeArray(b),g=e.length;
while(g--){if(d=e[g],n.inArray(n.valHooks.option.get(d),f)>-1){try{d.selected=c=!0
}catch(h){d.scrollHeight
}}else{d.selected=!1
}}return c||(a.selectedIndex=-1),e
}}}}),n.each(["radio","checkbox"],function(){n.valHooks[this]={set:function(a,b){return n.isArray(b)?a.checked=n.inArray(n(a).val(),b)>-1:void 0
}},l.checkOn||(n.valHooks[this].get=function(a){return null===a.getAttribute("value")?"on":a.value
})
});
var tb,ub,vb=n.expr.attrHandle,wb=/^(?:checked|selected)$/i,xb=l.getSetAttribute,yb=l.input;
n.fn.extend({attr:function(a,b){return Y(this,n.attr,a,b,arguments.length>1)
},removeAttr:function(a){return this.each(function(){n.removeAttr(this,a)
})
}}),n.extend({attr:function(a,b,c){var d,e,f=a.nodeType;
if(3!==f&&8!==f&&2!==f){return"undefined"==typeof a.getAttribute?n.prop(a,b,c):(1===f&&n.isXMLDoc(a)||(b=b.toLowerCase(),e=n.attrHooks[b]||(n.expr.match.bool.test(b)?ub:tb)),void 0!==c?null===c?void n.removeAttr(a,b):e&&"set" in e&&void 0!==(d=e.set(a,c,b))?d:(a.setAttribute(b,c+""),c):e&&"get" in e&&null!==(d=e.get(a,b))?d:(d=n.find.attr(a,b),null==d?void 0:d))
}},attrHooks:{type:{set:function(a,b){if(!l.radioValue&&"radio"===b&&n.nodeName(a,"input")){var c=a.value;
return a.setAttribute("type",b),c&&(a.value=c),b
}}}},removeAttr:function(a,b){var c,d,e=0,f=b&&b.match(G);
if(f&&1===a.nodeType){while(c=f[e++]){d=n.propFix[c]||c,n.expr.match.bool.test(c)?yb&&xb||!wb.test(c)?a[d]=!1:a[n.camelCase("default-"+c)]=a[d]=!1:n.attr(a,c,""),a.removeAttribute(xb?c:d)
}}}}),ub={set:function(a,b,c){return b===!1?n.removeAttr(a,c):yb&&xb||!wb.test(c)?a.setAttribute(!xb&&n.propFix[c]||c,c):a[n.camelCase("default-"+c)]=a[c]=!0,c
}},n.each(n.expr.match.bool.source.match(/\w+/g),function(a,b){var c=vb[b]||n.find.attr;
yb&&xb||!wb.test(b)?vb[b]=function(a,b,d){var e,f;
return d||(f=vb[b],vb[b]=e,e=null!=c(a,b,d)?b.toLowerCase():null,vb[b]=f),e
}:vb[b]=function(a,b,c){return c?void 0:a[n.camelCase("default-"+b)]?b.toLowerCase():null
}
}),yb&&xb||(n.attrHooks.value={set:function(a,b,c){return n.nodeName(a,"input")?void (a.defaultValue=b):tb&&tb.set(a,b,c)
}}),xb||(tb={set:function(a,b,c){var d=a.getAttributeNode(c);
return d||a.setAttributeNode(d=a.ownerDocument.createAttribute(c)),d.value=b+="","value"===c||b===a.getAttribute(c)?b:void 0
}},vb.id=vb.name=vb.coords=function(a,b,c){var d;
return c?void 0:(d=a.getAttributeNode(b))&&""!==d.value?d.value:null
},n.valHooks.button={get:function(a,b){var c=a.getAttributeNode(b);
return c&&c.specified?c.value:void 0
},set:tb.set},n.attrHooks.contenteditable={set:function(a,b,c){tb.set(a,""===b?!1:b,c)
}},n.each(["width","height"],function(a,b){n.attrHooks[b]={set:function(a,c){return""===c?(a.setAttribute(b,"auto"),c):void 0
}}
})),l.style||(n.attrHooks.style={get:function(a){return a.style.cssText||void 0
},set:function(a,b){return a.style.cssText=b+""
}});
var zb=/^(?:input|select|textarea|button|object)$/i,Ab=/^(?:a|area)$/i;
n.fn.extend({prop:function(a,b){return Y(this,n.prop,a,b,arguments.length>1)
},removeProp:function(a){return a=n.propFix[a]||a,this.each(function(){try{this[a]=void 0,delete this[a]
}catch(b){}})
}}),n.extend({prop:function(a,b,c){var d,e,f=a.nodeType;
if(3!==f&&8!==f&&2!==f){return 1===f&&n.isXMLDoc(a)||(b=n.propFix[b]||b,e=n.propHooks[b]),void 0!==c?e&&"set" in e&&void 0!==(d=e.set(a,c,b))?d:a[b]=c:e&&"get" in e&&null!==(d=e.get(a,b))?d:a[b]
}},propHooks:{tabIndex:{get:function(a){var b=n.find.attr(a,"tabindex");
return b?parseInt(b,10):zb.test(a.nodeName)||Ab.test(a.nodeName)&&a.href?0:-1
}}},propFix:{"for":"htmlFor","class":"className"}}),l.hrefNormalized||n.each(["href","src"],function(a,b){n.propHooks[b]={get:function(a){return a.getAttribute(b,4)
}}
}),l.optSelected||(n.propHooks.selected={get:function(a){var b=a.parentNode;
return b&&(b.selectedIndex,b.parentNode&&b.parentNode.selectedIndex),null
},set:function(a){var b=a.parentNode;
b&&(b.selectedIndex,b.parentNode&&b.parentNode.selectedIndex)
}}),n.each(["tabIndex","readOnly","maxLength","cellSpacing","cellPadding","rowSpan","colSpan","useMap","frameBorder","contentEditable"],function(){n.propFix[this.toLowerCase()]=this
}),l.enctype||(n.propFix.enctype="encoding");
var Bb=/[\t\r\n\f]/g;
function Cb(a){return n.attr(a,"class")||""
}n.fn.extend({addClass:function(a){var b,c,d,e,f,g,h,i=0;
if(n.isFunction(a)){return this.each(function(b){n(this).addClass(a.call(this,b,Cb(this)))
})
}if("string"==typeof a&&a){b=a.match(G)||[];
while(c=this[i++]){if(e=Cb(c),d=1===c.nodeType&&(" "+e+" ").replace(Bb," ")){g=0;
while(f=b[g++]){d.indexOf(" "+f+" ")<0&&(d+=f+" ")
}h=n.trim(d),e!==h&&n.attr(c,"class",h)
}}}return this
},removeClass:function(a){var b,c,d,e,f,g,h,i=0;
if(n.isFunction(a)){return this.each(function(b){n(this).removeClass(a.call(this,b,Cb(this)))
})
}if(!arguments.length){return this.attr("class","")
}if("string"==typeof a&&a){b=a.match(G)||[];
while(c=this[i++]){if(e=Cb(c),d=1===c.nodeType&&(" "+e+" ").replace(Bb," ")){g=0;
while(f=b[g++]){while(d.indexOf(" "+f+" ")>-1){d=d.replace(" "+f+" "," ")
}}h=n.trim(d),e!==h&&n.attr(c,"class",h)
}}}return this
},toggleClass:function(a,b){var c=typeof a;
return"boolean"==typeof b&&"string"===c?b?this.addClass(a):this.removeClass(a):n.isFunction(a)?this.each(function(c){n(this).toggleClass(a.call(this,c,Cb(this),b),b)
}):this.each(function(){var b,d,e,f;
if("string"===c){d=0,e=n(this),f=a.match(G)||[];
while(b=f[d++]){e.hasClass(b)?e.removeClass(b):e.addClass(b)
}}else{void 0!==a&&"boolean"!==c||(b=Cb(this),b&&n._data(this,"__className__",b),n.attr(this,"class",b||a===!1?"":n._data(this,"__className__")||""))
}})
},hasClass:function(a){var b,c,d=0;
b=" "+a+" ";
while(c=this[d++]){if(1===c.nodeType&&(" "+Cb(c)+" ").replace(Bb," ").indexOf(b)>-1){return !0
}}return !1
}}),n.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "),function(a,b){n.fn[b]=function(a,c){return arguments.length>0?this.on(b,null,a,c):this.trigger(b)
}
}),n.fn.extend({hover:function(a,b){return this.mouseenter(a).mouseleave(b||a)
}});
var Db=a.location,Eb=n.now(),Fb=/\?/,Gb=/(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g;
n.parseJSON=function(b){if(a.JSON&&a.JSON.parse){return a.JSON.parse(b+"")
}var c,d=null,e=n.trim(b+"");
return e&&!n.trim(e.replace(Gb,function(a,b,e,f){return c&&b&&(d=0),0===d?a:(c=e||b,d+=!f-!e,"")
}))?Function("return "+e)():n.error("Invalid JSON: "+b)
},n.parseXML=function(b){var c,d;
if(!b||"string"!=typeof b){return null
}try{a.DOMParser?(d=new a.DOMParser,c=d.parseFromString(b,"text/xml")):(c=new a.ActiveXObject("Microsoft.XMLDOM"),c.async="false",c.loadXML(b))
}catch(e){c=void 0
}return c&&c.documentElement&&!c.getElementsByTagName("parsererror").length||n.error("Invalid XML: "+b),c
};
var Hb=/#.*$/,Ib=/([?&])_=[^&]*/,Jb=/^(.*?):[ \t]*([^\r\n]*)\r?$/gm,Kb=/^(?:about|app|app-storage|.+-extension|file|res|widget):$/,Lb=/^(?:GET|HEAD)$/,Mb=/^\/\//,Nb=/^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,Ob={},Pb={},Qb="*/".concat("*"),Rb=Db.href,Sb=Nb.exec(Rb.toLowerCase())||[];
function Tb(a){return function(b,c){"string"!=typeof b&&(c=b,b="*");
var d,e=0,f=b.toLowerCase().match(G)||[];
if(n.isFunction(c)){while(d=f[e++]){"+"===d.charAt(0)?(d=d.slice(1)||"*",(a[d]=a[d]||[]).unshift(c)):(a[d]=a[d]||[]).push(c)
}}}
}function Ub(a,b,c,d){var e={},f=a===Pb;
function g(h){var i;
return e[h]=!0,n.each(a[h]||[],function(a,h){var j=h(b,c,d);
return"string"!=typeof j||f||e[j]?f?!(i=j):void 0:(b.dataTypes.unshift(j),g(j),!1)
}),i
}return g(b.dataTypes[0])||!e["*"]&&g("*")
}function Vb(a,b){var c,d,e=n.ajaxSettings.flatOptions||{};
for(d in b){void 0!==b[d]&&((e[d]?a:c||(c={}))[d]=b[d])
}return c&&n.extend(!0,a,c),a
}function Wb(a,b,c){var d,e,f,g,h=a.contents,i=a.dataTypes;
while("*"===i[0]){i.shift(),void 0===e&&(e=a.mimeType||b.getResponseHeader("Content-Type"))
}if(e){for(g in h){if(h[g]&&h[g].test(e)){i.unshift(g);
break
}}}if(i[0] in c){f=i[0]
}else{for(g in c){if(!i[0]||a.converters[g+" "+i[0]]){f=g;
break
}d||(d=g)
}f=f||d
}return f?(f!==i[0]&&i.unshift(f),c[f]):void 0
}function Xb(a,b,c,d){var e,f,g,h,i,j={},k=a.dataTypes.slice();
if(k[1]){for(g in a.converters){j[g.toLowerCase()]=a.converters[g]
}}f=k.shift();
while(f){if(a.responseFields[f]&&(c[a.responseFields[f]]=b),!i&&d&&a.dataFilter&&(b=a.dataFilter(b,a.dataType)),i=f,f=k.shift()){if("*"===f){f=i
}else{if("*"!==i&&i!==f){if(g=j[i+" "+f]||j["* "+f],!g){for(e in j){if(h=e.split(" "),h[1]===f&&(g=j[i+" "+h[0]]||j["* "+h[0]])){g===!0?g=j[e]:j[e]!==!0&&(f=h[0],k.unshift(h[1]));
break
}}}if(g!==!0){if(g&&a["throws"]){b=g(b)
}else{try{b=g(b)
}catch(l){return{state:"parsererror",error:g?l:"No conversion from "+i+" to "+f}
}}}}}}}return{state:"success",data:b}
}n.extend({active:0,lastModified:{},etag:{},ajaxSettings:{url:Rb,type:"GET",isLocal:Kb.test(Sb[1]),global:!0,processData:!0,async:!0,contentType:"application/x-www-form-urlencoded; charset=UTF-8",accepts:{"*":Qb,text:"text/plain",html:"text/html",xml:"application/xml, text/xml",json:"application/json, text/javascript"},contents:{xml:/\bxml\b/,html:/\bhtml/,json:/\bjson\b/},responseFields:{xml:"responseXML",text:"responseText",json:"responseJSON"},converters:{"* text":String,"text html":!0,"text json":n.parseJSON,"text xml":n.parseXML},flatOptions:{url:!0,context:!0}},ajaxSetup:function(a,b){return b?Vb(Vb(a,n.ajaxSettings),b):Vb(n.ajaxSettings,a)
},ajaxPrefilter:Tb(Ob),ajaxTransport:Tb(Pb),ajax:function(b,c){"object"==typeof b&&(c=b,b=void 0),c=c||{};
var d,e,f,g,h,i,j,k,l=n.ajaxSetup({},c),m=l.context||l,o=l.context&&(m.nodeType||m.jquery)?n(m):n.event,p=n.Deferred(),q=n.Callbacks("once memory"),r=l.statusCode||{},s={},t={},u=0,v="canceled",w={readyState:0,getResponseHeader:function(a){var b;
if(2===u){if(!k){k={};
while(b=Jb.exec(g)){k[b[1].toLowerCase()]=b[2]
}}b=k[a.toLowerCase()]
}return null==b?null:b
},getAllResponseHeaders:function(){return 2===u?g:null
},setRequestHeader:function(a,b){var c=a.toLowerCase();
return u||(a=t[c]=t[c]||a,s[a]=b),this
},overrideMimeType:function(a){return u||(l.mimeType=a),this
},statusCode:function(a){var b;
if(a){if(2>u){for(b in a){r[b]=[r[b],a[b]]
}}else{w.always(a[w.status])
}}return this
},abort:function(a){var b=a||v;
return j&&j.abort(b),y(0,b),this
}};
if(p.promise(w).complete=q.add,w.success=w.done,w.error=w.fail,l.url=((b||l.url||Rb)+"").replace(Hb,"").replace(Mb,Sb[1]+"//"),l.type=c.method||c.type||l.method||l.type,l.dataTypes=n.trim(l.dataType||"*").toLowerCase().match(G)||[""],null==l.crossDomain&&(d=Nb.exec(l.url.toLowerCase()),l.crossDomain=!(!d||d[1]===Sb[1]&&d[2]===Sb[2]&&(d[3]||("http:"===d[1]?"80":"443"))===(Sb[3]||("http:"===Sb[1]?"80":"443")))),l.data&&l.processData&&"string"!=typeof l.data&&(l.data=n.param(l.data,l.traditional)),Ub(Ob,l,c,w),2===u){return w
}i=n.event&&l.global,i&&0===n.active++&&n.event.trigger("ajaxStart"),l.type=l.type.toUpperCase(),l.hasContent=!Lb.test(l.type),f=l.url,l.hasContent||(l.data&&(f=l.url+=(Fb.test(f)?"&":"?")+l.data,delete l.data),l.cache===!1&&(l.url=Ib.test(f)?f.replace(Ib,"$1_="+Eb++):f+(Fb.test(f)?"&":"?")+"_="+Eb++)),l.ifModified&&(n.lastModified[f]&&w.setRequestHeader("If-Modified-Since",n.lastModified[f]),n.etag[f]&&w.setRequestHeader("If-None-Match",n.etag[f])),(l.data&&l.hasContent&&l.contentType!==!1||c.contentType)&&w.setRequestHeader("Content-Type",l.contentType),w.setRequestHeader("Accept",l.dataTypes[0]&&l.accepts[l.dataTypes[0]]?l.accepts[l.dataTypes[0]]+("*"!==l.dataTypes[0]?", "+Qb+"; q=0.01":""):l.accepts["*"]);
for(e in l.headers){w.setRequestHeader(e,l.headers[e])
}if(l.beforeSend&&(l.beforeSend.call(m,w,l)===!1||2===u)){return w.abort()
}v="abort";
for(e in {success:1,error:1,complete:1}){w[e](l[e])
}if(j=Ub(Pb,l,c,w)){if(w.readyState=1,i&&o.trigger("ajaxSend",[w,l]),2===u){return w
}l.async&&l.timeout>0&&(h=a.setTimeout(function(){w.abort("timeout")
},l.timeout));
try{u=1,j.send(s,y)
}catch(x){if(!(2>u)){throw x
}y(-1,x)
}}else{y(-1,"No Transport")
}function y(b,c,d,e){var k,s,t,v,x,y=c;
2!==u&&(u=2,h&&a.clearTimeout(h),j=void 0,g=e||"",w.readyState=b>0?4:0,k=b>=200&&300>b||304===b,d&&(v=Wb(l,w,d)),v=Xb(l,v,w,k),k?(l.ifModified&&(x=w.getResponseHeader("Last-Modified"),x&&(n.lastModified[f]=x),x=w.getResponseHeader("etag"),x&&(n.etag[f]=x)),204===b||"HEAD"===l.type?y="nocontent":304===b?y="notmodified":(y=v.state,s=v.data,t=v.error,k=!t)):(t=y,!b&&y||(y="error",0>b&&(b=0))),w.status=b,w.statusText=(c||y)+"",k?p.resolveWith(m,[s,y,w]):p.rejectWith(m,[w,y,t]),w.statusCode(r),r=void 0,i&&o.trigger(k?"ajaxSuccess":"ajaxError",[w,l,k?s:t]),q.fireWith(m,[w,y]),i&&(o.trigger("ajaxComplete",[w,l]),--n.active||n.event.trigger("ajaxStop")))
}return w
},getJSON:function(a,b,c){return n.get(a,b,c,"json")
},getScript:function(a,b){return n.get(a,void 0,b,"script")
}}),n.each(["get","post"],function(a,b){n[b]=function(a,c,d,e){return n.isFunction(c)&&(e=e||d,d=c,c=void 0),n.ajax(n.extend({url:a,type:b,dataType:e,data:c,success:d},n.isPlainObject(a)&&a))
}
}),n._evalUrl=function(a){return n.ajax({url:a,type:"GET",dataType:"script",cache:!0,async:!1,global:!1,"throws":!0})
},n.fn.extend({wrapAll:function(a){if(n.isFunction(a)){return this.each(function(b){n(this).wrapAll(a.call(this,b))
})
}if(this[0]){var b=n(a,this[0].ownerDocument).eq(0).clone(!0);
this[0].parentNode&&b.insertBefore(this[0]),b.map(function(){var a=this;
while(a.firstChild&&1===a.firstChild.nodeType){a=a.firstChild
}return a
}).append(this)
}return this
},wrapInner:function(a){return n.isFunction(a)?this.each(function(b){n(this).wrapInner(a.call(this,b))
}):this.each(function(){var b=n(this),c=b.contents();
c.length?c.wrapAll(a):b.append(a)
})
},wrap:function(a){var b=n.isFunction(a);
return this.each(function(c){n(this).wrapAll(b?a.call(this,c):a)
})
},unwrap:function(){return this.parent().each(function(){n.nodeName(this,"body")||n(this).replaceWith(this.childNodes)
}).end()
}});
function Yb(a){return a.style&&a.style.display||n.css(a,"display")
}function Zb(a){while(a&&1===a.nodeType){if("none"===Yb(a)||"hidden"===a.type){return !0
}a=a.parentNode
}return !1
}n.expr.filters.hidden=function(a){return l.reliableHiddenOffsets()?a.offsetWidth<=0&&a.offsetHeight<=0&&!a.getClientRects().length:Zb(a)
},n.expr.filters.visible=function(a){return !n.expr.filters.hidden(a)
};
var $b=/%20/g,_b=/\[\]$/,ac=/\r?\n/g,bc=/^(?:submit|button|image|reset|file)$/i,cc=/^(?:input|select|textarea|keygen)/i;
function dc(a,b,c,d){var e;
if(n.isArray(b)){n.each(b,function(b,e){c||_b.test(a)?d(a,e):dc(a+"["+("object"==typeof e&&null!=e?b:"")+"]",e,c,d)
})
}else{if(c||"object"!==n.type(b)){d(a,b)
}else{for(e in b){dc(a+"["+e+"]",b[e],c,d)
}}}}n.param=function(a,b){var c,d=[],e=function(a,b){b=n.isFunction(b)?b():null==b?"":b,d[d.length]=encodeURIComponent(a)+"="+encodeURIComponent(b)
};
if(void 0===b&&(b=n.ajaxSettings&&n.ajaxSettings.traditional),n.isArray(a)||a.jquery&&!n.isPlainObject(a)){n.each(a,function(){e(this.name,this.value)
})
}else{for(c in a){dc(c,a[c],b,e)
}}return d.join("&").replace($b,"+")
},n.fn.extend({serialize:function(){return n.param(this.serializeArray())
},serializeArray:function(){return this.map(function(){var a=n.prop(this,"elements");
return a?n.makeArray(a):this
}).filter(function(){var a=this.type;
return this.name&&!n(this).is(":disabled")&&cc.test(this.nodeName)&&!bc.test(a)&&(this.checked||!Z.test(a))
}).map(function(a,b){var c=n(this).val();
return null==c?null:n.isArray(c)?n.map(c,function(a){return{name:b.name,value:a.replace(ac,"\r\n")}
}):{name:b.name,value:c.replace(ac,"\r\n")}
}).get()
}}),n.ajaxSettings.xhr=void 0!==a.ActiveXObject?function(){return this.isLocal?ic():d.documentMode>8?hc():/^(get|post|head|put|delete|options)$/i.test(this.type)&&hc()||ic()
}:hc;
var ec=0,fc={},gc=n.ajaxSettings.xhr();
a.attachEvent&&a.attachEvent("onunload",function(){for(var a in fc){fc[a](void 0,!0)
}}),l.cors=!!gc&&"withCredentials" in gc,gc=l.ajax=!!gc,gc&&n.ajaxTransport(function(b){if(!b.crossDomain||l.cors){var c;
return{send:function(d,e){var f,g=b.xhr(),h=++ec;
if(g.open(b.type,b.url,b.async,b.username,b.password),b.xhrFields){for(f in b.xhrFields){g[f]=b.xhrFields[f]
}}b.mimeType&&g.overrideMimeType&&g.overrideMimeType(b.mimeType),b.crossDomain||d["X-Requested-With"]||(d["X-Requested-With"]="XMLHttpRequest");
for(f in d){void 0!==d[f]&&g.setRequestHeader(f,d[f]+"")
}g.send(b.hasContent&&b.data||null),c=function(a,d){var f,i,j;
if(c&&(d||4===g.readyState)){if(delete fc[h],c=void 0,g.onreadystatechange=n.noop,d){4!==g.readyState&&g.abort()
}else{j={},f=g.status,"string"==typeof g.responseText&&(j.text=g.responseText);
try{i=g.statusText
}catch(k){i=""
}f||!b.isLocal||b.crossDomain?1223===f&&(f=204):f=j.text?200:404
}}j&&e(f,i,j,g.getAllResponseHeaders())
},b.async?4===g.readyState?a.setTimeout(c):g.onreadystatechange=fc[h]=c:c()
},abort:function(){c&&c(void 0,!0)
}}
}});
function hc(){try{return new a.XMLHttpRequest
}catch(b){}}function ic(){try{return new a.ActiveXObject("Microsoft.XMLHTTP")
}catch(b){}}n.ajaxSetup({accepts:{script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},contents:{script:/\b(?:java|ecma)script\b/},converters:{"text script":function(a){return n.globalEval(a),a
}}}),n.ajaxPrefilter("script",function(a){void 0===a.cache&&(a.cache=!1),a.crossDomain&&(a.type="GET",a.global=!1)
}),n.ajaxTransport("script",function(a){if(a.crossDomain){var b,c=d.head||n("head")[0]||d.documentElement;
return{send:function(e,f){b=d.createElement("script"),b.async=!0,a.scriptCharset&&(b.charset=a.scriptCharset),b.src=a.url,b.onload=b.onreadystatechange=function(a,c){(c||!b.readyState||/loaded|complete/.test(b.readyState))&&(b.onload=b.onreadystatechange=null,b.parentNode&&b.parentNode.removeChild(b),b=null,c||f(200,"success"))
},c.insertBefore(b,c.firstChild)
},abort:function(){b&&b.onload(void 0,!0)
}}
}});
var jc=[],kc=/(=)\?(?=&|$)|\?\?/;
n.ajaxSetup({jsonp:"callback",jsonpCallback:function(){var a=jc.pop()||n.expando+"_"+Eb++;
return this[a]=!0,a
}}),n.ajaxPrefilter("json jsonp",function(b,c,d){var e,f,g,h=b.jsonp!==!1&&(kc.test(b.url)?"url":"string"==typeof b.data&&0===(b.contentType||"").indexOf("application/x-www-form-urlencoded")&&kc.test(b.data)&&"data");
return h||"jsonp"===b.dataTypes[0]?(e=b.jsonpCallback=n.isFunction(b.jsonpCallback)?b.jsonpCallback():b.jsonpCallback,h?b[h]=b[h].replace(kc,"$1"+e):b.jsonp!==!1&&(b.url+=(Fb.test(b.url)?"&":"?")+b.jsonp+"="+e),b.converters["script json"]=function(){return g||n.error(e+" was not called"),g[0]
},b.dataTypes[0]="json",f=a[e],a[e]=function(){g=arguments
},d.always(function(){void 0===f?n(a).removeProp(e):a[e]=f,b[e]&&(b.jsonpCallback=c.jsonpCallback,jc.push(e)),g&&n.isFunction(f)&&f(g[0]),g=f=void 0
}),"script"):void 0
}),n.parseHTML=function(a,b,c){if(!a||"string"!=typeof a){return null
}"boolean"==typeof b&&(c=b,b=!1),b=b||d;
var e=x.exec(a),f=!c&&[];
return e?[b.createElement(e[1])]:(e=ja([a],b,f),f&&f.length&&n(f).remove(),n.merge([],e.childNodes))
};
var lc=n.fn.load;
n.fn.load=function(a,b,c){if("string"!=typeof a&&lc){return lc.apply(this,arguments)
}var d,e,f,g=this,h=a.indexOf(" ");
return h>-1&&(d=n.trim(a.slice(h,a.length)),a=a.slice(0,h)),n.isFunction(b)?(c=b,b=void 0):b&&"object"==typeof b&&(e="POST"),g.length>0&&n.ajax({url:a,type:e||"GET",dataType:"html",data:b}).done(function(a){f=arguments,g.html(d?n("<div>").append(n.parseHTML(a)).find(d):a)
}).always(c&&function(a,b){g.each(function(){c.apply(this,f||[a.responseText,b,a])
})
}),this
},n.each(["ajaxStart","ajaxStop","ajaxComplete","ajaxError","ajaxSuccess","ajaxSend"],function(a,b){n.fn[b]=function(a){return this.on(b,a)
}
}),n.expr.filters.animated=function(a){return n.grep(n.timers,function(b){return a===b.elem
}).length
};
function mc(a){return n.isWindow(a)?a:9===a.nodeType?a.defaultView||a.parentWindow:!1
}n.offset={setOffset:function(a,b,c){var d,e,f,g,h,i,j,k=n.css(a,"position"),l=n(a),m={};
"static"===k&&(a.style.position="relative"),h=l.offset(),f=n.css(a,"top"),i=n.css(a,"left"),j=("absolute"===k||"fixed"===k)&&n.inArray("auto",[f,i])>-1,j?(d=l.position(),g=d.top,e=d.left):(g=parseFloat(f)||0,e=parseFloat(i)||0),n.isFunction(b)&&(b=b.call(a,c,n.extend({},h))),null!=b.top&&(m.top=b.top-h.top+g),null!=b.left&&(m.left=b.left-h.left+e),"using" in b?b.using.call(a,m):l.css(m)
}},n.fn.extend({offset:function(a){if(arguments.length){return void 0===a?this:this.each(function(b){n.offset.setOffset(this,a,b)
})
}var b,c,d={top:0,left:0},e=this[0],f=e&&e.ownerDocument;
if(f){return b=f.documentElement,n.contains(b,e)?("undefined"!=typeof e.getBoundingClientRect&&(d=e.getBoundingClientRect()),c=mc(f),{top:d.top+(c.pageYOffset||b.scrollTop)-(b.clientTop||0),left:d.left+(c.pageXOffset||b.scrollLeft)-(b.clientLeft||0)}):d
}},position:function(){if(this[0]){var a,b,c={top:0,left:0},d=this[0];
return"fixed"===n.css(d,"position")?b=d.getBoundingClientRect():(a=this.offsetParent(),b=this.offset(),n.nodeName(a[0],"html")||(c=a.offset()),c.top+=n.css(a[0],"borderTopWidth",!0),c.left+=n.css(a[0],"borderLeftWidth",!0)),{top:b.top-c.top-n.css(d,"marginTop",!0),left:b.left-c.left-n.css(d,"marginLeft",!0)}
}},offsetParent:function(){return this.map(function(){var a=this.offsetParent;
while(a&&!n.nodeName(a,"html")&&"static"===n.css(a,"position")){a=a.offsetParent
}return a||Qa
})
}}),n.each({scrollLeft:"pageXOffset",scrollTop:"pageYOffset"},function(a,b){var c=/Y/.test(b);
n.fn[a]=function(d){return Y(this,function(a,d,e){var f=mc(a);
return void 0===e?f?b in f?f[b]:f.document.documentElement[d]:a[d]:void (f?f.scrollTo(c?n(f).scrollLeft():e,c?e:n(f).scrollTop()):a[d]=e)
},a,d,arguments.length,null)
}
}),n.each(["top","left"],function(a,b){n.cssHooks[b]=Ua(l.pixelPosition,function(a,c){return c?(c=Sa(a,b),Oa.test(c)?n(a).position()[b]+"px":c):void 0
})
}),n.each({Height:"height",Width:"width"},function(a,b){n.each({padding:"inner"+a,content:b,"":"outer"+a},function(c,d){n.fn[d]=function(d,e){var f=arguments.length&&(c||"boolean"!=typeof d),g=c||(d===!0||e===!0?"margin":"border");
return Y(this,function(b,c,d){var e;
return n.isWindow(b)?b.document.documentElement["client"+a]:9===b.nodeType?(e=b.documentElement,Math.max(b.body["scroll"+a],e["scroll"+a],b.body["offset"+a],e["offset"+a],e["client"+a])):void 0===d?n.css(b,c,g):n.style(b,c,d,g)
},b,f?d:void 0,f,null)
}
})
}),n.fn.extend({bind:function(a,b,c){return this.on(a,null,b,c)
},unbind:function(a,b){return this.off(a,null,b)
},delegate:function(a,b,c,d){return this.on(b,a,c,d)
},undelegate:function(a,b,c){return 1===arguments.length?this.off(a,"**"):this.off(b,a||"**",c)
}}),n.fn.size=function(){return this.length
},n.fn.andSelf=n.fn.addBack,"function"==typeof define&&define.amd&&define("jquery",[],function(){return n
});
var nc=a.jQuery,oc=a.$;
return n.noConflict=function(b){return a.$===n&&(a.$=oc),b&&a.jQuery===n&&(a.jQuery=nc),n
},b||(a.jQuery=a.$=n),n
});
/*! jQuery UI - v1.11.4 - 2016-08-01
 * http://jqueryui.com
 * Includes: core.js, widget.js, mouse.js, position.js, draggable.js, autocomplete.js, datepicker.js, menu.js, effect.js, effect-blind.js, effect-drop.js, effect-fade.js, effect-fold.js, effect-size.js, effect-slide.js, effect-transfer.js
 * Copyright jQuery Foundation and other contributors; Licensed MIT */
(function(b){"function"==typeof define&&define.amd?define(["jquery"],b):b(jQuery)
})(function(B){function w(l,d){var t,p,c,h=l.nodeName.toLowerCase();
return"area"===h?(t=l.parentNode,p=t.name,l.href&&p&&"map"===t.nodeName.toLowerCase()?(c=B("img[usemap='#"+p+"']")[0],!!c&&q(c)):!1):(/^(input|select|textarea|button|object)$/.test(h)?!l.disabled:"a"===h?l.href||d:d)&&q(l)
}function q(c){return B.expr.filters.visible(c)&&!B(c).parents().addBack().filter(function(){return"hidden"===B.css(this,"visibility")
}).length
}function C(d){for(var h,c;
d.length&&d[0]!==document;
){if(h=d.css("position"),("absolute"===h||"relative"===h||"fixed"===h)&&(c=parseInt(d.css("zIndex"),10),!isNaN(c)&&0!==c)){return c
}d=d.parent()
}return 0
}function k(){this._curInst=null,this._keyEvent=!1,this._disabledInputs=[],this._datepickerShowing=!1,this._inDialog=!1,this._mainDivId="ui-datepicker-div",this._inlineClass="ui-datepicker-inline",this._appendClass="ui-datepicker-append",this._triggerClass="ui-datepicker-trigger",this._dialogClass="ui-datepicker-dialog",this._disableClass="ui-datepicker-disabled",this._unselectableClass="ui-datepicker-unselectable",this._currentClass="ui-datepicker-current-day",this._dayOverClass="ui-datepicker-days-cell-over",this.regional=[],this.regional[""]={closeText:"Done",prevText:"Prev",nextText:"Next",currentText:"Today",monthNames:["January","February","March","April","May","June","July","August","September","October","November","December"],monthNamesShort:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],dayNames:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],dayNamesShort:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],dayNamesMin:["Su","Mo","Tu","We","Th","Fr","Sa"],weekHeader:"Wk",dateFormat:"mm/dd/yy",firstDay:0,isRTL:!1,showMonthAfterYear:!1,yearSuffix:""},this._defaults={showOn:"focus",showAnim:"fadeIn",showOptions:{},defaultDate:null,appendText:"",buttonText:"...",buttonImage:"",buttonImageOnly:!1,hideIfNoPrevNext:!1,navigationAsDateFormat:!1,gotoCurrent:!1,changeMonth:!1,changeYear:!1,yearRange:"c-10:c+10",showOtherMonths:!1,selectOtherMonths:!1,showWeek:!1,calculateWeek:this.iso8601Week,shortYearCutoff:"+10",minDate:null,maxDate:null,duration:"fast",beforeShowDay:null,beforeShow:null,onSelect:null,onChangeMonthYear:null,onClose:null,numberOfMonths:1,showCurrentAtPos:0,stepMonths:1,stepBigMonths:12,altField:"",altFormat:"",constrainInput:!0,showButtonPanel:!1,autoSize:!1,disabled:!1},B.extend(this._defaults,this.regional[""]),this.regional.en=B.extend(!0,{},this.regional[""]),this.regional["en-US"]=B.extend(!0,{},this.regional.en),this.dpDiv=g(B("<div id='"+this._mainDivId+"' class='ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>"))
}function g(d){var c="button, .ui-datepicker-prev, .ui-datepicker-next, .ui-datepicker-calendar td a";
return d.delegate(c,"mouseout",function(){B(this).removeClass("ui-state-hover"),-1!==this.className.indexOf("ui-datepicker-prev")&&B(this).removeClass("ui-datepicker-prev-hover"),-1!==this.className.indexOf("ui-datepicker-next")&&B(this).removeClass("ui-datepicker-next-hover")
}).delegate(c,"mouseover",z)
}function z(){B.datepicker._isDisabledDatepicker(A.inline?A.dpDiv.parent()[0]:A.input[0])||(B(this).parents(".ui-datepicker-calendar").find("a").removeClass("ui-state-hover"),B(this).addClass("ui-state-hover"),-1!==this.className.indexOf("ui-datepicker-prev")&&B(this).addClass("ui-datepicker-prev-hover"),-1!==this.className.indexOf("ui-datepicker-next")&&B(this).addClass("ui-datepicker-next-hover"))
}function b(h,c){B.extend(h,c);
for(var d in c){null==c[d]&&(h[d]=c[d])
}return h
}B.ui=B.ui||{},B.extend(B.ui,{version:"1.11.4",keyCode:{BACKSPACE:8,COMMA:188,DELETE:46,DOWN:40,END:35,ENTER:13,ESCAPE:27,HOME:36,LEFT:37,PAGE_DOWN:34,PAGE_UP:33,PERIOD:190,RIGHT:39,SPACE:32,TAB:9,UP:38}}),B.fn.extend({scrollParent:function(h){var c=this.css("position"),d="absolute"===c,p=h?/(auto|scroll|hidden)/:/(auto|scroll)/,l=this.parents().filter(function(){var n=B(this);
return d&&"static"===n.css("position")?!1:p.test(n.css("overflow")+n.css("overflow-y")+n.css("overflow-x"))
}).eq(0);
return"fixed"!==c&&l.length?l:B(this[0].ownerDocument||document)
},uniqueId:function(){var c=0;
return function(){return this.each(function(){this.id||(this.id="ui-id-"+ ++c)
})
}
}(),removeUniqueId:function(){return this.each(function(){/^ui-id-\d+$/.test(this.id)&&B(this).removeAttr("id")
})
}}),B.extend(B.expr[":"],{data:B.expr.createPseudo?B.expr.createPseudo(function(c){return function(d){return !!B.data(d,c)
}
}):function(h,c,d){return !!B.data(h,d[3])
},focusable:function(c){return w(c,!isNaN(B.attr(c,"tabindex")))
},tabbable:function(c){var d=B.attr(c,"tabindex"),e=isNaN(d);
return(e||d>=0)&&w(c,!e)
}}),B("<a>").outerWidth(1).jquery||B.each(["Width","Height"],function(l,d){function h(u,n,t,D){return B.each(r,function(){n-=parseFloat(B.css(u,"padding"+this))||0,t&&(n-=parseFloat(B.css(u,"border"+this+"Width"))||0),D&&(n-=parseFloat(B.css(u,"margin"+this))||0)
}),n
}var r="Width"===d?["Left","Right"]:["Top","Bottom"],p=d.toLowerCase(),c={innerWidth:B.fn.innerWidth,innerHeight:B.fn.innerHeight,outerWidth:B.fn.outerWidth,outerHeight:B.fn.outerHeight};
B.fn["inner"+d]=function(n){return void 0===n?c["inner"+d].call(this):this.each(function(){B(this).css(p,h(this,n)+"px")
})
},B.fn["outer"+d]=function(o,s){return"number"!=typeof o?c["outer"+d].call(this,o):this.each(function(){B(this).css(p,h(this,o,!0,s)+"px")
})
}
}),B.fn.addBack||(B.fn.addBack=function(c){return this.add(null==c?this.prevObject:this.prevObject.filter(c))
}),B("<a>").data("a-b","a").removeData("a-b").data("a-b")&&(B.fn.removeData=function(c){return function(d){return arguments.length?c.call(this,B.camelCase(d)):c.call(this)
}
}(B.fn.removeData)),B.ui.ie=!!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase()),B.fn.extend({focus:function(c){return function(d,e){return"number"==typeof d?this.each(function(){var h=this;
setTimeout(function(){B(h).focus(),e&&e.call(h)
},d)
}):c.apply(this,arguments)
}
}(B.fn.focus),disableSelection:function(){var c="onselectstart" in document.createElement("div")?"selectstart":"mousedown";
return function(){return this.bind(c+".ui-disableSelection",function(d){d.preventDefault()
})
}
}(),enableSelection:function(){return this.unbind(".ui-disableSelection")
},zIndex:function(h){if(void 0!==h){return this.css("zIndex",h)
}if(this.length){for(var c,d,l=B(this[0]);
l.length&&l[0]!==document;
){if(c=l.css("position"),("absolute"===c||"relative"===c||"fixed"===c)&&(d=parseInt(l.css("zIndex"),10),!isNaN(d)&&0!==d)){return d
}l=l.parent()
}}return 0
}}),B.ui.plugin={add:function(h,c,d){var p,l=B.ui[h].prototype;
for(p in d){l.plugins[p]=l.plugins[p]||[],l.plugins[p].push([c,d[p]])
}},call:function(d,l,c,h){var r,p=d.plugins[l];
if(p&&(h||d.element[0].parentNode&&11!==d.element[0].parentNode.nodeType)){for(r=0;
p.length>r;
r++){d.options[p[r][0]]&&p[r][1].apply(d.element,c)
}}}};
var m=0,v=Array.prototype.slice;
B.cleanData=function(c){return function(e){var h,p,l;
for(l=0;
null!=(p=e[l]);
l++){try{h=B._data(p,"events"),h&&h.remove&&B(p).triggerHandler("remove")
}catch(d){}}c(e)
}
}(B.cleanData),B.widget=function(E,u,G){var p,d,F,c,t={},D=E.split(".")[0];
return E=E.split(".")[1],p=D+"-"+E,G||(G=u,u=B.Widget),B.expr[":"][p.toLowerCase()]=function(h){return !!B.data(h,p)
},B[D]=B[D]||{},d=B[D][E],F=B[D][E]=function(h,l){return this._createWidget?(arguments.length&&this._createWidget(h,l),void 0):new F(h,l)
},B.extend(F,d,{version:G.version,_proto:B.extend({},G),_childConstructors:[]}),c=new u,c.options=B.widget.extend({},c.options),B.each(G,function(l,h){return B.isFunction(h)?(t[l]=function(){var e=function(){return u.prototype[l].apply(this,arguments)
},o=function(n){return u.prototype[l].apply(this,n)
};
return function(){var r,n=this._super,s=this._superApply;
return this._super=e,this._superApply=o,r=h.apply(this,arguments),this._super=n,this._superApply=s,r
}
}(),void 0):(t[l]=h,void 0)
}),F.prototype=B.widget.extend(c,{widgetEventPrefix:d?c.widgetEventPrefix||E:E},t,{constructor:F,namespace:D,widgetName:E,widgetFullName:p}),d?(B.each(d._childConstructors,function(n,h){var l=h.prototype;
B.widget(l.namespace+"."+l.widgetName,F,h._proto)
}),delete d._childConstructors):u._childConstructors.push(F),B.widget.bridge(E,F),F
},B.widget.extend=function(l){for(var d,h,r=v.call(arguments,1),p=0,c=r.length;
c>p;
p++){for(d in r[p]){h=r[p][d],r[p].hasOwnProperty(d)&&void 0!==h&&(l[d]=B.isPlainObject(h)?B.isPlainObject(l[d])?B.widget.extend({},l[d],h):B.widget.extend({},h):h)
}}return l
},B.widget.bridge=function(h,c){var d=c.prototype.widgetFullName||h;
B.fn[h]=function(s){var p="string"==typeof s,e=v.call(arguments,1),l=this;
return p?this.each(function(){var n,r=B.data(this,d);
return"instance"===s?(l=r,!1):r?B.isFunction(r[s])&&"_"!==s.charAt(0)?(n=r[s].apply(r,e),n!==r&&void 0!==n?(l=n&&n.jquery?l.pushStack(n.get()):n,!1):void 0):B.error("no such method '"+s+"' for "+h+" widget instance"):B.error("cannot call methods on "+h+" prior to initialization; attempted to call method '"+s+"'")
}):(e.length&&(s=B.widget.extend.apply(null,[s].concat(e))),this.each(function(){var n=B.data(this,d);
n?(n.option(s||{}),n._init&&n._init()):B.data(this,d,new c(s,this))
})),l
}
},B.Widget=function(){},B.Widget._childConstructors=[],B.Widget.prototype={widgetName:"widget",widgetEventPrefix:"",defaultElement:"<div>",options:{disabled:!1,create:null},_createWidget:function(d,c){c=B(c||this.defaultElement||this)[0],this.element=B(c),this.uuid=m++,this.eventNamespace="."+this.widgetName+this.uuid,this.bindings=B(),this.hoverable=B(),this.focusable=B(),c!==this&&(B.data(c,this.widgetFullName,this),this._on(!0,this.element,{remove:function(e){e.target===c&&this.destroy()
}}),this.document=B(c.style?c.ownerDocument:c.document||c),this.window=B(this.document[0].defaultView||this.document[0].parentWindow)),this.options=B.widget.extend({},this.options,this._getCreateOptions(),d),this._create(),this._trigger("create",null,this._getCreateEventData()),this._init()
},_getCreateOptions:B.noop,_getCreateEventData:B.noop,_create:B.noop,_init:B.noop,destroy:function(){this._destroy(),this.element.unbind(this.eventNamespace).removeData(this.widgetFullName).removeData(B.camelCase(this.widgetFullName)),this.widget().unbind(this.eventNamespace).removeAttr("aria-disabled").removeClass(this.widgetFullName+"-disabled ui-state-disabled"),this.bindings.unbind(this.eventNamespace),this.hoverable.removeClass("ui-state-hover"),this.focusable.removeClass("ui-state-focus")
},_destroy:B.noop,widget:function(){return this.element
},option:function(l,d){var h,r,p,c=l;
if(0===arguments.length){return B.widget.extend({},this.options)
}if("string"==typeof l){if(c={},h=l.split("."),l=h.shift(),h.length){for(r=c[l]=B.widget.extend({},this.options[l]),p=0;
h.length-1>p;
p++){r[h[p]]=r[h[p]]||{},r=r[h[p]]
}if(l=h.pop(),1===arguments.length){return void 0===r[l]?null:r[l]
}r[l]=d
}else{if(1===arguments.length){return void 0===this.options[l]?null:this.options[l]
}c[l]=d
}}return this._setOptions(c),this
},_setOptions:function(c){var d;
for(d in c){this._setOption(d,c[d])
}return this
},_setOption:function(c,d){return this.options[c]=d,"disabled"===c&&(this.widget().toggleClass(this.widgetFullName+"-disabled",!!d),d&&(this.hoverable.removeClass("ui-state-hover"),this.focusable.removeClass("ui-state-focus"))),this
},enable:function(){return this._setOptions({disabled:!1})
},disable:function(){return this._setOptions({disabled:!0})
},_on:function(h,c,d){var p,l=this;
"boolean"!=typeof h&&(d=c,c=h,h=!1),d?(c=p=B(c),this.bindings=this.bindings.add(c)):(d=c,c=this.element,p=this.widget()),B.each(d,function(t,n){function u(){return h||l.options.disabled!==!0&&!B(this).hasClass("ui-state-disabled")?("string"==typeof n?l[n]:n).apply(l,arguments):void 0
}"string"!=typeof n&&(u.guid=n.guid=n.guid||u.guid||B.guid++);
var e=t.match(/^([\w:-]*)\s*(.*)$/),o=e[1]+l.eventNamespace,D=e[2];
D?p.delegate(D,o,u):c.bind(o,u)
})
},_off:function(d,c){c=(c||"").split(" ").join(this.eventNamespace+" ")+this.eventNamespace,d.unbind(c).undelegate(c),this.bindings=B(this.bindings.not(d).get()),this.focusable=B(this.focusable.not(d).get()),this.hoverable=B(this.hoverable.not(d).get())
},_delay:function(d,l){function c(){return("string"==typeof d?h[d]:d).apply(h,arguments)
}var h=this;
return setTimeout(c,l||0)
},_hoverable:function(c){this.hoverable=this.hoverable.add(c),this._on(c,{mouseenter:function(d){B(d.currentTarget).addClass("ui-state-hover")
},mouseleave:function(d){B(d.currentTarget).removeClass("ui-state-hover")
}})
},_focusable:function(c){this.focusable=this.focusable.add(c),this._on(c,{focusin:function(d){B(d.currentTarget).addClass("ui-state-focus")
},focusout:function(d){B(d.currentTarget).removeClass("ui-state-focus")
}})
},_trigger:function(l,d,h){var r,p,c=this.options[l];
if(h=h||{},d=B.Event(d),d.type=(l===this.widgetEventPrefix?l:this.widgetEventPrefix+l).toLowerCase(),d.target=this.element[0],p=d.originalEvent){for(r in p){r in d||(d[r]=p[r])
}}return this.element.trigger(d,h),!(B.isFunction(c)&&c.apply(this.element[0],[d].concat(h))===!1||d.isDefaultPrevented())
}},B.each({show:"fadeIn",hide:"fadeOut"},function(d,c){B.Widget.prototype["_"+d]=function(h,t,p){"string"==typeof t&&(t={effect:t});
var e,l=t?t===!0||"number"==typeof t?c:t.effect||c:d;
t=t||{},"number"==typeof t&&(t={duration:t}),e=!B.isEmptyObject(t),t.complete=p,t.delay&&h.delay(t.delay),e&&B.effects&&B.effects.effect[l]?h[d](t):l!==d&&h[l]?h[l](t.duration,t.easing,p):h.queue(function(n){B(this)[d](),p&&p.call(h[0]),n()
})
}
}),B.widget;
var y=!1;
B(document).mouseup(function(){y=!1
}),B.widget("ui.mouse",{version:"1.11.4",options:{cancel:"input,textarea,button,select,option",distance:1,delay:0},_mouseInit:function(){var c=this;
this.element.bind("mousedown."+this.widgetName,function(d){return c._mouseDown(d)
}).bind("click."+this.widgetName,function(d){return !0===B.data(d.target,c.widgetName+".preventClickEvent")?(B.removeData(d.target,c.widgetName+".preventClickEvent"),d.stopImmediatePropagation(),!1):void 0
}),this.started=!1
},_mouseDestroy:function(){this.element.unbind("."+this.widgetName),this._mouseMoveDelegate&&this.document.unbind("mousemove."+this.widgetName,this._mouseMoveDelegate).unbind("mouseup."+this.widgetName,this._mouseUpDelegate)
},_mouseDown:function(h){if(!y){this._mouseMoved=!1,this._mouseStarted&&this._mouseUp(h),this._mouseDownEvent=h;
var c=this,d=1===h.which,l="string"==typeof this.options.cancel&&h.target.nodeName?B(h.target).closest(this.options.cancel).length:!1;
return d&&!l&&this._mouseCapture(h)?(this.mouseDelayMet=!this.options.delay,this.mouseDelayMet||(this._mouseDelayTimer=setTimeout(function(){c.mouseDelayMet=!0
},this.options.delay)),this._mouseDistanceMet(h)&&this._mouseDelayMet(h)&&(this._mouseStarted=this._mouseStart(h)!==!1,!this._mouseStarted)?(h.preventDefault(),!0):(!0===B.data(h.target,this.widgetName+".preventClickEvent")&&B.removeData(h.target,this.widgetName+".preventClickEvent"),this._mouseMoveDelegate=function(e){return c._mouseMove(e)
},this._mouseUpDelegate=function(e){return c._mouseUp(e)
},this.document.bind("mousemove."+this.widgetName,this._mouseMoveDelegate).bind("mouseup."+this.widgetName,this._mouseUpDelegate),h.preventDefault(),y=!0,!0)):!0
}},_mouseMove:function(c){if(this._mouseMoved){if(B.ui.ie&&(!document.documentMode||9>document.documentMode)&&!c.button){return this._mouseUp(c)
}if(!c.which){return this._mouseUp(c)
}}return(c.which||c.button)&&(this._mouseMoved=!0),this._mouseStarted?(this._mouseDrag(c),c.preventDefault()):(this._mouseDistanceMet(c)&&this._mouseDelayMet(c)&&(this._mouseStarted=this._mouseStart(this._mouseDownEvent,c)!==!1,this._mouseStarted?this._mouseDrag(c):this._mouseUp(c)),!this._mouseStarted)
},_mouseUp:function(c){return this.document.unbind("mousemove."+this.widgetName,this._mouseMoveDelegate).unbind("mouseup."+this.widgetName,this._mouseUpDelegate),this._mouseStarted&&(this._mouseStarted=!1,c.target===this._mouseDownEvent.target&&B.data(c.target,this.widgetName+".preventClickEvent",!0),this._mouseStop(c)),y=!1,!1
},_mouseDistanceMet:function(c){return Math.max(Math.abs(this._mouseDownEvent.pageX-c.pageX),Math.abs(this._mouseDownEvent.pageY-c.pageY))>=this.options.distance
},_mouseDelayMet:function(){return this.mouseDelayMet
},_mouseStart:function(){},_mouseDrag:function(){},_mouseStop:function(){},_mouseCapture:function(){return !0
}}),function(){function K(d,h,c){return[parseFloat(d[0])*(D.test(d[0])?h/100:1),parseFloat(d[1])*(D.test(d[1])?c/100:1)]
}function H(d,c){return parseInt(B.css(d,c),10)||0
}function P(d){var c=d[0];
return 9===c.nodeType?{width:d.width(),height:d.height(),offset:{top:0,left:0}}:B.isWindow(c)?{width:d.width(),height:d.height(),offset:{top:d.scrollTop(),left:d.scrollLeft()}}:c.preventDefault?{width:0,height:0,offset:{top:c.pageY,left:c.pageX}}:{width:d.outerWidth(),height:d.outerHeight(),offset:d.offset()}
}B.ui=B.ui||{};
var F,E,N=Math.max,t=Math.abs,G=Math.round,I=/left|center|right/,M=/top|center|bottom/,O=/[\+\-]\d+(\.[\d]+)?%?/,L=/^\w+/,D=/%$/,J=B.fn.position;
B.position={scrollbarWidth:function(){if(void 0!==F){return F
}var h,c,d=B("<div style='display:block;position:absolute;width:50px;height:50px;overflow:hidden;'><div style='height:100px;width:auto;'></div></div>"),l=d.children()[0];
return B("body").append(d),h=l.offsetWidth,d.css("overflow","scroll"),c=l.offsetWidth,h===c&&(c=d[0].clientWidth),d.remove(),F=h-c
},getScrollInfo:function(h){var c=h.isWindow||h.isDocument?"":h.element.css("overflow-x"),d=h.isWindow||h.isDocument?"":h.element.css("overflow-y"),p="scroll"===c||"auto"===c&&h.width<h.element[0].scrollWidth,l="scroll"===d||"auto"===d&&h.height<h.element[0].scrollHeight;
return{width:l?B.position.scrollbarWidth():0,height:p?B.position.scrollbarWidth():0}
},getWithinInfo:function(h){var c=B(h||window),d=B.isWindow(c[0]),l=!!c[0]&&9===c[0].nodeType;
return{element:c,isWindow:d,isDocument:l,offset:c.offset()||{left:0,top:0},scrollLeft:c.scrollLeft(),scrollTop:c.scrollTop(),width:d||l?c.width():c.outerWidth(),height:d||l?c.height():c.outerHeight()}
}},B.fn.position=function(e){if(!e||!e.of){return J.apply(this,arguments)
}e=B.extend({},e);
var d,o,h,R,S,s,r=B(e.of),Q=B.position.getWithinInfo(e.within),l=B.position.getScrollInfo(Q),u=(e.collision||"flip").split(" "),c={};
return s=P(r),r[0].preventDefault&&(e.at="left top"),o=s.width,h=s.height,R=s.offset,S=B.extend({},R),B.each(["my","at"],function(){var p,T,n=(e[this]||"").split(" ");
1===n.length&&(n=I.test(n[0])?n.concat(["center"]):M.test(n[0])?["center"].concat(n):["center","center"]),n[0]=I.test(n[0])?n[0]:"center",n[1]=M.test(n[1])?n[1]:"center",p=O.exec(n[0]),T=O.exec(n[1]),c[this]=[p?p[0]:0,T?T[0]:0],e[this]=[L.exec(n[0])[0],L.exec(n[1])[0]]
}),1===u.length&&(u[1]=u[0]),"right"===e.at[0]?S.left+=o:"center"===e.at[0]&&(S.left+=o/2),"bottom"===e.at[1]?S.top+=h:"center"===e.at[1]&&(S.top+=h/2),d=K(c.at,o,h),S.left+=d[0],S.top+=d[1],this.each(function(){var ac,U,Y=B(this),ab=Y.outerWidth(),X=Y.outerHeight(),V=H(this,"marginLeft"),Z=H(this,"marginTop"),n=ab+V+H(this,"marginRight")+l.width,p=X+Z+H(this,"marginBottom")+l.height,aa=B.extend({},S),W=K(c.my,Y.outerWidth(),Y.outerHeight());
"right"===e.my[0]?aa.left-=ab:"center"===e.my[0]&&(aa.left-=ab/2),"bottom"===e.my[1]?aa.top-=X:"center"===e.my[1]&&(aa.top-=X/2),aa.left+=W[0],aa.top+=W[1],E||(aa.left=G(aa.left),aa.top=G(aa.top)),ac={marginLeft:V,marginTop:Z},B.each(["left","top"],function(ad,T){B.ui.position[u[ad]]&&B.ui.position[u[ad]][T](aa,{targetWidth:o,targetHeight:h,elemWidth:ab,elemHeight:X,collisionPosition:ac,collisionWidth:n,collisionHeight:p,offset:[d[0]+W[0],d[1]+W[1]],my:e.my,at:e.at,within:Q,elem:Y})
}),e.using&&(U=function(ae){var ag=R.left-aa.left,ad=ag+o-ab,af=R.top-aa.top,ah=af+h-X,T={target:{element:r,left:R.left,top:R.top,width:o,height:h},element:{element:Y,left:aa.left,top:aa.top,width:ab,height:X},horizontal:0>ad?"left":ag>0?"right":"center",vertical:0>ah?"top":af>0?"bottom":"middle"};
ab>o&&o>t(ag+ad)&&(T.horizontal="center"),X>h&&h>t(af+ah)&&(T.vertical="middle"),T.important=N(t(ag),t(ad))>N(t(af),t(ah))?"horizontal":"vertical",e.using.call(this,ae,T)
}),Y.offset(B.extend(aa,{using:U}))
})
},B.ui.position={fit:{left:function(T,S){var Q,U=S.within,p=U.isWindow?U.scrollLeft:U.offset.left,d=U.width,c=T.left-S.collisionPosition.marginLeft,u=p-c,R=c+S.collisionWidth-d-p;
S.collisionWidth>d?u>0&&0>=R?(Q=T.left+u+S.collisionWidth-d-p,T.left+=u-Q):T.left=R>0&&0>=u?p:u>R?p+d-S.collisionWidth:p:u>0?T.left+=u:R>0?T.left-=R:T.left=N(T.left-c,T.left)
},top:function(T,S){var Q,U=S.within,p=U.isWindow?U.scrollTop:U.offset.top,d=S.within.height,c=T.top-S.collisionPosition.marginTop,u=p-c,R=c+S.collisionHeight-d-p;
S.collisionHeight>d?u>0&&0>=R?(Q=T.top+u+S.collisionHeight-d-p,T.top+=u-Q):T.top=R>0&&0>=u?p:u>R?p+d-S.collisionHeight:p:u>0?T.top+=u:R>0?T.top-=R:T.top=N(T.top-c,T.top)
}},flip:{left:function(ab,W){var T,ac,R=W.within,Q=R.offset.left+R.scrollLeft,Z=R.width,S=R.isWindow?R.scrollLeft:R.offset.left,U=ab.left-W.collisionPosition.marginLeft,Y=U-S,aa=U+W.collisionWidth-Z-S,X="left"===W.my[0]?-W.elemWidth:"right"===W.my[0]?W.elemWidth:0,r="left"===W.at[0]?W.targetWidth:"right"===W.at[0]?-W.targetWidth:0,V=-2*W.offset[0];
0>Y?(T=ab.left+X+r+V+W.collisionWidth-Z-Q,(0>T||t(Y)>T)&&(ab.left+=X+r+V)):aa>0&&(ac=ab.left-W.collisionPosition.marginLeft+X+r+V-S,(ac>0||aa>t(ac))&&(ab.left+=X+r+V))
},top:function(ac,X){var T,ad,R=X.within,Q=R.offset.top+R.scrollTop,aa=R.height,S=R.isWindow?R.scrollTop:R.offset.top,U=ac.top-X.collisionPosition.marginTop,Z=U-S,ab=U+X.collisionHeight-aa-S,Y="top"===X.my[1],r=Y?-X.elemHeight:"bottom"===X.my[1]?X.elemHeight:0,W="top"===X.at[1]?X.targetHeight:"bottom"===X.at[1]?-X.targetHeight:0,V=-2*X.offset[1];
0>Z?(ad=ac.top+r+W+V+X.collisionHeight-aa-Q,(0>ad||t(Z)>ad)&&(ac.top+=r+W+V)):ab>0&&(T=ac.top-X.collisionPosition.marginTop+r+W+V-S,(T>0||ab>t(T))&&(ac.top+=r+W+V))
}},flipfit:{left:function(){B.ui.position.flip.left.apply(this,arguments),B.ui.position.fit.left.apply(this,arguments)
},top:function(){B.ui.position.flip.top.apply(this,arguments),B.ui.position.fit.top.apply(this,arguments)
}}},function(){var u,h,o,Q,d,p=document.getElementsByTagName("body")[0],c=document.createElement("div");
u=document.createElement(p?"div":"body"),o={visibility:"hidden",width:0,height:0,border:0,margin:0,background:"none"},p&&B.extend(o,{position:"absolute",left:"-1000px",top:"-1000px"});
for(d in o){u.style[d]=o[d]
}u.appendChild(c),h=p||document.documentElement,h.insertBefore(u,h.firstChild),c.style.cssText="position: absolute; left: 10.7432222px;",Q=B(c).offset().left,E=Q>10&&11>Q,u.innerHTML="",h.removeChild(u)
}()
}(),B.ui.position,B.widget("ui.draggable",B.ui.mouse,{version:"1.11.4",widgetEventPrefix:"drag",options:{addClasses:!0,appendTo:"parent",axis:!1,connectToSortable:!1,containment:!1,cursor:"auto",cursorAt:!1,grid:!1,handle:!1,helper:"original",iframeFix:!1,opacity:!1,refreshPositions:!1,revert:!1,revertDuration:500,scope:"default",scroll:!0,scrollSensitivity:20,scrollSpeed:20,snap:!1,snapMode:"both",snapTolerance:20,stack:!1,zIndex:!1,drag:null,start:null,stop:null},_create:function(){"original"===this.options.helper&&this._setPositionRelative(),this.options.addClasses&&this.element.addClass("ui-draggable"),this.options.disabled&&this.element.addClass("ui-draggable-disabled"),this._setHandleClassName(),this._mouseInit()
},_setOption:function(c,d){this._super(c,d),"handle"===c&&(this._removeHandleClassName(),this._setHandleClassName())
},_destroy:function(){return(this.helper||this.element).is(".ui-draggable-dragging")?(this.destroyOnClear=!0,void 0):(this.element.removeClass("ui-draggable ui-draggable-dragging ui-draggable-disabled"),this._removeHandleClassName(),this._mouseDestroy(),void 0)
},_mouseCapture:function(d){var c=this.options;
return this._blurActiveElement(d),this.helper||c.disabled||B(d.target).closest(".ui-resizable-handle").length>0?!1:(this.handle=this._getHandle(d),this.handle?(this._blockFrames(c.iframeFix===!0?"iframe":c.iframeFix),!0):!1)
},_blockFrames:function(c){this.iframeBlocks=this.document.find(c).map(function(){var d=B(this);
return B("<div>").css("position","absolute").appendTo(d.parent()).outerWidth(d.outerWidth()).outerHeight(d.outerHeight()).offset(d.offset())[0]
})
},_unblockFrames:function(){this.iframeBlocks&&(this.iframeBlocks.remove(),delete this.iframeBlocks)
},_blurActiveElement:function(h){var c=this.document[0];
if(this.handleElement.is(h.target)){try{c.activeElement&&"body"!==c.activeElement.nodeName.toLowerCase()&&B(c.activeElement).blur()
}catch(d){}}},_mouseStart:function(d){var c=this.options;
return this.helper=this._createHelper(d),this.helper.addClass("ui-draggable-dragging"),this._cacheHelperProportions(),B.ui.ddmanager&&(B.ui.ddmanager.current=this),this._cacheMargins(),this.cssPosition=this.helper.css("position"),this.scrollParent=this.helper.scrollParent(!0),this.offsetParent=this.helper.offsetParent(),this.hasFixedAncestor=this.helper.parents().filter(function(){return"fixed"===B(this).css("position")
}).length>0,this.positionAbs=this.element.offset(),this._refreshOffsets(d),this.originalPosition=this.position=this._generatePosition(d,!1),this.originalPageX=d.pageX,this.originalPageY=d.pageY,c.cursorAt&&this._adjustOffsetFromHelper(c.cursorAt),this._setContainment(),this._trigger("start",d)===!1?(this._clear(),!1):(this._cacheHelperProportions(),B.ui.ddmanager&&!c.dropBehaviour&&B.ui.ddmanager.prepareOffsets(this,d),this._normalizeRightBottom(),this._mouseDrag(d,!0),B.ui.ddmanager&&B.ui.ddmanager.dragStart(this,d),!0)
},_refreshOffsets:function(c){this.offset={top:this.positionAbs.top-this.margins.top,left:this.positionAbs.left-this.margins.left,scroll:!1,parent:this._getParentOffset(),relative:this._getRelativeOffset()},this.offset.click={left:c.pageX-this.offset.left,top:c.pageY-this.offset.top}
},_mouseDrag:function(h,c){if(this.hasFixedAncestor&&(this.offset.parent=this._getParentOffset()),this.position=this._generatePosition(h,!0),this.positionAbs=this._convertPositionTo("absolute"),!c){var d=this._uiHash();
if(this._trigger("drag",h,d)===!1){return this._mouseUp({}),!1
}this.position=d.position
}return this.helper[0].style.left=this.position.left+"px",this.helper[0].style.top=this.position.top+"px",B.ui.ddmanager&&B.ui.ddmanager.drag(this,h),!1
},_mouseStop:function(h){var c=this,d=!1;
return B.ui.ddmanager&&!this.options.dropBehaviour&&(d=B.ui.ddmanager.drop(this,h)),this.dropped&&(d=this.dropped,this.dropped=!1),"invalid"===this.options.revert&&!d||"valid"===this.options.revert&&d||this.options.revert===!0||B.isFunction(this.options.revert)&&this.options.revert.call(this.element,d)?B(this.helper).animate(this.originalPosition,parseInt(this.options.revertDuration,10),function(){c._trigger("stop",h)!==!1&&c._clear()
}):this._trigger("stop",h)!==!1&&this._clear(),!1
},_mouseUp:function(c){return this._unblockFrames(),B.ui.ddmanager&&B.ui.ddmanager.dragStop(this,c),this.handleElement.is(c.target)&&this.element.focus(),B.ui.mouse.prototype._mouseUp.call(this,c)
},cancel:function(){return this.helper.is(".ui-draggable-dragging")?this._mouseUp({}):this._clear(),this
},_getHandle:function(c){return this.options.handle?!!B(c.target).closest(this.element.find(this.options.handle)).length:!0
},_setHandleClassName:function(){this.handleElement=this.options.handle?this.element.find(this.options.handle):this.element,this.handleElement.addClass("ui-draggable-handle")
},_removeHandleClassName:function(){this.handleElement.removeClass("ui-draggable-handle")
},_createHelper:function(h){var c=this.options,d=B.isFunction(c.helper),l=d?B(c.helper.apply(this.element[0],[h])):"clone"===c.helper?this.element.clone().removeAttr("id"):this.element;
return l.parents("body").length||l.appendTo("parent"===c.appendTo?this.element[0].parentNode:c.appendTo),d&&l[0]===this.element[0]&&this._setPositionRelative(),l[0]===this.element[0]||/(fixed|absolute)/.test(l.css("position"))||l.css("position","absolute"),l
},_setPositionRelative:function(){/^(?:r|a|f)/.test(this.element.css("position"))||(this.element[0].style.position="relative")
},_adjustOffsetFromHelper:function(c){"string"==typeof c&&(c=c.split(" ")),B.isArray(c)&&(c={left:+c[0],top:+c[1]||0}),"left" in c&&(this.offset.click.left=c.left+this.margins.left),"right" in c&&(this.offset.click.left=this.helperProportions.width-c.right+this.margins.left),"top" in c&&(this.offset.click.top=c.top+this.margins.top),"bottom" in c&&(this.offset.click.top=this.helperProportions.height-c.bottom+this.margins.top)
},_isRootNode:function(c){return/(html|body)/i.test(c.tagName)||c===this.document[0]
},_getParentOffset:function(){var d=this.offsetParent.offset(),c=this.document[0];
return"absolute"===this.cssPosition&&this.scrollParent[0]!==c&&B.contains(this.scrollParent[0],this.offsetParent[0])&&(d.left+=this.scrollParent.scrollLeft(),d.top+=this.scrollParent.scrollTop()),this._isRootNode(this.offsetParent[0])&&(d={top:0,left:0}),{top:d.top+(parseInt(this.offsetParent.css("borderTopWidth"),10)||0),left:d.left+(parseInt(this.offsetParent.css("borderLeftWidth"),10)||0)}
},_getRelativeOffset:function(){if("relative"!==this.cssPosition){return{top:0,left:0}
}var c=this.element.position(),d=this._isRootNode(this.scrollParent[0]);
return{top:c.top-(parseInt(this.helper.css("top"),10)||0)+(d?0:this.scrollParent.scrollTop()),left:c.left-(parseInt(this.helper.css("left"),10)||0)+(d?0:this.scrollParent.scrollLeft())}
},_cacheMargins:function(){this.margins={left:parseInt(this.element.css("marginLeft"),10)||0,top:parseInt(this.element.css("marginTop"),10)||0,right:parseInt(this.element.css("marginRight"),10)||0,bottom:parseInt(this.element.css("marginBottom"),10)||0}
},_cacheHelperProportions:function(){this.helperProportions={width:this.helper.outerWidth(),height:this.helper.outerHeight()}
},_setContainment:function(){var h,c,d,p=this.options,l=this.document[0];
return this.relativeContainer=null,p.containment?"window"===p.containment?(this.containment=[B(window).scrollLeft()-this.offset.relative.left-this.offset.parent.left,B(window).scrollTop()-this.offset.relative.top-this.offset.parent.top,B(window).scrollLeft()+B(window).width()-this.helperProportions.width-this.margins.left,B(window).scrollTop()+(B(window).height()||l.body.parentNode.scrollHeight)-this.helperProportions.height-this.margins.top],void 0):"document"===p.containment?(this.containment=[0,0,B(l).width()-this.helperProportions.width-this.margins.left,(B(l).height()||l.body.parentNode.scrollHeight)-this.helperProportions.height-this.margins.top],void 0):p.containment.constructor===Array?(this.containment=p.containment,void 0):("parent"===p.containment&&(p.containment=this.helper[0].parentNode),c=B(p.containment),d=c[0],d&&(h=/(scroll|auto)/.test(c.css("overflow")),this.containment=[(parseInt(c.css("borderLeftWidth"),10)||0)+(parseInt(c.css("paddingLeft"),10)||0),(parseInt(c.css("borderTopWidth"),10)||0)+(parseInt(c.css("paddingTop"),10)||0),(h?Math.max(d.scrollWidth,d.offsetWidth):d.offsetWidth)-(parseInt(c.css("borderRightWidth"),10)||0)-(parseInt(c.css("paddingRight"),10)||0)-this.helperProportions.width-this.margins.left-this.margins.right,(h?Math.max(d.scrollHeight,d.offsetHeight):d.offsetHeight)-(parseInt(c.css("borderBottomWidth"),10)||0)-(parseInt(c.css("paddingBottom"),10)||0)-this.helperProportions.height-this.margins.top-this.margins.bottom],this.relativeContainer=c),void 0):(this.containment=null,void 0)
},_convertPositionTo:function(d,l){l||(l=this.position);
var c="absolute"===d?1:-1,h=this._isRootNode(this.scrollParent[0]);
return{top:l.top+this.offset.relative.top*c+this.offset.parent.top*c-("fixed"===this.cssPosition?-this.offset.scroll.top:h?0:this.offset.scroll.top)*c,left:l.left+this.offset.relative.left*c+this.offset.parent.left*c-("fixed"===this.cssPosition?-this.offset.scroll.left:h?0:this.offset.scroll.left)*c}
},_generatePosition:function(H,F){var D,I,p,d,G=this.options,c=this._isRootNode(this.scrollParent[0]),u=H.pageX,E=H.pageY;
return c&&this.offset.scroll||(this.offset.scroll={top:this.scrollParent.scrollTop(),left:this.scrollParent.scrollLeft()}),F&&(this.containment&&(this.relativeContainer?(I=this.relativeContainer.offset(),D=[this.containment[0]+I.left,this.containment[1]+I.top,this.containment[2]+I.left,this.containment[3]+I.top]):D=this.containment,H.pageX-this.offset.click.left<D[0]&&(u=D[0]+this.offset.click.left),H.pageY-this.offset.click.top<D[1]&&(E=D[1]+this.offset.click.top),H.pageX-this.offset.click.left>D[2]&&(u=D[2]+this.offset.click.left),H.pageY-this.offset.click.top>D[3]&&(E=D[3]+this.offset.click.top)),G.grid&&(p=G.grid[1]?this.originalPageY+Math.round((E-this.originalPageY)/G.grid[1])*G.grid[1]:this.originalPageY,E=D?p-this.offset.click.top>=D[1]||p-this.offset.click.top>D[3]?p:p-this.offset.click.top>=D[1]?p-G.grid[1]:p+G.grid[1]:p,d=G.grid[0]?this.originalPageX+Math.round((u-this.originalPageX)/G.grid[0])*G.grid[0]:this.originalPageX,u=D?d-this.offset.click.left>=D[0]||d-this.offset.click.left>D[2]?d:d-this.offset.click.left>=D[0]?d-G.grid[0]:d+G.grid[0]:d),"y"===G.axis&&(u=this.originalPageX),"x"===G.axis&&(E=this.originalPageY)),{top:E-this.offset.click.top-this.offset.relative.top-this.offset.parent.top+("fixed"===this.cssPosition?-this.offset.scroll.top:c?0:this.offset.scroll.top),left:u-this.offset.click.left-this.offset.relative.left-this.offset.parent.left+("fixed"===this.cssPosition?-this.offset.scroll.left:c?0:this.offset.scroll.left)}
},_clear:function(){this.helper.removeClass("ui-draggable-dragging"),this.helper[0]===this.element[0]||this.cancelHelperRemoval||this.helper.remove(),this.helper=null,this.cancelHelperRemoval=!1,this.destroyOnClear&&this.destroy()
},_normalizeRightBottom:function(){"y"!==this.options.axis&&"auto"!==this.helper.css("right")&&(this.helper.width(this.helper.width()),this.helper.css("right","auto")),"x"!==this.options.axis&&"auto"!==this.helper.css("bottom")&&(this.helper.height(this.helper.height()),this.helper.css("bottom","auto"))
},_trigger:function(h,c,d){return d=d||this._uiHash(),B.ui.plugin.call(this,h,[c,d,this],!0),/^(drag|start|stop)/.test(h)&&(this.positionAbs=this._convertPositionTo("absolute"),d.offset=this.positionAbs),B.Widget.prototype._trigger.call(this,h,c,d)
},plugins:{},_uiHash:function(){return{helper:this.helper,position:this.position,originalPosition:this.originalPosition,offset:this.positionAbs}
}}),B.ui.plugin.add("draggable","connectToSortable",{start:function(h,c,d){var l=B.extend({},c,{item:d.element});
d.sortables=[],B(d.options.connectToSortable).each(function(){var e=B(this).sortable("instance");
e&&!e.options.disabled&&(d.sortables.push(e),e.refreshPositions(),e._trigger("activate",h,l))
})
},stop:function(h,c,d){var l=B.extend({},c,{item:d.element});
d.cancelHelperRemoval=!1,B.each(d.sortables,function(){var e=this;
e.isOver?(e.isOver=0,d.cancelHelperRemoval=!0,e.cancelHelperRemoval=!1,e._storedCSS={position:e.placeholder.css("position"),top:e.placeholder.css("top"),left:e.placeholder.css("left")},e._mouseStop(h),e.options.helper=e.options._helper):(e.cancelHelperRemoval=!0,e._trigger("deactivate",h,l))
})
},drag:function(h,c,d){B.each(d.sortables,function(){var l=!1,e=this;
e.positionAbs=d.positionAbs,e.helperProportions=d.helperProportions,e.offset.click=d.offset.click,e._intersectsWith(e.containerCache)&&(l=!0,B.each(d.sortables,function(){return this.positionAbs=d.positionAbs,this.helperProportions=d.helperProportions,this.offset.click=d.offset.click,this!==e&&this._intersectsWith(this.containerCache)&&B.contains(e.element[0],this.element[0])&&(l=!1),l
})),l?(e.isOver||(e.isOver=1,d._parent=c.helper.parent(),e.currentItem=c.helper.appendTo(e.element).data("ui-sortable-item",!0),e.options._helper=e.options.helper,e.options.helper=function(){return c.helper[0]
},h.target=e.currentItem[0],e._mouseCapture(h,!0),e._mouseStart(h,!0,!0),e.offset.click.top=d.offset.click.top,e.offset.click.left=d.offset.click.left,e.offset.parent.left-=d.offset.parent.left-e.offset.parent.left,e.offset.parent.top-=d.offset.parent.top-e.offset.parent.top,d._trigger("toSortable",h),d.dropped=e.element,B.each(d.sortables,function(){this.refreshPositions()
}),d.currentItem=d.element,e.fromOutside=d),e.currentItem&&(e._mouseDrag(h),c.position=e.position)):e.isOver&&(e.isOver=0,e.cancelHelperRemoval=!0,e.options._revert=e.options.revert,e.options.revert=!1,e._trigger("out",h,e._uiHash(e)),e._mouseStop(h,!0),e.options.revert=e.options._revert,e.options.helper=e.options._helper,e.placeholder&&e.placeholder.remove(),c.helper.appendTo(d._parent),d._refreshOffsets(h),c.position=d._generatePosition(h,!0),d._trigger("fromSortable",h),d.dropped=!1,B.each(d.sortables,function(){this.refreshPositions()
}))
})
}}),B.ui.plugin.add("draggable","cursor",{start:function(h,c,d){var p=B("body"),l=d.options;
p.css("cursor")&&(l._cursor=p.css("cursor")),p.css("cursor",l.cursor)
},stop:function(h,c,d){var l=d.options;
l._cursor&&B("body").css("cursor",l._cursor)
}}),B.ui.plugin.add("draggable","opacity",{start:function(h,c,d){var p=B(c.helper),l=d.options;
p.css("opacity")&&(l._opacity=p.css("opacity")),p.css("opacity",l.opacity)
},stop:function(h,c,d){var l=d.options;
l._opacity&&B(c.helper).css("opacity",l._opacity)
}}),B.ui.plugin.add("draggable","scroll",{start:function(d,h,c){c.scrollParentNotHidden||(c.scrollParentNotHidden=c.helper.scrollParent(!1)),c.scrollParentNotHidden[0]!==c.document[0]&&"HTML"!==c.scrollParentNotHidden[0].tagName&&(c.overflowOffset=c.scrollParentNotHidden.offset())
},drag:function(p,d,h){var u=h.options,t=!1,c=h.scrollParentNotHidden[0],l=h.document[0];
c!==l&&"HTML"!==c.tagName?(u.axis&&"x"===u.axis||(h.overflowOffset.top+c.offsetHeight-p.pageY<u.scrollSensitivity?c.scrollTop=t=c.scrollTop+u.scrollSpeed:p.pageY-h.overflowOffset.top<u.scrollSensitivity&&(c.scrollTop=t=c.scrollTop-u.scrollSpeed)),u.axis&&"y"===u.axis||(h.overflowOffset.left+c.offsetWidth-p.pageX<u.scrollSensitivity?c.scrollLeft=t=c.scrollLeft+u.scrollSpeed:p.pageX-h.overflowOffset.left<u.scrollSensitivity&&(c.scrollLeft=t=c.scrollLeft-u.scrollSpeed))):(u.axis&&"x"===u.axis||(p.pageY-B(l).scrollTop()<u.scrollSensitivity?t=B(l).scrollTop(B(l).scrollTop()-u.scrollSpeed):B(window).height()-(p.pageY-B(l).scrollTop())<u.scrollSensitivity&&(t=B(l).scrollTop(B(l).scrollTop()+u.scrollSpeed))),u.axis&&"y"===u.axis||(p.pageX-B(l).scrollLeft()<u.scrollSensitivity?t=B(l).scrollLeft(B(l).scrollLeft()-u.scrollSpeed):B(window).width()-(p.pageX-B(l).scrollLeft())<u.scrollSensitivity&&(t=B(l).scrollLeft(B(l).scrollLeft()+u.scrollSpeed)))),t!==!1&&B.ui.ddmanager&&!u.dropBehaviour&&B.ui.ddmanager.prepareOffsets(h,p)
}}),B.ui.plugin.add("draggable","snap",{start:function(h,c,d){var l=d.options;
d.snapElements=[],B(l.snap.constructor!==String?l.snap.items||":data(ui-draggable)":l.snap).each(function(){var o=B(this),n=o.offset();
this!==d.element[0]&&d.snapElements.push({item:this,width:o.outerWidth(),height:o.outerHeight(),top:n.top,left:n.left})
})
},drag:function(P,L,E){var I,H,T,F,K,M,R,D,Q,G,O=E.options,N=O.snapTolerance,J=L.offset.left,U=J+E.helperProportions.width,t=L.offset.top,S=t+E.helperProportions.height;
for(Q=E.snapElements.length-1;
Q>=0;
Q--){K=E.snapElements[Q].left-E.margins.left,M=K+E.snapElements[Q].width,R=E.snapElements[Q].top-E.margins.top,D=R+E.snapElements[Q].height,K-N>U||J>M+N||R-N>S||t>D+N||!B.contains(E.snapElements[Q].item.ownerDocument,E.snapElements[Q].item)?(E.snapElements[Q].snapping&&E.options.snap.release&&E.options.snap.release.call(E.element,P,B.extend(E._uiHash(),{snapItem:E.snapElements[Q].item})),E.snapElements[Q].snapping=!1):("inner"!==O.snapMode&&(I=N>=Math.abs(R-S),H=N>=Math.abs(D-t),T=N>=Math.abs(K-U),F=N>=Math.abs(M-J),I&&(L.position.top=E._convertPositionTo("relative",{top:R-E.helperProportions.height,left:0}).top),H&&(L.position.top=E._convertPositionTo("relative",{top:D,left:0}).top),T&&(L.position.left=E._convertPositionTo("relative",{top:0,left:K-E.helperProportions.width}).left),F&&(L.position.left=E._convertPositionTo("relative",{top:0,left:M}).left)),G=I||H||T||F,"outer"!==O.snapMode&&(I=N>=Math.abs(R-t),H=N>=Math.abs(D-S),T=N>=Math.abs(K-J),F=N>=Math.abs(M-U),I&&(L.position.top=E._convertPositionTo("relative",{top:R,left:0}).top),H&&(L.position.top=E._convertPositionTo("relative",{top:D-E.helperProportions.height,left:0}).top),T&&(L.position.left=E._convertPositionTo("relative",{top:0,left:K}).left),F&&(L.position.left=E._convertPositionTo("relative",{top:0,left:M-E.helperProportions.width}).left)),!E.snapElements[Q].snapping&&(I||H||T||F||G)&&E.options.snap.snap&&E.options.snap.snap.call(E.element,P,B.extend(E._uiHash(),{snapItem:E.snapElements[Q].item})),E.snapElements[Q].snapping=I||H||T||F||G)
}}}),B.ui.plugin.add("draggable","stack",{start:function(l,d,h){var r,p=h.options,c=B.makeArray(B(p.stack)).sort(function(o,n){return(parseInt(B(o).css("zIndex"),10)||0)-(parseInt(B(n).css("zIndex"),10)||0)
});
c.length&&(r=parseInt(B(c[0]).css("zIndex"),10)||0,B(c).each(function(n){B(this).css("zIndex",r+n)
}),this.css("zIndex",r+c.length))
}}),B.ui.plugin.add("draggable","zIndex",{start:function(h,c,d){var p=B(c.helper),l=d.options;
p.css("zIndex")&&(l._zIndex=p.css("zIndex")),p.css("zIndex",l.zIndex)
},stop:function(h,c,d){var l=d.options;
l._zIndex&&B(c.helper).css("zIndex",l._zIndex)
}}),B.ui.draggable,B.widget("ui.menu",{version:"1.11.4",defaultElement:"<ul>",delay:300,options:{icons:{submenu:"ui-icon-carat-1-e"},items:"> *",menus:"ul",position:{my:"left-1 top",at:"right top"},role:"menu",blur:null,focus:null,select:null},_create:function(){this.activeMenu=this.element,this.mouseHandled=!1,this.element.uniqueId().addClass("ui-menu ui-widget ui-widget-content").toggleClass("ui-menu-icons",!!this.element.find(".ui-icon").length).attr({role:this.options.role,tabIndex:0}),this.options.disabled&&this.element.addClass("ui-state-disabled").attr("aria-disabled","true"),this._on({"mousedown .ui-menu-item":function(c){c.preventDefault()
},"click .ui-menu-item":function(d){var c=B(d.target);
!this.mouseHandled&&c.not(".ui-state-disabled").length&&(this.select(d),d.isPropagationStopped()||(this.mouseHandled=!0),c.has(".ui-menu").length?this.expand(d):!this.element.is(":focus")&&B(this.document[0].activeElement).closest(".ui-menu").length&&(this.element.trigger("focus",[!0]),this.active&&1===this.active.parents(".ui-menu").length&&clearTimeout(this.timer)))
},"mouseenter .ui-menu-item":function(d){if(!this.previousFilter){var c=B(d.currentTarget);
c.siblings(".ui-state-active").removeClass("ui-state-active"),this.focus(d,c)
}},mouseleave:"collapseAll","mouseleave .ui-menu":"collapseAll",focus:function(d,h){var c=this.active||this.element.find(this.options.items).eq(0);
h||this.focus(d,c)
},blur:function(c){this._delay(function(){B.contains(this.element[0],this.document[0].activeElement)||this.collapseAll(c)
})
},keydown:"_keydown"}),this.refresh(),this._on(this.document,{click:function(c){this._closeOnDocumentClick(c)&&this.collapseAll(c),this.mouseHandled=!1
}})
},_destroy:function(){this.element.removeAttr("aria-activedescendant").find(".ui-menu").addBack().removeClass("ui-menu ui-widget ui-widget-content ui-menu-icons ui-front").removeAttr("role").removeAttr("tabIndex").removeAttr("aria-labelledby").removeAttr("aria-expanded").removeAttr("aria-hidden").removeAttr("aria-disabled").removeUniqueId().show(),this.element.find(".ui-menu-item").removeClass("ui-menu-item").removeAttr("role").removeAttr("aria-disabled").removeUniqueId().removeClass("ui-state-hover").removeAttr("tabIndex").removeAttr("role").removeAttr("aria-haspopup").children().each(function(){var c=B(this);
c.data("ui-menu-submenu-carat")&&c.remove()
}),this.element.find(".ui-menu-divider").removeClass("ui-menu-divider ui-widget-content")
},_keydown:function(l){var d,h,r,p,c=!0;
switch(l.keyCode){case B.ui.keyCode.PAGE_UP:this.previousPage(l);
break;
case B.ui.keyCode.PAGE_DOWN:this.nextPage(l);
break;
case B.ui.keyCode.HOME:this._move("first","first",l);
break;
case B.ui.keyCode.END:this._move("last","last",l);
break;
case B.ui.keyCode.UP:this.previous(l);
break;
case B.ui.keyCode.DOWN:this.next(l);
break;
case B.ui.keyCode.LEFT:this.collapse(l);
break;
case B.ui.keyCode.RIGHT:this.active&&!this.active.is(".ui-state-disabled")&&this.expand(l);
break;
case B.ui.keyCode.ENTER:case B.ui.keyCode.SPACE:this._activate(l);
break;
case B.ui.keyCode.ESCAPE:this.collapse(l);
break;
default:c=!1,h=this.previousFilter||"",r=String.fromCharCode(l.keyCode),p=!1,clearTimeout(this.filterTimer),r===h?p=!0:r=h+r,d=this._filterMenuItems(r),d=p&&-1!==d.index(this.active.next())?this.active.nextAll(".ui-menu-item"):d,d.length||(r=String.fromCharCode(l.keyCode),d=this._filterMenuItems(r)),d.length?(this.focus(l,d),this.previousFilter=r,this.filterTimer=this._delay(function(){delete this.previousFilter
},1000)):delete this.previousFilter
}c&&l.preventDefault()
},_activate:function(c){this.active.is(".ui-state-disabled")||(this.active.is("[aria-haspopup='true']")?this.expand(c):this.select(c))
},refresh:function(){var h,c,d=this,p=this.options.icons.submenu,l=this.element.find(this.options.menus);
this.element.toggleClass("ui-menu-icons",!!this.element.find(".ui-icon").length),l.filter(":not(.ui-menu)").addClass("ui-menu ui-widget ui-widget-content ui-front").hide().attr({role:this.options.role,"aria-hidden":"true","aria-expanded":"false"}).each(function(){var r=B(this),n=r.parent(),o=B("<span>").addClass("ui-menu-icon ui-icon "+p).data("ui-menu-submenu-carat",!0);
n.attr("aria-haspopup","true").prepend(o),r.attr("aria-labelledby",n.attr("id"))
}),h=l.add(this.element),c=h.find(this.options.items),c.not(".ui-menu-item").each(function(){var n=B(this);
d._isDivider(n)&&n.addClass("ui-widget-content ui-menu-divider")
}),c.not(".ui-menu-item, .ui-menu-divider").addClass("ui-menu-item").uniqueId().attr({tabIndex:-1,role:this._itemRole()}),c.filter(".ui-state-disabled").attr("aria-disabled","true"),this.active&&!B.contains(this.element[0],this.active[0])&&this.blur()
},_itemRole:function(){return{menu:"menuitem",listbox:"option"}[this.options.role]
},_setOption:function(c,d){"icons"===c&&this.element.find(".ui-menu-icon").removeClass(this.options.icons.submenu).addClass(d.submenu),"disabled"===c&&this.element.toggleClass("ui-state-disabled",!!d).attr("aria-disabled",d),this._super(c,d)
},focus:function(d,l){var c,h;
this.blur(d,d&&"focus"===d.type),this._scrollIntoView(l),this.active=l.first(),h=this.active.addClass("ui-state-focus").removeClass("ui-state-active"),this.options.role&&this.element.attr("aria-activedescendant",h.attr("id")),this.active.parent().closest(".ui-menu-item").addClass("ui-state-active"),d&&"keydown"===d.type?this._close():this.timer=this._delay(function(){this._close()
},this.delay),c=l.children(".ui-menu"),c.length&&d&&/^mouse/.test(d.type)&&this._startOpening(c),this.activeMenu=l.parent(),this._trigger("focus",d,{item:l})
},_scrollIntoView:function(p){var d,h,u,t,c,l;
this._hasScroll()&&(d=parseFloat(B.css(this.activeMenu[0],"borderTopWidth"))||0,h=parseFloat(B.css(this.activeMenu[0],"paddingTop"))||0,u=p.offset().top-this.activeMenu.offset().top-d-h,t=this.activeMenu.scrollTop(),c=this.activeMenu.height(),l=p.outerHeight(),0>u?this.activeMenu.scrollTop(t+u):u+l>c&&this.activeMenu.scrollTop(t+u-c+l))
},blur:function(c,d){d||clearTimeout(this.timer),this.active&&(this.active.removeClass("ui-state-focus"),this.active=null,this._trigger("blur",c,{item:this.active}))
},_startOpening:function(c){clearTimeout(this.timer),"true"===c.attr("aria-hidden")&&(this.timer=this._delay(function(){this._close(),this._open(c)
},this.delay))
},_open:function(d){var c=B.extend({of:this.active},this.options.position);
clearTimeout(this.timer),this.element.find(".ui-menu").not(d.parents(".ui-menu")).hide().attr("aria-hidden","true"),d.show().removeAttr("aria-hidden").attr("aria-expanded","true").position(c)
},collapseAll:function(d,c){clearTimeout(this.timer),this.timer=this._delay(function(){var e=c?this.element:B(d&&d.target).closest(this.element.find(".ui-menu"));
e.length||(e=this.element),this._close(e),this.blur(d),this.activeMenu=e
},this.delay)
},_close:function(c){c||(c=this.active?this.active.parent():this.element),c.find(".ui-menu").hide().attr("aria-hidden","true").attr("aria-expanded","false").end().find(".ui-state-active").not(".ui-state-focus").removeClass("ui-state-active")
},_closeOnDocumentClick:function(c){return !B(c.target).closest(".ui-menu").length
},_isDivider:function(c){return !/[^\-\u2014\u2013\s]/.test(c.text())
},collapse:function(c){var d=this.active&&this.active.parent().closest(".ui-menu-item",this.element);
d&&d.length&&(this._close(),this.focus(c,d))
},expand:function(c){var d=this.active&&this.active.children(".ui-menu ").find(this.options.items).first();
d&&d.length&&(this._open(d.parent()),this._delay(function(){this.focus(c,d)
}))
},next:function(c){this._move("next","first",c)
},previous:function(c){this._move("prev","last",c)
},isFirstItem:function(){return this.active&&!this.active.prevAll(".ui-menu-item").length
},isLastItem:function(){return this.active&&!this.active.nextAll(".ui-menu-item").length
},_move:function(d,l,c){var h;
this.active&&(h="first"===d||"last"===d?this.active["first"===d?"prevAll":"nextAll"](".ui-menu-item").eq(-1):this.active[d+"All"](".ui-menu-item").eq(0)),h&&h.length&&this.active||(h=this.activeMenu.find(this.options.items)[l]()),this.focus(c,h)
},nextPage:function(h){var c,d,l;
return this.active?(this.isLastItem()||(this._hasScroll()?(d=this.active.offset().top,l=this.element.height(),this.active.nextAll(".ui-menu-item").each(function(){return c=B(this),0>c.offset().top-d-l
}),this.focus(h,c)):this.focus(h,this.activeMenu.find(this.options.items)[this.active?"last":"first"]())),void 0):(this.next(h),void 0)
},previousPage:function(h){var c,d,l;
return this.active?(this.isFirstItem()||(this._hasScroll()?(d=this.active.offset().top,l=this.element.height(),this.active.prevAll(".ui-menu-item").each(function(){return c=B(this),c.offset().top-d+l>0
}),this.focus(h,c)):this.focus(h,this.activeMenu.find(this.options.items).first())),void 0):(this.next(h),void 0)
},_hasScroll:function(){return this.element.outerHeight()<this.element.prop("scrollHeight")
},select:function(d){this.active=this.active||B(d.target).closest(".ui-menu-item");
var c={item:this.active};
this.active.has(".ui-menu").length||this.collapseAll(d,!0),this._trigger("select",d,c)
},_filterMenuItems:function(h){var c=h.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g,"\\$&"),d=RegExp("^"+c,"i");
return this.activeMenu.find(this.options.items).filter(".ui-menu-item").filter(function(){return d.test(B.trim(B(this).text()))
})
}}),B.widget("ui.autocomplete",{version:"1.11.4",defaultElement:"<input>",options:{appendTo:null,autoFocus:!1,delay:300,minLength:1,position:{my:"left top",at:"left bottom",collision:"none"},source:null,change:null,close:null,focus:null,open:null,response:null,search:null,select:null},requestIndex:0,pending:0,_create:function(){var l,d,h,r=this.element[0].nodeName.toLowerCase(),p="textarea"===r,c="input"===r;
this.isMultiLine=p?!0:c?!1:this.element.prop("isContentEditable"),this.valueMethod=this.element[p||c?"val":"text"],this.isNewMenu=!0,this.element.addClass("ui-autocomplete-input").attr("autocomplete","off"),this._on(this.element,{keydown:function(s){if(this.element.prop("readOnly")){return l=!0,h=!0,d=!0,void 0
}l=!1,h=!1,d=!1;
var e=B.ui.keyCode;
switch(s.keyCode){case e.PAGE_UP:l=!0,this._move("previousPage",s);
break;
case e.PAGE_DOWN:l=!0,this._move("nextPage",s);
break;
case e.UP:l=!0,this._keyEvent("previous",s);
break;
case e.DOWN:l=!0,this._keyEvent("next",s);
break;
case e.ENTER:this.menu.active&&(l=!0,s.preventDefault(),this.menu.select(s));
break;
case e.TAB:this.menu.active&&this.menu.select(s);
break;
case e.ESCAPE:this.menu.element.is(":visible")&&(this.isMultiLine||this._value(this.term),this.close(s),s.preventDefault());
break;
default:d=!0,this._searchTimeout(s)
}},keypress:function(e){if(l){return l=!1,(!this.isMultiLine||this.menu.element.is(":visible"))&&e.preventDefault(),void 0
}if(!d){var o=B.ui.keyCode;
switch(e.keyCode){case o.PAGE_UP:this._move("previousPage",e);
break;
case o.PAGE_DOWN:this._move("nextPage",e);
break;
case o.UP:this._keyEvent("previous",e);
break;
case o.DOWN:this._keyEvent("next",e)
}}},input:function(e){return h?(h=!1,e.preventDefault(),void 0):(this._searchTimeout(e),void 0)
},focus:function(){this.selectedItem=null,this.previous=this._value()
},blur:function(e){return this.cancelBlur?(delete this.cancelBlur,void 0):(clearTimeout(this.searching),this.close(e),this._change(e),void 0)
}}),this._initSource(),this.menu=B("<ul>").addClass("ui-autocomplete ui-front").appendTo(this._appendTo()).menu({role:null}).hide().menu("instance"),this._on(this.menu.element,{mousedown:function(o){o.preventDefault(),this.cancelBlur=!0,this._delay(function(){delete this.cancelBlur
});
var n=this.menu.element[0];
B(o.target).closest(".ui-menu-item").length||this._delay(function(){var s=this;
this.document.one("mousedown",function(e){e.target===s.element[0]||e.target===n||B.contains(n,e.target)||s.close()
})
})
},menufocus:function(u,o){var t,D;
return this.isNewMenu&&(this.isNewMenu=!1,u.originalEvent&&/^mouse/.test(u.originalEvent.type))?(this.menu.blur(),this.document.one("mousemove",function(){B(u.target).trigger(u.originalEvent)
}),void 0):(D=o.item.data("ui-autocomplete-item"),!1!==this._trigger("focus",u,{item:D})&&u.originalEvent&&/^key/.test(u.originalEvent.type)&&this._value(D.value),t=o.item.attr("aria-label")||D.value,t&&B.trim(t).length&&(this.liveRegion.children().hide(),B("<div>").text(t).appendTo(this.liveRegion)),void 0)
},menuselect:function(o,D){var n=D.item.data("ui-autocomplete-item"),u=this.previous;
this.element[0]!==this.document[0].activeElement&&(this.element.focus(),this.previous=u,this._delay(function(){this.previous=u,this.selectedItem=n
})),!1!==this._trigger("select",o,{item:n})&&this._value(n.value),this.term=this._value(),this.close(o),this.selectedItem=n
}}),this.liveRegion=B("<span>",{role:"status","aria-live":"assertive","aria-relevant":"additions"}).addClass("ui-helper-hidden-accessible").appendTo(this.document[0].body),this._on(this.window,{beforeunload:function(){this.element.removeAttr("autocomplete")
}})
},_destroy:function(){clearTimeout(this.searching),this.element.removeClass("ui-autocomplete-input").removeAttr("autocomplete"),this.menu.element.remove(),this.liveRegion.remove()
},_setOption:function(c,d){this._super(c,d),"source"===c&&this._initSource(),"appendTo"===c&&this.menu.element.appendTo(this._appendTo()),"disabled"===c&&d&&this.xhr&&this.xhr.abort()
},_appendTo:function(){var c=this.options.appendTo;
return c&&(c=c.jquery||c.nodeType?B(c):this.document.find(c).eq(0)),c&&c[0]||(c=this.element.closest(".ui-front")),c.length||(c=this.document[0].body),c
},_initSource:function(){var h,c,d=this;
B.isArray(this.options.source)?(h=this.options.source,this.source=function(e,l){l(B.ui.autocomplete.filter(h,e.term))
}):"string"==typeof this.options.source?(c=this.options.source,this.source=function(l,o){d.xhr&&d.xhr.abort(),d.xhr=B.ajax({url:c,data:l,dataType:"json",success:function(e){o(e)
},error:function(){o([])
}})
}):this.source=this.options.source
},_searchTimeout:function(c){clearTimeout(this.searching),this.searching=this._delay(function(){var l=this.term===this._value(),d=this.menu.element.is(":visible"),h=c.altKey||c.ctrlKey||c.metaKey||c.shiftKey;
(!l||l&&!d&&!h)&&(this.selectedItem=null,this.search(null,c))
},this.options.delay)
},search:function(c,d){return c=null!=c?c:this._value(),this.term=this._value(),c.length<this.options.minLength?this.close(d):this._trigger("search",d)!==!1?this._search(c):void 0
},_search:function(c){this.pending++,this.element.addClass("ui-autocomplete-loading"),this.cancelSearch=!1,this.source({term:c},this._response())
},_response:function(){var c=++this.requestIndex;
return B.proxy(function(d){c===this.requestIndex&&this.__response(d),this.pending--,this.pending||this.element.removeClass("ui-autocomplete-loading")
},this)
},__response:function(c){c&&(c=this._normalize(c)),this._trigger("response",null,{content:c}),!this.options.disabled&&c&&c.length&&!this.cancelSearch?(this._suggest(c),this._trigger("open")):this._close()
},close:function(c){this.cancelSearch=!0,this._close(c)
},_close:function(c){this.menu.element.is(":visible")&&(this.menu.element.hide(),this.menu.blur(),this.isNewMenu=!0,this._trigger("close",c))
},_change:function(c){this.previous!==this._value()&&this._trigger("change",c,{item:this.selectedItem})
},_normalize:function(c){return c.length&&c[0].label&&c[0].value?c:B.map(c,function(d){return"string"==typeof d?{label:d,value:d}:B.extend({},d,{label:d.label||d.value,value:d.value||d.label})
})
},_suggest:function(d){var c=this.menu.element.empty();
this._renderMenu(c,d),this.isNewMenu=!0,this.menu.refresh(),c.show(),this._resizeMenu(),c.position(B.extend({of:this.element},this.options.position)),this.options.autoFocus&&this.menu.next()
},_resizeMenu:function(){var c=this.menu.element;
c.outerWidth(Math.max(c.width("").outerWidth()+1,this.element.outerWidth()))
},_renderMenu:function(h,c){var d=this;
B.each(c,function(l,e){d._renderItemData(h,e)
})
},_renderItemData:function(c,d){return this._renderItem(c,d).data("ui-autocomplete-item",d)
},_renderItem:function(d,c){return B("<li>").text(c.label).appendTo(d)
},_move:function(c,d){return this.menu.element.is(":visible")?this.menu.isFirstItem()&&/^previous/.test(c)||this.menu.isLastItem()&&/^next/.test(c)?(this.isMultiLine||this._value(this.term),this.menu.blur(),void 0):(this.menu[c](d),void 0):(this.search(null,d),void 0)
},widget:function(){return this.menu.element
},_value:function(){return this.valueMethod.apply(this.element,arguments)
},_keyEvent:function(c,d){(!this.isMultiLine||this.menu.element.is(":visible"))&&(this._move(c,d),d.preventDefault())
}}),B.extend(B.ui.autocomplete,{escapeRegex:function(c){return c.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g,"\\$&")
},filter:function(h,c){var d=RegExp(B.ui.autocomplete.escapeRegex(c),"i");
return B.grep(h,function(e){return d.test(e.label||e.value||e)
})
}}),B.widget("ui.autocomplete",B.ui.autocomplete,{options:{messages:{noResults:"No search results.",results:function(c){return c+(c>1?" results are":" result is")+" available, use up and down arrow keys to navigate."
}}},__response:function(d){var c;
this._superApply(arguments),this.options.disabled||this.cancelSearch||(c=d&&d.length?this.options.messages.results(d.length):this.options.messages.noResults,this.liveRegion.children().hide(),B("<div>").text(c).appendTo(this.liveRegion))
}}),B.ui.autocomplete,B.extend(B.ui,{datepicker:{version:"1.11.4"}});
var A;
B.extend(k.prototype,{markerClassName:"hasDatepicker",maxRows:4,_widgetDatepicker:function(){return this.dpDiv
},setDefaults:function(c){return b(this._defaults,c||{}),this
},_attachDatepicker:function(h,c){var d,p,l;
d=h.nodeName.toLowerCase(),p="div"===d||"span"===d,h.id||(this.uuid+=1,h.id="dp"+this.uuid),l=this._newInst(B(h),p),l.settings=B.extend({},c||{}),"input"===d?this._connectDatepicker(h,l):p&&this._inlineDatepicker(h,l)
},_newInst:function(h,c){var d=h[0].id.replace(/([^A-Za-z0-9_\-])/g,"\\\\$1");
return{id:d,input:h,selectedDay:0,selectedMonth:0,selectedYear:0,drawMonth:0,drawYear:0,inline:c,dpDiv:c?g(B("<div class='"+this._inlineClass+" ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>")):this.dpDiv}
},_connectDatepicker:function(h,c){var d=B(h);
c.append=B([]),c.trigger=B([]),d.hasClass(this.markerClassName)||(this._attachments(d,c),d.addClass(this.markerClassName).keydown(this._doKeyDown).keypress(this._doKeyPress).keyup(this._doKeyUp),this._autoSize(c),B.data(h,"datepicker",c),c.settings.disabled&&this._disableDatepicker(h))
},_attachments:function(p,d){var h,u,t,c=this._get(d,"appendText"),l=this._get(d,"isRTL");
d.append&&d.append.remove(),c&&(d.append=B("<span class='"+this._appendClass+"'>"+c+"</span>"),p[l?"before":"after"](d.append)),p.unbind("focus",this._showDatepicker),d.trigger&&d.trigger.remove(),h=this._get(d,"showOn"),("focus"===h||"both"===h)&&p.focus(this._showDatepicker),("button"===h||"both"===h)&&(u=this._get(d,"buttonText"),t=this._get(d,"buttonImage"),d.trigger=B(this._get(d,"buttonImageOnly")?B("<img/>").addClass(this._triggerClass).attr({src:t,alt:u,title:u}):B("<button type='button'></button>").addClass(this._triggerClass).html(t?B("<img/>").attr({src:t,alt:u,title:u}):u)),p[l?"before":"after"](d.trigger),d.trigger.click(function(){return B.datepicker._datepickerShowing&&B.datepicker._lastInput===p[0]?B.datepicker._hideDatepicker():B.datepicker._datepickerShowing&&B.datepicker._lastInput!==p[0]?(B.datepicker._hideDatepicker(),B.datepicker._showDatepicker(p[0])):B.datepicker._showDatepicker(p[0]),!1
}))
},_autoSize:function(h){if(this._get(h,"autoSize")&&!h.inline){var p,d,l,u,r=new Date(2009,11,20),c=this._get(h,"dateFormat");
c.match(/[DM]/)&&(p=function(e){for(d=0,l=0,u=0;
e.length>u;
u++){e[u].length>d&&(d=e[u].length,l=u)
}return l
},r.setMonth(p(this._get(h,c.match(/MM/)?"monthNames":"monthNamesShort"))),r.setDate(p(this._get(h,c.match(/DD/)?"dayNames":"dayNamesShort"))+20-r.getDay())),h.input.attr("size",this._formatDate(h,r).length)
}},_inlineDatepicker:function(h,c){var d=B(h);
d.hasClass(this.markerClassName)||(d.addClass(this.markerClassName).append(c.dpDiv),B.data(h,"datepicker",c),this._setDate(c,this._getDefaultDate(c),!0),this._updateDatepicker(c),this._updateAlternate(c),c.settings.disabled&&this._disableDatepicker(h),c.dpDiv.css("display","block"))
},_dialogDatepicker:function(F,D,K,r,p){var I,t,E,H,J,G=this._dialogInst;
return G||(this.uuid+=1,I="dp"+this.uuid,this._dialogInput=B("<input type='text' id='"+I+"' style='position: absolute; top: -100px; width: 0px;'/>"),this._dialogInput.keydown(this._doKeyDown),B("body").append(this._dialogInput),G=this._dialogInst=this._newInst(this._dialogInput,!1),G.settings={},B.data(this._dialogInput[0],"datepicker",G)),b(G.settings,r||{}),D=D&&D.constructor===Date?this._formatDate(G,D):D,this._dialogInput.val(D),this._pos=p?p.length?p:[p.pageX,p.pageY]:null,this._pos||(t=document.documentElement.clientWidth,E=document.documentElement.clientHeight,H=document.documentElement.scrollLeft||document.body.scrollLeft,J=document.documentElement.scrollTop||document.body.scrollTop,this._pos=[t/2-100+H,E/2-150+J]),this._dialogInput.css("left",this._pos[0]+20+"px").css("top",this._pos[1]+"px"),G.settings.onSelect=K,this._inDialog=!0,this.dpDiv.addClass(this._dialogClass),this._showDatepicker(this._dialogInput[0]),B.blockUI&&B.blockUI(this.dpDiv),B.data(this._dialogInput[0],"datepicker",G),this
},_destroyDatepicker:function(h){var c,d=B(h),l=B.data(h,"datepicker");
d.hasClass(this.markerClassName)&&(c=h.nodeName.toLowerCase(),B.removeData(h,"datepicker"),"input"===c?(l.append.remove(),l.trigger.remove(),d.removeClass(this.markerClassName).unbind("focus",this._showDatepicker).unbind("keydown",this._doKeyDown).unbind("keypress",this._doKeyPress).unbind("keyup",this._doKeyUp)):("div"===c||"span"===c)&&d.removeClass(this.markerClassName).empty(),A===l&&(A=null))
},_enableDatepicker:function(h){var c,d,p=B(h),l=B.data(h,"datepicker");
p.hasClass(this.markerClassName)&&(c=h.nodeName.toLowerCase(),"input"===c?(h.disabled=!1,l.trigger.filter("button").each(function(){this.disabled=!1
}).end().filter("img").css({opacity:"1.0",cursor:""})):("div"===c||"span"===c)&&(d=p.children("."+this._inlineClass),d.children().removeClass("ui-state-disabled"),d.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled",!1)),this._disabledInputs=B.map(this._disabledInputs,function(e){return e===h?null:e
}))
},_disableDatepicker:function(h){var c,d,p=B(h),l=B.data(h,"datepicker");
p.hasClass(this.markerClassName)&&(c=h.nodeName.toLowerCase(),"input"===c?(h.disabled=!0,l.trigger.filter("button").each(function(){this.disabled=!0
}).end().filter("img").css({opacity:"0.5",cursor:"default"})):("div"===c||"span"===c)&&(d=p.children("."+this._inlineClass),d.children().addClass("ui-state-disabled"),d.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled",!0)),this._disabledInputs=B.map(this._disabledInputs,function(e){return e===h?null:e
}),this._disabledInputs[this._disabledInputs.length]=h)
},_isDisabledDatepicker:function(c){if(!c){return !1
}for(var d=0;
this._disabledInputs.length>d;
d++){if(this._disabledInputs[d]===c){return !0
}}return !1
},_getInst:function(d){try{return B.data(d,"datepicker")
}catch(c){throw"Missing instance data for this datepicker"
}},_optionDatepicker:function(u,p,t){var E,D,d,c,r=this._getInst(u);
return 2===arguments.length&&"string"==typeof p?"defaults"===p?B.extend({},B.datepicker._defaults):r?"all"===p?B.extend({},r.settings):this._get(r,p):null:(E=p||{},"string"==typeof p&&(E={},E[p]=t),r&&(this._curInst===r&&this._hideDatepicker(),D=this._getDateDatepicker(u,!0),d=this._getMinMaxDate(r,"min"),c=this._getMinMaxDate(r,"max"),b(r.settings,E),null!==d&&void 0!==E.dateFormat&&void 0===E.minDate&&(r.settings.minDate=this._formatDate(r,d)),null!==c&&void 0!==E.dateFormat&&void 0===E.maxDate&&(r.settings.maxDate=this._formatDate(r,c)),"disabled" in E&&(E.disabled?this._disableDatepicker(u):this._enableDatepicker(u)),this._attachments(B(u),r),this._autoSize(r),this._setDate(r,D),this._updateAlternate(r),this._updateDatepicker(r)),void 0)
},_changeDatepicker:function(d,h,c){this._optionDatepicker(d,h,c)
},_refreshDatepicker:function(c){var d=this._getInst(c);
d&&this._updateDatepicker(d)
},_setDateDatepicker:function(d,h){var c=this._getInst(d);
c&&(this._setDate(c,h),this._updateDatepicker(c),this._updateAlternate(c))
},_getDateDatepicker:function(d,h){var c=this._getInst(d);
return c&&!c.inline&&this._setDateFromField(c,h),c?this._getDate(c):null
},_doKeyDown:function(p){var d,h,u,t=B.datepicker._getInst(p.target),c=!0,l=t.dpDiv.is(".ui-datepicker-rtl");
if(t._keyEvent=!0,B.datepicker._datepickerShowing){switch(p.keyCode){case 9:B.datepicker._hideDatepicker(),c=!1;
break;
case 13:return u=B("td."+B.datepicker._dayOverClass+":not(."+B.datepicker._currentClass+")",t.dpDiv),u[0]&&B.datepicker._selectDay(p.target,t.selectedMonth,t.selectedYear,u[0]),d=B.datepicker._get(t,"onSelect"),d?(h=B.datepicker._formatDate(t),d.apply(t.input?t.input[0]:null,[h,t])):B.datepicker._hideDatepicker(),!1;
case 27:B.datepicker._hideDatepicker();
break;
case 33:B.datepicker._adjustDate(p.target,p.ctrlKey?-B.datepicker._get(t,"stepBigMonths"):-B.datepicker._get(t,"stepMonths"),"M");
break;
case 34:B.datepicker._adjustDate(p.target,p.ctrlKey?+B.datepicker._get(t,"stepBigMonths"):+B.datepicker._get(t,"stepMonths"),"M");
break;
case 35:(p.ctrlKey||p.metaKey)&&B.datepicker._clearDate(p.target),c=p.ctrlKey||p.metaKey;
break;
case 36:(p.ctrlKey||p.metaKey)&&B.datepicker._gotoToday(p.target),c=p.ctrlKey||p.metaKey;
break;
case 37:(p.ctrlKey||p.metaKey)&&B.datepicker._adjustDate(p.target,l?1:-1,"D"),c=p.ctrlKey||p.metaKey,p.originalEvent.altKey&&B.datepicker._adjustDate(p.target,p.ctrlKey?-B.datepicker._get(t,"stepBigMonths"):-B.datepicker._get(t,"stepMonths"),"M");
break;
case 38:(p.ctrlKey||p.metaKey)&&B.datepicker._adjustDate(p.target,-7,"D"),c=p.ctrlKey||p.metaKey;
break;
case 39:(p.ctrlKey||p.metaKey)&&B.datepicker._adjustDate(p.target,l?-1:1,"D"),c=p.ctrlKey||p.metaKey,p.originalEvent.altKey&&B.datepicker._adjustDate(p.target,p.ctrlKey?+B.datepicker._get(t,"stepBigMonths"):+B.datepicker._get(t,"stepMonths"),"M");
break;
case 40:(p.ctrlKey||p.metaKey)&&B.datepicker._adjustDate(p.target,7,"D"),c=p.ctrlKey||p.metaKey;
break;
default:c=!1
}}else{36===p.keyCode&&p.ctrlKey?B.datepicker._showDatepicker(this):c=!1
}c&&(p.preventDefault(),p.stopPropagation())
},_doKeyPress:function(h){var c,d,l=B.datepicker._getInst(h.target);
return B.datepicker._get(l,"constrainInput")?(c=B.datepicker._possibleChars(B.datepicker._get(l,"dateFormat")),d=String.fromCharCode(null==h.charCode?h.keyCode:h.charCode),h.ctrlKey||h.metaKey||" ">d||!c||c.indexOf(d)>-1):void 0
},_doKeyUp:function(h){var c,d=B.datepicker._getInst(h.target);
if(d.input.val()!==d.lastVal){try{c=B.datepicker.parseDate(B.datepicker._get(d,"dateFormat"),d.input?d.input.val():null,B.datepicker._getFormatConfig(d)),c&&(B.datepicker._setDateFromField(d),B.datepicker._updateAlternate(d),B.datepicker._updateDatepicker(d))
}catch(l){}}return !0
},_showDatepicker:function(t){if(t=t.target||t,"input"!==t.nodeName.toLowerCase()&&(t=B("input",t.parentNode)[0]),!B.datepicker._isDisabledDatepicker(t)&&B.datepicker._lastInput!==t){var r,E,u,p,d,s,D;
r=B.datepicker._getInst(t),B.datepicker._curInst&&B.datepicker._curInst!==r&&(B.datepicker._curInst.dpDiv.stop(!0,!0),r&&B.datepicker._datepickerShowing&&B.datepicker._hideDatepicker(B.datepicker._curInst.input[0])),E=B.datepicker._get(r,"beforeShow"),u=E?E.apply(t,[t,r]):{},u!==!1&&(b(r.settings,u),r.lastVal=null,B.datepicker._lastInput=t,B.datepicker._setDateFromField(r),B.datepicker._inDialog&&(t.value=""),B.datepicker._pos||(B.datepicker._pos=B.datepicker._findPos(t),B.datepicker._pos[1]+=t.offsetHeight),p=!1,B(t).parents().each(function(){return p|="fixed"===B(this).css("position"),!p
}),d={left:B.datepicker._pos[0],top:B.datepicker._pos[1]},B.datepicker._pos=null,r.dpDiv.empty(),r.dpDiv.css({position:"absolute",display:"block",top:"-1000px"}),B.datepicker._updateDatepicker(r),d=B.datepicker._checkOffset(r,d,p),r.dpDiv.css({position:B.datepicker._inDialog&&B.blockUI?"static":p?"fixed":"absolute",display:"none",left:d.left+"px",top:d.top+"px"}),r.inline||(s=B.datepicker._get(r,"showAnim"),D=B.datepicker._get(r,"duration"),r.dpDiv.css("z-index",C(B(t))+1),B.datepicker._datepickerShowing=!0,B.effects&&B.effects.effect[s]?r.dpDiv.show(s,B.datepicker._get(r,"showOptions"),D):r.dpDiv[s||"show"](s?D:null),B.datepicker._shouldFocusInput(r)&&r.input.focus(),B.datepicker._curInst=r))
}},_updateDatepicker:function(l){this.maxRows=4,A=l,l.dpDiv.empty().append(this._generateHTML(l)),this._attachHandlers(l);
var c,d=this._getNumberOfMonths(l),t=d[1],p=17,h=l.dpDiv.find("."+this._dayOverClass+" a");
h.length>0&&z.apply(h.get(0)),l.dpDiv.removeClass("ui-datepicker-multi-2 ui-datepicker-multi-3 ui-datepicker-multi-4").width(""),t>1&&l.dpDiv.addClass("ui-datepicker-multi-"+t).css("width",p*t+"em"),l.dpDiv[(1!==d[0]||1!==d[1]?"add":"remove")+"Class"]("ui-datepicker-multi"),l.dpDiv[(this._get(l,"isRTL")?"add":"remove")+"Class"]("ui-datepicker-rtl"),l===B.datepicker._curInst&&B.datepicker._datepickerShowing&&B.datepicker._shouldFocusInput(l)&&l.input.focus(),l.yearshtml&&(c=l.yearshtml,setTimeout(function(){c===l.yearshtml&&l.yearshtml&&l.dpDiv.find("select.ui-datepicker-year:first").replaceWith(l.yearshtml),c=l.yearshtml=null
},0))
},_shouldFocusInput:function(c){return c.input&&c.input.is(":visible")&&!c.input.is(":disabled")&&!c.input.is(":focus")
},_checkOffset:function(E,u,G){var p=E.dpDiv.outerWidth(),d=E.dpDiv.outerHeight(),F=E.input?E.input.outerWidth():0,c=E.input?E.input.outerHeight():0,t=document.documentElement.clientWidth+(G?0:B(document).scrollLeft()),D=document.documentElement.clientHeight+(G?0:B(document).scrollTop());
return u.left-=this._get(E,"isRTL")?p-F:0,u.left-=G&&u.left===E.input.offset().left?B(document).scrollLeft():0,u.top-=G&&u.top===E.input.offset().top+c?B(document).scrollTop():0,u.left-=Math.min(u.left,u.left+p>t&&t>p?Math.abs(u.left+p-t):0),u.top-=Math.min(u.top,u.top+d>D&&D>d?Math.abs(d+c):0),u
},_findPos:function(h){for(var c,d=this._getInst(h),l=this._get(d,"isRTL");
h&&("hidden"===h.type||1!==h.nodeType||B.expr.filters.hidden(h));
){h=h[l?"previousSibling":"nextSibling"]
}return c=B(h).offset(),[c.left,c.top]
},_hideDatepicker:function(l){var d,h,r,p,c=this._curInst;
!c||l&&c!==B.data(l,"datepicker")||this._datepickerShowing&&(d=this._get(c,"showAnim"),h=this._get(c,"duration"),r=function(){B.datepicker._tidyDialog(c)
},B.effects&&(B.effects.effect[d]||B.effects[d])?c.dpDiv.hide(d,B.datepicker._get(c,"showOptions"),h,r):c.dpDiv["slideDown"===d?"slideUp":"fadeIn"===d?"fadeOut":"hide"](d?h:null,r),d||r(),this._datepickerShowing=!1,p=this._get(c,"onClose"),p&&p.apply(c.input?c.input[0]:null,[c.input?c.input.val():"",c]),this._lastInput=null,this._inDialog&&(this._dialogInput.css({position:"absolute",left:"0",top:"-100px"}),B.blockUI&&(B.unblockUI(),B("body").append(this.dpDiv))),this._inDialog=!1)
},_tidyDialog:function(c){c.dpDiv.removeClass(this._dialogClass).unbind(".ui-datepicker-calendar")
},_checkExternalClick:function(h){if(B.datepicker._curInst){var c=B(h.target),d=B.datepicker._getInst(c[0]);
(c[0].id!==B.datepicker._mainDivId&&0===c.parents("#"+B.datepicker._mainDivId).length&&!c.hasClass(B.datepicker.markerClassName)&&!c.closest("."+B.datepicker._triggerClass).length&&B.datepicker._datepickerShowing&&(!B.datepicker._inDialog||!B.blockUI)||c.hasClass(B.datepicker.markerClassName)&&B.datepicker._curInst!==d)&&B.datepicker._hideDatepicker()
}},_adjustDate:function(h,c,d){var p=B(h),l=this._getInst(p[0]);
this._isDisabledDatepicker(p[0])||(this._adjustInstDate(l,c+("M"===d?this._get(l,"showCurrentAtPos"):0),d),this._updateDatepicker(l))
},_gotoToday:function(h){var c,d=B(h),l=this._getInst(d[0]);
this._get(l,"gotoCurrent")&&l.currentDay?(l.selectedDay=l.currentDay,l.drawMonth=l.selectedMonth=l.currentMonth,l.drawYear=l.selectedYear=l.currentYear):(c=new Date,l.selectedDay=c.getDate(),l.drawMonth=l.selectedMonth=c.getMonth(),l.drawYear=l.selectedYear=c.getFullYear()),this._notifyChange(l),this._adjustDate(d)
},_selectMonthYear:function(h,c,d){var p=B(h),l=this._getInst(p[0]);
l["selected"+("M"===d?"Month":"Year")]=l["draw"+("M"===d?"Month":"Year")]=parseInt(c.options[c.selectedIndex].value,10),this._notifyChange(l),this._adjustDate(p)
},_selectDay:function(l,d,h,r){var p,c=B(l);
B(r).hasClass(this._unselectableClass)||this._isDisabledDatepicker(c[0])||(p=this._getInst(c[0]),p.selectedDay=p.currentDay=B("a",r).html(),p.selectedMonth=p.currentMonth=d,p.selectedYear=p.currentYear=h,this._selectDate(l,this._formatDate(p,p.currentDay,p.currentMonth,p.currentYear)))
},_clearDate:function(d){var c=B(d);
this._selectDate(c,"")
},_selectDate:function(h,c){var d,p=B(h),l=this._getInst(p[0]);
c=null!=c?c:this._formatDate(l),l.input&&l.input.val(c),this._updateAlternate(l),d=this._get(l,"onSelect"),d?d.apply(l.input?l.input[0]:null,[c,l]):l.input&&l.input.trigger("change"),l.inline?this._updateDatepicker(l):(this._hideDatepicker(),this._lastInput=l.input[0],"object"!=typeof l.input[0]&&l.input.focus(),this._lastInput=null)
},_updateAlternate:function(h){var c,d,p,l=this._get(h,"altField");
l&&(c=this._get(h,"altFormat")||this._get(h,"dateFormat"),d=this._getDate(h),p=this.formatDate(c,d,this._getFormatConfig(h)),B(l).each(function(){B(this).val(p)
}))
},noWeekends:function(c){var d=c.getDay();
return[d>0&&6>d,""]
},iso8601Week:function(d){var h,c=new Date(d.getTime());
return c.setDate(c.getDate()+4-(c.getDay()||7)),h=c.getTime(),c.setMonth(0),c.setDate(1),Math.floor(Math.round((h-c)/86400000)/7)+1
},parseDate:function(T,P,H){if(null==T||null==P){throw"Invalid arguments"
}if(P="object"==typeof P?""+P:P+"",""===P){return null
}var L,K,X,I,N=0,Q=(H?H.shortYearCutoff:null)||this._defaults.shortYearCutoff,V="string"!=typeof Q?Q:(new Date).getFullYear()%100+parseInt(Q,10),G=(H?H.dayNamesShort:null)||this._defaults.dayNamesShort,U=(H?H.dayNames:null)||this._defaults.dayNames,J=(H?H.monthNamesShort:null)||this._defaults.monthNamesShort,S=(H?H.monthNames:null)||this._defaults.monthNames,R=-1,M=-1,Y=-1,F=-1,W=!1,t=function(d){var c=T.length>L+1&&T.charAt(L+1)===d;
return c&&L++,c
},E=function(d){var l=t(d),h="@"===d?14:"!"===d?20:"y"===d&&l?4:"o"===d?3:2,r="y"===d?h:1,p=RegExp("^\\d{"+r+","+h+"}"),c=P.substring(N).match(p);
if(!c){throw"Missing number at position "+N
}return N+=c[0].length,parseInt(c[0],10)
},O=function(h,d,p){var l=-1,c=B.map(t(h)?p:d,function(n,o){return[[o,n]]
}).sort(function(n,o){return -(n[1].length-o[1].length)
});
if(B.each(c,function(n,r){var o=r[1];
return P.substr(N,o.length).toLowerCase()===o.toLowerCase()?(l=r[0],N+=o.length,!1):void 0
}),-1!==l){return l+1
}throw"Unknown name at position "+N
},D=function(){if(P.charAt(N)!==T.charAt(L)){throw"Unexpected literal at position "+N
}N++
};
for(L=0;
T.length>L;
L++){if(W){"'"!==T.charAt(L)||t("'")?D():W=!1
}else{switch(T.charAt(L)){case"d":Y=E("d");
break;
case"D":O("D",G,U);
break;
case"o":F=E("o");
break;
case"m":M=E("m");
break;
case"M":M=O("M",J,S);
break;
case"y":R=E("y");
break;
case"@":I=new Date(E("@")),R=I.getFullYear(),M=I.getMonth()+1,Y=I.getDate();
break;
case"!":I=new Date((E("!")-this._ticksTo1970)/10000),R=I.getFullYear(),M=I.getMonth()+1,Y=I.getDate();
break;
case"'":t("'")?D():W=!0;
break;
default:D()
}}}if(P.length>N&&(X=P.substr(N),!/^\s+/.test(X))){throw"Extra/unparsed characters found in date: "+X
}if(-1===R?R=(new Date).getFullYear():100>R&&(R+=(new Date).getFullYear()-(new Date).getFullYear()%100+(V>=R?0:-100)),F>-1){for(M=1,Y=F;
;
){if(K=this._getDaysInMonth(R,M-1),K>=Y){break
}M++,Y-=K
}}if(I=this._daylightSavingAdjust(new Date(R,M-1,Y)),I.getFullYear()!==R||I.getMonth()+1!==M||I.getDate()!==Y){throw"Invalid date"
}return I
},ATOM:"yy-mm-dd",COOKIE:"D, dd M yy",ISO_8601:"yy-mm-dd",RFC_822:"D, d M y",RFC_850:"DD, dd-M-y",RFC_1036:"D, d M y",RFC_1123:"D, d M yy",RFC_2822:"D, d M yy",RSS:"D, d M y",TICKS:"!",TIMESTAMP:"@",W3C:"yy-mm-dd",_ticksTo1970:10000000*60*60*24*(718685+Math.floor(492.5)-Math.floor(19.7)+Math.floor(4.925)),formatDate:function(N,I,G){if(!I){return""
}var O,E=(G?G.dayNamesShort:null)||this._defaults.dayNamesShort,D=(G?G.dayNames:null)||this._defaults.dayNames,L=(G?G.monthNamesShort:null)||this._defaults.monthNamesShort,p=(G?G.monthNames:null)||this._defaults.monthNames,F=function(d){var c=N.length>O+1&&N.charAt(O+1)===d;
return c&&O++,c
},H=function(d,l,c){var h=""+l;
if(F(d)){for(;
c>h.length;
){h="0"+h
}}return h
},K=function(d,l,c,h){return F(d)?h[l]:c[l]
},M="",J=!1;
if(I){for(O=0;
N.length>O;
O++){if(J){"'"!==N.charAt(O)||F("'")?M+=N.charAt(O):J=!1
}else{switch(N.charAt(O)){case"d":M+=H("d",I.getDate(),2);
break;
case"D":M+=K("D",I.getDay(),E,D);
break;
case"o":M+=H("o",Math.round((new Date(I.getFullYear(),I.getMonth(),I.getDate()).getTime()-new Date(I.getFullYear(),0,0).getTime())/86400000),3);
break;
case"m":M+=H("m",I.getMonth()+1,2);
break;
case"M":M+=K("M",I.getMonth(),L,p);
break;
case"y":M+=F("y")?I.getFullYear():(10>I.getYear()%100?"0":"")+I.getYear()%100;
break;
case"@":M+=I.getTime();
break;
case"!":M+=10000*I.getTime()+this._ticksTo1970;
break;
case"'":F("'")?M+="'":J=!0;
break;
default:M+=N.charAt(O)
}}}}return M
},_possibleChars:function(d){var l,c="",h=!1,o=function(e){var n=d.length>l+1&&d.charAt(l+1)===e;
return n&&l++,n
};
for(l=0;
d.length>l;
l++){if(h){"'"!==d.charAt(l)||o("'")?c+=d.charAt(l):h=!1
}else{switch(d.charAt(l)){case"d":case"m":case"y":case"@":c+="0123456789";
break;
case"D":case"M":return null;
case"'":o("'")?c+="'":h=!0;
break;
default:c+=d.charAt(l)
}}}return c
},_get:function(c,d){return void 0!==c.settings[d]?c.settings[d]:this._defaults[d]
},_setDateFromField:function(h,u){if(h.input.val()!==h.lastVal){var d=this._get(h,"dateFormat"),l=h.lastVal=h.input?h.input.val():null,E=this._getDefaultDate(h),D=E,c=this._getFormatConfig(h);
try{D=this.parseDate(d,l,c)||E
}catch(p){l=u?"":l
}h.selectedDay=D.getDate(),h.drawMonth=h.selectedMonth=D.getMonth(),h.drawYear=h.selectedYear=D.getFullYear(),h.currentDay=l?D.getDate():0,h.currentMonth=l?D.getMonth():0,h.currentYear=l?D.getFullYear():0,this._adjustInstDate(h)
}},_getDefaultDate:function(c){return this._restrictMinMax(c,this._determineDate(c,this._get(c,"defaultDate"),new Date))
},_determineDate:function(l,d,h){var r=function(n){var o=new Date;
return o.setDate(o.getDate()+n),o
},p=function(u){try{return B.datepicker.parseDate(B.datepicker._get(l,"dateFormat"),u,B.datepicker._getFormatConfig(l))
}catch(E){}for(var H=(u.toLowerCase().match(/^c/)?B.datepicker._getDate(l):null)||new Date,G=H.getFullYear(),t=H.getMonth(),F=H.getDate(),e=/([+\-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?/g,D=e.exec(u);
D;
){switch(D[2]||"d"){case"d":case"D":F+=parseInt(D[1],10);
break;
case"w":case"W":F+=7*parseInt(D[1],10);
break;
case"m":case"M":t+=parseInt(D[1],10),F=Math.min(F,B.datepicker._getDaysInMonth(G,t));
break;
case"y":case"Y":G+=parseInt(D[1],10),F=Math.min(F,B.datepicker._getDaysInMonth(G,t))
}D=e.exec(u)
}return new Date(G,t,F)
},c=null==d||""===d?h:"string"==typeof d?p(d):"number"==typeof d?isNaN(d)?h:r(d):new Date(d.getTime());
return c=c&&"Invalid Date"==""+c?h:c,c&&(c.setHours(0),c.setMinutes(0),c.setSeconds(0),c.setMilliseconds(0)),this._daylightSavingAdjust(c)
},_daylightSavingAdjust:function(c){return c?(c.setHours(c.getHours()>12?c.getHours()+2:0),c):null
},_setDate:function(h,p,d){var l=!p,u=h.selectedMonth,r=h.selectedYear,c=this._restrictMinMax(h,this._determineDate(h,p,new Date));
h.selectedDay=h.currentDay=c.getDate(),h.drawMonth=h.selectedMonth=h.currentMonth=c.getMonth(),h.drawYear=h.selectedYear=h.currentYear=c.getFullYear(),u===h.selectedMonth&&r===h.selectedYear||d||this._notifyChange(h),this._adjustInstDate(h),h.input&&h.input.val(l?"":this._formatDate(h))
},_getDate:function(c){var d=!c.currentYear||c.input&&""===c.input.val()?null:this._daylightSavingAdjust(new Date(c.currentYear,c.currentMonth,c.currentDay));
return d
},_attachHandlers:function(h){var c=this._get(h,"stepMonths"),d="#"+h.id.replace(/\\\\/g,"\\");
h.dpDiv.find("[data-handler]").map(function(){var l={prev:function(){B.datepicker._adjustDate(d,-c,"M")
},next:function(){B.datepicker._adjustDate(d,+c,"M")
},hide:function(){B.datepicker._hideDatepicker()
},today:function(){B.datepicker._gotoToday(d)
},selectDay:function(){return B.datepicker._selectDay(d,+this.getAttribute("data-month"),+this.getAttribute("data-year"),this),!1
},selectMonth:function(){return B.datepicker._selectMonthYear(d,this,"M"),!1
},selectYear:function(){return B.datepicker._selectMonthYear(d,this,"Y"),!1
}};
B(this).bind(this.getAttribute("data-event"),l[this.getAttribute("data-handler")])
})
},_generateHTML:function(aJ){var aY,aU,aK,aP,aO,a2,aL,aR,aV,a0,aI,aZ,aN,aX,aW,aQ,a3,aH,a1,aE,aG,aS,aF,az,ay,ah,at,ao,al,ai,an,au,aD,aB,am,ax,ae,aw,ap,aj=new Date,ab=this._daylightSavingAdjust(new Date(aj.getFullYear(),aj.getMonth(),aj.getDate())),aA=this._get(aJ,"isRTL"),aT=this._get(aJ,"showButtonPanel"),aM=this._get(aJ,"hideIfNoPrevNext"),aq=this._get(aJ,"navigationAsDateFormat"),ag=this._getNumberOfMonths(aJ),af=this._get(aJ,"showCurrentAtPos"),ac=this._get(aJ,"stepMonths"),aC=1!==ag[0]||1!==ag[1],av=this._daylightSavingAdjust(aJ.currentDay?new Date(aJ.currentYear,aJ.currentMonth,aJ.currentDay):new Date(9999,9,9)),ar=this._getMinMaxDate(aJ,"min"),ak=this._getMinMaxDate(aJ,"max"),aa=aJ.drawMonth-af,ad=aJ.drawYear;
if(0>aa&&(aa+=12,ad--),ak){for(aY=this._daylightSavingAdjust(new Date(ak.getFullYear(),ak.getMonth()-ag[0]*ag[1]+1,ak.getDate())),aY=ar&&ar>aY?ar:aY;
this._daylightSavingAdjust(new Date(ad,aa,1))>aY;
){aa--,0>aa&&(aa=11,ad--)
}}for(aJ.drawMonth=aa,aJ.drawYear=ad,aU=this._get(aJ,"prevText"),aU=aq?this.formatDate(aU,this._daylightSavingAdjust(new Date(ad,aa-ac,1)),this._getFormatConfig(aJ)):aU,aK=this._canAdjustMonth(aJ,-1,ad,aa)?"<a class='ui-datepicker-prev ui-corner-all' data-handler='prev' data-event='click' title='"+aU+"'><span class='ui-icon ui-icon-circle-triangle-"+(aA?"e":"w")+"'>"+aU+"</span></a>":aM?"":"<a class='ui-datepicker-prev ui-corner-all ui-state-disabled' title='"+aU+"'><span class='ui-icon ui-icon-circle-triangle-"+(aA?"e":"w")+"'>"+aU+"</span></a>",aP=this._get(aJ,"nextText"),aP=aq?this.formatDate(aP,this._daylightSavingAdjust(new Date(ad,aa+ac,1)),this._getFormatConfig(aJ)):aP,aO=this._canAdjustMonth(aJ,1,ad,aa)?"<a class='ui-datepicker-next ui-corner-all' data-handler='next' data-event='click' title='"+aP+"'><span class='ui-icon ui-icon-circle-triangle-"+(aA?"w":"e")+"'>"+aP+"</span></a>":aM?"":"<a class='ui-datepicker-next ui-corner-all ui-state-disabled' title='"+aP+"'><span class='ui-icon ui-icon-circle-triangle-"+(aA?"w":"e")+"'>"+aP+"</span></a>",a2=this._get(aJ,"currentText"),aL=this._get(aJ,"gotoCurrent")&&aJ.currentDay?av:ab,a2=aq?this.formatDate(a2,aL,this._getFormatConfig(aJ)):a2,aR=aJ.inline?"":"<button type='button' class='ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all' data-handler='hide' data-event='click'>"+this._get(aJ,"closeText")+"</button>",aV=aT?"<div class='ui-datepicker-buttonpane ui-widget-content'>"+(aA?aR:"")+(this._isInRange(aJ,aL)?"<button type='button' class='ui-datepicker-current ui-state-default ui-priority-secondary ui-corner-all' data-handler='today' data-event='click'>"+a2+"</button>":"")+(aA?"":aR)+"</div>":"",a0=parseInt(this._get(aJ,"firstDay"),10),a0=isNaN(a0)?0:a0,aI=this._get(aJ,"showWeek"),aZ=this._get(aJ,"dayNames"),aN=this._get(aJ,"dayNamesMin"),aX=this._get(aJ,"monthNames"),aW=this._get(aJ,"monthNamesShort"),aQ=this._get(aJ,"beforeShowDay"),a3=this._get(aJ,"showOtherMonths"),aH=this._get(aJ,"selectOtherMonths"),a1=this._getDefaultDate(aJ),aE="",aS=0;
ag[0]>aS;
aS++){for(aF="",this.maxRows=4,az=0;
ag[1]>az;
az++){if(ay=this._daylightSavingAdjust(new Date(ad,aa,aJ.selectedDay)),ah=" ui-corner-all",at="",aC){if(at+="<div class='ui-datepicker-group",ag[1]>1){switch(az){case 0:at+=" ui-datepicker-group-first",ah=" ui-corner-"+(aA?"right":"left");
break;
case ag[1]-1:at+=" ui-datepicker-group-last",ah=" ui-corner-"+(aA?"left":"right");
break;
default:at+=" ui-datepicker-group-middle",ah=""
}}at+="'>"
}for(at+="<div class='ui-datepicker-header ui-widget-header ui-helper-clearfix"+ah+"'>"+(/all|left/.test(ah)&&0===aS?aA?aO:aK:"")+(/all|right/.test(ah)&&0===aS?aA?aK:aO:"")+this._generateMonthYearHeader(aJ,aa,ad,ar,ak,aS>0||az>0,aX,aW)+"</div><table class='ui-datepicker-calendar'><thead><tr>",ao=aI?"<th class='ui-datepicker-week-col'>"+this._get(aJ,"weekHeader")+"</th>":"",aG=0;
7>aG;
aG++){al=(aG+a0)%7,ao+="<th scope='col'"+((aG+a0+6)%7>=5?" class='ui-datepicker-week-end'":"")+"><span title='"+aZ[al]+"'>"+aN[al]+"</span></th>"
}for(at+=ao+"</tr></thead><tbody>",ai=this._getDaysInMonth(ad,aa),ad===aJ.selectedYear&&aa===aJ.selectedMonth&&(aJ.selectedDay=Math.min(aJ.selectedDay,ai)),an=(this._getFirstDayOfMonth(ad,aa)-a0+7)%7,au=Math.ceil((an+ai)/7),aD=aC?this.maxRows>au?this.maxRows:au:au,this.maxRows=aD,aB=this._daylightSavingAdjust(new Date(ad,aa,1-an)),am=0;
aD>am;
am++){for(at+="<tr>",ax=aI?"<td class='ui-datepicker-week-col'>"+this._get(aJ,"calculateWeek")(aB)+"</td>":"",aG=0;
7>aG;
aG++){ae=aQ?aQ.apply(aJ.input?aJ.input[0]:null,[aB]):[!0,""],aw=aB.getMonth()!==aa,ap=aw&&!aH||!ae[0]||ar&&ar>aB||ak&&aB>ak,ax+="<td class='"+((aG+a0+6)%7>=5?" ui-datepicker-week-end":"")+(aw?" ui-datepicker-other-month":"")+(aB.getTime()===ay.getTime()&&aa===aJ.selectedMonth&&aJ._keyEvent||a1.getTime()===aB.getTime()&&a1.getTime()===ay.getTime()?" "+this._dayOverClass:"")+(ap?" "+this._unselectableClass+" ui-state-disabled":"")+(aw&&!a3?"":" "+ae[1]+(aB.getTime()===av.getTime()?" "+this._currentClass:"")+(aB.getTime()===ab.getTime()?" ui-datepicker-today":""))+"'"+(aw&&!a3||!ae[2]?"":" title='"+ae[2].replace(/'/g,"&#39;")+"'")+(ap?"":" data-handler='selectDay' data-event='click' data-month='"+aB.getMonth()+"' data-year='"+aB.getFullYear()+"'")+">"+(aw&&!a3?"&#xa0;":ap?"<span class='ui-state-default'>"+aB.getDate()+"</span>":"<a class='ui-state-default"+(aB.getTime()===ab.getTime()?" ui-state-highlight":"")+(aB.getTime()===av.getTime()?" ui-state-active":"")+(aw?" ui-priority-secondary":"")+"' href='#'>"+aB.getDate()+"</a>")+"</td>",aB.setDate(aB.getDate()+1),aB=this._daylightSavingAdjust(aB)
}at+=ax+"</tr>"
}aa++,aa>11&&(aa=0,ad++),at+="</tbody></table>"+(aC?"</div>"+(ag[0]>0&&az===ag[1]-1?"<div class='ui-datepicker-row-break'></div>":""):""),aF+=at
}aE+=aF
}return aE+=aV,aJ._keyEvent=!1,aE
},_generateMonthYearHeader:function(G,S,O,H,L,K,W,I){var N,P,U,F,T,J,R,Q,M=this._get(G,"changeMonth"),X=this._get(G,"changeYear"),E=this._get(G,"showMonthAfterYear"),V="<div class='ui-datepicker-title'>",D="";
if(K||!M){D+="<span class='ui-datepicker-month'>"+W[S]+"</span>"
}else{for(N=H&&H.getFullYear()===O,P=L&&L.getFullYear()===O,D+="<select class='ui-datepicker-month' data-handler='selectMonth' data-event='change'>",U=0;
12>U;
U++){(!N||U>=H.getMonth())&&(!P||L.getMonth()>=U)&&(D+="<option value='"+U+"'"+(U===S?" selected='selected'":"")+">"+I[U]+"</option>")
}D+="</select>"
}if(E||(V+=D+(!K&&M&&X?"":"&#xa0;")),!G.yearshtml){if(G.yearshtml="",K||!X){V+="<span class='ui-datepicker-year'>"+O+"</span>"
}else{for(F=this._get(G,"yearRange").split(":"),T=(new Date).getFullYear(),J=function(c){var d=c.match(/c[+\-].*/)?O+parseInt(c.substring(1),10):c.match(/[+\-].*/)?T+parseInt(c,10):parseInt(c,10);
return isNaN(d)?T:d
},R=J(F[0]),Q=Math.max(R,J(F[1]||"")),R=H?Math.max(R,H.getFullYear()):R,Q=L?Math.min(Q,L.getFullYear()):Q,G.yearshtml+="<select class='ui-datepicker-year' data-handler='selectYear' data-event='change'>";
Q>=R;
R++){G.yearshtml+="<option value='"+R+"'"+(R===O?" selected='selected'":"")+">"+R+"</option>"
}G.yearshtml+="</select>",V+=G.yearshtml,G.yearshtml=null
}}return V+=this._get(G,"yearSuffix"),E&&(V+=(!K&&M&&X?"":"&#xa0;")+D),V+="</div>"
},_adjustInstDate:function(h,p,d){var l=h.drawYear+("Y"===d?p:0),u=h.drawMonth+("M"===d?p:0),r=Math.min(h.selectedDay,this._getDaysInMonth(l,u))+("D"===d?p:0),c=this._restrictMinMax(h,this._daylightSavingAdjust(new Date(l,u,r)));
h.selectedDay=c.getDate(),h.drawMonth=h.selectedMonth=c.getMonth(),h.drawYear=h.selectedYear=c.getFullYear(),("M"===d||"Y"===d)&&this._notifyChange(h)
},_restrictMinMax:function(d,l){var c=this._getMinMaxDate(d,"min"),h=this._getMinMaxDate(d,"max"),o=c&&c>l?c:l;
return h&&o>h?h:o
},_notifyChange:function(c){var d=this._get(c,"onChangeMonthYear");
d&&d.apply(c.input?c.input[0]:null,[c.selectedYear,c.selectedMonth+1,c])
},_getNumberOfMonths:function(c){var d=this._get(c,"numberOfMonths");
return null==d?[1,1]:"number"==typeof d?[1,d]:d
},_getMinMaxDate:function(c,d){return this._determineDate(c,this._get(c,d+"Date"),null)
},_getDaysInMonth:function(c,d){return 32-this._daylightSavingAdjust(new Date(c,d,32)).getDate()
},_getFirstDayOfMonth:function(c,d){return new Date(c,d,1).getDay()
},_canAdjustMonth:function(d,l,c,h){var r=this._getNumberOfMonths(d),p=this._daylightSavingAdjust(new Date(c,h+(0>l?l:r[0]*r[1]),1));
return 0>l&&p.setDate(this._getDaysInMonth(p.getFullYear(),p.getMonth())),this._isInRange(d,p)
},_isInRange:function(F,D){var u,G,h=this._getMinMaxDate(F,"min"),d=this._getMinMaxDate(F,"max"),E=null,c=null,p=this._get(F,"yearRange");
return p&&(u=p.split(":"),G=(new Date).getFullYear(),E=parseInt(u[0],10),c=parseInt(u[1],10),u[0].match(/[+\-].*/)&&(E+=G),u[1].match(/[+\-].*/)&&(c+=G)),(!h||D.getTime()>=h.getTime())&&(!d||D.getTime()<=d.getTime())&&(!E||D.getFullYear()>=E)&&(!c||c>=D.getFullYear())
},_getFormatConfig:function(c){var d=this._get(c,"shortYearCutoff");
return d="string"!=typeof d?d:(new Date).getFullYear()%100+parseInt(d,10),{shortYearCutoff:d,dayNamesShort:this._get(c,"dayNamesShort"),dayNames:this._get(c,"dayNames"),monthNamesShort:this._get(c,"monthNamesShort"),monthNames:this._get(c,"monthNames")}
},_formatDate:function(d,l,c,h){l||(d.currentDay=d.selectedDay,d.currentMonth=d.selectedMonth,d.currentYear=d.selectedYear);
var o=l?"object"==typeof l?l:this._daylightSavingAdjust(new Date(h,c,l)):this._daylightSavingAdjust(new Date(d.currentYear,d.currentMonth,d.currentDay));
return this.formatDate(this._get(d,"dateFormat"),o,this._getFormatConfig(d))
}}),B.fn.datepicker=function(d){if(!this.length){return this
}B.datepicker.initialized||(B(document).mousedown(B.datepicker._checkExternalClick),B.datepicker.initialized=!0),0===B("#"+B.datepicker._mainDivId).length&&B("body").append(B.datepicker.dpDiv);
var c=Array.prototype.slice.call(arguments,1);
return"string"!=typeof d||"isDisabled"!==d&&"getDate"!==d&&"widget"!==d?"option"===d&&2===arguments.length&&"string"==typeof arguments[1]?B.datepicker["_"+d+"Datepicker"].apply(B.datepicker,[this[0]].concat(c)):this.each(function(){"string"==typeof d?B.datepicker["_"+d+"Datepicker"].apply(B.datepicker,[this].concat(c)):B.datepicker._attachDatepicker(this,d)
}):B.datepicker["_"+d+"Datepicker"].apply(B.datepicker,[this[0]].concat(c))
},B.datepicker=new k,B.datepicker.initialized=!1,B.datepicker.uuid=(new Date).getTime(),B.datepicker.version="1.11.4",B.datepicker;
var x="ui-effects-",f=B;
B.effects={effect:{}},function(Q,L){function I(d,l,c){var h=P[l.type]||{};
return null==d?c||!l.def?null:l.def:(d=h.floor?~~d:parseFloat(d),isNaN(d)?l.def:h.mod?(d+h.mod)%h.mod:0>d?0:d>h.max?h.max:d)
}function R(c){var d=J(),e=d._rgba=[];
return c=c.toLowerCase(),K(H,function(s,T){var p,S=T.re.exec(c),n=S&&T.parse(S),u=T.space||"rgba";
return n?(p=d[u](n),d[N[u].cache]=p[N[u].cache],e=d._rgba=p._rgba,!1):L
}),e.length?("0,0,0,0"===e.join()&&Q.extend(e,F.transparent),d):F[c]
}function G(d,h,c){return c=(c+1)%1,1>6*c?d+6*(h-d)*c:1>2*c?h:2>3*c?d+6*(h-d)*(2/3-c):d
}var F,O="backgroundColor borderBottomColor borderLeftColor borderRightColor borderTopColor color columnRuleColor outlineColor textDecorationColor textEmphasisColor",D=/^([\-+])=\s*(\d+\.?\d*)/,H=[{re:/rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,parse:function(c){return[c[1],c[2],c[3],c[4]]
}},{re:/rgba?\(\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,parse:function(c){return[2.55*c[1],2.55*c[2],2.55*c[3],c[4]]
}},{re:/#([a-f0-9]{2})([a-f0-9]{2})([a-f0-9]{2})/,parse:function(c){return[parseInt(c[1],16),parseInt(c[2],16),parseInt(c[3],16)]
}},{re:/#([a-f0-9])([a-f0-9])([a-f0-9])/,parse:function(c){return[parseInt(c[1]+c[1],16),parseInt(c[2]+c[2],16),parseInt(c[3]+c[3],16)]
}},{re:/hsla?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,space:"hsla",parse:function(c){return[c[1],c[2]/100,c[3]/100,c[4]]
}}],J=Q.Color=function(h,c,d,l){return new Q.Color.fn.parse(h,c,d,l)
},N={rgba:{props:{red:{idx:0,type:"byte"},green:{idx:1,type:"byte"},blue:{idx:2,type:"byte"}}},hsla:{props:{hue:{idx:0,type:"degrees"},saturation:{idx:1,type:"percent"},lightness:{idx:2,type:"percent"}}}},P={"byte":{floor:!0,max:255},percent:{max:1},degrees:{mod:360,floor:!0}},M=J.support={},E=Q("<p>")[0],K=Q.each;
E.style.cssText="background-color:rgba(1,1,1,.5)",M.rgba=E.style.backgroundColor.indexOf("rgba")>-1,K(N,function(c,d){d.cache="_"+c,d.props.alpha={idx:3,type:"percent",def:1}
}),J.fn=Q.extend(J.prototype,{parse:function(S,e,o,c){if(S===L){return this._rgba=[null,null,null,null],this
}(S.jquery||S.nodeType)&&(S=Q(S).css(e),e=L);
var h=this,t=Q.type(S),s=this._rgba=[];
return e!==L&&(S=[S,e,o,c],t="array"),"string"===t?this.parse(R(S)||F._default):"array"===t?(K(N.rgba.props,function(d,l){s[l.idx]=I(S[l.idx],l)
}),this):"object"===t?(S instanceof J?K(N,function(d,l){S[l.cache]&&(h[l.cache]=S[l.cache].slice())
}):K(N,function(l,d){var n=d.cache;
K(d.props,function(p,r){if(!h[n]&&d.to){if("alpha"===p||null==S[p]){return
}h[n]=d.to(h._rgba)
}h[n][r.idx]=I(S[p],r,!0)
}),h[n]&&0>Q.inArray(null,h[n].slice(0,3))&&(h[n][3]=1,d.from&&(h._rgba=d.from(h[n])))
}),this):L
},is:function(d){var c=J(d),e=!0,h=this;
return K(N,function(n,s){var l,p=c[s.cache];
return p&&(l=h[s.cache]||s.to&&s.to(h._rgba)||[],K(s.props,function(r,o){return null!=p[o.idx]?e=p[o.idx]===l[o.idx]:L
})),e
}),e
},_space:function(){var c=[],d=this;
return K(N,function(e,h){d[h.cache]&&c.push(e)
}),c.pop()
},transition:function(h,S){var p=J(h),U=p._space(),T=N[U],d=0===this.alpha()?J("transparent"):this,u=d[T.cache]||T.to(d._rgba),c=u.slice();
return p=p[T.cache],K(T.props,function(l,W){var s=W.idx,e=u[s],r=p[s],V=P[W.type]||{};
null!==r&&(null===e?c[s]=r:(V.mod&&(r-e>V.mod/2?e+=V.mod:e-r>V.mod/2&&(e-=V.mod)),c[s]=I((r-e)*S+e,W)))
}),this[U](c)
},blend:function(h){if(1===this._rgba[3]){return this
}var c=this._rgba.slice(),d=c.pop(),l=J(h)._rgba;
return J(Q.map(c,function(n,o){return(1-d)*l[o]+d*n
}))
},toRgbaString:function(){var d="rgba(",c=Q.map(this._rgba,function(h,l){return null==h?l>2?1:0:h
});
return 1===c[3]&&(c.pop(),d="rgb("),d+c.join()+")"
},toHslaString:function(){var d="hsla(",c=Q.map(this.hsla(),function(h,l){return null==h&&(h=l>2?1:0),l&&3>l&&(h=Math.round(100*h)+"%"),h
});
return 1===c[3]&&(c.pop(),d="hsl("),d+c.join()+")"
},toHexString:function(h){var c=this._rgba.slice(),d=c.pop();
return h&&c.push(~~(255*d)),"#"+Q.map(c,function(e){return e=(e||0).toString(16),1===e.length?"0"+e:e
}).join("")
},toString:function(){return 0===this._rgba[3]?"transparent":this.toRgbaString()
}}),J.fn.parse.prototype=J.fn,N.hsla.to=function(aa){if(null==aa[0]||null==aa[1]||null==aa[2]){return[null,null,null,aa[3]]
}var W,U,ab=aa[0]/255,S=aa[1]/255,p=aa[2]/255,Y=aa[3],d=Math.max(ab,S,p),T=Math.min(ab,S,p),V=d-T,X=d+T,Z=0.5*X;
return W=T===d?0:ab===d?60*(S-p)/V+360:S===d?60*(p-ab)/V+120:60*(ab-S)/V+240,U=0===V?0:0.5>=Z?V/X:V/(2-X),[Math.round(W)%360,U,Z,null==Y?1:Y]
},N.hsla.from=function(h){if(null==h[0]||null==h[1]||null==h[2]){return[null,null,null,h[3]]
}var p=h[0]/360,d=h[1],l=h[2],u=h[3],c=0.5>=l?l*(1+d):l+d-l*d,n=2*l-c;
return[Math.round(255*G(n,c,p+1/3)),Math.round(255*G(n,c,p)),Math.round(255*G(n,c,p-1/3)),u]
},K(N,function(h,t){var p=t.props,e=t.cache,d=t.to,r=t.from;
J.fn[h]=function(l){if(d&&!this[e]&&(this[e]=d(this._rgba)),l===L){return this[e].slice()
}var T,o=Q.type(l),c="array"===o||"object"===o?l:arguments,S=this[e].slice();
return K(p,function(n,U){var u=c["object"===o?n:U.idx];
null==u&&(u=S[U.idx]),S[U.idx]=I(u,U)
}),r?(T=J(r(S)),T[e]=S,T):J(S)
},K(p,function(l,c){J.fn[l]||(J.fn[l]=function(V){var T,u=Q.type(V),s="alpha"===l?this._hsla?"hsla":"rgba":h,S=this[s](),U=S[c.idx];
return"undefined"===u?U:("function"===u&&(V=V.call(this,U),u=Q.type(V)),null==V&&c.empty?this:("string"===u&&(T=D.exec(V),T&&(V=U+parseFloat(T[2])*("+"===T[1]?1:-1))),S[c.idx]=V,this[s](S)))
})
})
}),J.hook=function(d){var c=d.split(" ");
K(c,function(l,h){Q.cssHooks[h]={set:function(u,T){var S,s,t="";
if("transparent"!==T&&("string"!==Q.type(T)||(S=R(T)))){if(T=J(S||T),!M.rgba&&1!==T._rgba[3]){for(s="backgroundColor"===h?u.parentNode:u;
(""===t||"transparent"===t)&&s&&s.style;
){try{t=Q.css(s,"backgroundColor"),s=s.parentNode
}catch(p){}}T=T.blend(t&&"transparent"!==t?t:"_default")
}T=T.toRgbaString()
}try{u.style[h]=T
}catch(p){}}},Q.fx.step[h]=function(n){n.colorInit||(n.start=J(n.elem,h),n.end=J(n.end),n.colorInit=!0),Q.cssHooks[h].set(n.elem,n.start.transition(n.end,n.pos))
}
})
},J.hook(O),Q.cssHooks.borderColor={expand:function(c){var d={};
return K(["Top","Right","Bottom","Left"],function(e,h){d["border"+h+"Color"]=c
}),d
}},F=Q.Color.names={aqua:"#00ffff",black:"#000000",blue:"#0000ff",fuchsia:"#ff00ff",gray:"#808080",green:"#008000",lime:"#00ff00",maroon:"#800000",navy:"#000080",olive:"#808000",purple:"#800080",red:"#ff0000",silver:"#c0c0c0",teal:"#008080",white:"#ffffff",yellow:"#ffff00",transparent:[null,null,null,0],_default:"#ffffff"}
}(f),function(){function h(t){var p,r,D=t.ownerDocument.defaultView?t.ownerDocument.defaultView.getComputedStyle(t,null):t.currentStyle,u={};
if(D&&D.length&&D[0]&&D[D[0]]){for(r=D.length;
r--;
){p=D[r],"string"==typeof D[p]&&(u[B.camelCase(p)]=D[p])
}}else{for(p in D){"string"==typeof D[p]&&(u[p]=D[p])
}}return u
}function c(t,p){var r,u,n={};
for(r in p){u=p[r],t[r]!==u&&(l[r]||(B.fx.step[r]||!isNaN(parseFloat(u)))&&(n[r]=u))
}return n
}var d=["add","remove","toggle"],l={border:1,borderBottom:1,borderColor:1,borderLeft:1,borderRight:1,borderTop:1,borderWidth:1,margin:1,padding:1};
B.each(["borderLeftStyle","borderRightStyle","borderBottomStyle","borderTopStyle"],function(o,n){B.fx.step[n]=function(e){("none"!==e.end&&!e.setAttr||1===e.pos&&!e.setAttr)&&(f.style(e.elem,n,e.end),e.setAttr=!0)
}
}),B.fn.addBack||(B.fn.addBack=function(e){return this.add(null==e?this.prevObject:this.prevObject.filter(e))
}),B.effects.animateClass=function(u,t,p,s){var e=B.speed(t,p,s);
return this.queue(function(){var F,n=B(this),E=n.attr("class")||"",D=e.children?n.find("*").addBack():n;
D=D.map(function(){var o=B(this);
return{el:o,start:h(this)}
}),F=function(){B.each(d,function(o,r){u[r]&&n[r+"Class"](u[r])
})
},F(),D=D.map(function(){return this.end=h(this.el[0]),this.diff=c(this.start,this.end),this
}),n.attr("class",E),D=D.map(function(){var G=this,o=B.Deferred(),r=B.extend({},e,{queue:!1,complete:function(){o.resolve(G)
}});
return this.el.animate(this.diff,r),o.promise()
}),B.when.apply(B,D.get()).done(function(){F(),B.each(arguments,function(){var o=this.el;
B.each(this.diff,function(r){o.css(r,"")
})
}),e.complete.call(n[0])
})
})
},B.fn.extend({addClass:function(n){return function(e,p,t,r){return p?B.effects.animateClass.call(this,{add:e},p,t,r):n.apply(this,arguments)
}
}(B.fn.addClass),removeClass:function(n){return function(e,p,t,r){return arguments.length>1?B.effects.animateClass.call(this,{remove:e},p,t,r):n.apply(this,arguments)
}
}(B.fn.removeClass),toggleClass:function(n){return function(p,r,u,t,e){return"boolean"==typeof r||void 0===r?u?B.effects.animateClass.call(this,r?{add:p}:{remove:p},u,t,e):n.apply(this,arguments):B.effects.animateClass.call(this,{toggle:p},r,u,t)
}
}(B.fn.toggleClass),switchClass:function(t,p,r,D,u){return B.effects.animateClass.call(this,{add:p,remove:t},r,D,u)
}})
}(),function(){function d(o,h,l,p){return B.isPlainObject(o)&&(h=o,o=o.effect),o={effect:o},null==h&&(h={}),B.isFunction(h)&&(p=h,l=null,h={}),("number"==typeof h||B.fx.speeds[h])&&(p=l,l=h,h={}),B.isFunction(l)&&(p=l,l=null),h&&B.extend(o,h),l=l||h.duration,o.duration=B.fx.off?0:"number"==typeof l?l:l in B.fx.speeds?B.fx.speeds[l]:B.fx.speeds._default,o.complete=p||h.complete,o
}function c(h){return !h||"number"==typeof h||B.fx.speeds[h]?!0:"string"!=typeof h||B.effects.effect[h]?B.isFunction(h)?!0:"object"!=typeof h||h.effect?!1:!0:!0
}B.extend(B.effects,{version:"1.11.4",save:function(l,n){for(var h=0;
n.length>h;
h++){null!==n[h]&&l.data(x+n[h],l[0].style[n[h]])
}},restore:function(l,o){var h,n;
for(n=0;
o.length>n;
n++){null!==o[n]&&(h=l.data(x+o[n]),void 0===h&&(h=""),l.css(o[n],h))
}},setMode:function(h,l){return"toggle"===l&&(l=h.is(":hidden")?"show":"hide"),l
},getBaseline:function(l,o){var h,n;
switch(l[0]){case"top":h=0;
break;
case"middle":h=0.5;
break;
case"bottom":h=1;
break;
default:h=l[0]/o.height
}switch(l[1]){case"left":n=0;
break;
case"center":n=0.5;
break;
case"right":n=1;
break;
default:n=l[1]/o.width
}return{x:n,y:h}
},createWrapper:function(r){if(r.parent().is(".ui-effects-wrapper")){return r.parent()
}var l={width:r.outerWidth(!0),height:r.outerHeight(!0),"float":r.css("float")},p=B("<div></div>").addClass("ui-effects-wrapper").css({fontSize:"100%",background:"transparent",border:"none",margin:0,padding:0}),u={width:r.width(),height:r.height()},t=document.activeElement;
try{t.id
}catch(h){t=document.body
}return r.wrap(p),(r[0]===t||B.contains(r[0],t))&&B(t).focus(),p=r.parent(),"static"===r.css("position")?(p.css({position:"relative"}),r.css({position:"relative"})):(B.extend(l,{position:r.css("position"),zIndex:r.css("z-index")}),B.each(["top","left","bottom","right"],function(e,n){l[n]=r.css(n),isNaN(parseInt(l[n],10))&&(l[n]="auto")
}),r.css({position:"relative",top:0,left:0,right:"auto",bottom:"auto"})),r.css(u),p.css(l).show()
},removeWrapper:function(l){var h=document.activeElement;
return l.parent().is(".ui-effects-wrapper")&&(l.parent().replaceWith(l),(l[0]===h||B.contains(l[0],h))&&B(h).focus()),l
},setTransition:function(o,h,l,p){return p=p||{},B.each(h,function(n,e){var r=o.cssUnit(e);
r[0]>0&&(p[e]=r[0]*l+r[1])
}),p
}}),B.fn.extend({effect:function(){function h(u){function s(){B.isFunction(D)&&D.call(E[0]),B.isFunction(u)&&u()
}var E=B(this),D=l.complete,t=l.mode;
(E.is(":hidden")?"hide"===t:"show"===t)?(E[t](),s()):e.call(E[0],l,s)
}var l=d.apply(this,arguments),r=l.mode,p=l.queue,e=B.effects.effect[l.effect];
return B.fx.off||!e?r?this[r](l.duration,l.complete):this.each(function(){l.complete&&l.complete.call(this)
}):p===!1?this.each(h):this.queue(p||"fx",h)
},show:function(e){return function(h){if(c(h)){return e.apply(this,arguments)
}var l=d.apply(this,arguments);
return l.mode="show",this.effect.call(this,l)
}
}(B.fn.show),hide:function(e){return function(h){if(c(h)){return e.apply(this,arguments)
}var l=d.apply(this,arguments);
return l.mode="hide",this.effect.call(this,l)
}
}(B.fn.hide),toggle:function(e){return function(h){if(c(h)||"boolean"==typeof h){return e.apply(this,arguments)
}var l=d.apply(this,arguments);
return l.mode="toggle",this.effect.call(this,l)
}
}(B.fn.toggle),cssUnit:function(n){var h=this.css(n),l=[];
return B.each(["em","px","%","pt"],function(o,p){h.indexOf(p)>0&&(l=[parseFloat(h),p])
}),l
}})
}(),function(){var c={};
B.each(["Quad","Cubic","Quart","Quint","Expo"],function(e,d){c[d]=function(h){return Math.pow(h,e+2)
}
}),B.extend(c,{Sine:function(d){return 1-Math.cos(d*Math.PI/2)
},Circ:function(d){return 1-Math.sqrt(1-d*d)
},Elastic:function(d){return 0===d||1===d?d:-Math.pow(2,8*(d-1))*Math.sin((80*(d-1)-7.5)*Math.PI/15)
},Back:function(d){return d*d*(3*d-2)
},Bounce:function(h){for(var l,d=4;
((l=Math.pow(2,--d))-1)/11>h;
){}return 1/Math.pow(4,3-d)-7.5625*Math.pow((3*l-2)/22-h,2)
}}),B.each(c,function(h,d){B.easing["easeIn"+h]=d,B.easing["easeOut"+h]=function(e){return 1-d(1-e)
},B.easing["easeInOut"+h]=function(e){return 0.5>e?d(2*e)/2:1-d(-2*e+2)/2
}
})
}(),B.effects,B.effects.effect.blind=function(M,I){var S,F,E,P=B(this),t=/up|down|vertical/,H=/up|left|vertical|horizontal/,J=["position","top","bottom","left","right","height","width"],O=B.effects.setMode(P,M.mode||"hide"),R=M.direction||"up",N=t.test(R),D=N?"height":"width",L=N?"top":"left",K=H.test(R),G={},Q="show"===O;
P.parent().is(".ui-effects-wrapper")?B.effects.save(P.parent(),J):B.effects.save(P,J),P.show(),S=B.effects.createWrapper(P).css({overflow:"hidden"}),F=S[D](),E=parseFloat(S.css(L))||0,G[D]=Q?F:0,K||(P.css(N?"bottom":"right",0).css(N?"top":"left","auto").css({position:"absolute"}),G[L]=Q?E:F+E),Q&&(S.css(D,0),K||S.css(L,E+F)),S.animate(G,{duration:M.duration,easing:M.easing,queue:!1,complete:function(){"hide"===O&&P.hide(),B.effects.restore(P,J),B.effects.removeWrapper(P),I()
}})
},B.effects.effect.drop=function(G,E){var K,t=B(this),p=["position","top","bottom","left","right","opacity","height","width"],I=B.effects.setMode(t,G.mode||"hide"),d="show"===I,D=G.direction||"left",F="up"===D||"down"===D?"top":"left",H="up"===D||"left"===D?"pos":"neg",J={opacity:d?1:0};
B.effects.save(t,p),t.show(),B.effects.createWrapper(t),K=G.distance||t["top"===F?"outerHeight":"outerWidth"](!0)/2,d&&t.css("opacity",0).css(F,"pos"===H?-K:K),J[F]=(d?"pos"===H?"+=":"-=":"pos"===H?"-=":"+=")+K,t.animate(J,{queue:!1,duration:G.duration,easing:G.easing,complete:function(){"hide"===I&&t.hide(),B.effects.restore(t,p),B.effects.removeWrapper(t),E()
}})
},B.effects.effect.fade=function(h,c){var d=B(this),l=B.effects.setMode(d,h.mode||"toggle");
d.animate({opacity:l},{queue:!1,duration:h.duration,easing:h.easing,complete:c})
},B.effects.effect.fold=function(M,I){var S,F,E=B(this),P=["position","top","bottom","left","right","height","width"],t=B.effects.setMode(E,M.mode||"hide"),H="show"===t,J="hide"===t,O=M.size||15,R=/([0-9]+)%/.exec(O),N=!!M.horizFirst,D=H!==N,L=D?["width","height"]:["height","width"],K=M.duration/2,G={},Q={};
B.effects.save(E,P),E.show(),S=B.effects.createWrapper(E).css({overflow:"hidden"}),F=D?[S.width(),S.height()]:[S.height(),S.width()],R&&(O=parseInt(R[1],10)/100*F[J?0:1]),H&&S.css(N?{height:0,width:O}:{height:O,width:0}),G[L[0]]=H?F[0]:O,Q[L[1]]=H?F[1]:0,S.animate(G,K,M.easing).animate(Q,K,M.easing,function(){J&&E.hide(),B.effects.restore(E,P),B.effects.removeWrapper(E),I()
})
},B.effects.effect.size=function(P,L){var E,I,H,T=B(this),F=["position","top","bottom","left","right","width","height","overflow","opacity"],K=["position","top","bottom","left","right","overflow","opacity"],M=["width","height","overflow"],R=["fontSize"],D=["borderTopWidth","borderBottomWidth","paddingTop","paddingBottom"],Q=["borderLeftWidth","borderRightWidth","paddingLeft","paddingRight"],G=B.effects.setMode(T,P.mode||"effect"),O=P.restore||"effect"!==G,N=P.scale||"both",J=P.origin||["middle","center"],U=T.css("position"),t=O?F:K,S={height:0,width:0,outerHeight:0,outerWidth:0};
"show"===G&&T.show(),E={height:T.height(),width:T.width(),outerHeight:T.outerHeight(),outerWidth:T.outerWidth()},"toggle"===P.mode&&"show"===G?(T.from=P.to||S,T.to=P.from||E):(T.from=P.from||("show"===G?S:E),T.to=P.to||("hide"===G?S:E)),H={from:{y:T.from.height/E.height,x:T.from.width/E.width},to:{y:T.to.height/E.height,x:T.to.width/E.width}},("box"===N||"both"===N)&&(H.from.y!==H.to.y&&(t=t.concat(D),T.from=B.effects.setTransition(T,D,H.from.y,T.from),T.to=B.effects.setTransition(T,D,H.to.y,T.to)),H.from.x!==H.to.x&&(t=t.concat(Q),T.from=B.effects.setTransition(T,Q,H.from.x,T.from),T.to=B.effects.setTransition(T,Q,H.to.x,T.to))),("content"===N||"both"===N)&&H.from.y!==H.to.y&&(t=t.concat(R).concat(M),T.from=B.effects.setTransition(T,R,H.from.y,T.from),T.to=B.effects.setTransition(T,R,H.to.y,T.to)),B.effects.save(T,t),T.show(),B.effects.createWrapper(T),T.css("overflow","hidden").css(T.from),J&&(I=B.effects.getBaseline(J,E),T.from.top=(E.outerHeight-T.outerHeight())*I.y,T.from.left=(E.outerWidth-T.outerWidth())*I.x,T.to.top=(E.outerHeight-T.to.outerHeight)*I.y,T.to.left=(E.outerWidth-T.to.outerWidth)*I.x),T.css(T.from),("content"===N||"both"===N)&&(D=D.concat(["marginTop","marginBottom"]).concat(R),Q=Q.concat(["marginLeft","marginRight"]),M=F.concat(D).concat(Q),T.find("*[width]").each(function(){var c=B(this),d={height:c.height(),width:c.width(),outerHeight:c.outerHeight(),outerWidth:c.outerWidth()};
O&&B.effects.save(c,M),c.from={height:d.height*H.from.y,width:d.width*H.from.x,outerHeight:d.outerHeight*H.from.y,outerWidth:d.outerWidth*H.from.x},c.to={height:d.height*H.to.y,width:d.width*H.to.x,outerHeight:d.height*H.to.y,outerWidth:d.width*H.to.x},H.from.y!==H.to.y&&(c.from=B.effects.setTransition(c,D,H.from.y,c.from),c.to=B.effects.setTransition(c,D,H.to.y,c.to)),H.from.x!==H.to.x&&(c.from=B.effects.setTransition(c,Q,H.from.x,c.from),c.to=B.effects.setTransition(c,Q,H.to.x,c.to)),c.css(c.from),c.animate(c.to,P.duration,P.easing,function(){O&&B.effects.restore(c,M)
})
})),T.animate(T.to,{queue:!1,duration:P.duration,easing:P.easing,complete:function(){0===T.to.opacity&&T.css("opacity",T.from.opacity),"hide"===G&&T.hide(),B.effects.restore(T,t),O||("static"===U?T.css({position:"relative",top:T.to.top,left:T.to.left}):B.each(["top","left"],function(c,d){T.css(d,function(o,h){var l=parseInt(h,10),p=c?T.to.left:T.to.top;
return"auto"===h?p+"px":l+p+"px"
})
})),B.effects.removeWrapper(T),L()
}})
},B.effects.effect.slide=function(G,E){var K,t=B(this),p=["position","top","bottom","left","right","width","height"],I=B.effects.setMode(t,G.mode||"show"),d="show"===I,D=G.direction||"left",F="up"===D||"down"===D?"top":"left",H="up"===D||"left"===D,J={};
B.effects.save(t,p),t.show(),K=G.distance||t["top"===F?"outerHeight":"outerWidth"](!0),B.effects.createWrapper(t).css({overflow:"hidden"}),d&&t.css(F,H?isNaN(K)?"-"+K:-K:K),J[F]=(d?H?"+=":"-=":H?"-=":"+=")+K,t.animate(J,{queue:!1,duration:G.duration,easing:G.easing,complete:function(){"hide"===I&&t.hide(),B.effects.restore(t,p),B.effects.removeWrapper(t),E()
}})
},B.effects.effect.transfer=function(H,F){var M=B(this),D=B(H.to),t="fixed"===D.css("position"),K=B("body"),p=t?K.scrollTop():0,E=t?K.scrollLeft():0,G=D.offset(),J={top:G.top-p,left:G.left-E,height:D.innerHeight(),width:D.innerWidth()},L=M.offset(),I=B("<div class='ui-effects-transfer'></div>").appendTo(document.body).addClass(H.className).css({top:L.top-p,left:L.left-E,height:M.innerHeight(),width:M.innerWidth(),position:t?"fixed":"absolute"}).animate(J,H.duration,H.easing,function(){I.remove(),F()
})
}
});
(function(b){if(typeof define==="function"&&define.amd){define(["../widgets/datepicker"],b)
}else{b(jQuery.datepicker)
}}(function(b){b.regional.it={closeText:"Chiudi",prevText:"&#x3C;Prec",nextText:"Succ&#x3E;",currentText:"Oggi",monthNames:["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"],monthNamesShort:["Gen","Feb","Mar","Apr","Mag","Giu","Lug","Ago","Set","Ott","Nov","Dic"],dayNames:["Domenica","LunedÃ¬","MartedÃ¬","MercoledÃ¬","GiovedÃ¬","VenerdÃ¬","Sabato"],dayNamesShort:["Dom","Lun","Mar","Mer","Gio","Ven","Sab"],dayNamesMin:["Do","Lu","Ma","Me","Gi","Ve","Sa"],weekHeader:"Sm",dateFormat:"dd/mm/yy",firstDay:1,isRTL:false,showMonthAfterYear:false,yearSuffix:""};
b.setDefaults(b.regional.it);
return b.regional.it
}));
!function(b){"function"==typeof define&&define.amd?define(["jquery"],b):"object"==typeof exports?module.exports=b:b(jQuery)
}(function(v){function u(B){var A=B||window.event,z=n.call(arguments,1),y=0,x=0,w=0,k=0,f=0,e=0;
if(B=v.event.fix(A),B.type="mousewheel","detail" in A&&(w=-1*A.detail),"wheelDelta" in A&&(w=A.wheelDelta),"wheelDeltaY" in A&&(w=A.wheelDeltaY),"wheelDeltaX" in A&&(x=-1*A.wheelDeltaX),"axis" in A&&A.axis===A.HORIZONTAL_AXIS&&(x=-1*w,w=0),y=0===w?x:w,"deltaY" in A&&(w=-1*A.deltaY,y=w),"deltaX" in A&&(x=A.deltaX,0===w&&(y=-1*x)),0!==w||0!==x){if(1===A.deltaMode){var d=v.data(this,"mousewheel-line-height");
y*=d,w*=d,x*=d
}else{if(2===A.deltaMode){var c=v.data(this,"mousewheel-page-height");
y*=c,w*=c,x*=c
}}if(k=Math.max(Math.abs(w),Math.abs(x)),(!q||q>k)&&(q=k,s(A,k)&&(q/=40)),s(A,k)&&(y/=40,x/=40,w/=40),y=Math[y>=1?"floor":"ceil"](y/q),x=Math[x>=1?"floor":"ceil"](x/q),w=Math[w>=1?"floor":"ceil"](w/q),l.settings.normalizeOffset&&this.getBoundingClientRect){var C=this.getBoundingClientRect();
f=B.clientX-C.left,e=B.clientY-C.top
}return B.deltaX=x,B.deltaY=w,B.deltaFactor=q,B.offsetX=f,B.offsetY=e,B.deltaMode=0,z.unshift(B,y,x,w),r&&clearTimeout(r),r=setTimeout(t,200),(v.event.dispatch||v.event.handle).apply(this,z)
}}function t(){q=null
}function s(d,c){return l.settings.adjustOldDeltas&&"mousewheel"===d.type&&c%120===0
}var r,q,p=["wheel","mousewheel","DOMMouseScroll","MozMousePixelScroll"],o="onwheel" in document||document.documentMode>=9?["wheel"]:["mousewheel","DomMouseScroll","MozMousePixelScroll"],n=Array.prototype.slice;
if(v.event.fixHooks){for(var m=p.length;
m;
){v.event.fixHooks[p[--m]]=v.event.mouseHooks
}}var l=v.event.special.mousewheel={version:"3.1.12",setup:function(){if(this.addEventListener){for(var b=o.length;
b;
){this.addEventListener(o[--b],u,!1)
}}else{this.onmousewheel=u
}v.data(this,"mousewheel-line-height",l.getLineHeight(this)),v.data(this,"mousewheel-page-height",l.getPageHeight(this))
},teardown:function(){if(this.removeEventListener){for(var b=o.length;
b;
){this.removeEventListener(o[--b],u,!1)
}}else{this.onmousewheel=null
}v.removeData(this,"mousewheel-line-height"),v.removeData(this,"mousewheel-page-height")
},getLineHeight:function(e){var g=v(e),f=g["offsetParent" in v.fn?"offsetParent":"parent"]();
return f.length||(f=v("body")),parseInt(f.css("fontSize"),10)||parseInt(g.css("fontSize"),10)||16
},getPageHeight:function(c){return v(c).height()
},settings:{adjustOldDeltas:!0,normalizeOffset:!0}};
v.fn.extend({mousewheel:function(b){return b?this.bind("mousewheel",b):this.trigger("mousewheel")
},unmousewheel:function(b){return this.unbind("mousewheel",b)
}})
});
!function(b){"function"==typeof define&&define.amd?define(["jquery"],b):"object"==typeof exports?module.exports=b:b(jQuery)
}(function(v){function u(B){var A=B||window.event,z=n.call(arguments,1),y=0,x=0,w=0,k=0,f=0,e=0;
if(B=v.event.fix(A),B.type="mousewheel","detail" in A&&(w=-1*A.detail),"wheelDelta" in A&&(w=A.wheelDelta),"wheelDeltaY" in A&&(w=A.wheelDeltaY),"wheelDeltaX" in A&&(x=-1*A.wheelDeltaX),"axis" in A&&A.axis===A.HORIZONTAL_AXIS&&(x=-1*w,w=0),y=0===w?x:w,"deltaY" in A&&(w=-1*A.deltaY,y=w),"deltaX" in A&&(x=A.deltaX,0===w&&(y=-1*x)),0!==w||0!==x){if(1===A.deltaMode){var d=v.data(this,"mousewheel-line-height");
y*=d,w*=d,x*=d
}else{if(2===A.deltaMode){var c=v.data(this,"mousewheel-page-height");
y*=c,w*=c,x*=c
}}if(k=Math.max(Math.abs(w),Math.abs(x)),(!q||q>k)&&(q=k,s(A,k)&&(q/=40)),s(A,k)&&(y/=40,x/=40,w/=40),y=Math[y>=1?"floor":"ceil"](y/q),x=Math[x>=1?"floor":"ceil"](x/q),w=Math[w>=1?"floor":"ceil"](w/q),l.settings.normalizeOffset&&this.getBoundingClientRect){var C=this.getBoundingClientRect();
f=B.clientX-C.left,e=B.clientY-C.top
}return B.deltaX=x,B.deltaY=w,B.deltaFactor=q,B.offsetX=f,B.offsetY=e,B.deltaMode=0,z.unshift(B,y,x,w),r&&clearTimeout(r),r=setTimeout(t,200),(v.event.dispatch||v.event.handle).apply(this,z)
}}function t(){q=null
}function s(d,c){return l.settings.adjustOldDeltas&&"mousewheel"===d.type&&c%120===0
}var r,q,p=["wheel","mousewheel","DOMMouseScroll","MozMousePixelScroll"],o="onwheel" in document||document.documentMode>=9?["wheel"]:["mousewheel","DomMouseScroll","MozMousePixelScroll"],n=Array.prototype.slice;
if(v.event.fixHooks){for(var m=p.length;
m;
){v.event.fixHooks[p[--m]]=v.event.mouseHooks
}}var l=v.event.special.mousewheel={version:"3.1.12",setup:function(){if(this.addEventListener){for(var b=o.length;
b;
){this.addEventListener(o[--b],u,!1)
}}else{this.onmousewheel=u
}v.data(this,"mousewheel-line-height",l.getLineHeight(this)),v.data(this,"mousewheel-page-height",l.getPageHeight(this))
},teardown:function(){if(this.removeEventListener){for(var b=o.length;
b;
){this.removeEventListener(o[--b],u,!1)
}}else{this.onmousewheel=null
}v.removeData(this,"mousewheel-line-height"),v.removeData(this,"mousewheel-page-height")
},getLineHeight:function(e){var g=v(e),f=g["offsetParent" in v.fn?"offsetParent":"parent"]();
return f.length||(f=v("body")),parseInt(f.css("fontSize"),10)||parseInt(g.css("fontSize"),10)||16
},getPageHeight:function(c){return v(c).height()
},settings:{adjustOldDeltas:!0,normalizeOffset:!0}};
v.fn.extend({mousewheel:function(b){return b?this.bind("mousewheel",b):this.trigger("mousewheel")
},unmousewheel:function(b){return this.unbind("mousewheel",b)
}})
});
!function(b){"undefined"!=typeof module&&module.exports?module.exports=b:b(jQuery,window,document)
}(function(b){!function(e){var f="function"==typeof define&&define.amd,c="undefined"!=typeof module&&module.exports,g="https:"==document.location.protocol?"https:":"http:",d="cdnjs.cloudflare.com/ajax/libs/jquery-mousewheel/3.1.13/jquery.mousewheel.min.js";
f||(c?require("jquery-mousewheel")(b):b.event.special.mousewheel||b("head").append(decodeURI("%3Cscript src="+g+"//"+d+"%3E%3C/script%3E"))),e()
}(function(){var aI,aN="mCustomScrollbar",a1="mCS",aO=".mCustomScrollbar",aT={setTop:0,setLeft:0,axis:"y",scrollbarPosition:"inside",scrollInertia:950,autoDraggerLength:!0,alwaysShowScrollbar:0,snapOffset:0,mouseWheel:{enable:!0,scrollAmount:"auto",axis:"y",deltaFactor:"auto",disableOver:["select","option","keygen","datalist","textarea"]},scrollButtons:{scrollType:"stepless",scrollAmount:"auto"},keyboard:{enable:!0,scrollType:"stepless",scrollAmount:"auto"},contentTouchScroll:25,documentTouchScroll:!0,advanced:{autoScrollOnFocus:"input,textarea,select,button,datalist,keygen,a[tabindex],area,object,[contenteditable='true']",updateOnContentResize:!0,updateOnImageLoad:"auto",autoUpdateTimeout:60},theme:"light",callbacks:{onTotalScrollOffset:0,onTotalScrollBackOffset:0,alwaysTriggerOffsets:!0}},aK=0,aQ={},aJ=window.attachEvent&&!window.addEventListener?1:0,aY=!1,aX=["mCSB_dragger_onDrag","mCSB_scrollTools_onDrag","mCS_img_loaded","mCS_disabled","mCS_destroyed","mCS_no_scrollbar","mCS-autoHide","mCS-dir-rtl","mCS_no_scrollbar_y","mCS_no_scrollbar_x","mCS_y_hidden","mCS_x_hidden","mCSB_draggerContainer","mCSB_buttonUp","mCSB_buttonDown","mCSB_buttonLeft","mCSB_buttonRight"],aH={init:function(d){var d=b.extend(!0,{},aT,d),g=aW.call(this);
if(d.live){var f=d.liveSelector||this.selector||aO,h=b(f);
if("off"===d.live){return void aP(f)
}aQ[f]=setTimeout(function(){h.mCustomScrollbar(d),"once"===d.live&&h.length&&aP(f)
},500)
}else{aP(f)
}return d.setWidth=d.set_width?d.set_width:d.setWidth,d.setHeight=d.set_height?d.set_height:d.setHeight,d.axis=d.horizontalScroll?"x":aM(d.axis),d.scrollInertia=d.scrollInertia>0&&d.scrollInertia<17?17:d.scrollInertia,"object"!=typeof d.mouseWheel&&1==d.mouseWheel&&(d.mouseWheel={enable:!0,scrollAmount:"auto",axis:"y",preventDefault:!1,deltaFactor:"auto",normalizeDelta:!1,invert:!1}),d.mouseWheel.scrollAmount=d.mouseWheelPixels?d.mouseWheelPixels:d.mouseWheel.scrollAmount,d.mouseWheel.normalizeDelta=d.advanced.normalizeMouseWheelDelta?d.advanced.normalizeMouseWheelDelta:d.mouseWheel.normalizeDelta,d.scrollButtons.scrollType=aV(d.scrollButtons.scrollType),aU(d),b(g).each(function(){var q=b(this);
if(!q.data(a1)){q.data(a1,{idx:++aK,opt:d,scrollRatio:{y:null,x:null},overflowed:null,contentReset:{y:null,x:null},bindEvents:!1,tweenRunning:!1,sequential:{},langDir:q.css("direction"),cbOffsets:null,trigger:null,poll:{size:{o:0,n:0},img:{o:0,n:0},change:{o:0,n:0}}});
var t=q.data(a1),m=t.opt,k=q.data("mcs-axis"),p=q.data("mcs-scrollbar-position"),r=q.data("mcs-theme");
k&&(m.axis=k),p&&(m.scrollbarPosition=p),r&&(m.theme=r,aU(m)),aG.call(this),t&&m.callbacks.onCreate&&"function"==typeof m.callbacks.onCreate&&m.callbacks.onCreate.call(this),b("#mCSB_"+t.idx+"_container img:not(."+aX[2]+")").addClass(aX[2]),aH.update.call(null,q)
}})
},update:function(c,d){var f=c||aW.call(this);
return b(f).each(function(){var k=b(this);
if(k.data(a1)){var q=k.data(a1),h=q.opt,o=b("#mCSB_"+q.idx+"_container"),g=b("#mCSB_"+q.idx),m=[b("#mCSB_"+q.idx+"_dragger_vertical"),b("#mCSB_"+q.idx+"_dragger_horizontal")];
if(!o.length){return
}q.tweenRunning&&am(k),d&&q&&h.callbacks.onBeforeUpdate&&"function"==typeof h.callbacks.onBeforeUpdate&&h.callbacks.onBeforeUpdate.call(this),k.hasClass(aX[3])&&k.removeClass(aX[3]),k.hasClass(aX[4])&&k.removeClass(aX[4]),g.css("max-height","none"),g.height()!==k.height()&&g.css("max-height",k.height()),a2.call(this),"y"===h.axis||h.advanced.autoExpandHorizontalScroll||o.css("width",aE(o)),q.overflowed=aD.call(this),an.call(this),h.autoDraggerLength&&ah.call(this),aZ.call(this),ag.call(this);
var p=[Math.abs(o[0].offsetTop),Math.abs(o[0].offsetLeft)];
"x"!==h.axis&&(q.overflowed[0]?m[0].height()>m[0].parent().height()?az.call(this):(ae(k,p[0].toString(),{dir:"y",dur:0,overwrite:"none"}),q.contentReset.y=null):(az.call(this),"y"===h.axis?aR.call(this):"yx"===h.axis&&q.overflowed[1]&&ae(k,p[1].toString(),{dir:"x",dur:0,overwrite:"none"}))),"y"!==h.axis&&(q.overflowed[1]?m[1].width()>m[1].parent().width()?az.call(this):(ae(k,p[1].toString(),{dir:"x",dur:0,overwrite:"none"}),q.contentReset.x=null):(az.call(this),"x"===h.axis?aR.call(this):"yx"===h.axis&&q.overflowed[0]&&ae(k,p[0].toString(),{dir:"y",dur:0,overwrite:"none"}))),d&&q&&(2===d&&h.callbacks.onImageLoad&&"function"==typeof h.callbacks.onImageLoad?h.callbacks.onImageLoad.call(this):3===d&&h.callbacks.onSelectorChange&&"function"==typeof h.callbacks.onSelectorChange?h.callbacks.onSelectorChange.call(this):h.callbacks.onUpdate&&"function"==typeof h.callbacks.onUpdate&&h.callbacks.onUpdate.call(this)),aS.call(this)
}})
},scrollTo:function(c,d){if("undefined"!=typeof c&&null!=c){var f=aW.call(this);
return b(f).each(function(){var q=b(this);
if(q.data(a1)){var h=q.data(a1),m=h.opt,g={trigger:"external",scrollInertia:m.scrollInertia,scrollEasing:"mcsEaseInOut",moveDragger:!1,timeout:60,callbacks:!0,onStart:!0,onUpdate:!0,onComplete:!0},k=b.extend(!0,{},g,d),p=aL.call(this,c),o=k.scrollInertia>0&&k.scrollInertia<17?17:k.scrollInertia;
p[0]=aa.call(this,p[0],"y"),p[1]=aa.call(this,p[1],"x"),k.moveDragger&&(p[0]*=h.scrollRatio.y,p[1]*=h.scrollRatio.x),k.dur=o,setTimeout(function(){null!==p[0]&&"undefined"!=typeof p[0]&&"x"!==m.axis&&h.overflowed[0]&&(k.dir="y",k.overwrite="all",ae(q,p[0].toString(),k)),null!==p[1]&&"undefined"!=typeof p[1]&&"y"!==m.axis&&h.overflowed[1]&&(k.dir="x",k.overwrite="none",ae(q,p[1].toString(),k))
},k.timeout)
}})
}},stop:function(){var c=aW.call(this);
return b(c).each(function(){var d=b(this);
d.data(a1)&&am(d)
})
},disable:function(c){var d=aW.call(this);
return b(d).each(function(){var f=b(this);
if(f.data(a1)){f.data(a1);
aS.call(this,"remove"),aR.call(this),c&&az.call(this),an.call(this,!0),f.addClass(aX[3])
}})
},destroy:function(){var c=aW.call(this);
return b(c).each(function(){var m=b(this);
if(m.data(a1)){var f=m.data(a1),h=f.opt,d=b("#mCSB_"+f.idx),g=b("#mCSB_"+f.idx+"_container"),k=b(".mCSB_"+f.idx+"_scrollbar");
h.live&&aP(h.liveSelector||b(c).selector),aS.call(this,"remove"),aR.call(this),az.call(this),m.removeData(a1),ap(this,"mcs"),k.remove(),g.find("img."+aX[2]).removeClass(aX[2]),d.replaceWith(g.contents()),m.removeClass(aN+" _"+a1+"_"+f.idx+" "+aX[6]+" "+aX[7]+" "+aX[5]+" "+aX[3]).addClass(aX[4])
}})
}},aW=function(){return"object"!=typeof b(this)||b(this).length<1?aO:this
},aU=function(f){var h=["rounded","rounded-dark","rounded-dots","rounded-dots-dark"],c=["rounded-dots","rounded-dots-dark","3d","3d-dark","3d-thick","3d-thick-dark","inset","inset-dark","inset-2","inset-2-dark","inset-3","inset-3-dark"],k=["minimal","minimal-dark"],d=["minimal","minimal-dark"],g=["minimal","minimal-dark"];
f.autoDraggerLength=b.inArray(f.theme,h)>-1?!1:f.autoDraggerLength,f.autoExpandScrollbar=b.inArray(f.theme,c)>-1?!1:f.autoExpandScrollbar,f.scrollButtons.enable=b.inArray(f.theme,k)>-1?!1:f.scrollButtons.enable,f.autoHideScrollbar=b.inArray(f.theme,d)>-1?!0:f.autoHideScrollbar,f.scrollbarPosition=b.inArray(f.theme,g)>-1?"outside":f.scrollbarPosition
},aP=function(c){aQ[c]&&(clearTimeout(aQ[c]),ap(aQ,c))
},aM=function(c){return"yx"===c||"xy"===c||"auto"===c?"yx":"x"===c||"horizontal"===c?"x":"y"
},aV=function(c){return"stepped"===c||"pixels"===c||"step"===c||"click"===c?"stepped":"stepless"
},aG=function(){var C=b(this),o=C.data(a1),w=o.opt,d=w.autoExpandScrollbar?" "+aX[1]+"_expand":"",v=["<div id='mCSB_"+o.idx+"_scrollbar_vertical' class='mCSB_scrollTools mCSB_"+o.idx+"_scrollbar mCS-"+w.theme+" mCSB_scrollTools_vertical"+d+"'><div class='"+aX[12]+"'><div id='mCSB_"+o.idx+"_dragger_vertical' class='mCSB_dragger' style='position:absolute;' oncontextmenu='return false;'><div class='mCSB_dragger_bar' /></div><div class='mCSB_draggerRail' /></div></div>","<div id='mCSB_"+o.idx+"_scrollbar_horizontal' class='mCSB_scrollTools mCSB_"+o.idx+"_scrollbar mCS-"+w.theme+" mCSB_scrollTools_horizontal"+d+"'><div class='"+aX[12]+"'><div id='mCSB_"+o.idx+"_dragger_horizontal' class='mCSB_dragger' style='position:absolute;' oncontextmenu='return false;'><div class='mCSB_dragger_bar' /></div><div class='mCSB_draggerRail' /></div></div>"],D="yx"===w.axis?"mCSB_vertical_horizontal":"x"===w.axis?"mCSB_horizontal":"mCSB_vertical",A="yx"===w.axis?v[0]+v[1]:"x"===w.axis?v[1]:v[0],B="yx"===w.axis?"<div id='mCSB_"+o.idx+"_container_wrapper' class='mCSB_container_wrapper' />":"",z=w.autoHideScrollbar?" "+aX[6]:"",x="x"!==w.axis&&"rtl"===o.langDir?" "+aX[7]:"";
w.setWidth&&C.css("width",w.setWidth),w.setHeight&&C.css("height",w.setHeight),w.setLeft="y"!==w.axis&&"rtl"===o.langDir?"989999px":w.setLeft,C.addClass(aN+" _"+a1+"_"+o.idx+z+x).wrapInner("<div id='mCSB_"+o.idx+"' class='mCustomScrollBox mCS-"+w.theme+" "+D+"'><div id='mCSB_"+o.idx+"_container' class='mCSB_container' style='position:relative; top:"+w.setTop+"; left:"+w.setLeft+";' dir="+o.langDir+" /></div>");
var q=b("#mCSB_"+o.idx),k=b("#mCSB_"+o.idx+"_container");
"y"===w.axis||w.advanced.autoExpandHorizontalScroll||k.css("width",aE(k)),"outside"===w.scrollbarPosition?("static"===C.css("position")&&C.css("position","relative"),C.css("overflow","visible"),q.addClass("mCSB_outside").after(A)):(q.addClass("mCSB_inside").append(A),k.wrap(B)),aF.call(this);
var y=[b("#mCSB_"+o.idx+"_dragger_vertical"),b("#mCSB_"+o.idx+"_dragger_horizontal")];
y[0].css("min-height",y[0].height()),y[1].css("min-width",y[1].width())
},aE=function(d){var f=[d[0].scrollWidth,Math.max.apply(Math,d.children().map(function(){return b(this).outerWidth(!0)
}).get())],c=d.parent().width();
return f[0]>c?f[0]:f[1]>c?f[1]:"100%"
},a2=function(){var d=b(this),g=d.data(a1),h=g.opt,c=b("#mCSB_"+g.idx+"_container");
if(h.advanced.autoExpandHorizontalScroll&&"y"!==h.axis){c.css({width:"auto","min-width":0,"overflow-x":"scroll"});
var f=Math.ceil(c[0].scrollWidth);
3===h.advanced.autoExpandHorizontalScroll||2!==h.advanced.autoExpandHorizontalScroll&&f>c.parent().width()?c.css({width:f,"min-width":"100%","overflow-x":"inherit"}):c.css({"overflow-x":"inherit",position:"absolute"}).wrap("<div class='mCSB_h_wrapper' style='position:relative; left:0; width:999999px;' />").css({width:Math.ceil(c[0].getBoundingClientRect().right+0.4)-Math.floor(c[0].getBoundingClientRect().left),"min-width":"100%",position:"relative"}).unwrap()
}},aF=function(){var f=b(this),k=f.data(a1),m=k.opt,d=b(".mCSB_"+k.idx+"_scrollbar:first"),h=a0(m.scrollButtons.tabindex)?"tabindex='"+m.scrollButtons.tabindex+"'":"",c=["<a href='#' class='"+aX[13]+"' oncontextmenu='return false;' "+h+" />","<a href='#' class='"+aX[14]+"' oncontextmenu='return false;' "+h+" />","<a href='#' class='"+aX[15]+"' oncontextmenu='return false;' "+h+" />","<a href='#' class='"+aX[16]+"' oncontextmenu='return false;' "+h+" />"],g=["x"===m.axis?c[2]:c[0],"x"===m.axis?c[3]:c[1],c[2],c[3]];
m.scrollButtons.enable&&d.prepend(g[0]).append(g[1]).next(".mCSB_scrollTools").prepend(g[2]).append(g[3])
},ah=function(){var v=b(this),g=v.data(a1),h=b("#mCSB_"+g.idx),m=b("#mCSB_"+g.idx+"_container"),f=[b("#mCSB_"+g.idx+"_dragger_vertical"),b("#mCSB_"+g.idx+"_dragger_horizontal")],k=[h.height()/m.outerHeight(!1),h.width()/m.outerWidth(!1)],q=[parseInt(f[0].css("min-height")),Math.round(k[0]*f[0].parent().height()),parseInt(f[1].css("min-width")),Math.round(k[1]*f[1].parent().width())],p=aJ&&q[1]<q[0]?q[0]:q[1],s=aJ&&q[3]<q[2]?q[2]:q[3];
f[0].css({height:p,"max-height":f[0].parent().height()-10}).find(".mCSB_dragger_bar").css({"line-height":q[0]+"px"}),f[1].css({width:s,"max-width":f[1].parent().width()-10})
},aZ=function(){var f=b(this),k=f.data(a1),m=b("#mCSB_"+k.idx),d=b("#mCSB_"+k.idx+"_container"),h=[b("#mCSB_"+k.idx+"_dragger_vertical"),b("#mCSB_"+k.idx+"_dragger_horizontal")],c=[d.outerHeight(!1)-m.height(),d.outerWidth(!1)-m.width()],g=[c[0]/(h[0].parent().height()-h[0].height()),c[1]/(h[1].parent().width()-h[1].width())];
k.scrollRatio={y:g[0],x:g[1]}
},ay=function(f,d,g){var c=g?aX[0]+"_expanded":"",h=f.closest(".mCSB_scrollTools");
"active"===d?(f.toggleClass(aX[0]+" "+c),h.toggleClass(aX[1]),f[0]._draggable=f[0]._draggable?0:1):f[0]._draggable||("hide"===d?(f.removeClass(aX[0]),h.removeClass(aX[1])):(f.addClass(aX[0]),h.addClass(aX[1])))
},aD=function(){var g=b(this),m=g.data(a1),q=b("#mCSB_"+m.idx),f=b("#mCSB_"+m.idx+"_container"),k=null==m.overflowed?f.height():f.outerHeight(!1),d=null==m.overflowed?f.width():f.outerWidth(!1),h=f[0].scrollHeight,p=f[0].scrollWidth;
return h>k&&(k=h),p>d&&(d=p),[k>q.height(),d>q.width()]
},az=function(){var f=b(this),k=f.data(a1),m=k.opt,d=b("#mCSB_"+k.idx),h=b("#mCSB_"+k.idx+"_container"),c=[b("#mCSB_"+k.idx+"_dragger_vertical"),b("#mCSB_"+k.idx+"_dragger_horizontal")];
if(am(f),("x"!==m.axis&&!k.overflowed[0]||"y"===m.axis&&k.overflowed[0])&&(c[0].add(h).css("top",0),ae(f,"_resetY")),"y"!==m.axis&&!k.overflowed[1]||"x"===m.axis&&k.overflowed[1]){var g=dx=0;
"rtl"===k.langDir&&(g=d.width()-h.outerWidth(!1),dx=Math.abs(g/k.scrollRatio.x)),h.css("left",g),c[1].css("left",dx),ae(f,"_resetX")
}},ag=function(){function d(){f=setTimeout(function(){b.event.special.mousewheel?(clearTimeout(f),aw.call(g[0])):d()
},100)
}var g=b(this),h=g.data(a1),c=h.opt;
if(!h.bindEvents){if(ar.call(this),c.contentTouchScroll&&ax.call(this),ai.call(this),c.mouseWheel.enable){var f;
d()
}aC.call(this),ak.call(this),c.advanced.autoScrollOnFocus&&aA.call(this),c.scrollButtons.enable&&at.call(this),c.keyboard.enable&&af.call(this),h.bindEvents=!0
}},aR=function(){var f=b(this),k=f.data(a1),m=k.opt,d=a1+"_"+k.idx,h=".mCSB_"+k.idx+"_scrollbar",c=b("#mCSB_"+k.idx+",#mCSB_"+k.idx+"_container,#mCSB_"+k.idx+"_container_wrapper,"+h+" ."+aX[12]+",#mCSB_"+k.idx+"_dragger_vertical,#mCSB_"+k.idx+"_dragger_horizontal,"+h+">a"),g=b("#mCSB_"+k.idx+"_container");
m.advanced.releaseDraggableSelectors&&c.add(b(m.advanced.releaseDraggableSelectors)),k.bindEvents&&(b(document).unbind("."+d),c.each(function(){b(this).unbind("."+d)
}),clearTimeout(f[0]._focusTimeout),ap(f[0],"_focusTimeout"),clearTimeout(k.sequential.step),ap(k.sequential,"step"),clearTimeout(g[0].onCompleteTimeout),ap(g[0],"onCompleteTimeout"),k.bindEvents=!1)
},an=function(g){var m=b(this),q=m.data(a1),f=q.opt,k=b("#mCSB_"+q.idx+"_container_wrapper"),d=k.length?k:b("#mCSB_"+q.idx+"_container"),h=[b("#mCSB_"+q.idx+"_scrollbar_vertical"),b("#mCSB_"+q.idx+"_scrollbar_horizontal")],p=[h[0].find(".mCSB_dragger"),h[1].find(".mCSB_dragger")];
"x"!==f.axis&&(q.overflowed[0]&&!g?(h[0].add(p[0]).add(h[0].children("a")).css("display","block"),d.removeClass(aX[8]+" "+aX[10])):(f.alwaysShowScrollbar?(2!==f.alwaysShowScrollbar&&p[0].css("display","none"),d.removeClass(aX[10])):(h[0].css("display","none"),d.addClass(aX[10])),d.addClass(aX[8]))),"y"!==f.axis&&(q.overflowed[1]&&!g?(h[1].add(p[1]).add(h[1].children("a")).css("display","block"),d.removeClass(aX[9]+" "+aX[11])):(f.alwaysShowScrollbar?(2!==f.alwaysShowScrollbar&&p[1].css("display","none"),d.removeClass(aX[11])):(h[1].css("display","none"),d.addClass(aX[11])),d.addClass(aX[9]))),q.overflowed[0]||q.overflowed[1]?m.removeClass(aX[5]):m.addClass(aX[5])
},al=function(f){var d=f.type;
switch(d){case"pointerdown":case"MSPointerDown":case"pointermove":case"MSPointerMove":case"pointerup":case"MSPointerUp":return f.target.ownerDocument!==document?[f.originalEvent.screenY,f.originalEvent.screenX,!1]:[f.originalEvent.pageY,f.originalEvent.pageX,!1];
case"touchstart":case"touchmove":case"touchend":var g=f.originalEvent.touches[0]||f.originalEvent.changedTouches[0],c=f.originalEvent.touches.length||f.originalEvent.changedTouches.length;
return f.target.ownerDocument!==document?[g.screenY,g.screenX,c>1]:[g.pageY,g.pageX,c>1];
default:return[f.pageY,f.pageX,!1]
}},ar=function(){function D(f){var d=v.find("iframe");
if(d.length){var g=f?"auto":"none";
d.css("pointer-events",g)
}}function q(l,g,m,d){if(v[0].idleTimer=C.scrollInertia<233?250:0,s.attr("id")===y[1]){var f="x",h=(s[0].offsetLeft-g+d)*B.scrollRatio.x
}else{var f="y",h=(s[0].offsetTop-l+m)*B.scrollRatio.y
}ae(w,h.toString(),{dir:f,drag:!0})
}var s,x,c,w=b(this),B=w.data(a1),C=B.opt,A=a1+"_"+B.idx,y=["mCSB_"+B.idx+"_dragger_vertical","mCSB_"+B.idx+"_dragger_horizontal"],v=b("#mCSB_"+B.idx+"_container"),k=b("#"+y[0]+",#"+y[1]),z=C.advanced.releaseDraggableSelectors?k.add(b(C.advanced.releaseDraggableSelectors)):k;
k.bind("mousedown."+A+" touchstart."+A+" pointerdown."+A+" MSPointerDown."+A,function(t){if(t.stopImmediatePropagation(),t.preventDefault(),e(t)){aY=!0,aJ&&(document.onselectstart=function(){return !1
}),D(!1),am(w),s=b(this);
var l=s.offset(),r=al(t)[0]-l.top,p=al(t)[1]-l.left,n=s.height()+l.top,g=s.width()+l.left;
n>r&&r>0&&g>p&&p>0&&(x=r,c=p),ay(s,"active",C.autoExpandScrollbar)
}}).bind("touchmove."+A,function(h){h.stopImmediatePropagation(),h.preventDefault();
var g=s.offset(),f=al(h)[0]-g.top,d=al(h)[1]-g.left;
q(x,c,f,d)
}),b(document).bind("mousemove."+A+" pointermove."+A+" MSPointerMove."+A,function(h){if(s){var g=s.offset(),f=al(h)[0]-g.top,d=al(h)[1]-g.left;
if(x===f&&c===d){return
}q(x,c,f,d)
}}).add(z).bind("mouseup."+A+" touchend."+A+" pointerup."+A+" MSPointerUp."+A,function(d){s&&(ay(s,"active",C.autoExpandScrollbar),s=null),aY=!1,aJ&&(document.onselectstart=null),D(!0)
})
},ax=function(){function bb(d){if(!aB(d)||aY||al(d)[2]){return void (aI=0)
}aI=1,bl=0,a6=0,bk=1,O.removeClass("mCS_touch_action");
var f=Q.offset();
Z=al(d)[0]-f.top,bj=al(d)[1]-f.left,a9=[al(d)[0],al(d)[1]]
}function bc(s){if(aB(s)&&!aY&&!al(s)[2]&&(q.documentTouchScroll||s.preventDefault(),s.stopImmediatePropagation(),(!a6||bl)&&bk)){bi=au();
var v=J.offset(),f=al(s)[0]-v.top,u=al(s)[1]-v.left,g="mcsLinearOut";
if(F.push(f),a3.push(u),a9[2]=Math.abs(al(s)[0]-a9[0]),a9[3]=Math.abs(al(s)[1]-a9[1]),a8.overflowed[0]){var m=a4[0].parent().height()-a4[0].height(),d=Z-f>0&&f-Z>-(m*a8.scrollRatio.y)&&(2*a9[3]<a9[2]||"yx"===q.axis)
}if(a8.overflowed[1]){var k=a4[1].parent().width()-a4[1].width(),p=bj-u>0&&u-bj>-(k*a8.scrollRatio.x)&&(2*a9[2]<a9[3]||"yx"===q.axis)
}d||p?(c||s.preventDefault(),bl=1):(a6=1,O.addClass("mCS_touch_action")),c&&s.preventDefault(),X="yx"===q.axis?[Z-f,bj-u]:"x"===q.axis?[null,bj-u]:[Z-f,null],Q[0].idleTimer=250,a8.overflowed[0]&&a5(X[0],K,g,"y","all",!0),a8.overflowed[1]&&a5(X[1],K,g,"x",N,!0)
}}function bg(d){if(!aB(d)||aY||al(d)[2]){return void (aI=0)
}aI=1,d.stopImmediatePropagation(),am(O),ba=au();
var f=J.offset();
bh=al(d)[0]-f.top,bd=al(d)[1]-f.left,F=[],a3=[]
}function a7(m){if(aB(m)&&!aY&&!al(m)[2]){bk=0,m.stopImmediatePropagation(),bl=0,a6=0,Y=au();
var w=J.offset(),g=al(m)[0]-w.top,s=al(m)[1]-w.left;
if(!(Y-bi>30)){bm=1000/(Y-ba);
var h="mcsEaseOut",k=2.5>bm,d=k?[F[F.length-2],a3[a3.length-2]]:[0,0];
V=k?[g-d[0],s-d[1]]:[g-bh,s-bd];
var v=[Math.abs(V[0]),Math.abs(V[1])];
bm=k?[Math.abs(V[0]/4),Math.abs(V[1]/4)]:[bm,bm];
var l=[Math.abs(Q[0].offsetTop)-V[0]*be(v[0]/bm[0],bm[0]),Math.abs(Q[0].offsetLeft)-V[1]*be(v[1]/bm[1],bm[1])];
X="yx"===q.axis?[l[0],l[1]]:"x"===q.axis?[null,l[1]]:[l[0],null],t=[4*v[0]+q.scrollInertia,4*v[1]+q.scrollInertia];
var p=parseInt(q.contentTouchScroll)||0;
X[0]=v[0]>p?X[0]:0,X[1]=v[1]>p?X[1]:0,a8.overflowed[0]&&a5(X[0],t[0],h,"y",N,!1),a8.overflowed[1]&&a5(X[1],t[1],h,"x",N,!1)
}}}function be(f,d){var g=[1.5*d,2*d,d/1.5,d/2];
return f>90?d>4?g[0]:g[3]:f>60?d>3?g[3]:g[2]:f>30?d>8?g[1]:d>6?g[0]:d>4?d:g[2]:d>8?d:g[3]
}function a5(h,g,k,d,l,f){h&&ae(O,h.toString(),{dur:g,scrollEasing:k,dir:d,overwrite:l,drag:f})
}var bk,Z,bj,bh,bd,ba,bi,Y,V,bm,X,t,bl,a6,O=b(this),a8=O.data(a1),q=a8.opt,bf=a1+"_"+a8.idx,J=b("#mCSB_"+a8.idx),Q=b("#mCSB_"+a8.idx+"_container"),a4=[b("#mCSB_"+a8.idx+"_dragger_vertical"),b("#mCSB_"+a8.idx+"_dragger_horizontal")],F=[],a3=[],K=0,N="yx"===q.axis?"none":"all",a9=[],G=Q.find("iframe"),W=["touchstart."+bf+" pointerdown."+bf+" MSPointerDown."+bf,"touchmove."+bf+" pointermove."+bf+" MSPointerMove."+bf,"touchend."+bf+" pointerup."+bf+" MSPointerUp."+bf],c=void 0!==document.body.style.touchAction;
Q.bind(W[0],function(d){bb(d)
}).bind(W[1],function(d){bc(d)
}),J.bind(W[0],function(d){bg(d)
}).bind(W[2],function(d){a7(d)
}),G.length&&G.each(function(){b(this).load(function(){ad(this)&&b(this.contentDocument||this.contentWindow.document).bind(W[0],function(d){bb(d),bg(d)
}).bind(W[1],function(d){bc(d)
}).bind(W[2],function(d){a7(d)
})
})
})
},ai=function(){function g(){return window.getSelection?window.getSelection().toString():document.selection&&"Control"!=document.selection.type?document.selection.createRange().text:0
}function k(f,d,h){v.type=h&&p?"stepped":"stepless",v.scrollAmount=10,av(c,f,d,"mcsLinearOut",h?60:null)
}var p,c=b(this),m=c.data(a1),x=m.opt,v=m.sequential,w=a1+"_"+m.idx,t=b("#mCSB_"+m.idx+"_container"),q=t.parent();
t.bind("mousedown."+w,function(d){aI||p||(p=1,aY=!0)
}).add(document).bind("mousemove."+w,function(h){if(!aI&&p&&g()){var d=t.offset(),f=al(h)[0]-d.top+t[0].offsetTop,l=al(h)[1]-d.left+t[0].offsetLeft;
f>0&&f<q.height()&&l>0&&l<q.width()?v.step&&k("off",null,"stepped"):("x"!==x.axis&&m.overflowed[0]&&(0>f?k("on",38):f>q.height()&&k("on",40)),"y"!==x.axis&&m.overflowed[1]&&(0>l?k("on",37):l>q.width()&&k("on",39)))
}}).bind("mouseup."+w+" dragend."+w,function(d){aI||(p&&(p=0,k("off",null)),aY=!1)
})
},aw=function(){function h(C,z){if(am(p),!ao(p,C.target)){var c="auto"!==g.mouseWheel.deltaFactor?parseInt(g.mouseWheel.deltaFactor):aJ&&C.deltaFactor<100?100:C.deltaFactor||100,y=g.scrollInertia;
if("x"===g.axis||"x"===g.mouseWheel.axis){var B="x",x=[Math.round(c*s.scrollRatio.x),parseInt(g.mouseWheel.scrollAmount)],o="auto"!==g.mouseWheel.scrollAmount?x[1]:x[0]>=f.width()?0.9*f.width():x[0],n=Math.abs(b("#mCSB_"+s.idx+"_container")[0].offsetLeft),l=q[1][0].offsetLeft,w=q[1].parent().width()-q[1].width(),A=C.deltaX||C.deltaY||z
}else{var B="y",x=[Math.round(c*s.scrollRatio.y),parseInt(g.mouseWheel.scrollAmount)],o="auto"!==g.mouseWheel.scrollAmount?x[1]:x[0]>=f.height()?0.9*f.height():x[0],n=Math.abs(b("#mCSB_"+s.idx+"_container")[0].offsetTop),l=q[0][0].offsetTop,w=q[0].parent().height()-q[0].height(),A=C.deltaY||z
}"y"===B&&!s.overflowed[0]||"x"===B&&!s.overflowed[1]||((g.mouseWheel.invert||C.webkitDirectionInvertedFromDevice)&&(A=-A),g.mouseWheel.normalizeDelta&&(A=0>A?-1:1),(A>0&&0!==l||0>A&&l!==w||g.mouseWheel.preventDefault)&&(C.stopImmediatePropagation(),C.preventDefault()),C.deltaFactor<2&&!g.mouseWheel.normalizeDelta&&(o=C.deltaFactor,y=17),ae(p,(n-A*o).toString(),{dir:B,dur:y}))
}}if(b(this).data(a1)){var p=b(this),s=p.data(a1),g=s.opt,k=a1+"_"+s.idx,f=b("#mCSB_"+s.idx),q=[b("#mCSB_"+s.idx+"_dragger_vertical"),b("#mCSB_"+s.idx+"_dragger_horizontal")],m=b("#mCSB_"+s.idx+"_container").find("iframe");
m.length&&m.each(function(){b(this).load(function(){ad(this)&&b(this.contentDocument||this.contentWindow.document).bind("mousewheel."+k,function(c,d){h(c,d)
})
})
}),f.bind("mousewheel."+k,function(c,d){h(c,d)
})
}},ad=function(f){var d=null;
try{var g=f.contentDocument||f.contentWindow.document;
d=g.body.innerHTML
}catch(c){}return null!==d
},ao=function(d,g){var h=g.nodeName.toLowerCase(),c=d.data(a1).opt.mouseWheel.disableOver,f=["select","textarea"];
return b.inArray(h,c)>-1&&!(b.inArray(h,f)>-1&&!b(g).is(":focus"))
},aC=function(){var f,k=b(this),m=k.data(a1),d=a1+"_"+m.idx,h=b("#mCSB_"+m.idx+"_container"),c=h.parent(),g=b(".mCSB_"+m.idx+"_scrollbar ."+aX[12]);
g.bind("mousedown."+d+" touchstart."+d+" pointerdown."+d+" MSPointerDown."+d,function(l){aY=!0,b(l.target).hasClass("mCSB_dragger")||(f=1)
}).bind("touchend."+d+" pointerup."+d+" MSPointerUp."+d,function(l){aY=!1
}).bind("click."+d,function(l){if(f&&(f=0,b(l.target).hasClass(aX[12])||b(l.target).hasClass("mCSB_draggerRail"))){am(k);
var o=b(this),p=o.find(".mCSB_dragger");
if(o.parent(".mCSB_scrollTools_horizontal").length>0){if(!m.overflowed[1]){return
}var r="x",n=l.pageX>p.offset().left?-1:1,q=Math.abs(h[0].offsetLeft)-0.9*n*c.width()
}else{if(!m.overflowed[0]){return
}var r="y",n=l.pageY>p.offset().top?-1:1,q=Math.abs(h[0].offsetTop)-0.9*n*c.height()
}ae(k,q.toString(),{dir:r,scrollEasing:"mcsEaseInOut"})
}})
},aA=function(){var f=b(this),h=f.data(a1),k=h.opt,d=a1+"_"+h.idx,g=b("#mCSB_"+h.idx+"_container"),c=g.parent();
g.bind("focusin."+d,function(p){var l=b(document.activeElement),m=g.find(".mCustomScrollBox").length,n=0;
l.is(k.advanced.autoScrollOnFocus)&&(am(f),clearTimeout(f[0]._focusTimeout),f[0]._focusTimer=m?(n+17)*m:0,f[0]._focusTimeout=setTimeout(function(){var r=[ac(l)[0],ac(l)[1]],s=[g[0].offsetTop,g[0].offsetLeft],q=[s[0]+r[0]>=0&&s[0]+r[0]<c.height()-l.outerHeight(!1),s[1]+r[1]>=0&&s[0]+r[1]<c.width()-l.outerWidth(!1)],t="yx"!==k.axis||q[0]||q[1]?"all":"none";
"x"===k.axis||q[0]||ae(f,r[0].toString(),{dir:"y",scrollEasing:"mcsEaseInOut",overwrite:t,dur:n}),"y"===k.axis||q[1]||ae(f,r[1].toString(),{dir:"x",scrollEasing:"mcsEaseInOut",overwrite:t,dur:n})
},f[0]._focusTimer))
})
},ak=function(){var d=b(this),f=d.data(a1),g=a1+"_"+f.idx,c=b("#mCSB_"+f.idx+"_container").parent();
c.bind("scroll."+g,function(h){(0!==c.scrollTop()||0!==c.scrollLeft())&&b(".mCSB_"+f.idx+"_scrollbar").css("visibility","hidden")
})
},at=function(){var f=b(this),k=f.data(a1),m=k.opt,d=k.sequential,h=a1+"_"+k.idx,c=".mCSB_"+k.idx+"_scrollbar",g=b(c+">a");
g.bind("mousedown."+h+" touchstart."+h+" pointerdown."+h+" MSPointerDown."+h+" mouseup."+h+" touchend."+h+" pointerup."+h+" MSPointerUp."+h+" mouseout."+h+" pointerout."+h+" MSPointerOut."+h+" click."+h,function(o){function p(l,q){d.scrollAmount=m.snapAmount||m.scrollButtons.scrollAmount,av(f,l,q)
}if(o.preventDefault(),e(o)){var n=b(this).attr("class");
switch(d.type=m.scrollButtons.scrollType,o.type){case"mousedown":case"touchstart":case"pointerdown":case"MSPointerDown":if("stepped"===d.type){return
}aY=!0,k.tweenRunning=!1,p("on",n);
break;
case"mouseup":case"touchend":case"pointerup":case"MSPointerUp":case"mouseout":case"pointerout":case"MSPointerOut":if("stepped"===d.type){return
}aY=!1,d.dir&&p("off",n);
break;
case"click":if("stepped"!==d.type||k.tweenRunning){return
}p("on",n)
}}})
},af=function(){function A(o){function n(h,f){g.type=q.keyboard.scrollType,g.scrollAmount=q.snapAmount||q.keyboard.scrollAmount,"stepped"===g.type&&m.tweenRunning||av(k,h,f)
}switch(o.type){case"blur":m.tweenRunning&&g.dir&&n("off",null);
break;
case"keydown":case"keyup":var d=o.keyCode?o.keyCode:o.which,u="on";
if("x"!==q.axis&&(38===d||40===d)||"y"!==q.axis&&(37===d||39===d)){if((38===d||40===d)&&!m.overflowed[0]||(37===d||39===d)&&!m.overflowed[1]){return
}"keyup"===o.type&&(u="off"),b(document.activeElement).is(z)||(o.preventDefault(),o.stopImmediatePropagation(),n(u,d))
}else{if(33===d||34===d){if((m.overflowed[0]||m.overflowed[1])&&(o.preventDefault(),o.stopImmediatePropagation()),"keyup"===o.type){am(k);
var C=34===d?-1:1;
if("x"===q.axis||"yx"===q.axis&&m.overflowed[1]&&!m.overflowed[0]){var r="x",c=Math.abs(y[0].offsetLeft)-0.9*C*x.width()
}else{var r="y",c=Math.abs(y[0].offsetTop)-0.9*C*x.height()
}ae(k,c.toString(),{dir:r,scrollEasing:"mcsEaseInOut"})
}}else{if((35===d||36===d)&&!b(document.activeElement).is(z)&&((m.overflowed[0]||m.overflowed[1])&&(o.preventDefault(),o.stopImmediatePropagation()),"keyup"===o.type)){if("x"===q.axis||"yx"===q.axis&&m.overflowed[1]&&!m.overflowed[0]){var r="x",c=35===d?Math.abs(x.width()-y.outerWidth(!1)):0
}else{var r="y",c=35===d?Math.abs(x.height()-y.outerHeight(!1)):0
}ae(k,c.toString(),{dir:r,scrollEasing:"mcsEaseInOut"})
}}}}}var k=b(this),m=k.data(a1),q=m.opt,g=m.sequential,p=a1+"_"+m.idx,B=b("#mCSB_"+m.idx),y=b("#mCSB_"+m.idx+"_container"),x=y.parent(),z="input,textarea,select,datalist,keygen,[contenteditable='true']",w=y.find("iframe"),v=["blur."+p+" keydown."+p+" keyup."+p];
w.length&&w.each(function(){b(this).load(function(){ad(this)&&b(this.contentDocument||this.contentWindow.document).bind(v[0],function(c){A(c)
})
})
}),B.attr("tabindex","0").bind(v[0],function(c){A(c)
})
},av=function(E,q,v,y,d){function x(h){var c="stepped"!==B.type,r=d?d:h?c?k/1.5:A:1000/60,f=h?c?7.5:40:2.5,I=[Math.abs(z[0].offsetTop),Math.abs(z[0].offsetLeft)],l=[C.scrollRatio.y>10?10:C.scrollRatio.y,C.scrollRatio.x>10?10:C.scrollRatio.x],H="x"===B.dir[0]?I[1]+B.dir[1]*l[1]*f:I[0]+B.dir[1]*l[0]*f,g="x"===B.dir[0]?I[1]+B.dir[1]*parseInt(B.scrollAmount):I[0]+B.dir[1]*parseInt(B.scrollAmount),G="auto"!==B.scrollAmount?g:H,p=y?y:h?c?"mcsLinearOut":"mcsEaseInOut":"mcsLinear",t=h?!0:!1;
return h&&17>r&&(G="x"===B.dir[0]?I[1]:I[0]),ae(E,G.toString(),{dir:B.dir[0],scrollEasing:p,dur:r,onComplete:t}),h?void (B.dir=!1):(clearTimeout(B.step),void (B.step=setTimeout(function(){x()
},r)))
}function F(){clearTimeout(B.step),ap(B,"step"),am(E)
}var C=E.data(a1),D=C.opt,B=C.sequential,z=b("#mCSB_"+C.idx+"_container"),w="stepped"===B.type?!0:!1,k=D.scrollInertia<26?26:D.scrollInertia,A=D.scrollInertia<1?17:D.scrollInertia;
switch(q){case"on":if(B.dir=[v===aX[16]||v===aX[15]||39===v||37===v?"x":"y",v===aX[13]||v===aX[15]||38===v||37===v?-1:1],am(E),a0(v)&&"stepped"===B.type){return
}x(w);
break;
case"off":F(),(w||C.tweenRunning&&B.dir)&&x(!0)
}},aL=function(c){var d=b(this).data(a1).opt,f=[];
return"function"==typeof c&&(c=c()),c instanceof Array?f=c.length>1?[c[0],c[1]]:"x"===d.axis?[null,c[0]]:[c[0],null]:(f[0]=c.y?c.y:c.x||"x"===d.axis?null:c,f[1]=c.x?c.x:c.y||"y"===d.axis?null:c),"function"==typeof f[0]&&(f[0]=f[0]()),"function"==typeof f[1]&&(f[1]=f[1]()),f
},aa=function(C,q){if(null!=C&&"undefined"!=typeof C){var u=b(this),x=u.data(a1),g=x.opt,w=b("#mCSB_"+x.idx+"_container"),D=w.parent(),B=typeof C;
q||(q="x"===g.axis?"x":"y");
var A="x"===q?w.outerWidth(!1):w.outerHeight(!1),z="x"===q?w[0].offsetLeft:w[0].offsetTop,y="x"===q?"left":"top";
switch(B){case"function":return C();
case"object":var v=C.jquery?C:b(C);
if(!v.length){return
}return"x"===q?ac(v)[1]:ac(v)[0];
case"string":case"number":if(a0(C)){return Math.abs(C)
}if(-1!==C.indexOf("%")){return Math.abs(A*parseInt(C)/100)
}if(-1!==C.indexOf("-=")){return Math.abs(z-parseInt(C.split("-=")[1]))
}if(-1!==C.indexOf("+=")){var k=z+parseInt(C.split("+=")[1]);
return k>=0?0:Math.abs(k)
}if(-1!==C.indexOf("px")&&a0(C.split("px")[0])){return Math.abs(C.split("px")[0])
}if("top"===C||"left"===C){return 0
}if("bottom"===C){return Math.abs(D.height()-w.outerHeight(!1))
}if("right"===C){return Math.abs(D.width()-w.outerWidth(!1))
}if("first"===C||"last"===C){var v=w.find(":"+C);
return"x"===q?ac(v)[1]:ac(v)[0]
}return b(C).length?"x"===q?ac(b(C))[1]:ac(b(C))[0]:(w.css(y,C),void aH.update.call(null,u[0]))
}}},aS=function(u){function g(){return clearTimeout(p[0].autoUpdate),0===k.parents("html").length?void (k=null):void (p[0].autoUpdate=setTimeout(function(){return q.advanced.updateOnSelectorChange&&(v.poll.change.n=m(),v.poll.change.n!==v.poll.change.o)?(v.poll.change.o=v.poll.change.n,void d(3)):q.advanced.updateOnContentResize&&(v.poll.size.n=k[0].scrollHeight+k[0].scrollWidth+p[0].offsetHeight+k[0].offsetHeight,v.poll.size.n!==v.poll.size.o)?(v.poll.size.o=v.poll.size.n,void d(1)):!q.advanced.updateOnImageLoad||"auto"===q.advanced.updateOnImageLoad&&"y"===q.axis||(v.poll.img.n=p.find("img").length,v.poll.img.n===v.poll.img.o)?void ((q.advanced.updateOnSelectorChange||q.advanced.updateOnContentResize||q.advanced.updateOnImageLoad)&&g()):(v.poll.img.o=v.poll.img.n,void p.find("img").each(function(){h(this)
}))
},q.advanced.autoUpdateTimeout))
}function h(f){function l(o,n){return function(){return n.apply(o,arguments)
}
}function c(){this.onload=null,b(f).addClass(aX[2]),d(2)
}if(b(f).hasClass(aX[2])){return void d()
}var r=new Image;
r.onload=l(r,c),r.src=f.src
}function m(){q.advanced.updateOnSelectorChange===!0&&(q.advanced.updateOnSelectorChange="*");
var f=0,c=p.find(q.advanced.updateOnSelectorChange);
return q.advanced.updateOnSelectorChange&&c.length>0&&c.each(function(){f+=this.offsetHeight+this.offsetWidth
}),f
}function d(c){clearTimeout(p[0].autoUpdate),aH.update.call(null,k[0],c)
}var k=b(this),v=k.data(a1),q=v.opt,p=b("#mCSB_"+v.idx+"_container");
return u?(clearTimeout(p[0].autoUpdate),void ap(p[0],"autoUpdate")):void g()
},ab=function(d,c,f){return Math.round(d/c)*c-f
},am=function(c){var d=c.data(a1),f=b("#mCSB_"+d.idx+"_container,#mCSB_"+d.idx+"_container_wrapper,#mCSB_"+d.idx+"_dragger_vertical,#mCSB_"+d.idx+"_dragger_horizontal");
f.each(function(){aq.call(this)
})
},ae=function(F,K,L){function O(c){return G&&V.callbacks[c]&&"function"==typeof V.callbacks[c]
}function H(){return[V.callbacks.alwaysTriggerOffsets||X>=C[0]+W,V.callbacks.alwaysTriggerOffsets||-z>=X]
}function N(){var f=[P[0].offsetTop,P[0].offsetLeft],g=[D[0].offsetTop,D[0].offsetLeft],c=[P.outerHeight(!1),P.outerWidth(!1)],d=[R.height(),R.width()];
F[0].mcs={content:P,top:f[0],left:f[1],draggerTop:g[0],draggerLeft:g[1],topPct:Math.round(100*Math.abs(f[0])/(Math.abs(c[0])-d[0])),leftPct:Math.round(100*Math.abs(f[1])/(Math.abs(c[1])-d[1])),direction:L.dir}
}var G=F.data(a1),V=G.opt,U={trigger:"internal",dir:"y",scrollEasing:"mcsEaseOut",drag:!1,dur:V.scrollInertia,overwrite:"all",callbacks:!0,onStart:!0,onUpdate:!0,onComplete:!0},L=b.extend(U,L),E=[L.dur,L.drag?0:L.dur],R=b("#mCSB_"+G.idx),P=b("#mCSB_"+G.idx+"_container"),M=P.parent(),J=V.callbacks.onTotalScrollOffset?aL.call(F,V.callbacks.onTotalScrollOffset):[0,0],Q=V.callbacks.onTotalScrollBackOffset?aL.call(F,V.callbacks.onTotalScrollBackOffset):[0,0];
if(G.trigger=L.trigger,(0!==M.scrollTop()||0!==M.scrollLeft())&&(b(".mCSB_"+G.idx+"_scrollbar").css("visibility","visible"),M.scrollTop(0).scrollLeft(0)),"_resetY"!==K||G.contentReset.y||(O("onOverflowYNone")&&V.callbacks.onOverflowYNone.call(F[0]),G.contentReset.y=1),"_resetX"!==K||G.contentReset.x||(O("onOverflowXNone")&&V.callbacks.onOverflowXNone.call(F[0]),G.contentReset.x=1),"_resetY"!==K&&"_resetX"!==K){switch(!G.contentReset.y&&F[0].mcs||!G.overflowed[0]||(O("onOverflowY")&&V.callbacks.onOverflowY.call(F[0]),G.contentReset.x=null),!G.contentReset.x&&F[0].mcs||!G.overflowed[1]||(O("onOverflowX")&&V.callbacks.onOverflowX.call(F[0]),G.contentReset.x=null),V.snapAmount&&(K=ab(K,V.snapAmount,V.snapOffset)),L.dir){case"x":var D=b("#mCSB_"+G.idx+"_dragger_horizontal"),A="left",X=P[0].offsetLeft,C=[R.width()-P.outerWidth(!1),D.parent().width()-D.width()],q=[K,0===K?0:K/G.scrollRatio.x],W=J[1],z=Q[1],I=W>0?W/G.scrollRatio.x:0,k=z>0?z/G.scrollRatio.x:0;
break;
case"y":var D=b("#mCSB_"+G.idx+"_dragger_vertical"),A="top",X=P[0].offsetTop,C=[R.height()-P.outerHeight(!1),D.parent().height()-D.height()],q=[K,0===K?0:K/G.scrollRatio.y],W=J[0],z=Q[0],I=W>0?W/G.scrollRatio.y:0,k=z>0?z/G.scrollRatio.y:0
}q[1]<0||0===q[0]&&0===q[1]?q=[0,0]:q[1]>=C[1]?q=[C[0],C[1]]:q[0]=-q[0],F[0].mcs||(N(),O("onInit")&&V.callbacks.onInit.call(F[0])),clearTimeout(P[0].onCompleteTimeout),(G.tweenRunning||!(0===X&&q[0]>=0||X===C[0]&&q[0]<=C[0]))&&(aj(D[0],A,Math.round(q[1]),E[1],L.scrollEasing),aj(P[0],A,Math.round(q[0]),E[0],L.scrollEasing,L.overwrite,{onStart:function(){L.callbacks&&L.onStart&&!G.tweenRunning&&(O("onScrollStart")&&(N(),V.callbacks.onScrollStart.call(F[0])),G.tweenRunning=!0,ay(D),G.cbOffsets=H())
},onUpdate:function(){L.callbacks&&L.onUpdate&&O("whileScrolling")&&(N(),V.callbacks.whileScrolling.call(F[0]))
},onComplete:function(){if(L.callbacks&&L.onComplete){"yx"===V.axis&&clearTimeout(P[0].onCompleteTimeout);
var c=P[0].idleTimer||0;
P[0].onCompleteTimeout=setTimeout(function(){O("onScroll")&&(N(),V.callbacks.onScroll.call(F[0])),O("onTotalScroll")&&q[1]>=C[1]-I&&G.cbOffsets[0]&&(N(),V.callbacks.onTotalScroll.call(F[0])),O("onTotalScrollBack")&&q[1]<=k&&G.cbOffsets[1]&&(N(),V.callbacks.onTotalScrollBack.call(F[0])),G.tweenRunning=!1,P[0].idleTimer=0,ay(D,"hide")
},c)
}}}))
}},aj=function(N,B,F,R,G,J,D){function I(){k.stop||(q||H.call(),q=au()-z,C(),q>=k.time&&(k.time=q>k.time?q+M-(q-k.time):q+M-1,k.time<q+1&&(k.time=q+1)),k.time<R?k.id=K(I):L.call())
}function C(){R>0?(k.currVal=A(k.time,T,Q,R,G),y[B]=Math.round(k.currVal)+"px"):y[B]=F+"px",E.call()
}function P(){M=1000/60,k.time=q+M,K=window.requestAnimationFrame?window.requestAnimationFrame:function(c){return C(),setTimeout(c,0.01)
},k.id=K(I)
}function O(){null!=k.id&&(window.requestAnimationFrame?window.cancelAnimationFrame(k.id):clearTimeout(k.id),k.id=null)
}function A(h,f,l,c,m){switch(m){case"linear":case"mcsLinear":return l*h/c+f;
case"mcsLinearOut":return h/=c,h--,l*Math.sqrt(1-h*h)+f;
case"easeInOutSmooth":return h/=c/2,1>h?l/2*h*h+f:(h--,-l/2*(h*(h-2)-1)+f);
case"easeInOutStrong":return h/=c/2,1>h?l/2*Math.pow(2,10*(h-1))+f:(h--,l/2*(-Math.pow(2,-10*h)+2)+f);
case"easeInOut":case"mcsEaseInOut":return h/=c/2,1>h?l/2*h*h*h+f:(h-=2,l/2*(h*h*h+2)+f);
case"easeOutSmooth":return h/=c,h--,-l*(h*h*h*h-1)+f;
case"easeOutStrong":return l*(-Math.pow(2,-10*h/c)+1)+f;
case"easeOut":case"mcsEaseOut":default:var d=(h/=c)*h,g=d*h;
return f+l*(0.499999999999997*g*d+-2.5*d*d+5.5*g+-6.5*d+4*h)
}}N._mTween||(N._mTween={top:{},left:{}});
var M,K,D=D||{},H=D.onStart||function(){},E=D.onUpdate||function(){},L=D.onComplete||function(){},z=au(),q=0,T=N.offsetTop,y=N.style,k=N._mTween[B];
"left"===B&&(T=N.offsetLeft);
var Q=F-T;
k.stop=0,"none"!==J&&O(),P()
},au=function(){return window.performance&&window.performance.now?window.performance.now():window.performance&&window.performance.webkitNow?window.performance.webkitNow():Date.now?Date.now():(new Date).getTime()
},aq=function(){var f=this;
f._mTween||(f._mTween={top:{},left:{}});
for(var d=["top","left"],g=0;
g<d.length;
g++){var c=d[g];
f._mTween[c].id&&(window.requestAnimationFrame?window.cancelAnimationFrame(f._mTween[c].id):clearTimeout(f._mTween[c].id),f._mTween[c].id=null,f._mTween[c].stop=1)
}},ap=function(d,c){try{delete d[c]
}catch(f){d[c]=null
}},e=function(c){return !(c.which&&1!==c.which)
},aB=function(d){var c=d.originalEvent.pointerType;
return !(c&&"touch"!==c&&2!==c)
},a0=function(c){return !isNaN(parseFloat(c))&&isFinite(c)
},ac=function(d){var c=d.parents(".mCSB_container");
return[d.offset().top-c.offset().top,d.offset().left-c.offset().left]
};
b.fn[aN]=function(c){return aH[c]?aH[c].apply(this,Array.prototype.slice.call(arguments,1)):"object"!=typeof c&&c?void b.error("Method "+c+" does not exist"):aH.init.apply(this,arguments)
},b[aN]=function(c){return aH[c]?aH[c].apply(this,Array.prototype.slice.call(arguments,1)):"object"!=typeof c&&c?void b.error("Method "+c+" does not exist"):aH.init.apply(this,arguments)
},b[aN].defaults=aT,window[aN]=!0,b(window).load(function(){b(aO)[aN](),b.extend(b.expr[":"],{mcsInView:b.expr[":"].mcsInView||function(f){var g,c,h=b(f),d=h.parents(".mCSB_container");
if(d.length){return g=d.parent(),c=[d[0].offsetTop,d[0].offsetLeft],c[0]+ac(h)[0]>=0&&c[0]+ac(h)[0]<g.height()-h.outerHeight(!1)&&c[1]+ac(h)[1]>=0&&c[1]+ac(h)[1]<g.width()-h.outerWidth(!1)
}},mcsOverflow:b.expr[":"].mcsOverflow||function(c){var d=b(c).data(a1);
if(d){return d.overflowed[0]||d.overflowed[1]
}}})
})
})
});
/*!
 * JavaScript Cookie v2.0.4
 * https://github.com/js-cookie/js-cookie
 *
 * Copyright 2006, 2015 Klaus Hartl & Fagner Brack
 * Released under the MIT license
 */
(function(b){if(typeof define==="function"&&define.amd){define(b)
}else{if(typeof exports==="object"){module.exports=b()
}else{var d=window.Cookies;
var c=window.Cookies=b();
c.noConflict=function(){window.Cookies=d;
return c
}
}}}(function(){function c(){var g=0;
var d={};
for(;
g<arguments.length;
g++){var e=arguments[g];
for(var f in e){d[f]=e[f]
}}return d
}function b(e){function d(p,o,l){var s;
if(arguments.length>1){l=c({path:"/"},d.defaults,l);
if(typeof l.expires==="number"){var h=new Date();
h.setMilliseconds(h.getMilliseconds()+l.expires*86400000);
l.expires=h
}try{s=JSON.stringify(o);
if(/^[\{\[]/.test(s)){o=s
}}catch(n){}o=encodeURIComponent(String(o));
o=o.replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g,decodeURIComponent);
p=encodeURIComponent(String(p));
p=p.replace(/%(23|24|26|2B|5E|60|7C)/g,decodeURIComponent);
p=p.replace(/[\(\)]/g,escape);
return(document.cookie=[p,"=",o,l.expires&&"; expires="+l.expires.toUTCString(),l.path&&"; path="+l.path,l.domain&&"; domain="+l.domain,l.secure?"; secure":""].join(""))
}if(!p){s={}
}var r=document.cookie?document.cookie.split("; "):[];
var q=/(%[0-9A-Z]{2})+/g;
var m=0;
for(;
m<r.length;
m++){var k=r[m].split("=");
var f=k[0].replace(q,decodeURIComponent);
var g=k.slice(1).join("=");
if(g.charAt(0)==='"'){g=g.slice(1,-1)
}try{g=e&&e(g,f)||g.replace(q,decodeURIComponent);
if(this.json){try{g=JSON.parse(g)
}catch(n){}}if(p===f){s=g;
break
}if(!p){s[f]=g
}}catch(n){}}return s
}d.get=d.set=d;
d.getJSON=function(){return d.apply({json:true},[].slice.call(arguments))
};
d.defaults={};
d.remove=function(g,f){d(g,"",c(f,{expires:-1}))
};
d.withConverter=b;
return d
}return b()
}));
!function(b){var d={},c={mode:"horizontal",slideSelector:"",infiniteLoop:!0,hideControlOnEnd:!1,speed:500,easing:null,slideMargin:0,startSlide:0,randomStart:!1,captions:!1,ticker:!1,tickerHover:!1,adaptiveHeight:!1,adaptiveHeightSpeed:500,video:!1,useCSS:!0,preloadImages:"visible",responsive:!0,slideZIndex:50,wrapperClass:"bx-wrapper",touchEnabled:!0,swipeThreshold:50,oneToOneTouch:!0,preventDefaultSwipeX:!0,preventDefaultSwipeY:!1,pager:!0,pagerType:"full",pagerShortSeparator:" / ",pagerSelector:null,buildPager:null,pagerCustom:null,controls:!0,nextText:"Next",prevText:"Prev",nextSelector:null,prevSelector:null,autoControls:!1,startText:"Start",stopText:"Stop",autoControlsCombine:!1,autoControlsSelector:null,auto:!1,pause:4000,autoStart:!0,autoDirection:"next",autoHover:!1,autoDelay:0,autoSlideForOnePage:!1,minSlides:1,maxSlides:1,moveSlides:0,slideWidth:0,autoReload:!1,onSliderLoad:function(){},onSlideBefore:function(){},onSlideAfter:function(){},onSlideNext:function(){},onSlidePrev:function(){},onSliderResize:function(){}};
b.fn.bxSlider=function(ar){if(0==this.length){return this
}if(this.length>1){return this.each(function(){b(this).bxSlider(ar)
}),this
}var aq={},an=this;
d.el=this;
var aC=b(window).width(),au=b(window).height(),az=function(){function D(g,l,f){var h=(g-f*(l-1))/l;
return Math.floor(h)
}function y(f){for(var g in f){aq.settings[g]=f[g]
}}function o(){aq.settings.slides&&(aq.settings.maxSlides=aq.settings.slides,aq.settings.minSlides=aq.settings.slides,aq.settings.slideWidth=D(aC,aq.settings.slides,aq.settings.slideMargin))
}function E(f){f=f.replace(/([a-zA-Z0-9]+?):/g,'"$1":'),f=f.replace(/'/g,'"');
var g=jQuery.parseJSON(f);
return g
}aq.settings=b.extend({},c,ar),o();
var A=b(window).width();
aC=A;
var z=b(an).attr("data-options");
if(z){var k=z.charAt(z.length-1),L=z.charAt(0);
"{"!=L&&"}"!=k&&(z="{"+z+"}");
var M=E(z);
for(var C in M){aq.settings[C]=M[C]
}o()
}var H=b(an).attr("data-breaks");
if(H&&(aq.settings.breaks=E(H)),aq.settings.breaks){aq.settings.breaks.sort(function(f,g){return f.screen-g.screen
});
for(var n=0;
n<aq.settings.breaks.length;
++n){var r,F=aq.settings.breaks[n],I={},q=F.screen;
n<aq.settings.breaks.length-1?(I=aq.settings.breaks[n+1],r=I.screen,A>=q&&r>A&&y(F)):A>=q&&y(F)
}o()
}aq.settings.slideWidth=parseInt(aq.settings.slideWidth),aq.children=an.children(aq.settings.slideSelector),aq.children.length<aq.settings.minSlides&&(aq.settings.minSlides=aq.children.length),aq.children.length<aq.settings.maxSlides&&(aq.settings.maxSlides=aq.children.length),aq.settings.randomStart&&(aq.settings.startSlide=Math.floor(Math.random()*aq.children.length)),aq.active={index:aq.settings.startSlide},aq.carousel=aq.settings.minSlides>1||aq.settings.maxSlides>1,aq.carousel&&(aq.settings.preloadImages="all"),aq.minThreshold=aq.settings.minSlides*aq.settings.slideWidth+(aq.settings.minSlides-1)*aq.settings.slideMargin,aq.maxThreshold=aq.settings.maxSlides*aq.settings.slideWidth+(aq.settings.maxSlides-1)*aq.settings.slideMargin,aq.working=!1,aq.controls={},aq.interval=null,aq.animProp="vertical"==aq.settings.mode?"top":"left",aq.usingCSS=aq.settings.useCSS&&"fade"!=aq.settings.mode&&function(){var g=document.createElement("div"),h=["WebkitPerspective","MozPerspective","OPerspective","msPerspective"];
for(var f in h){if(void 0!==g.style[h[f]]){return aq.cssPrefix=h[f].replace("Perspective","").toLowerCase(),aq.animProp="-"+aq.cssPrefix+"-transform",!0
}}return !1
}(),"vertical"==aq.settings.mode&&(aq.settings.maxSlides=aq.settings.minSlides),an.data("origStyle",an.attr("style")),an.children(aq.settings.slideSelector).each(function(){b(this).data("origStyle",b(this).attr("style"))
}),aA()
},aA=function(){an.wrap('<div class="'+aq.settings.wrapperClass+'"><div class="bx-viewport"></div></div>'),aq.viewport=an.parent(),aq.loader=b('<div class="bx-loading" />'),aq.viewport.prepend(aq.loader),an.css({width:"horizontal"==aq.settings.mode?100*aq.children.length+215+"%":"auto",position:"relative"}),aq.usingCSS&&aq.settings.easing?an.css("-"+aq.cssPrefix+"-transition-timing-function",aq.settings.easing):aq.settings.easing||(aq.settings.easing="swing");
ay();
aq.viewport.css({width:"100%",overflow:"hidden",position:"relative"}),aq.viewport.parent().css({maxWidth:al()}),aq.settings.pager||aq.viewport.parent().css({margin:"0 auto 0px"}),aq.children.css({"float":"horizontal"==aq.settings.mode?"left":"none",listStyle:"none",position:"relative"}),aq.children.css("width",am()),"horizontal"==aq.settings.mode&&aq.settings.slideMargin>0&&aq.children.css("marginRight",aq.settings.slideMargin),"vertical"==aq.settings.mode&&aq.settings.slideMargin>0&&aq.children.css("marginBottom",aq.settings.slideMargin),"fade"==aq.settings.mode&&(aq.children.css({position:"absolute",zIndex:0,display:"none"}),aq.children.eq(aq.settings.startSlide).css({zIndex:aq.settings.slideZIndex,display:"block"})),aq.controls.el=b('<div class="bx-controls" />'),aq.settings.captions&&K(),aq.active.last=aq.settings.startSlide==aj()-1,aq.settings.video&&an.fitVids();
var f=aq.children.eq(aq.settings.startSlide);
"all"==aq.settings.preloadImages&&(f=aq.children),aq.settings.ticker?aq.settings.pager=!1:(aq.settings.pager&&B(),aq.settings.controls&&af(),aq.settings.auto&&aq.settings.autoControls&&ad(),(aq.settings.controls||aq.settings.autoControls||aq.settings.pager)&&aq.viewport.after(aq.controls.el)),ax(f,aw)
},ax=function(h,f){var g=h.find("img, iframe").length;
if(0==g){return void f()
}var k=0;
h.find("img, iframe").each(function(){b(this).one("load",function(){++k==g&&f()
}).each(function(){this.complete&&b(this).load()
})
})
},aw=function(){if(aq.settings.infiniteLoop&&"fade"!=aq.settings.mode&&!aq.settings.ticker){var h="vertical"==aq.settings.mode?aq.settings.minSlides:aq.settings.maxSlides,f=aq.children.slice(0,h).clone().addClass("bx-clone"),g=aq.children.slice(-h).clone().addClass("bx-clone");
an.append(f).prepend(g)
}aq.loader.remove(),G(),"vertical"==aq.settings.mode&&(aq.settings.adaptiveHeight=!0),aq.viewport.height(ap()),an.redrawSlider(),aq.settings.onSliderLoad(aq.active.index),aq.initialized=!0,aq.settings.responsive&&b(window).bind("resize",J),aq.settings.auto&&aq.settings.autoStart&&(aj()>1||aq.settings.autoSlideForOnePage)&&ab(),aq.settings.ticker&&Z(),aq.settings.pager&&ao(aq.settings.startSlide),aq.settings.controls&&t(),aq.settings.touchEnabled&&!aq.settings.ticker&&U()
},ap=function(){var g=0,f=b();
if("vertical"==aq.settings.mode||aq.settings.adaptiveHeight){if(aq.carousel){var h=1==aq.settings.moveSlides?aq.active.index:aq.active.index*at();
for(f=aq.children.eq(h),i=1;
i<=aq.settings.maxSlides-1;
i++){f=f.add(h+i>=aq.children.length?aq.children.eq(i-1):aq.children.eq(h+i))
}}else{f=aq.children.eq(aq.active.index)
}}else{f=aq.children
}return"vertical"==aq.settings.mode?(f.each(function(){g+=b(this).outerHeight()
}),aq.settings.slideMargin>0&&(g+=aq.settings.slideMargin*(aq.settings.minSlides-1))):g=Math.max.apply(Math,f.map(function(){return b(this).outerHeight(!1)
}).get()),"border-box"==aq.viewport.css("box-sizing")?g+=parseFloat(aq.viewport.css("padding-top"))+parseFloat(aq.viewport.css("padding-bottom"))+parseFloat(aq.viewport.css("border-top-width"))+parseFloat(aq.viewport.css("border-bottom-width")):"padding-box"==aq.viewport.css("box-sizing")&&(g+=parseFloat(aq.viewport.css("padding-top"))+parseFloat(aq.viewport.css("padding-bottom"))),g
},al=function(){var f="100%";
return aq.settings.slideWidth>0&&(f="horizontal"==aq.settings.mode?aq.settings.maxSlides*aq.settings.slideWidth+(aq.settings.maxSlides-1)*aq.settings.slideMargin:aq.settings.slideWidth),f
},am=function(){var f=aq.settings.slideWidth,g=aq.viewport.width();
return 0==aq.settings.slideWidth||aq.settings.slideWidth>g&&!aq.carousel||"vertical"==aq.settings.mode?f=g:aq.settings.maxSlides>1&&"horizontal"==aq.settings.mode&&(g>aq.maxThreshold||g<aq.minThreshold&&(f=(g-aq.settings.slideMargin*(aq.settings.minSlides-1))/aq.settings.minSlides)),f
},ay=function(){var f=1;
if("horizontal"==aq.settings.mode&&aq.settings.slideWidth>0){if(aq.viewport.width()<aq.minThreshold){f=aq.settings.minSlides
}else{if(aq.viewport.width()>aq.maxThreshold){f=aq.settings.maxSlides
}else{var g=aq.children.first().width()+aq.settings.slideMargin;
f=Math.floor((aq.viewport.width()+aq.settings.slideMargin)/g)
}}}else{"vertical"==aq.settings.mode&&(f=aq.settings.minSlides)
}return f
},aj=function(){var g=0;
if(aq.settings.moveSlides>0){if(aq.settings.infiniteLoop){g=Math.ceil(aq.children.length/at())
}else{for(var h=0,f=0;
h<aq.children.length;
){++g,h=f+ay(),f+=aq.settings.moveSlides<=ay()?aq.settings.moveSlides:ay()
}}}else{g=Math.ceil(aq.children.length/ay())
}return g
},at=function(){return aq.settings.moveSlides>0&&aq.settings.moveSlides<=ay()?aq.settings.moveSlides:ay()
},G=function(){if(aq.children.length>aq.settings.maxSlides&&aq.active.last&&!aq.settings.infiniteLoop){if("horizontal"==aq.settings.mode){var g=aq.children.last(),h=g.position();
aB(-(h.left-(aq.viewport.width()-g.outerWidth())),"reset",0)
}else{if("vertical"==aq.settings.mode){var f=aq.children.length-aq.settings.minSlides,h=aq.children.eq(f).position();
aB(-h.top,"reset",0)
}}}else{var h=aq.children.eq(aq.active.index*at()).position();
aq.active.index==aj()-1&&(aq.active.last=!0),void 0!=h&&("horizontal"==aq.settings.mode?aB(-h.left,"reset",0):"vertical"==aq.settings.mode&&aB(-h.top,"reset",0))
}},aB=function(h,l,g,k){if(aq.usingCSS){var m="vertical"==aq.settings.mode?"translate3d(0, "+h+"px, 0)":"translate3d("+h+"px, 0, 0)";
an.css("-"+aq.cssPrefix+"-transition-duration",g/1000+"s"),"slide"==l?(an.css(aq.animProp,m),an.bind("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd",function(){an.unbind("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd"),ag()
})):"reset"==l?an.css(aq.animProp,m):"ticker"==l&&(an.css("-"+aq.cssPrefix+"-transition-timing-function","linear"),an.css(aq.animProp,m),an.bind("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd",function(){an.unbind("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd"),aB(k.resetValue,"reset",0),ac()
}))
}else{var f={};
f[aq.animProp]=h,"slide"==l?an.animate(f,g,aq.settings.easing,function(){ag()
}):"reset"==l?an.css(aq.animProp,h):"ticker"==l&&an.animate(f,speed,"linear",function(){aB(k.resetValue,"reset",0),ac()
})
}},ak=function(){for(var h="",f=aj(),g=0;
f>g;
g++){var k="";
aq.settings.buildPager&&b.isFunction(aq.settings.buildPager)?(k=aq.settings.buildPager(g),aq.pagerEl.addClass("bx-custom-pager")):(k=g+1,aq.pagerEl.addClass("bx-default-pager")),h+='<div class="bx-pager-item"><a href="" data-slide-index="'+g+'" class="bx-pager-link">'+k+"</a></div>"
}aq.pagerEl.html(h)
},B=function(){aq.settings.pagerCustom?aq.pagerEl=b(aq.settings.pagerCustom):(aq.pagerEl=b('<div class="bx-pager" />'),aq.settings.pagerSelector?b(aq.settings.pagerSelector).html(aq.pagerEl):aq.controls.el.addClass("bx-has-pager").append(aq.pagerEl),ak()),aq.pagerEl.on("click","a",aa)
},af=function(){aq.controls.next=b('<a class="bx-next" href="">'+aq.settings.nextText+"</a>"),aq.controls.prev=b('<a class="bx-prev" href="">'+aq.settings.prevText+"</a>"),aq.controls.next.bind("click",ah),aq.controls.prev.bind("click",av),aq.settings.nextSelector&&b(aq.settings.nextSelector).append(aq.controls.next),aq.settings.prevSelector&&b(aq.settings.prevSelector).append(aq.controls.prev),aq.settings.nextSelector||aq.settings.prevSelector||(aq.controls.directionEl=b('<div class="bx-controls-direction" />'),aq.controls.directionEl.append(aq.controls.prev).append(aq.controls.next),aq.controls.el.addClass("bx-has-controls-direction").append(aq.controls.directionEl))
},ad=function(){aq.controls.start=b('<div class="bx-controls-auto-item"><a class="bx-start" href="">'+aq.settings.startText+"</a></div>"),aq.controls.stop=b('<div class="bx-controls-auto-item"><a class="bx-stop" href="">'+aq.settings.stopText+"</a></div>"),aq.controls.autoEl=b('<div class="bx-controls-auto" />'),aq.controls.autoEl.on("click",".bx-start",ai),aq.controls.autoEl.on("click",".bx-stop",V),aq.settings.autoControlsCombine?aq.controls.autoEl.append(aq.controls.start):aq.controls.autoEl.append(aq.controls.start).append(aq.controls.stop),aq.settings.autoControlsSelector?b(aq.settings.autoControlsSelector).html(aq.controls.autoEl):aq.controls.el.addClass("bx-has-controls-auto").append(aq.controls.autoEl),ae(aq.settings.autoStart?"stop":"start")
},K=function(){aq.children.each(function(){var f=b(this).find("img:first").attr("title");
void 0!=f&&(""+f).length&&b(this).append('<div class="bx-caption"><span>'+f+"</span></div>")
})
},ah=function(f){aq.settings.auto&&an.stopAuto(),an.goToNextSlide(),f.preventDefault()
},av=function(f){aq.settings.auto&&an.stopAuto(),an.goToPrevSlide(),f.preventDefault()
},ai=function(f){an.startAuto(),f.preventDefault()
},V=function(f){an.stopAuto(),f.preventDefault()
},aa=function(h){aq.settings.auto&&an.stopAuto();
var f=b(h.currentTarget);
if(void 0!==f.attr("data-slide-index")){var g=parseInt(f.attr("data-slide-index"));
g!=aq.active.index&&an.goToSlide(g),h.preventDefault()
}},ao=function(g){var f=aq.children.length;
return"short"==aq.settings.pagerType?(aq.settings.maxSlides>1&&(f=Math.ceil(aq.children.length/aq.settings.maxSlides)),void aq.pagerEl.html(g+1+aq.settings.pagerShortSeparator+f)):(aq.pagerEl.find("a").removeClass("active"),void aq.pagerEl.each(function(h,k){b(k).find("a").eq(g).addClass("active")
}))
},ag=function(){if(aq.settings.infiniteLoop){var f="";
0==aq.active.index?f=aq.children.eq(0).position():aq.active.index==aj()-1&&aq.carousel?f=aq.children.eq((aj()-1)*at()).position():aq.active.index==aq.children.length-1&&(f=aq.children.eq(aq.children.length-1).position()),f&&("horizontal"==aq.settings.mode?aB(-f.left,"reset",0):"vertical"==aq.settings.mode&&aB(-f.top,"reset",0))
}aq.working=!1,aq.settings.onSlideAfter(aq.children.eq(aq.active.index),aq.oldIndex,aq.active.index)
},ae=function(f){aq.settings.autoControlsCombine?aq.controls.autoEl.html(aq.controls[f]):(aq.controls.autoEl.find("a").removeClass("active"),aq.controls.autoEl.find("a:not(.bx-"+f+")").addClass("active"))
},t=function(){1==aj()?(aq.controls.prev.addClass("disabled"),aq.controls.next.addClass("disabled")):!aq.settings.infiniteLoop&&aq.settings.hideControlOnEnd&&(0==aq.active.index?(aq.controls.prev.addClass("disabled"),aq.controls.next.removeClass("disabled")):aq.active.index==aj()-1?(aq.controls.next.addClass("disabled"),aq.controls.prev.removeClass("disabled")):(aq.controls.prev.removeClass("disabled"),aq.controls.next.removeClass("disabled")))
},ab=function(){if(aq.settings.autoDelay>0){setTimeout(an.startAuto,aq.settings.autoDelay)
}else{an.startAuto()
}aq.settings.autoHover&&an.hover(function(){aq.interval&&(an.stopAuto(!0),aq.autoPaused=!0)
},function(){aq.autoPaused&&(an.startAuto(!0),aq.autoPaused=null)
})
},Z=function(){var g=0;
if("next"==aq.settings.autoDirection){an.append(aq.children.clone().addClass("bx-clone"))
}else{an.prepend(aq.children.clone().addClass("bx-clone"));
var f=aq.children.first().position();
g="horizontal"==aq.settings.mode?-f.left:-f.top
}aB(g,"reset",0),aq.settings.pager=!1,aq.settings.controls=!1,aq.settings.autoControls=!1,aq.settings.tickerHover&&!aq.usingCSS&&aq.viewport.hover(function(){an.stop()
},function(){var l=0;
aq.children.each(function(){l+="horizontal"==aq.settings.mode?b(this).outerWidth(!0):b(this).outerHeight(!0)
});
var h=aq.settings.speed/l,k="horizontal"==aq.settings.mode?"left":"top",m=h*(l-Math.abs(parseInt(an.css(k))));
ac(m)
}),ac()
},ac=function(h){speed=h?h:aq.settings.speed;
var l={left:0,top:0},g={left:0,top:0};
"next"==aq.settings.autoDirection?l=an.find(".bx-clone").first().position():g=aq.children.first().position();
var k="horizontal"==aq.settings.mode?-l.left:-l.top,m="horizontal"==aq.settings.mode?-g.left:-g.top,f={resetValue:m};
aB(k,"ticker",speed,f)
},U=function(){aq.touch={start:{x:0,y:0},end:{x:0,y:0}},aq.viewport.bind("touchstart",Q)
},Q=function(f){if(aq.working){f.preventDefault()
}else{aq.touch.originalPos=an.position();
var g=f.originalEvent;
aq.touch.start.x=g.changedTouches[0].pageX,aq.touch.start.y=g.changedTouches[0].pageY,aq.viewport.bind("touchmove",s),aq.viewport.bind("touchend",e)
}},s=function(g){var l=g.originalEvent,f=Math.abs(l.changedTouches[0].pageX-aq.touch.start.x),h=Math.abs(l.changedTouches[0].pageY-aq.touch.start.y);
if(3*f>h&&aq.settings.preventDefaultSwipeX?g.preventDefault():3*h>f&&aq.settings.preventDefaultSwipeY&&g.preventDefault(),"fade"!=aq.settings.mode&&aq.settings.oneToOneTouch){var m=0;
if("horizontal"==aq.settings.mode){var k=l.changedTouches[0].pageX-aq.touch.start.x;
m=aq.touch.originalPos.left+k
}else{var k=l.changedTouches[0].pageY-aq.touch.start.y;
m=aq.touch.originalPos.top+k
}aB(m,"reset",0)
}},e=function(g){aq.viewport.unbind("touchmove",s);
var k=g.originalEvent,f=0;
if(aq.touch.end.x=k.changedTouches[0].pageX,aq.touch.end.y=k.changedTouches[0].pageY,"fade"==aq.settings.mode){var h=Math.abs(aq.touch.start.x-aq.touch.end.x);
h>=aq.settings.swipeThreshold&&(aq.touch.start.x>aq.touch.end.x?an.goToNextSlide():an.goToPrevSlide(),an.stopAuto())
}else{var h=0;
"horizontal"==aq.settings.mode?(h=aq.touch.end.x-aq.touch.start.x,f=aq.touch.originalPos.left):(h=aq.touch.end.y-aq.touch.start.y,f=aq.touch.originalPos.top),!aq.settings.infiniteLoop&&(0==aq.active.index&&h>0||aq.active.last&&0>h)?aB(f,"reset",200):Math.abs(h)>=aq.settings.swipeThreshold?(0>h?an.goToNextSlide():an.goToPrevSlide(),an.stopAuto()):aB(f,"reset",200)
}aq.viewport.unbind("touchend",e)
},J=function(){if(aq.initialized){var g=b(window).width(),f=b(window).height();
(aC!=g||au!=f)&&(aC=g,au=f,an.redrawSlider(),aq.settings.onSliderResize.call(an,aq.active.index))
}};
return an.goToSlide=function(o,k){if(!aq.working&&aq.active.index!=o){if(aq.working=!0,aq.oldIndex=aq.active.index,aq.active.index=0>o?aj()-1:o>=aj()?0:o,aq.settings.onSlideBefore(aq.children.eq(aq.active.index),aq.oldIndex,aq.active.index),"next"==k?aq.settings.onSlideNext(aq.children.eq(aq.active.index),aq.oldIndex,aq.active.index):"prev"==k&&aq.settings.onSlidePrev(aq.children.eq(aq.active.index),aq.oldIndex,aq.active.index),aq.active.last=aq.active.index>=aj()-1,aq.settings.pager&&ao(aq.active.index),aq.settings.controls&&t(),"fade"==aq.settings.mode){aq.settings.adaptiveHeight&&aq.viewport.height()!=ap()&&aq.viewport.animate({height:ap()},aq.settings.adaptiveHeightSpeed),aq.children.filter(":visible").fadeOut(aq.settings.speed).css({zIndex:0}),aq.children.eq(aq.active.index).css("zIndex",aq.settings.slideZIndex+1).fadeIn(aq.settings.speed,function(){b(this).css("zIndex",aq.settings.slideZIndex),ag()
})
}else{aq.settings.adaptiveHeight&&aq.viewport.height()!=ap()&&aq.viewport.animate({height:ap()},aq.settings.adaptiveHeightSpeed);
var u=0,f={left:0,top:0};
if(!aq.settings.infiniteLoop&&aq.carousel&&aq.active.last){if("horizontal"==aq.settings.mode){var r=aq.children.eq(aq.children.length-1);
f=r.position(),u=aq.viewport.width()-r.outerWidth()
}else{var h=aq.children.length-aq.settings.minSlides;
f=aq.children.eq(h).position()
}}else{if(aq.carousel&&aq.active.last&&"prev"==k){var p=1==aq.settings.moveSlides?aq.settings.maxSlides-at():(aj()-1)*at()-(aq.children.length-aq.settings.maxSlides),r=an.children(".bx-clone").eq(p);
f=r.position()
}else{if("next"==k&&0==aq.active.index){f=an.find("> .bx-clone").eq(aq.settings.maxSlides).position(),aq.active.last=!1
}else{if(o>=0){var q=o*at();
f=aq.children.eq(q).position()
}}}}if("undefined"!=typeof f){var m="horizontal"==aq.settings.mode?-(f.left-u):-f.top;
aB(m,"slide",aq.settings.speed)
}}}},an.goToNextSlide=function(){if(aq.settings.infiniteLoop||!aq.active.last){var f=parseInt(aq.active.index)+1;
an.goToSlide(f,"next")
}},an.goToPrevSlide=function(){if(aq.settings.infiniteLoop||0!=aq.active.index){var f=parseInt(aq.active.index)-1;
an.goToSlide(f,"prev")
}},an.startAuto=function(f){aq.interval||(aq.interval=setInterval(function(){"next"==aq.settings.autoDirection?an.goToNextSlide():an.goToPrevSlide()
},aq.settings.pause),aq.settings.autoControls&&1!=f&&ae("stop"))
},an.stopAuto=function(f){aq.interval&&(clearInterval(aq.interval),aq.interval=null,aq.settings.autoControls&&1!=f&&ae("start"))
},an.getCurrentSlide=function(){return aq.active.index
},an.getCurrentSlideElement=function(){return aq.children.eq(aq.active.index)
},an.getSlideCount=function(){return aq.children.length
},an.redrawSlider=function(){aq.children.add(an.find(".bx-clone")).width(am()),aq.viewport.css("height",ap()),aq.settings.ticker||G(),aq.active.last&&(aq.active.index=aj()-1),aq.active.index>=aj()&&(aq.active.last=!0),aq.settings.pager&&!aq.settings.pagerCustom&&(ak(),ao(aq.active.index))
},an.destroySlider=function(){aq.initialized&&(aq.initialized=!1,b(".bx-clone",this).remove(),aq.children.each(function(){void 0!=b(this).data("origStyle")?b(this).attr("style",b(this).data("origStyle")):b(this).removeAttr("style")
}),void 0!=b(this).data("origStyle")?this.attr("style",b(this).data("origStyle")):b(this).removeAttr("style"),b(this).unwrap().unwrap(),aq.controls.el&&aq.controls.el.remove(),aq.controls.next&&aq.controls.next.remove(),aq.controls.prev&&aq.controls.prev.remove(),aq.pagerEl&&aq.settings.controls&&aq.pagerEl.remove(),b(".bx-caption",this).remove(),aq.controls.autoEl&&aq.controls.autoEl.remove(),clearInterval(aq.interval),aq.settings.responsive&&b(window).unbind("resize",J))
},an.reloadSlider=function(f){void 0!=f&&(ar=f),an.destroySlider(),az()
},b(window).resize(function(){aq.settings.autoReload&&an.reloadSlider()
}),az(),this
},b('[data-call="bxslider"]').each(function(){b(this).bxSlider()
})
}(jQuery);
!function(b){"function"==typeof define&&define.amd?define(["jquery"],b):"undefined"!=typeof module&&module.exports?module.exports=b(require("jquery")):b(jQuery)
}(function(d){var h=-1,k=-1,c=function(e){return parseFloat(e)||0
},b=function(q){var s=1,m=d(q),t=null,p=[];
return m.each(function(){var r=d(this),n=r.offset().top-c(r.css("margin-top")),o=p.length>0?p[p.length-1]:null;
null===o?p.push(r):Math.floor(Math.abs(t-n))<=s?p[p.length-1]=o.add(r):p.push(r),t=n
}),p
},l=function(m){var n={byRow:!0,property:"height",target:null,remove:!1};
return"object"==typeof m?d.extend(n,m):("boolean"==typeof m?n.byRow=m:"remove"===m&&(n.remove=!0),n)
},g=d.fn.matchHeight=function(n){var p=l(n);
if(p.remove){var m=this;
return this.css(p.property,""),d.each(g._groups,function(o,q){q.elements=q.elements.not(m)
}),this
}return this.length<=1&&!p.target?this:(g._groups.push({elements:this,options:p}),g._apply(this,p),this)
};
g.version="0.7.0",g._groups=[],g._throttle=80,g._maintainScroll=!1,g._beforeUpdate=null,g._afterUpdate=null,g._rows=b,g._parse=c,g._parseOptions=l,g._apply=function(t,v){var q=l(v),n=d(t),m=[n],w=d(window).scrollTop(),r=d("html").outerHeight(!0),u=n.parents().filter(":hidden");
return u.each(function(){var o=d(this);
o.data("style-cache",o.attr("style"))
}),u.css("display","block"),q.byRow&&!q.target&&(n.each(function(){var p=d(this),s=p.css("display");
"inline-block"!==s&&"flex"!==s&&"inline-flex"!==s&&(s="block"),p.data("style-cache",p.attr("style")),p.css({display:s,"padding-top":"0","padding-bottom":"0","margin-top":"0","margin-bottom":"0","border-top-width":"0","border-bottom-width":"0",height:"100px",overflow:"hidden"})
}),m=b(n),n.each(function(){var o=d(this);
o.attr("style",o.data("style-cache")||"")
})),d.each(m,function(s,x){var p=d(x),y=0;
if(q.target){y=q.target.outerHeight(!1)
}else{if(q.byRow&&p.length<=1){return void p.css(q.property,"")
}p.each(function(){var B=d(this),C=B.attr("style"),A=B.css("display");
"inline-block"!==A&&"flex"!==A&&"inline-flex"!==A&&(A="block");
var z={display:A};
z[q.property]="",B.css(z),B.outerHeight(!1)>y&&(y=B.outerHeight(!1)),C?B.attr("style",C):B.css("display","")
})
}p.each(function(){var z=d(this),A=0;
q.target&&z.is(q.target)||("border-box"!==z.css("box-sizing")&&(A+=c(z.css("border-top-width"))+c(z.css("border-bottom-width")),A+=c(z.css("padding-top"))+c(z.css("padding-bottom"))),z.css(q.property,y-A+"px"))
})
}),u.each(function(){var o=d(this);
o.attr("style",o.data("style-cache")||null)
}),g._maintainScroll&&d(window).scrollTop(w/r*d("html").outerHeight(!0)),this
},g._applyDataApi=function(){var m={};
d("[data-match-height], [data-mh]").each(function(){var n=d(this),e=n.attr("data-mh")||n.attr("data-match-height");
e in m?m[e]=m[e].add(n):m[e]=n
}),d.each(m,function(){this.matchHeight(!0)
})
};
var f=function(m){g._beforeUpdate&&g._beforeUpdate(m,g._groups),d.each(g._groups,function(){g._apply(this.elements,this.options)
}),g._afterUpdate&&g._afterUpdate(m,g._groups)
};
g._update=function(m,e){if(e&&"resize"===e.type){var o=d(window).width();
if(o===h){return
}h=o
}m?-1===k&&(k=setTimeout(function(){f(e),k=-1
},g._throttle)):f(e)
},d(g._applyDataApi),d(window).bind("load",function(e){g._update(!1,e)
}),d(window).bind("resize orientationchange",function(e){g._update(!0,e)
})
});
/*!
 * jQuery Cookie Plugin v1.4.1
 * https://github.com/carhartl/jquery-cookie
 *
 * Copyright 2013 Klaus Hartl
 * Released under the MIT license
 */
(function(b){if(typeof define==="function"&&define.amd){define(["jquery"],b)
}else{if(typeof exports==="object"){b(require("jquery"))
}else{b(jQuery)
}}}(function(g){var b=/\+/g;
function e(l){return c.raw?l:encodeURIComponent(l)
}function h(l){return c.raw?l:decodeURIComponent(l)
}function k(l){return e(c.json?JSON.stringify(l):String(l))
}function d(l){if(l.indexOf('"')===0){l=l.slice(1,-1).replace(/\\"/g,'"').replace(/\\\\/g,"\\")
}try{l=decodeURIComponent(l.replace(b," "));
return c.json?JSON.parse(l):l
}catch(m){}}function f(m,l){var n=c.raw?m:d(m);
return g.isFunction(l)?l(n):n
}var c=g.cookie=function(s,r,x){if(r!==undefined&&!g.isFunction(r)){x=g.extend({},c.defaults,x);
if(typeof x.expires==="number"){var u=x.expires,w=x.expires=new Date();
w.setTime(+w+u*86400000)
}return(document.cookie=[e(s),"=",k(r),x.expires?"; expires="+x.expires.toUTCString():"",x.path?"; path="+x.path:"",x.domain?"; domain="+x.domain:"",x.secure?"; secure":""].join(""))
}var y=s?undefined:{};
var v=document.cookie?document.cookie.split("; "):[];
for(var q=0,o=v.length;
q<o;
q++){var p=v[q].split("=");
var m=h(p.shift());
var n=p.join("=");
if(s&&s===m){y=f(n,r);
break
}if(!s&&(n=f(n))!==undefined){y[m]=n
}}return y
};
c.defaults={};
g.removeCookie=function(m,l){if(g.cookie(m)===undefined){return false
}g.cookie(m,"",g.extend({},l,{expires:-1}));
return !g.cookie(m)
}
}));
$(window).on("resize orientationchange",function(){$(".pws_card_category .pws_cards_list .item").matchHeight({property:"min-height"});
$(".pws_card_category .pws_cards_list .item .item_in").matchHeight()
});
$(document).ready(function(){$(".campaign-position:has(.linestripCE)").css("padding-top","20px");
var u=$(".sidebar-switch a");
$(document).off("click",".scroll-icon");
$(document).on("click ",".scroll-icon",function(){var y=$(".pws_menu .submenu:visible").height()||0;
$("html, body").animate({scrollTop:$($(this).attr("href")).offset().top-$("#header").outerHeight()-y+"px"},{duration:500,easing:"swing"});
return false
});
function g(y){$(y).toggleClass("closed");
$(y).parent().find(".info_content").slideToggle()
}$(document).off("click",".btn_more_info");
$(document).on("click ",".btn_more_info",function(){if($(this).hasClass("autoclose")&&($(this).hasClass("closed"))){$(".btn_more_info.autoclose").each(function(){if(!$(this).hasClass("closed")){g(this)
}})
}g(this);
if($(this).parent().find(".pws_gallery").length){$(this).parent().find(".pws_gallery").each(function(){pwsGallery.reloadSlide($(this).attr("id"))
})
}});
$(".call_num").click(function(){if($(this).find("a").length==0){var y=$(this).data("tel");
if($(".isMobile").is(":visible")||$(".isTablet").is(":visible")){window.location.href="tel:"+y
}}});
$(document).off("click",".pws .btn.btn_navigation_alt.disabled");
$(document).on("click ",".pws .btn.btn_navigation_alt.disabled",function(y){y.preventDefault()
});
$(document).off("click",".txt_chat_label");
$(document).on("click ",".txt_chat_label",function(){$(".chat-window").removeClass("hidden",function(){})
});
$(document).on("keyup",".chat_input input",d);
$(document).on("keydown",".chat_input input",d);
function d(){var A=$(this).val().length;
var z=$(".chat_start .btn.btn_navigation_alt");
var y=z.hasClass("disabled");
if(A>3){if(y){z.removeClass("disabled")
}}else{if(A<=3){if(!y){z.addClass("disabled")
}}}}$(".youtube-player").each(function(y,z){var A=$(this);
var B=A.data("id");
A.append(c(B));
A.click(function(C){o(B,A)
})
});
function c(z){var y=z.indexOf("?list");
if(y>=0){z=z.slice(0,y)
}return'<img class="youtube-thumb" src="//i.ytimg.com/vi/'+z+'/hqdefault.jpg"><div class="play-button"></div>'
}function o(A,z){var y=document.createElement("iframe");
y.setAttribute("src","//www.youtube.com/embed/"+A+"?autoplay=1&wmode=transparent&rel=0");
y.setAttribute("frameborder","0");
y.setAttribute("id","youtube-iframe");
z.append(y)
}if(!$("body > .modal").length){$(".modal").appendTo("body");
$(document).not(".overlay").on("shown.bs.modal hidden.bs.modal",function(y){$("#container").toggleClass("blurred")
});
$(".overlay").on("show.bs.modal",function(){$("body").addClass("overlay_open")
});
$(".overlay").on("hidden.bs.modal",function(y){$("body").removeClass("overlay_open")
});
$(".overlay.nobg").modal({backdrop:false,show:false});
$(".overlay.dark").modal({backdrop:true,show:false})
}$(document).off("click",".pws_share_btn a, .closer, a.pws_share_btn");
$(document).on("click ",".pws_share_btn a, .closer, a.pws_share_btn",function(){var y;
if($(this).closest(".no_bg").length==0){y=$(".pws_share_wrapper.alt .pws_share_container")
}else{y=$(this).closest(".pws_breadcrumb_container").find(".pws_share_container")
}y.slideToggle("400",function(){if(y.is(":visible")==true){if(($(".share_in li a.facebook .count").text()=="")){$.get("https://graph.facebook.com/?id="+window.location.href,function(B){if(B.share&&B.share.share_count){$(".share_in li a.facebook .count").html(B.share.share_count)
}})
}if($(".share_in li a.linkedin .count").text()==""){myCallback=function(B){$(".share_in li a.linkedin .count").html(B.count)
};
var z="https://www.linkedin.com/countserv/count/share?url="+window.location.href+"&format=jsonp&callback=myCallback";
$.getScript(z)
}if($(".share_in li a.googleplus .count").text()==""){var A={method:"pos.plusones.get",id:window.location.href,params:{nolog:true,id:window.location.href,source:"widget",userId:"@viewer",groupId:"@self"},jsonrpc:"2.0",key:"AIzaSyAvje-dXMqcspHLFOPAVJbWELTOSL_zt5w",apiVersion:"v1"};
$.ajax({type:"POST",url:"https://clients6.google.com/rpc",processData:true,contentType:"application/json",data:JSON.stringify(A),success:function(B){$(".share_in li a.googleplus .count").text(B.result.metadata.globalCounts.count)
}})
}}})
});
var p={b:$("body"),h:$("#header"),s:$("#sidebar"),show:function(){$(".pws_cookie_bar").show();
var y=$(".pws_cookie_bar").outerHeight()||0;
this.b.attr("style","padding-top: "+parseInt(y)+"px !important");
this.h.attr("style","top: "+parseInt(y)+"px !important");
$("#sidebar").attr("style","top: "+($(".sidebar-switch").height()+y)+"px !important")
},hide:function(){this.b.attr("style","padding-top 0px");
this.h.attr("style","top 0px");
$("#sidebar").attr("style","top "+$(".sidebar-switch").height());
$(".pws_cookie_bar").hide();
if($("#sidebar").hasClass("expanded")){$("#sidebar").show()
}},close:function(){this.hide();
this.init();
Cookies.set("claw_uci_enable","YU",{expires:365,domain:this.getDomain()});
try{window.dataLayer.user.cookieLaw="YU"
}catch(y){console.log(y)
}},init:function(){if($(".pws_cookie_bar").is(":hidden")){this.hide()
}else{this.show()
}},getDomain:function(){var y=".unicredit.it";
if(location.href.indexOf("usinet.it")>-1){y=".usinet.it"
}return y
}};
var e=Cookies.get("claw_uci_enable");
if(typeof editCookieLaw!=="undefined"&&editCookieLaw==true){p.show()
}else{if(e==undefined||e!="YA"&&e!="YU"&&e!="N"){var b=parseInt(Cookies.get("claw_uci_info"),10);
if(!b){b=1;
Cookies.set("claw_uci_info",b,{expires:365,domain:p.getDomain()});
p.show()
}else{if(b==1){var l=false;
if(document.referrer.indexOf(".unicredit.it")!=-1||document.referrer.indexOf(document.location.hostname.toLowerCase())){l=true
}if(l){Cookies.set("claw_uci_enable","YA",{expires:365,domain:p.getDomain()});
Cookies.remove("claw_uci_info")
}else{b=2;
Cookies.set("claw_uci_info",b,{expires:365,domain:p.getDomain()});
p.show()
}}else{Cookies.set("claw_uci_enable","YA",{expires:365,domain:p.getDomain()});
Cookies.remove("claw_uci_info")
}}}}$(document).off("click","#cookieAccepted");
$(document).on("click ","#cookieAccepted",function(){p.close()
});
$(window).on("load resize",function(){p.init()
});
var t=function(y){var z=$(y);
z.find(".submenu").toggle("fast");
$("body").toggleClass("submenu_open","fast");
z.toggleClass("hover")
};
var r=function(){var A=$(".pws_menu_fl > li.header-search");
A.find(".submenu").toggle();
A.toggleClass("hover");
if($("#sidebar").hasClass("expanded")){$(".sidebar-switch a").click()
}var y=$(".black_opacity");
if(y.length==0){$("#content").append('<div class="black_opacity"></div>')
}else{y.remove()
}var z=$("#input_search_menu");
z.focus()
};
$("#input_search_menu").on("keydown",function(z){if(!z){z=event
}var y=Number(this.value.length);
if((z.keyCode<112||z.keyCode>123)&&z.keyCode!=9&&z.keyCode!=20&&z.keyCode!=16&&z.keyCode!=17&&z.keyCode!=18&&z.keyCode!=91&&z.keyCode!=92&&z.keyCode!=27&&z.keyCode!=37&&z.keyCode!=38&&z.keyCode!=39&&z.keyCode!=40&&z.keyCode!=13&&z.keyCode!=45){y=Number(this.value.length)+1
}if(z.keyCode=="8"||z.keyCode=="46"){y=Number(this.value.length)-1
}if(y>0){this.parentNode.getElementsByTagName("label")[0].style.zIndex="-1"
}else{this.parentNode.getElementsByTagName("label")[0].style.zIndex="0"
}});
if($("#input_search_menu").val()!=""){$("#input_search_menu").next().css("z-index","-1")
}$(document).off("click",".pws_menu_fl.pws_menu_left > li > a");
$(document).on("click ",".pws_menu_fl.pws_menu_left > li > a",function(){var y=$(this).parent();
if(y.hasClass("with_submenu")){t(y)
}if(y.hasClass("header-search")){r()
}if(!y.hasClass("with_submenu")&&!y.hasClass("header-search")&&!y.hasClass("misc-phone")){$(".pws_menu_fl > li").removeClass("active");
y.toggleClass("active")
}});
$(document).on("click ",function(y){if($(".pws_menu_fl > li.header-search").hasClass("hover")){if($(y.target).is(".black_opacity")||$(y.target).is(".hamburger")){r()
}}});
$("body").removeClass("submenu_open");
if($(".pws_menu_fl .with_submenu a").hasClass("current")){var v=$(".pws_menu_fl .with_submenu a.current").parents(".with_submenu");
t(v)
}if($(".autocomplete-suggestions").length){$(".autocomplete-suggestions").remove()
}$("#input_search_menu").autocomplete({serviceUrl:"/bin/gimb/servlet/gsasuggest",minChars:3,transformResult:function(A){var y=$("<textarea />").html(A).text();
var z=jQuery.parseJSON(y);
return{suggestions:jQuery.map(z.results,function(B){return{value:B.name,data:B.name}
})}
},onSelect:function(y){if($("body").hasClass("pri_to_pub")){$.ajax({type:"GET",url:"/it/search-results.prv.html?_charset_=UTF-8&pws_menu_search_input="+$("#input_search_menu").val(),success:function(z){$("body").addClass("nopadding");
$("#injectedContent").html(z)
}})
}else{$("#input_search_menu").parent().submit()
}}});
$(document).off("click",".search_sidebar");
$(document).on("click ",".search_sidebar",function(){$(".phone_container, .redbar_links").fadeOut("3000",function(){$(".search_close, .search_container").fadeIn("fast")
})
});
$(document).off("click",".search_close");
$(document).on("click ",".search_close",function(){$(".search_close, .search_container").fadeOut("fast",function(){$(".phone_container, .redbar_links").fadeIn("3000")
})
});
$("#sidebar").mCustomScrollbar({autoHideScrollbar:true,scrollInertia:1000,alwaysShowScrollbar:0,mouseWheelPixels:250,scrollInertia:0,advanced:{updateOnContentResize:true}});
$(document).off("click",".sidebar-switch a");
$(document).on("click",".sidebar-switch a",function(A){if($(".isMobile").is(":visible")||(($(".isTablet").is(":visible")&&$(".isTabletPortrait").is(":visible")))||($("body").hasClass("pri_to_pub")&&$(window).width()<1291)){var y=0;
if(!$("#sidebar").hasClass("expanded")){y=500
}setTimeout(function(){if($("body").hasClass("pri_to_pub")){$(".redbar_links_container").style("display","list-item","important")
}if(!y){$(".redbar_links_container").slideUp()
}else{$(".redbar_links_container").slideDown()
}},y)
}var z=$(".pws_side_txt, .pws_side_txt_exp");
if($(".isMobile").is(":visible")){$("#sidebar").toggleClass("expanded");
z.toggle();
$("#sidebar").toggle()
}else{$("#sidebar").toggleClass("expanded","800");
z.fadeToggle("800")
}});
$(window).on("orientationchange resize",function(){if($(".isTablet").is(":visible")){if($("#sidebar").hasClass("expanded")){if(!$(".redbar_links_container").is(":visible")){$(".redbar_links_container").slideToggle()
}}}if($(".isMobile").is(":visible")){if($("#sidebar").hasClass("expanded")){$("#sidebar").css("display","block")
}}if(($("body").hasClass("pri_to_pub")&&$(window).width()<1291)){if($("#sidebar").hasClass("expanded")){$(".redbar_links_container").style("display","list-item","important")
}}if(($("body").hasClass("pri_to_pub")&&$(window).width()>=1291)){if($("#sidebar").hasClass("expanded")){$(".redbar_links_container").style("display","")
}}});
var s=function(){u.click();
setTimeout(function(){u.click()
},2000)
};
if($(".isMobile").is(":hidden")&&(typeof Cookies.get("menu")==="undefined")){s();
Cookies.set("menu","1",{expires:7})
}$(".pws_slide").bxSlider({controls:true,pager:false,slideMargin:0,infiniteLoop:false,autoReload:true,touchEnabled:($(".pws_slide li").not(".bx-clone").length>1)?true:false,moveSlides:1,nextText:" ",prevText:" ",breaks:[{screen:0,slides:1},{screen:460,slides:2},{screen:768,slides:3}]});
$(".pws_related .item .promo-name").matchHeight();
$(".pws_related .item .costo").matchHeight();
$(".pws_related .item .text").matchHeight();
$(".pws_advices .item_container .item .type").matchHeight();
$(".pws_advices .item_container .item .rate").matchHeight();
$(".pws_advices .item_container .item .big").matchHeight();
$(".pws_advices .item_container .item .tan-taeg").matchHeight();
var n=$(".pws_multi_column .box-content");
$(document).off("click",".pws_multi_column_filter .pws_filter a");
$(document).on("click ",".pws_multi_column_filter .pws_filter a",function(){var y=$(this).closest(".pws_multi_column").find(".box-content");
selectFilter($(this),y);
var z=$(this).closest(".pws_multi_column").find(".disclaimer-content");
selectFilter($(this),z)
});
$(".pws_three_column .t").matchHeight();
$(".pws_item_column .t").matchHeight();
$(".pws_three_column .testo").matchHeight();
$(".regioni path").hover(function(){var y=$(this).attr("class");
$("."+y).css({fill:"#00adce"})
},function(){var y=$(this).attr("class");
$("."+y).css({fill:"#CECCCC"})
});
$(document).off("click","#italymap .map_region");
$(document).on("click ","#italymap .map_region",function(){var z=$(this).attr("class").replace("map_region","").trim();
var y=$("."+z).find("path").data("url");
if(y){window.location.href=y
}});
clearLeftCard();
$(".pws_card_category").each(function(){var B=$(this);
var A=".pws_cards_list ";
if(B.find(".pws_cards_list > span").length>0){A+="> span > li"
}else{A+="> li"
}if(B.data("show-all")!="all"){var z=B.find(".pws_cards_list .item").length;
var C=B.find(A);
if(B.data("show-all")=="3"){if(B.find(".big").length==0){C.not(A+":eq(0), "+A+":eq(1), "+A+":eq(2)").hide()
}if(B.find(".big").length==1){C.not(A+":eq(0), "+A+":eq(1)").hide()
}}if(B.data("show-all")=="6"){if(B.find(".big").length==0){C.not(A+":eq(0), "+A+":eq(1), "+A+":eq(2), "+A+":eq(3), "+A+":eq(4), "+A+":eq(5)").hide()
}if(B.find(".big").length==1){C.not(A+":eq(0), "+A+":eq(1), "+A+":eq(2), "+A+":eq(3), "+A+":eq(4)").hide()
}if(B.find(".big").length==2){C.not(A+":eq(0), "+A+":eq(1), "+A+":eq(2), "+A+":eq(3)").hide()
}}}else{var y=0;
B.find(A).each(function(D,E){if((D==2&&$(this).hasClass("big")||y>=6)){$(this).addClass("showed")
}if($(this).hasClass("big")){y+=2
}else{y++
}})
}});
var f=function(){var y=$(".pws_compare .btn");
var z=y.data("target");
$(".pws_cards_list .item.selected").each(function(A){var C=$(this).data("product");
var B=A+1;
C="code"+B+"="+C;
if(A>0){C="&"+C
}z+=C
});
y.attr("href",z)
};
var w=function(){var y=$(".pws_compare .btn_selector");
var z=y.data("target");
$(".pws_cards_list .item.selected").each(function(A){var B=$(this).data("product");
z+="."+B
});
y.attr("href",z+".html")
};
var m=function(D){var y=$(".pws_compare");
D.parents(".item").toggleClass("selected");
D.find(".i").toggleClass("plus, ok");
var E=$(".pws_cards_list .item.selected").length;
var z=[];
$(".pws_cards_list .item.selected").each(function(G){var F=$(this).closest("div[data-category]").attr("data-category");
if(z.indexOf(F)==-1){z.push(F)
}});
var C=z.length;
y.find(".num").text(E);
if(E>0){if($(".pws_compare").is(":hidden")){try{window.waUtilsObj.link({trackType:"ASYNC-TOOL",tool:{name:$("#WAToolName").text(),start:"true",type:"comparator"}})
}catch(A){console.log("ERRWAUTILS")
}y.slideToggle()
}}else{y.hide()
}y.find(".t").addClass("hidden");
y.find(".btn").addClass("hidden");
var B=y.find(".err_t2").length>0;
if(B&&C>1){y.find(".err_t2").removeClass("hidden")
}else{if(E==1){y.find(".first_t").removeClass("hidden")
}else{if(E==2||E==3){y.find(".selected_t").removeClass("hidden");
y.find(".btn").removeClass("hidden")
}else{if(E>3){y.find(".err_t").removeClass("hidden")
}}}}if(y.find(".btn").hasClass("btn_selector")){w()
}else{f()
}};
$(document).off("click",".pws_cards_list .item .compare");
$(document).on("click ",".pws_cards_list .item .compare",function(){var z=$(this);
var y=z.parents(".item").hasClass("selected");
var A=$(".pws_cards_list .item.selected").length;
m(z)
});
$(document).off("click","a.toggle_cards");
$(document).on("click ","a.toggle_cards",function(){var z=$(this);
if(!z.hasClass("alt_gsa")&&!z.hasClass("alt")){var y=$(this).parents(".pws_card_category").find("li");
if(z.hasClass("hide_all")){y.filter(".showed").slideToggle().removeClass("showed")
}else{y.filter(":hidden").slideToggle().addClass("showed")
}z.find(".arrow-down, .arrow-up").toggleClass("hidden");
z.find(".t span").toggleClass("hidden");
z.toggleClass("hide_all")
}});
$(document).off("click",".pws_category_filter .pws_filter a");
$(document).on("click ",".pws_category_filter .pws_filter a",function(){$("html,body").animate({scrollTop:$(".pws_category_filter").offset().top-100},"slow");
selectFilter($(this),$(".pws_card_category"));
selectFilter($(this),$(".productlist_disclaimer .disclaimer-content"))
});
if($(".editorial-bar").length!=0){$(".pws_compare").css("top","105px")
}$(window).on("load resize orientationchange",function(){textOverflow()
});
$(document).off("click",".toggle_cards.alt");
$(document).on("click ",".toggle_cards.alt",function(){var y=$(this);
y.parent().find(".text").toggleClass("closed open");
y.parents(".item_in").toggleClass("open");
y.find(".arrow-down, .arrow-up").toggleClass("hidden");
y.find(".t span").toggleClass("hidden")
});
var h=function(){var z=$(".compare_cards .pws_cards_list > li");
var y=$(".compare_cards .list_details .s");
y.css("height","");
y.each(function(B){var D=0;
for(var C=0;
C<z.length;
C++){var E=$(".compare_cards .pws_cards_list > li:eq("+C+") .list_details .s:eq("+B+")");
if(E.height()>D){D=E.height()
}}for(var A=0;
A<z.length;
A++){$(".compare_cards .pws_cards_list > li:eq("+A+") .list_details .s:eq("+B+")").height(D)
}})
};
$(window).on("load resize orientationchange",function(){h()
});
$(window).on("load resize orientationchange",function(){if(!$(".isMobile").is(":visible")){$(".compare_cards .pws_cards_list .item .btn").each(function(){var y=$(this).innerWidth()+2;
$(this).css("margin-left",-y/2)
})
}else{$(".compare_cards .pws_cards_list .item .btn").css("margin-left","auto")
}});
$(document).off("click",".tooltip_icon, .tooltip_content p");
$(document).on("click",".tooltip_icon, .tooltip_content p",function(){$(this).closest(".tooltip_container").find(".tooltip_content").toggleClass("hidden")
});
$(document).off("click",".nav-tabs li a");
$(document).on("click ",".nav-tabs li a",function(){var y=$(this).closest(".nav-tabs");
var z=$(this).data("target");
y.next(".tab-content").find(".tab-pane").removeClass("active");
y.find("li").removeClass("active");
y.next(".tab-content").find(z).addClass("active");
$(this).parent().addClass("active");
pwsGallery.start();
return false
});
function k(){var y=0;
$(".import_mondo .valori_paesi").each(function(){y=y+parseFloat($(this).attr("valore"))
});
$(".import_mondo .valori_paesi").each(function(){var z=(parseFloat($(this).attr("valore"))*100)/y;
$(this).animate({width:z+"%"},1000,"swing")
});
var y=0;
$(".import_mondo_crescita .valori_paesi").each(function(){y=y+parseFloat($(this).attr("valore"))
});
$(".import_mondo_crescita .valori_paesi").each(function(){var z=(parseFloat($(this).attr("valore"))*100)/y;
$(this).animate({width:z+"%"},1000,"swing")
});
var y=0;
$(".import_italia .valori_paesi").each(function(){y=y+parseFloat($(this).attr("valore"))
});
$(".import_italia .valori_paesi").each(function(){var z=(parseFloat($(this).attr("valore"))*100)/y;
$(this).animate({width:z+"%"},1000,"swing")
});
var y=0;
$(".import_italia_crescita .valori_paesi").each(function(){y=y+parseFloat($(this).attr("valore"))
});
$(".import_italia_crescita .valori_paesi").each(function(){var z=(parseFloat($(this).attr("valore"))*100)/y;
$(this).animate({width:z+"%"},1000,"swing")
});
$(".trova_un_paese_box .suggestion .t").html($(".industria .selected-value span").html()+" - "+$(".settore .selected-value span").html()+" - "+$(".prodotto .selected-value span").html())
}$(".box_result_cerca_min").matchHeight();
$(document).on("click ",".trova_un_paese_box .cerca_paesi",function(){$(".primo_step").hide();
$(".box_result_cerca").show();
k()
});
$(document).on("click ",".trova_un_paese_box .valori_paesi",function(){$('.valori_paesi:not([paese="'+$(this).attr("paese")+'"])').parent().parent().remove()
});
$(document).on("click ",".trova_un_paese_box #return_search",function(){$(".primo_step").show();
$(".box_result_cerca").hide()
});
var q=navigator.userAgent;
var x=(q.indexOf("Mozilla/5.0")>-1&&q.indexOf("Android ")>-1&&q.indexOf("AppleWebKit")>-1&&q.indexOf("Chrome")===-1);
if(x){$("body").addClass("android-browser")
}$filter=$(".pws_filter a")
});
$(window).load(function(){$(".pws_related .bx-viewport").css("height","")
});
var filterElement=function(c,b){if(typeof c=="undefined"||c==""){return false
}if(c=="all"){b.show()
}else{b.each(function(){var d=$(this);
if(d.attr("data-category")==c){d.show()
}else{d.hide()
}})
}};
var selectFilter=function(d,c){var b=d.attr("data-value");
$filter.removeClass("current");
d.addClass("current");
filterElement(b,c)
};
function matchHeightPws(){$(".compare_cards .pws_cards_list .item .text").matchHeight({byRow:false});
$(".item .lab_container").matchHeight({byRow:false});
$(".compare_cards .pws_cards_list .item .costo").matchHeight({byRow:false});
$(".item .costo").matchHeight();
$(".compare_cards .pws_cards_list .item .promo-name .promo_in").matchHeight({byRow:false});
$(".compare_cards .pws_cards_list .item .item_footer").matchHeight({byRow:false});
$(".pws_card_category .pws_cards_list .item").matchHeight({property:"min-height",remove:true});
$(".pws_card_category .pws_cards_list .item .item_in").matchHeight();
$(".pws_cards_list .item .item_content .lab_container").matchHeight();
$(".modules_selected .text_alt").matchHeight();
$(".item.grey .promo-name").matchHeight();
$(".pws_multi_column .box-content").matchHeight();
$(".pws_cards_list .item").not(".grey").find(".promo-name").matchHeight();
$(".bx-viewport").not(".grey").find(".promo-name").matchHeight();
$(".bx-viewport .item .text").matchHeight({byRow:false});
$(".pws_cards_list .item").not(".grey").find(".item_content").matchHeight();
$(".pws_multi_column .t").matchHeight();
$(".pws_multi_column .testo").matchHeight()
}function setMatchHeight(c,b){if($(b+" "+c).length){$(b).each(function(){var d=0;
$(this).find(c).each(function(){$(this).css("height","");
if(parseFloat($(this).css("height").replace("px",""))>d){d=parseFloat($(this).css("height").replace("px",""))
}});
$(this).find(c).css("height",d+"px")
})
}}function recommenderTutteLe(b,r){try{var s=$.parseJSON(b);
var c={};
var o={};
var g=[];
var t=[];
var h="";
var e=r.toLowerCase();
$("[data-category]").each(function(){var u=$(this).attr("data-category");
g.push(u);
o[u]=[];
$("[data-category='"+u+"'] .item").each(function(){o[u].push($(this).attr("data-product"))
});
c[u]=[];
for(var v in s){if(($.inArray(v,o[u])>-1)){c[u].push(v)
}}});
for(var n in s){for(var m in c){var q=m;
for(var l in c[m]){if(c[m][l]==n){if(!($.inArray(q,t)>-1)){t.push(q);
break
}}}}}for(var n in c){var q=n;
var k=[];
for(var m in c[n]){if($("div[data-product='"+c[n][m]+"']").length){$("div[data-product='"+c[n][m]+"']").closest("li").css("clear","");
k.push($("div[data-product='"+c[n][m]+"']").closest("li")[0].outerHTML);
$("div[data-product='"+c[n][m]+"']").closest("li").remove()
}}var p=$("div[data-category='"+q+"']").find("ul").html();
$("div[data-category='"+q+"']").find("ul").html("");
for(var f=0;
f<k.length;
f++){$("div[data-category='"+q+"']").find("ul").append(k[f])
}$("div[data-category='"+q+"']").find("ul").append(p)
}for(var n in t){h=h+$("div[data-category='"+t[n]+"']")[0].outerHTML;
$("div[data-category='"+t[n]+"']").remove()
}if($("div.spinnerableContent .pws_filter").length){$("div.spinnerableContent div.pws_filter").after(h)
}else{$("div.spinnerableContent").append(h)
}clearLeftCard()
}catch(d){console.log("Errore funzione reccommender "+d);
console.log(d)
}}function textOverflow(){$(".item.grey .text").each(function(){if($(this)[0].scrollHeight>$(this).innerHeight()){$(this).addClass("closed");
$(this).parent().find(".toggle_cards.alt").show()
}else{$(this).removeClass("open");
$(this).parent().find(".toggle_cards.alt").hide()
}})
}function equalizeEachLine(){var d=$(".compare_cards .pws_cards_list > li");
var b=$(".compare_cards .list_details .s");
b.css("height","");
b.each(function(e){var g=0;
for(var f=0;
f<d.length;
f++){var h=$(".compare_cards .pws_cards_list > li:eq("+f+") .list_details .s:eq("+e+")");
if(h.height()>g){g=h.height()
}}for(var c=0;
c<d.length;
c++){$(".compare_cards .pws_cards_list > li:eq("+c+") .list_details .s:eq("+e+")").height(g)
}})
}function clearLeftCard(){if($(".isMobile").is(":hidden")){$(".pws_card_category .pws_cards_list").each(function(){var b=0;
$(this).find("li").each(function(){var e=$(this);
var c=e.attr("class");
var d=1;
if(typeof c!="undefined"){if(c.search("col-sm-8")!=-1){d=2
}}b=b+d;
if(b==1||b>3){e.css("clear","left");
b=d
}})
})
}}
/*!
 * Bootstrap v3.3.5 (http://getbootstrap.com)
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 */
;
/*!
 * Generated using the Bootstrap Customizer (http://getbootstrap.com/customize/?id=5f1e1166528ae6b0c795)
 * Config saved to config.json and https://gist.github.com/5f1e1166528ae6b0c795
 */
;
if(typeof jQuery==="undefined"){throw new Error("Bootstrap's JavaScript requires jQuery")
}+function(c){var b=c.fn.jquery.split(" ")[0].split(".");
if((b[0]<2&&b[1]<9)||(b[0]==1&&b[1]==9&&b[2]<1)){throw new Error("Bootstrap's JavaScript requires jQuery version 1.9.1 or higher")
}}(jQuery);
+function(e){var c=function(g,f){this.options=f;
this.$body=e(document.body);
this.$element=e(g);
this.$dialog=this.$element.find(".modal-dialog");
this.$backdrop=null;
this.isShown=null;
this.originalBodyPad=null;
this.scrollbarWidth=0;
this.ignoreBackdropClick=false;
if(this.options.remote){this.$element.find(".modal-content").load(this.options.remote,e.proxy(function(){this.$element.trigger("loaded.bs.modal")
},this))
}};
c.VERSION="3.3.5";
c.TRANSITION_DURATION=300;
c.BACKDROP_TRANSITION_DURATION=150;
c.DEFAULTS={backdrop:true,keyboard:true,show:true};
c.prototype.toggle=function(f){return this.isShown?this.hide():this.show(f)
};
c.prototype.show=function(h){var f=this;
var g=e.Event("show.bs.modal",{relatedTarget:h});
this.$element.trigger(g);
if(this.isShown||g.isDefaultPrevented()){return
}this.isShown=true;
this.checkScrollbar();
this.setScrollbar();
this.$body.addClass("modal-open");
this.escape();
this.resize();
this.$element.on("click.dismiss.bs.modal",'[data-dismiss="modal"]',e.proxy(this.hide,this));
this.$dialog.on("mousedown.dismiss.bs.modal",function(){f.$element.one("mouseup.dismiss.bs.modal",function(k){if(e(k.target).is(f.$element)){f.ignoreBackdropClick=true
}})
});
this.backdrop(function(){var l=e.support.transition&&f.$element.hasClass("fade");
if(!f.$element.parent().length){f.$element.appendTo(f.$body)
}f.$element.show().scrollTop(0);
f.adjustDialog();
if(l){f.$element[0].offsetWidth
}f.$element.addClass("in");
f.enforceFocus();
var k=e.Event("shown.bs.modal",{relatedTarget:h});
l?f.$dialog.one("bsTransitionEnd",function(){f.$element.trigger("focus").trigger(k)
}).emulateTransitionEnd(c.TRANSITION_DURATION):f.$element.trigger("focus").trigger(k)
})
};
c.prototype.hide=function(f){if(f){f.preventDefault()
}f=e.Event("hide.bs.modal");
this.$element.trigger(f);
if(!this.isShown||f.isDefaultPrevented()){return
}this.isShown=false;
this.escape();
this.resize();
e(document).off("focusin.bs.modal");
this.$element.removeClass("in").off("click.dismiss.bs.modal").off("mouseup.dismiss.bs.modal");
this.$dialog.off("mousedown.dismiss.bs.modal");
e.support.transition&&this.$element.hasClass("fade")?this.$element.one("bsTransitionEnd",e.proxy(this.hideModal,this)).emulateTransitionEnd(c.TRANSITION_DURATION):this.hideModal()
};
c.prototype.enforceFocus=function(){e(document).off("focusin.bs.modal").on("focusin.bs.modal",e.proxy(function(f){if(this.$element[0]!==f.target&&!this.$element.has(f.target).length){this.$element.trigger("focus")
}},this))
};
c.prototype.escape=function(){if(this.isShown&&this.options.keyboard){this.$element.on("keydown.dismiss.bs.modal",e.proxy(function(f){f.which==27&&this.hide()
},this))
}else{if(!this.isShown){this.$element.off("keydown.dismiss.bs.modal")
}}};
c.prototype.resize=function(){if(this.isShown){e(window).on("resize.bs.modal",e.proxy(this.handleUpdate,this))
}else{e(window).off("resize.bs.modal")
}};
c.prototype.hideModal=function(){var f=this;
this.$element.hide();
this.backdrop(function(){f.$body.removeClass("modal-open");
f.resetAdjustments();
f.resetScrollbar();
f.$element.trigger("hidden.bs.modal")
})
};
c.prototype.removeBackdrop=function(){this.$backdrop&&this.$backdrop.remove();
this.$backdrop=null
};
c.prototype.backdrop=function(l){var k=this;
var g=this.$element.hasClass("fade")?"fade":"";
if(this.isShown&&this.options.backdrop){var f=e.support.transition&&g;
this.$backdrop=e(document.createElement("div")).addClass("modal-backdrop "+g).appendTo(this.$body);
this.$element.on("click.dismiss.bs.modal",e.proxy(function(m){if(this.ignoreBackdropClick){this.ignoreBackdropClick=false;
return
}if(m.target!==m.currentTarget){return
}this.options.backdrop=="static"?this.$element[0].focus():this.hide()
},this));
if(f){this.$backdrop[0].offsetWidth
}this.$backdrop.addClass("in");
if(!l){return
}f?this.$backdrop.one("bsTransitionEnd",l).emulateTransitionEnd(c.BACKDROP_TRANSITION_DURATION):l()
}else{if(!this.isShown&&this.$backdrop){this.$backdrop.removeClass("in");
var h=function(){k.removeBackdrop();
l&&l()
};
e.support.transition&&this.$element.hasClass("fade")?this.$backdrop.one("bsTransitionEnd",h).emulateTransitionEnd(c.BACKDROP_TRANSITION_DURATION):h()
}else{if(l){l()
}}}};
c.prototype.handleUpdate=function(){this.adjustDialog()
};
c.prototype.adjustDialog=function(){var f=this.$element[0].scrollHeight>document.documentElement.clientHeight;
this.$element.css({paddingLeft:!this.bodyIsOverflowing&&f?this.scrollbarWidth:"",paddingRight:this.bodyIsOverflowing&&!f?this.scrollbarWidth:""})
};
c.prototype.resetAdjustments=function(){this.$element.css({paddingLeft:"",paddingRight:""})
};
c.prototype.checkScrollbar=function(){var g=window.innerWidth;
if(!g){var f=document.documentElement.getBoundingClientRect();
g=f.right-Math.abs(f.left)
}this.bodyIsOverflowing=document.body.clientWidth<g;
this.scrollbarWidth=this.measureScrollbar()
};
c.prototype.setScrollbar=function(){var f=parseInt((this.$body.css("padding-right")||0),10);
this.originalBodyPad=document.body.style.paddingRight||"";
if(this.bodyIsOverflowing){this.$body.css("padding-right",f+this.scrollbarWidth)
}};
c.prototype.resetScrollbar=function(){this.$body.css("padding-right",this.originalBodyPad)
};
c.prototype.measureScrollbar=function(){var g=document.createElement("div");
g.className="modal-scrollbar-measure";
this.$body.append(g);
var f=g.offsetWidth-g.clientWidth;
this.$body[0].removeChild(g);
return f
};
function d(f,g){return this.each(function(){var l=e(this);
var k=l.data("bs.modal");
var h=e.extend({},c.DEFAULTS,l.data(),typeof f=="object"&&f);
if(!k){l.data("bs.modal",(k=new c(this,h)))
}if(typeof f=="string"){k[f](g)
}else{if(h.show){k.show(g)
}}})
}var b=e.fn.modal;
e.fn.modal=d;
e.fn.modal.Constructor=c;
e.fn.modal.noConflict=function(){e.fn.modal=b;
return this
};
e(document).on("click.bs.modal.data-api",'[data-toggle="modal"]',function(l){var k=e(this);
var g=k.attr("href");
var f=e(k.attr("data-target")||(g&&g.replace(/.*(?=#[^\s]+$)/,"")));
var h=f.data("bs.modal")?"toggle":e.extend({remote:!/#/.test(g)&&g},f.data(),k.data());
if(k.is("a")){l.preventDefault()
}f.one("show.bs.modal",function(m){if(m.isDefaultPrevented()){return
}f.one("hidden.bs.modal",function(){k.is(":visible")&&k.trigger("focus")
})
});
d.call(f,h,this)
})
}(jQuery);
+function(c){function b(){var f=document.createElement("bootstrap");
var e={WebkitTransition:"webkitTransitionEnd",MozTransition:"transitionend",OTransition:"oTransitionEnd otransitionend",transition:"transitionend"};
for(var d in e){if(f.style[d]!==undefined){return{end:e[d]}
}}return false
}c.fn.emulateTransitionEnd=function(f){var e=false;
var d=this;
c(this).one("bsTransitionEnd",function(){e=true
});
var g=function(){if(!e){c(d).trigger(c.support.transition.end)
}};
setTimeout(g,f);
return this
};
c(function(){c.support.transition=b();
if(!c.support.transition){return
}c.event.special.bsTransitionEnd={bindType:c.support.transition.end,delegateType:c.support.transition.end,handle:function(d){if(c(d.target).is(this)){return d.handleObj.handler.apply(this,arguments)
}}}
})
}(jQuery);
!function(b){"function"==typeof define&&define.amd?define(["jquery"],b):b("object"==typeof exports&&"function"==typeof require?require("jquery"):jQuery)
}(function(f){function e(n,m){var l=function(){},k=this,b={ajaxSettings:{},autoSelectFirst:!1,appendTo:document.body,serviceUrl:null,lookup:null,onSelect:null,width:"auto",minChars:1,maxHeight:300,deferRequestBy:0,params:{},formatResult:e.formatResult,delimiter:null,zIndex:9999,type:"GET",noCache:!1,onSearchStart:l,onSearchComplete:l,onSearchError:l,preserveInput:!1,containerClass:"autocomplete-suggestions",tabDisabled:!1,dataType:"text",currentRequest:null,triggerSelectOnValidInput:!0,preventBadQueries:!0,lookupFilter:function(o,d,p){return -1!==o.value.toLowerCase().indexOf(p)
},paramName:"query",transformResult:function(c){return"string"==typeof c?f.parseJSON(c):c
},showNoSuggestionNotice:!1,noSuggestionNotice:"No results",orientation:"bottom",forceFixPosition:!1};
k.element=n,k.el=f(n),k.suggestions=[],k.badQueries=[],k.selectedIndex=-1,k.currentValue=k.element.value,k.intervalId=0,k.cachedResponse={},k.onChangeInterval=null,k.onChange=null,k.isLocal=!1,k.suggestionsContainer=null,k.noSuggestionsContainer=null,k.options=f.extend({},b,m),k.classes={selected:"autocomplete-selected",suggestion:"autocomplete-suggestion"},k.hint=null,k.hintValue="",k.selection=null,k.initialize(),k.setOptions(m)
}var h=function(){return{escapeRegExChars:function(b){return b.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,"\\$&")
},createNode:function(d){var c=document.createElement("div");
return c.className=d,c.style.position="absolute",c.style.display="none",c
}}
}(),g={ESC:27,TAB:9,RETURN:13,LEFT:37,UP:38,RIGHT:39,DOWN:40};
e.utils=h,f.Autocomplete=e,e.formatResult=function(k,c){var l="("+h.escapeRegExChars(c)+")";
return k.value.replace(new RegExp(l,"gi"),"<strong>$1</strong>").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/&lt;(\/?strong)&gt;/g,"<$1>")
},e.prototype={killerFn:null,initialize:function(){var n,m=this,l="."+m.classes.suggestion,k=m.classes.selected,b=m.options;
m.element.setAttribute("autocomplete","off"),m.killerFn=function(c){0===f(c.target).closest("."+m.options.containerClass).length&&(m.killSuggestions(),m.disableKillerFn())
},m.noSuggestionsContainer=f('<div class="autocomplete-no-suggestion"></div>').html(this.options.noSuggestionNotice).get(0),m.suggestionsContainer=e.utils.createNode(b.containerClass),n=f(m.suggestionsContainer),n.appendTo(b.appendTo),"auto"!==b.width&&n.width(b.width),n.on("mouseover.autocomplete",l,function(){m.activate(f(this).data("index"))
}),n.on("mouseout.autocomplete",function(){m.selectedIndex=-1,n.children("."+k).removeClass(k)
}),n.on("click.autocomplete",l,function(){m.select(f(this).data("index"))
}),m.fixPositionCapture=function(){m.visible&&m.fixPosition()
},f(window).on("resize.autocomplete",m.fixPositionCapture),m.el.on("keydown.autocomplete",function(c){m.onKeyPress(c)
}),m.el.on("keyup.autocomplete",function(c){m.onKeyUp(c)
}),m.el.on("blur.autocomplete",function(){m.onBlur()
}),m.el.on("focus.autocomplete",function(){m.onFocus()
}),m.el.on("change.autocomplete",function(c){m.onKeyUp(c)
}),m.el.on("input.autocomplete",function(c){m.onKeyUp(c)
})
},onFocus:function(){var b=this;
b.fixPosition(),0===b.options.minChars&&0===b.el.val().length&&b.onValueChange()
},onBlur:function(){this.enableKillerFn()
},abortAjax:function(){var b=this;
b.currentRequest&&(b.currentRequest.abort(),b.currentRequest=null)
},setOptions:function(k){var m=this,l=m.options;
f.extend(l,k),m.isLocal=f.isArray(l.lookup),m.isLocal&&(l.lookup=m.verifySuggestionsFormat(l.lookup)),l.orientation=m.validateOrientation(l.orientation,"bottom"),f(m.suggestionsContainer).css({"max-height":l.maxHeight+"px",width:l.width+"px","z-index":l.zIndex})
},clearCache:function(){this.cachedResponse={},this.badQueries=[]
},clear:function(){this.clearCache(),this.currentValue="",this.suggestions=[]
},disable:function(){var b=this;
b.disabled=!0,clearInterval(b.onChangeInterval),b.abortAjax()
},enable:function(){this.disabled=!1
},fixPosition:function(){var C=this,B=f(C.suggestionsContainer),A=B.parent().get(0);
if(A===document.body||C.options.forceFixPosition){var z=C.options.orientation,y=B.outerHeight(),x=C.el.outerHeight(),w=C.el.offset(),v={top:w.top,left:w.left};
if("auto"===z){var u=f(window).height(),t=f(window).scrollTop(),s=-t+w.top-y,r=t+u-(w.top+x+y);
z=Math.max(s,r)===s?"top":"bottom"
}if("top"===z?v.top+=-y:v.top+=x,A!==document.body){var q,p=B.css("opacity");
C.visible||B.css("opacity",0).show(),q=B.offsetParent().offset(),v.top-=q.top,v.left-=q.left,C.visible||B.css("opacity",p).hide()
}"auto"===C.options.width&&(v.width=C.el.outerWidth()-2+"px"),B.css(v)
}},enableKillerFn:function(){var c=this;
f(document).on("click.autocomplete",c.killerFn)
},disableKillerFn:function(){var c=this;
f(document).off("click.autocomplete",c.killerFn)
},killSuggestions:function(){var b=this;
b.stopKillSuggestions(),b.intervalId=window.setInterval(function(){b.visible&&(b.el.val(b.currentValue),b.hide()),b.stopKillSuggestions()
},50)
},stopKillSuggestions:function(){window.clearInterval(this.intervalId)
},isCursorAtEnd:function(){var l,k=this,n=k.el.val().length,m=k.element.selectionStart;
return"number"==typeof m?m===n:document.selection?(l=document.selection.createRange(),l.moveStart("character",-n),n===l.text.length):!0
},onKeyPress:function(d){var c=this;
if(!c.disabled&&!c.visible&&d.which===g.DOWN&&c.currentValue){return void c.suggest()
}if(!c.disabled&&c.visible){switch(d.which){case g.ESC:c.el.val(c.currentValue),c.hide();
break;
case g.RIGHT:if(c.hint&&c.options.onHint&&c.isCursorAtEnd()){c.selectHint();
break
}return;
case g.TAB:if(c.hint&&c.options.onHint){return void c.selectHint()
}if(-1===c.selectedIndex){return void c.hide()
}if(c.select(c.selectedIndex),c.options.tabDisabled===!1){return
}break;
case g.RETURN:if(-1===c.selectedIndex){return void c.hide()
}c.select(c.selectedIndex);
break;
case g.UP:c.moveUp();
break;
case g.DOWN:c.moveDown();
break;
default:return
}d.stopImmediatePropagation(),d.preventDefault()
}},onKeyUp:function(d){var c=this;
if(!c.disabled){switch(d.which){case g.UP:case g.DOWN:return
}clearInterval(c.onChangeInterval),c.currentValue!==c.el.val()&&(c.findBestHint(),c.options.deferRequestBy>0?c.onChangeInterval=setInterval(function(){c.onValueChange()
},c.options.deferRequestBy):c.onValueChange())
}},onValueChange:function(){var k=this,n=k.options,m=k.el.val(),l=k.getQuery(m);
return k.selection&&k.currentValue!==l&&(k.selection=null,(n.onInvalidateSelection||f.noop).call(k.element)),clearInterval(k.onChangeInterval),k.currentValue=m,k.selectedIndex=-1,n.triggerSelectOnValidInput&&k.isExactMatch(l)?void k.select(0):void (l.length<n.minChars?k.hide():k.getSuggestions(l))
},isExactMatch:function(d){var c=this.suggestions;
return 1===c.length&&c[0].value.toLowerCase()===d.toLowerCase()
},getQuery:function(k){var m,l=this.options.delimiter;
return l?(m=k.split(l),f.trim(m[m.length-1])):k
},getSuggestionsLocal:function(k){var q,p=this,o=p.options,n=k.toLowerCase(),m=o.lookupFilter,l=parseInt(o.lookupLimit,10);
return q={suggestions:f.grep(o.lookup,function(b){return m(b,k,n)
})},l&&q.suggestions.length>l&&(q.suggestions=q.suggestions.slice(0,l)),q
},getSuggestions:function(k){var r,q,p,o,n=this,m=n.options,l=m.serviceUrl;
if(m.params[m.paramName]=k,q=m.ignoreParams?null:m.params,m.onSearchStart.call(n.element,m.params)!==!1){if(f.isFunction(m.lookup)){return void m.lookup(k,function(b){n.suggestions=b.suggestions,n.suggest(),m.onSearchComplete.call(n.element,k,b.suggestions)
})
}n.isLocal?r=n.getSuggestionsLocal(k):(f.isFunction(l)&&(l=l.call(n.element,k)),p=l+"?"+f.param(q||{}),r=n.cachedResponse[p]),r&&f.isArray(r.suggestions)?(n.suggestions=r.suggestions,n.suggest(),m.onSearchComplete.call(n.element,k,r.suggestions)):n.isBadQuery(k)?m.onSearchComplete.call(n.element,k,[]):(n.abortAjax(),o={url:l,data:q,type:m.type,dataType:m.dataType},f.extend(o,m.ajaxSettings),n.currentRequest=f.ajax(o).done(function(b){var d;
n.currentRequest=null,d=m.transformResult(b,k),n.processResponse(d,k,p),m.onSearchComplete.call(n.element,k,d.suggestions)
}).fail(function(b,t,s){m.onSearchError.call(n.element,k,b,t,s)
}))
}},isBadQuery:function(k){if(!this.options.preventBadQueries){return !1
}for(var d=this.badQueries,l=d.length;
l--;
){if(0===k.indexOf(d[l])){return !0
}}return !1
},hide:function(){var d=this,k=f(d.suggestionsContainer);
f.isFunction(d.options.onHide)&&d.visible&&d.options.onHide.call(d.element,k),d.visible=!1,d.selectedIndex=-1,clearInterval(d.onChangeInterval),f(d.suggestionsContainer).hide(),d.signalHint(null)
},suggest:function(){if(0===this.suggestions.length){return void (this.options.showNoSuggestionNotice?this.noSuggestions():this.hide())
}var A,z=this,y=z.options,x=y.groupBy,w=y.formatResult,v=z.getQuery(z.currentValue),u=z.classes.suggestion,t=z.classes.selected,s=f(z.suggestionsContainer),r=f(z.noSuggestionsContainer),q=y.beforeRender,p="",o=function(b,l){var k=b.data[x];
return A===k?"":(A=k,'<div class="autocomplete-group"><strong>'+A+"</strong></div>")
};
return y.triggerSelectOnValidInput&&z.isExactMatch(v)?void z.select(0):(f.each(z.suggestions,function(d,c){x&&(p+=o(c,v,d)),p+='<div class="'+u+'" data-index="'+d+'">'+w(c,v)+"</div>"
}),this.adjustContainerWidth(),r.detach(),s.html(p),f.isFunction(q)&&q.call(z.element,s),z.fixPosition(),s.show(),y.autoSelectFirst&&(z.selectedIndex=0,s.scrollTop(0),s.children("."+u).first().addClass(t)),z.visible=!0,void z.findBestHint())
},noSuggestions:function(){var k=this,m=f(k.suggestionsContainer),l=f(k.noSuggestionsContainer);
this.adjustContainerWidth(),l.detach(),m.empty(),m.append(l),k.fixPosition(),m.show(),k.visible=!0
},adjustContainerWidth:function(){var k,n=this,m=n.options,l=f(n.suggestionsContainer);
"auto"===m.width&&(k=n.el.outerWidth()-2,l.width(k>0?k:300))
},findBestHint:function(){var k=this,m=k.el.val().toLowerCase(),l=null;
m&&(f.each(k.suggestions,function(d,c){var n=0===c.value.toLowerCase().indexOf(m);
return n&&(l=c),!n
}),k.signalHint(l))
},signalHint:function(k){var m="",l=this;
k&&(m=l.currentValue+k.value.substr(l.currentValue.length)),l.hintValue!==m&&(l.hintValue=m,l.hint=k,(this.options.onHint||f.noop)(m))
},verifySuggestionsFormat:function(c){return c.length&&"string"==typeof c[0]?f.map(c,function(b){return{value:b,data:null}
}):c
},validateOrientation:function(d,k){return d=f.trim(d||"").toLowerCase(),-1===f.inArray(d,["auto","bottom","top"])&&(d=k),d
},processResponse:function(l,k,o){var n=this,m=n.options;
l.suggestions=n.verifySuggestionsFormat(l.suggestions),m.noCache||(n.cachedResponse[o]=l,m.preventBadQueries&&0===l.suggestions.length&&n.badQueries.push(k)),k===n.getQuery(n.currentValue)&&(n.suggestions=l.suggestions,n.suggest())
},activate:function(k){var p,o=this,n=o.classes.selected,m=f(o.suggestionsContainer),l=m.find("."+o.classes.suggestion);
return m.find("."+n).removeClass(n),o.selectedIndex=k,-1!==o.selectedIndex&&l.length>o.selectedIndex?(p=l.get(o.selectedIndex),f(p).addClass(n),p):null
},selectHint:function(){var d=this,k=f.inArray(d.hint,d.suggestions);
d.select(k)
},select:function(d){var c=this;
c.hide(),c.onSelect(d)
},moveUp:function(){var c=this;
if(-1!==c.selectedIndex){return 0===c.selectedIndex?(f(c.suggestionsContainer).children().first().removeClass(c.classes.selected),c.selectedIndex=-1,c.el.val(c.currentValue),void c.findBestHint()):void c.adjustScroll(c.selectedIndex-1)
}},moveDown:function(){var b=this;
b.selectedIndex!==b.suggestions.length-1&&b.adjustScroll(b.selectedIndex+1)
},adjustScroll:function(k){var q=this,p=q.activate(k);
if(p){var o,n,m,l=f(p).outerHeight();
o=p.offsetTop,n=f(q.suggestionsContainer).scrollTop(),m=n+q.options.maxHeight-l,n>o?f(q.suggestionsContainer).scrollTop(o):o>m&&f(q.suggestionsContainer).scrollTop(o-q.options.maxHeight+l),q.options.preserveInput||q.el.val(q.getValue(q.suggestions[k].value)),q.signalHint(null)
}},onSelect:function(k){var n=this,m=n.options.onSelect,l=n.suggestions[k];
n.currentValue=n.getValue(l.value),n.currentValue===n.el.val()||n.options.preserveInput||n.el.val(n.currentValue),n.signalHint(null),n.suggestions=[],n.selection=l,f.isFunction(m)&&m.call(n.element,l)
},getValue:function(l){var k,o,n=this,m=n.options.delimiter;
return m?(k=n.currentValue,o=k.split(m),1===o.length?l:k.substr(0,k.length-o[o.length-1].length)+l):l
},dispose:function(){var c=this;
c.el.off(".autocomplete").removeData("autocomplete"),c.disableKillerFn(),f(window).off("resize.autocomplete",c.fixPositionCapture),f(c.suggestionsContainer).remove()
}},f.fn.autocomplete=f.fn.devbridgeAutocomplete=function(l,k){var b="autocomplete";
return 0===arguments.length?this.first().data(b):this.each(function(){var d=f(this),c=d.data(b);
"string"==typeof l?c&&"function"==typeof c[l]&&c[l](k):(c&&c.dispose&&c.dispose(),c=new e(this,l),d.data(b,c))
})
}
});
!function a(h,o,n){function m(f,e){if(!o[f]){if(!h[f]){var d="function"==typeof require&&require;
if(!e&&d){return d(f,!0)
}if(l){return l(f,!0)
}var c=new Error("Cannot find module '"+f+"'");
throw c.code="MODULE_NOT_FOUND",c
}var b=o[f]={exports:{}};
h[f][0].call(b.exports,function(g){var p=h[f][1][g];
return m(p?p:g)
},b,b.exports,a,h,o,n)
}return o[f].exports
}for(var l="function"==typeof require&&require,k=0;
k<n.length;
k++){m(n[k])
}return m
}({1:[function(d,c){(function(b){var e=function(x){function w(f){m.children(":nth-child("+(o.currentIndex+1||0)+")").removeClass("itemslide-active"),m.children(":nth-child("+(f+1||0)+")").addClass("itemslide-active"),f!=n.currentIndex&&(o.currentIndex=f,m.trigger("changeActiveIndex"))
}function v(f){return -(f*m.children().outerWidth(!0)-(m.parent().outerWidth(!0)-m.children().outerWidth(!0))/2)
}function u(){var f=Date.now()-q;
return n.left_sided&&(p.currentLandPos=clamp(-(o.allSlidesWidth-m.parent().width()),0,p.currentLandPos)),m.trigger("changePos"),m.translate3d(r-easeOutBack(f,0,r-p.currentLandPos,t,s)),f>=t?void m.translate3d(p.currentLandPos):void (p.slidesGlobalID=requestAnimationFrame(u))
}var t,s,r,q,p=this,o=x.vars,n=x.options,m=x.$el;
p.gotoSlideByIndex=function(g,f){var h;
return g>=m.children().length-1||0>=g?(h=!0,g=Math.min(Math.max(g,0),m.children().length-1)):h=!1,w(g),t=Math.max(n.duration-1920/$(window).width()*Math.abs(o.velocity)*9*(n.duration/230)-(p.isOutBoundaries()?o.distanceFromStart/15:0)*(n.duration/230),50),s=h?250*Math.abs(o.velocity)/$(window).width():0,r=m.translate3d().x,p.currentLandPos=v(g),f?void m.translate3d(v(g)):(window.cancelAnimationFrame(p.slidesGlobalID),q=Date.now(),void (p.slidesGlobalID=window.requestAnimationFrame(u)))
},p.getLandingSlideIndex=function(g){for(var f=0;
f<m.children().length;
f++){if(m.children().outerWidth(!0)*f+m.children().outerWidth(!0)/2-m.children().outerWidth(!0)*n.pan_threshold*o.direction-v(0)>g){return n.one_item?f!=o.currentIndex?o.currentIndex+o.direction:o.currentIndex:f
}}return n.one_item?o.currentIndex+1:m.children().length-1
},p.isOutBoundaries=function(){return Math.floor(m.translate3d().x)>v(0)&&-1==o.direction||Math.ceil(m.translate3d().x)<v(m.children().length-1)&&1==o.direction
}
};
c.exports=e,b.matrixToArray=function(f){return f.substr(7,f.length-8).split(", ")
},b.easeOutBack=function(g,f,l,k,h){return void 0==h&&(h=1.70158),l*((g=g/k-1)*g*((h+1)*g+h)+1)+f
},$.fn.translate3d=function(g,f){if(null==g){var k=matrixToArray(this.css("transform"));
if(null!=$.fn.jquery){return{x:parseFloat(isExplorer?k[12]:k[4]),y:parseFloat(isExplorer?k[13]:k[5])}
}var h=this.css("transform").replace("translate3d","").replace("(","").replace(")","").replace(" ","").replace("px","").split(",");
return{x:parseFloat(h[0]),y:parseFloat(h[1])}
}this.css("transform","translate3d("+g+"px,"+(f||0)+"px, 0px)")
},b.clamp=function(g,f,h){return Math.min(Math.max(h,g),f)
},b.getCurrentTotalWidth=function(g){var f=0;
return g.children().each(function(){f+=$(this).outerWidth(!0)
}),f
}
}).call(this,"undefined"!=typeof global?global:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{})
},{}],2:[function(h,g){var n=h("./navigation"),m=h("./animation"),l=h("./slideout"),k=h("./mousewheel");
g.exports={create:function(d,c){var p=this;
p.$el=c,p.options=d,p.options.parent_width&&c.children().width(c.parent().outerWidth(!0)),c.css({"touch-action":"pan-y","-webkit-user-select":"none","-webkit-touch-callout":"none","-webkit-user-drag":"none","-webkit-tap-highlight-color":"rgba(0, 0, 0, 0)"}),p.options.disable_autowidth||c.css("width",c.children("li").length*c.children().outerWidth(!0)+10),p.vars={currentIndex:0,parent_width:p.options.parent_width,velocity:0,slideHeight:c.children().height(),direction:1,allSlidesWidth:getCurrentTotalWidth(c)},c.end_animation=!0,p.options.swipe_out&&l.slideout(p);
var o=new m(p),f=new n(p,o);
if(p.anim=o,p.nav=f,c.translate3d(0),o.gotoSlideByIndex(p.options.start),!p.options.disable_scroll){try{k.add(p,o,f,c)
}catch(e){}}}}
},{"./animation":1,"./mousewheel":5,"./navigation":6,"./slideout":8}],3:[function(d,c){c.exports={apply:function(f,e){f.gotoSlide=function(b){e.anim.gotoSlideByIndex(b)
},f.next=function(){e.anim.gotoSlideByIndex(e.vars.currentIndex+1)
},f.previous=function(){e.anim.gotoSlideByIndex(e.vars.currentIndex-1)
},f.reload=function(){var g=e.$el,b=e.vars;
b.parent_width&&g.children().width(g.parent().outerWidth(!0)),e.options.disable_autowidth||g.css("width",g.children("li").length*g.children().outerWidth(!0)+10),b.slideHeight=g.children().height(),b.allSlidesWidth=getCurrentTotalWidth(g),b.velocity=0,f.gotoSlide(b.currentIndex)
},f.addSlide=function(b){f.append("<li>"+b+"</li>"),e.nav.createEvents(),f.reload()
},f.removeSlide=function(b){e.$el.children(":nth-child("+(b+1||0)+")").remove(),e.vars.allSlidesWidth=getCurrentTotalWidth(e.$el)
},f.getActiveIndex=function(){return e.vars.currentIndex
},f.getCurrentPos=function(){return f.translate3d().x
},f.getIndexByPosition=function(b){return e.anim.getLandingSlideIndex(-b)
}
}}
},{}],4:[function(b){(function(f){f.isExplorer=!!document.documentMode,b("./polyfills");
var k=b("./carousel"),h=b("./external_funcs"),g={duration:350,swipe_sensitivity:150,disable_slide:!1,disable_clicktoslide:!1,disable_scroll:!1,start:0,one_item:!1,pan_threshold:0.3,disable_autowidth:!1,parent_width:!1,swipe_out:!1,left_sided:!1,infinite:!1};
$.fn.itemslide=function(d){var c=$.extend(!0,{},k);
h.apply(this,c),c.create($.extend(g,d),this)
}
}).call(this,"undefined"!=typeof global?global:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{})
},{"./carousel":2,"./external_funcs":3,"./polyfills":7}],5:[function(d,c){c.exports={add:function(h,g,n,m){var l=0,k=4;
m.mousewheel(function(f){if(!n.get_vertical_pan()){var e=f.deltaFactor>=100||f.deltaFactor%1==0;
if(!e&&(l++,l==k)){return void (l=0)
}f.preventDefault();
var b=h.vars.currentIndex-((0==f.deltaX?f.deltaY:f.deltaX)>0?1:-1);
if(b>=m.children("li").length||0>b){return
}h.vars.velocity=0,g.gotoSlideByIndex(b)
}})
}}
},{}],6:[function(g,f){function l(){window.getSelection?window.getSelection().empty?window.getSelection().empty():window.getSelection().removeAllRanges&&window.getSelection().removeAllRanges():document.selection&&document.selection.empty()
}function k(b){return null==$.fn.jquery?b.changedTouches[0]:b.originalEvent.touches[0]||b.originalEvent.changedTouches[0]
}var h=function(L,K){function J(m){if("true"!==$(m.target).attr("no-drag")&&G.end_animation){var e;
e="touchstart"==m.type?k(m):m,C=Date.now(),B=1,A=0,z=e.pageX,y=e.pageY,v=!1,x=!1,G.savedSlide=$(this),G.savedSlideIndex=G.savedSlide.index(),w=0,$(window).on("mousemove touchmove",function(b){I(b)
}),l()
}}function I(b){var e;
if("touchmove"==b.type?(e=k(b),Math.abs(e.pageX-z)>10&&(A=1),A&&b.preventDefault()):(e=b,F.disable_slide||F.swipe_out||b.preventDefault()),E.direction=-(e.pageX-z)>0?1:-1,K.isOutBoundaries()?c&&(d=e.pageX,c=0):(c||(K.currentLandPos=G.translate3d().x,z=e.pageX),c=1),1==w&&(G.children().css("height",E.slideHeight),G.savedSlide.wrapAll("<div class='itemslide_slideoutwrap' />"),w=-1),Math.abs(e.pageX-z)>6&&(!v&&G.end_animation&&(x=!0),window.cancelAnimationFrame(K.slidesGlobalID)),Math.abs(e.pageY-y)>6&&!x&&G.end_animation&&(v=!0),x){if(F.disable_slide){return
}F.left_sided&&(K.currentLandPos=clamp(-(E.allSlidesWidth-G.parent().width()),0,K.currentLandPos)),v=!1,G.translate3d((0==c?d-z+(e.pageX-d)/4:e.pageX-z)+K.currentLandPos),G.trigger("changePos"),G.trigger("pan")
}else{v&&F.swipe_out&&(b.preventDefault(),$(".itemslide_slideoutwrap").translate3d(0,e.pageY-y),-1!=w&&(w=1))
}}function H(b){if(B){B=!1;
var o;
if(o="touchend"==b.type?k(b):b,$(window).off("mousemove touchmove"),v&&F.swipe_out){return v=!1,void D()
}if(G.end_animation&&!F.disable_slide){var n=Date.now()-C;
n++,E.velocity=-(o.pageX-z)/n,E.direction=E.velocity>0?1:-1,E.distanceFromStart=(o.pageX-z)*E.direction*-1;
var m=K.getLandingSlideIndex(E.velocity*F.swipe_sensitivity-G.translate3d().x);
if(E.distanceFromStart>6){return void K.gotoSlideByIndex(m)
}}G.trigger({type:"clickSlide",slide:G.savedSlideIndex}),G.savedSlideIndex==E.currentIndex||F.disable_clicktoslide||(b.preventDefault(),K.gotoSlideByIndex(G.savedSlideIndex))
}}var G=L.$el,F=L.options,E=L.vars,D=L.swipeOut;
this.createEvents=function(){G.children().on("mousedown touchstart",function(b){J.call(this,b)
}),$(window).on("mouseup touchend",function(b){H(b)
})
},this.createEvents();
var C,B,A,z,y,x,w,v=!1;
this.get_vertical_pan=function(){return v
};
var d,c
};
f.exports=h
},{}],7:[function(){"function"!=typeof Object.create&&(Object.create=function(d){function c(){}return c.prototype=d,new c
}),$.fn.outerWidth=function(){if($(this)[0] instanceof Element){var e=$(this)[0],d=e.offsetWidth,f=getComputedStyle(e);
return d+=parseInt(f.marginLeft)+parseInt(f.marginRight)
}}
},{}],8:[function(e,d){function f(L){function K(){if(w=Date.now()-D,x){$(".itemslide_slideoutwrap").translate3d(0,C-easeOutBack(w,0,C-E,250,0)),H.savedSlide.css("opacity",z-easeOutBack(w,0,z,250,0)*(y?-1:1))
}else{if(y){return $(".itemslide_slideoutwrap").children().unwrap(),$(t).children().unwrap(),H.children().css("height",""),H.end_animation=!0,void (w=0)
}$(t).translate3d(0-easeOutBack(w-250,0,0+H.savedSlide.width(),125,0)*(u?-1:1),0)
}return 1==v&&($(".itemslide_slideoutwrap").children().unwrap(),H.savedSlideIndex==F.currentIndex&&$(t).children(":nth-child(1)").addClass("itemslide-active"),H.savedSlideIndex!=H.children().length-1||u||H.savedSlideIndex!=F.currentIndex||(G.duration=200,L.anim.gotoSlideByIndex(H.children().length-2)),0==H.savedSlideIndex&&0!=F.currentIndex&&(w=500),v=-1),w>=250&&(x=!1,-1!=v&&(v=1),w>=375)?($(t).children().unwrap(),H.removeSlide(J.index()),(0==H.savedSlideIndex&&0!=F.currentIndex||u)&&L.anim.gotoSlideByIndex(F.currentIndex-1,!0),G.duration=A,w=0,void (H.end_animation=!0)):void (B=requestAnimationFrame(K))
}var J,I,H=L.$el,G=L.options,F=L.vars,E=-400,D=Date.now(),C=0,B=0,A=0,z=0;
H.end_animation=!0,H.savedSlideIndex=0;
var y=!1;
L.swipeOut=function(){C=$(".itemslide_slideoutwrap").translate3d().y,I=0>C,E=I?-400:400,Math.abs(0-C)<50?(y=!0,E=0):(y=!1,H.trigger({type:"swipeout",slide:H.savedSlideIndex})),v=0,A=G.duration,J=H.savedSlide,D=Date.now(),z=H.savedSlide.css("opacity"),H.savedSlideIndex<F.currentIndex?(u=!0,H.children(":nth-child(-n+"+(H.savedSlideIndex+1)+")").wrapAll("<div class='itemslide_move' />")):(u=!1,H.children(":nth-child(n+"+(H.savedSlideIndex+2)+")").wrapAll("<div class='itemslide_move' />")),x=!0,H.end_animation=!1,B=requestAnimationFrame(K)
};
var x=!0,w=0,v=0,u=!1,t=".itemslide_move"
}d.exports={slideout:f}
},{}]},{},[4]);
$(document).ready(function(){$(".clickable").each(function(){var $this=$(this);
if($this.find(".btn").length==1){$this.css("cursor","pointer")
}});
$(document).on("click",".clickable",function(e){var btn=$(this).find(".btn");
if(btn.length==1){e.preventDefault();
var url=btn.attr("href")||window.location.href;
var target=btn.attr("target")||"_self";
eval(btn.attr("onmousedown"));
eval(btn.attr("onclick"));
window.open(url,target)
}})
});
var pwsGallery=(function(){var g=[];
var b=[];
function k(l,n){if($("#"+n+" .pws_slide_pager_num .allslide").is(":empty")){var m=$("#"+n+" ul.pws_slide_gallery li").not(".bx-clone").length;
$("#"+n+" .pws_slide_pager_num .allslide").text(m)
}$("#"+n+" .pws_slide_pager_num .current").text(l)
}function h(n,l){var m=c(n,l);
if($("#"+n+" .pws_slide_gallery").find(".bx-clone").length==0){g[l]=$("#"+n+" .pws_slide_gallery").bxSlider(m)
}}var c=function(m,l){return{pagerCustom:"#"+m+" .pws_slide_pager",onSliderLoad:function(n){k(n+1,m)
},onSlideBefore:function(p,o,n){k(n+1,m);
e(o,m)
},onSlideAfter:function(r,q,o){var p=parseInt(m.replace("pws_slide_gallery_",""));
b[p].gotoSlide(o)
}}
};
function e(l,m){var n=$("#"+m+" li").not(".bx-clone");
n.each(function(q){if(q==l){var p=$(this).find("iframe");
var o=$(this).find("video");
if(p.length>0){var r=p.prop("src");
p.attr("src","");
p.attr("src",r)
}if(o.length>0){o[0].pause()
}}})
}function d(){$(".pws_gallery").each(function(m,o){var n="pws_slide_gallery_"+m;
var p="pws_pager_"+m;
$(this).attr("id",n);
$(this).find(".pws_slide_pager_in").attr("id",p);
if($(this).is(":visible")){h(n,m)
}});
$(".pws_slide_pager_in").each(function(m,n){b[m]=$(this);
if($(this).is(":visible")){b[m].itemslide({disable_autowidth:true,left_sided:true,disable_scroll:true})
}});
var l;
$(".pws_modal_gallery").on("shown.bs.modal",function(r){if($(this).find(".pws_gallery_slide_modal .modal-slider").length==0){$(this).find(".pws_gallery_slide_modal").html('<ul class="modal-slider"></ul>');
var n=$(this).attr("id");
var m=$('.fullview_gallery[data-target="#'+n+'"]').closest(".pws_gallery").find(".pws_slide_gallery").clone();
var p=$('.fullview_gallery[data-target="#'+n+'"]').closest(".pws_gallery").find(".itemslide-active").children().attr("data-slide-index");
m.find("li").each(function(s,t){if($(this).hasClass("bx-clone")){$(this).remove()
}});
m=m.html();
$(this).find(".modal-slider").append(m);
l=$(this).find(".pws_gallery_slide_modal ul").bxSlider({pager:false,startSlide:p});
var q=$('[data-target="#'+$(this).attr("id")+'"]').closest(".pws_gallery").attr("id");
var o=$("#"+q+".pws_gallery .pws_slide_pager li a.active").data("slide-index");
e(o,q)
}$(window).trigger("resize")
});
$(".pws_modal_gallery").on("hide.bs.modal",function(m){l.destroySlider();
$(this).find(".pws_gallery_slide_modal .modal-slider").remove()
})
}function f(n){var l=n.replace("pws_slide_gallery_","");
var m=c(n,l);
var o=$("#"+n+" .pws_slide_gallery");
if($("#"+n).find(".bx-wrapper").length==0){o.bxSlider(m);
b[l].itemslide({disable_autowidth:true,left_sided:true,disable_scroll:true})
}}return{start:d,reloadSlide:f}
})();
$(document).ready(function(){pwsGallery.start()
});
try{if(!Object.keys){Object.keys=(function(){var d=Object.prototype.hasOwnProperty,e=!({toString:null}).propertyIsEnumerable("toString"),c=["toString","toLocaleString","valueOf","hasOwnProperty","isPrototypeOf","propertyIsEnumerable","constructor"],b=c.length;
return function(h){if(typeof h!=="object"&&(typeof h!=="function"||h===null)){throw new TypeError("Object.keys called on non-object")
}var f=[],k,g;
for(k in h){if(d.call(h,k)){f.push(k)
}}if(e){for(g=0;
g<b;
g++){if(d.call(h,c[g])){f.push(c[g])
}}}return f
}
}())
}}catch(err){}var WAUtilsObj=function(b){this.debug=false;
this.win=b;
this.log("Init WAUtilsObj");
this.defaultParams={lang:"it"};
this.params=null;
this.log("WAUtilsObj init ended");
return this
};
WAUtilsObj.prototype.getDateTime=function(){var e=new Date(),f=e.getFullYear(),g=e.getMonth()+1,c=e.getDate(),b=e.getHours(),h=e.getMinutes(),d=e.getSeconds();
if(g.toString().length===1){g="0"+g
}if(c.toString().length===1){c="0"+c
}if(b.toString().length===1){b="0"+b
}if(h.toString().length===1){h="0"+h
}if(d.toString().length===1){d="0"+d
}return b+":"+h+":"+d
};
WAUtilsObj.prototype.log=function(b){if(this.debug===false){return
}if(typeof console!=="undefined"){console.log("[DEBUG "+this.getDateTime()+"] - "+b)
}};
WAUtilsObj.prototype.getParams=function(){if(this.params===null){this.params=this.defaultParams
}return this.params
};
WAUtilsObj.prototype.isUtagPresent=function(){var b=typeof window.utag!=="undefined";
if(!b){this.log("utag is undefined")
}return b
};
WAUtilsObj.prototype.isUtagPresent=function(){var b=typeof window.utag!=="undefined";
if(!b){this.log("utag is undefined")
}return b
};
WAUtilsObj.prototype.isDataLayerPresent=function(){var b=typeof window.dataLayer!=="undefined";
if(!b){this.log("dataLayer is undefined")
}return b
};
WAUtilsObj.prototype.cloneObject=function(d,c){if(d==null||typeof d!="object"){return d
}if(d.constructor!=Object&&d.constructor!=Array){return d
}if(d.constructor==Date||d.constructor==RegExp||d.constructor==Function||d.constructor==String||d.constructor==Number||d.constructor==Boolean){return new d.constructor(d)
}c=c||new d.constructor();
for(var b in d){c[b]=typeof c[b]=="undefined"?this.cloneObject(d[b],null):c[b]
}return c
};
WAUtilsObj.prototype.cloneDataLayer=function(b){try{if(this.isDataLayerPresent()){return this.cloneObject(window.dataLayer,b)
}else{return{}
}}catch(c){this.log("Error cloning DataLayer")
}this.log("ooops");
return null
};
WAUtilsObj.prototype.view=function(b){if(!this.isUtagPresent()){return
}if(typeof b!=="object"){this.log("view::missed::undefined object");
return
}window.utag.view(b)
};
WAUtilsObj.prototype.link=function(b){if(!this.isUtagPresent()){return
}if(typeof b!=="object"){this.log("link::missed::undefined object");
return
}window.utag.link(b)
};
WAUtilsObj.prototype.getVarRef=function(c){var b=c.replace(/(^[' "]+|[" ']+$)/g,"");
var d=b.match(/(^[\w\$]+(\.[\w\$]+)*)/);
if(d){d=d[1].split(".");
b=window[d.shift()];
while(b&&d.length){b=b[d.shift()]
}}return b||null
};
WAUtilsObj.prototype.initArray=function(element,dropIfNotArray,dropIfExists){if(typeof element!=="string"){this.log("pushObject::string is expected but "+(typeof element)+" is given");
return
}var v=this.getVarRef(element);
if(v===null){eval("window."+element+"=new Array()");
return
}if((dropIfNotArray===true&&Object.prototype.toString.call(v)!=="[object Array]")||dropIfExists===true){v=[]
}};
WAUtilsObj.prototype.pushObject=function(g,c,e,b){if(typeof g!=="string"){this.log("pushObject::string is expected but "+(typeof g)+" is given");
return
}var l=this.getVarRef(g);
if(l!==null&&Object.prototype.toString.call(l)==="[object Array]"){if(typeof e==="undefined"||e===true){var f=this.attributeListToArray(c,b);
var k;
for(var h=l.length-1;
h>=0;
h--){k=false;
for(var d=f.length-1;
d>=0&&!k;
d--){if(l[h][f[d]]!==c[f[d]]){k=true
}}if(!k){return
}}l.push(c)
}else{l.push(c)
}}};
WAUtilsObj.prototype.removeObjects=function(f,c,k,b){if(typeof f!=="string"){this.log("pushObject::string is expected but "+(typeof f)+" is given");
return
}var l=this.getVarRef(f);
if(l!==null&&Object.prototype.toString.call(l)==="[object Array]"){var e=Object.keys(c);
var h;
for(var g=l.length-1;
g>=0;
g--){h=e.length;
for(var d=e.length-1;
d>=0&&h>0;
d--){if((l[g][e[d]]===c[e[d]])===k){if(b===true){h=0
}else{h--
}}}if(h<=0){l.splice(g,1)
}}}};
WAUtilsObj.prototype.attributeListToArray=function(d,c){var b;
if(typeof c==="undefined"||c===null||typeof c!=="string"||c===""){b=Object.keys(d)
}else{b=c.split(" ");
for(j=b.length-1;
j>=0;
j--){if(typeof d[b[j]]==="undefined"){b.splice(j,1)
}}if(b.length===0){b=Object.keys(d)
}}return b
};
WAUtilsObj.prototype.pushProduct=function(c,d,b){var e="dataLayer.aProduct";
this.initArray(e,true,false);
this.pushObject(e,c,d,b)
};
WAUtilsObj.prototype.pushEngagement=function(c,d,b){var e="dataLayer.aEngagement";
this.initArray(e,true,false);
this.pushObject(e,c,d,b)
};
WAUtilsObj.prototype.removeEngagement=function(c,b){var d="dataLayer.aEngagement";
this.initArray(d,true,false);
this.removeObjects(d,c,true,b)
};
WAUtilsObj.prototype.removeEngagementNotEqual=function(c,b){var d="dataLayer.aEngagement";
this.initArray(d,true,false);
this.removeObjects(d,c,false,b)
};
WAUtilsObj.prototype.pushAirMessage=function(c,d,b){var e="dataLayer.aAirMessage";
this.initArray(e,true,false);
this.pushObject(e,c,d,b)
};
WAUtilsObj.prototype.parseQueryString=function(k){var b=null;
try{var c,e=/\+/g,d=/([^&=]+)=?([^&]*)/g,h=function(l){return decodeURIComponent(l.replace(e," "))
},g=k.location.search.substring(1);
b={};
while(c=d.exec(g)){b[h(c[1])]=h(c[2])
}return b
}catch(f){b=null;
this.log("Error retrieving querystring params")
}return b
};
WAUtilsObj.prototype.getQueryStringParam=function(e,d){try{if(typeof d!=="string"||d.trim()===""){return""
}var b=this.parseQueryString(e);
if(typeof b!=="object"||typeof b[d]!="string"){return""
}return typeof b[d]
}catch(c){this.log("Error retrieving the querystring param")
}return""
};
WAUtilsObj.prototype.setQSParamToDL=function(win,paramName,dlParamName){try{var paramValue=this.getQueryStringParam(win,paramName);
var v=this.getVarRef(dlParamName);
if(v===null){eval("window."+element+'=""');
v=this.getVarRef(dlParamName)
}if(v!==null){v=paramValue
}else{this.loog("Error retrievin new DL parameter")
}}catch(err){this.log("Error retrieving the querystring param")
}return""
};
(function(){window.waUtilsObj=waUtilsObj=new WAUtilsObj(window)
})();
function parseQueryString(k){var b=null;
try{var c,e=/\+/g,d=/([^&=]+)=?([^&]*)/g,h=function(l){return decodeURIComponent(l.replace(e," "))
},g=k.location.search.substring(1);
b={};
while(c=d.exec(g)){b[h(c[1])]=h(c[2])
}return b
}catch(f){b=null;
if(typeof console!=="undefined"){console.log("Error retrieving query string params")
}}return b
}function viewport(){var c=window,b="inner";
if(!("innerWidth" in window)){b="client";
c=document.documentElement||document.body
}return c[b+"Width"]
}if(viewport()<768){$(".third_mobile").html($(".third").html())
}$(window).resize(function(){if(viewport()<768){if($(".third_mobile").html()==""){$(".third_mobile").html($(".third").html())
}$(".third").html("")
}else{if($(".third").html()==""){$(".third").html($(".third_mobile").html())
}$(".third_mobile").html("")
}});
$(document).off("click",".prefooter_box .select_boxfooter ul li");
$(document).on("click",".prefooter_box .select_boxfooter ul li",function(b){$(this).closest(".prefooter_box").slideUp();
$("html,body").animate({scrollTop:0},"slow")
});
$(updateBoxDimension);
$(window).on("load scroll resize orientationchange",updateBoxDimension);
function updateBoxDimension(){var g=$("#boxcash_boxfooter1");
var f=$("#boxcash_boxfooter2");
var e=$("#boxcash_boxfooter3");
var d=(g.parent().height())/2-(g.height()/2);
var c=(f.parent().height())/2-(f.height()/2);
var b=(e.parent().height())/2-(e.height()/2);
g.css("margin-top",d+"px");
f.css("margin-top",c+"px");
e.css("margin-top",b+"px");
setHeightPrefooter(".boxcash_boxfooter");
setHeightPrefooter(".prefooter_box .big");
setHeightPrefooter(".prefooter_box .rate");
setHeightPrefooter(".prefooter_box .type");
setHeightPrefooter(".prefooter_box .tan-taeg");
setWidthPrefooter()
}function setHeightPrefooter(b){if($(b).length>1){var c=0;
$(b).each(function(){$(this).css("height","");
if(parseFloat($(this).css("height").replace("px",""))>c){c=parseFloat($(this).css("height").replace("px",""))
}});
$(b).css("height",c+"px")
}}function setWidthPrefooter(){if($(".prefooter_box .minuspadd").length>1){if($(window).width()>768){$(".prefooter_box .minuspadd").css("width","");
$(".prefooter_box .minuspadd").css("min-width","");
if($(".prefooter_box .content_box").height()>300){var b=($(".prefooter_box .content_box").outerWidth(true)-5)/$(".prefooter_box .minuspadd").length;
$(".prefooter_box .minuspadd").css("width",b+"px");
$(".prefooter_box .minuspadd").css("min-width",b+"px")
}}else{$(".prefooter_box .minuspadd").css("width","");
$(".prefooter_box .minuspadd").css("min-width","")
}}}function position_headerfix_boxfooter(){if($("body.bvi .headerfix_boxfooter").length){if($(".sidebar").hasClass("open")){$(".headerfix_boxfooter").css("left","");
$(".headerfix_boxfooter").css("margin-left","");
if($(window).width()>1227){if($(".headerfix_boxfooter").css("left")=="80px"){$(".headerfix_boxfooter").animate({left:"280px"},"slow",function(){})
}}else{$(".headerfix_boxfooter").css("margin-left","0px");
$(".headerfix_boxfooter").css("left","355px")
}}else{if($(window).width()>1027){if($(".headerfix_boxfooter").css("left")=="280px"){$(".headerfix_boxfooter").animate({left:"80px"},"slow",function(){})
}}else{$(".headerfix_boxfooter").css("margin-left","0px");
$(".headerfix_boxfooter").css("left","155px")
}}}if($(".bg-title .pws_strip_bvi").length){$(".bg-title .pws_strip_bvi").css("margin-left","-"+$(".pws_strip_bvi").css("width"))
}setWidthPrefooter()
}function actionPreFooter(){if($(".headerfix_boxfooter").length){$(".headerfix_boxfooter").css("width",$(".header_boxfooter").width()+"px")
}setHeightPrefooter(".boxcash_boxfooter");
setHeightPrefooter(".prefooter_box .big");
setHeightPrefooter(".prefooter_box .rate");
setHeightPrefooter(".prefooter_box .type");
setHeightPrefooter(".prefooter_box .tan-taeg");
setWidthPrefooter();
removeHeaderBox()
}$(window).on("load scroll resize orientationchange",removeHeaderBox);
function removeHeaderBox(){if(!$(".prefooter_box").hasClass("ce-not-show-ce")){if($(".header_boxfooter").length||$(".table_boxfooter").length){if(isElementInViewport($(".header_boxfooter"))||isElementInViewport($(".table_boxfooter"))){$(".headerfix_boxfooter").remove()
}}}position_headerfix_boxfooter()
}$(window).load(removeHeaderBox);
$(removeHeaderBox);
function isElementInViewport(b){if((b.width()>0)&&(b.is(":visible"))){var c=b[0].getBoundingClientRect();
return(c.top>=0&&c.left>=0&&c.bottom<=(window.innerHeight||document.documentElement.clientHeight)&&c.right<=(window.innerWidth||document.documentElement.clientWidth))
}else{return false
}}$(document).off("click",".prefooter_box .headerfix_boxfooter");
$(document).on("click",".prefooter_box .headerfix_boxfooter",function(c){if($("body").hasClass("pws")){var b=$("#header").height();
if($("body").hasClass("submenu_open")){b=b+40
}$("html, body").animate({scrollTop:($(".header_boxfooter").offset().top-b)})
}else{$("html, body").animate({scrollTop:($(".header_boxfooter").offset().top-$("header").height())})
}});
$(document).off("click",".prefooter_box .close_scrool_box");
$(document).on("click",".prefooter_box .close_scrool_box",function(b){b.stopPropagation();
$(".prefooter_box .headerfix_boxfooter").slideDown("slow","linear",function(){$(".prefooter_box .headerfix_boxfooter").hide()
})
});
$(document).off("click",".custom-select .selected-value");
$(document).on("click",".custom-select .selected-value",function(b){var c=$(this);
if(!$(this).hasClass("custom-select")){c=c.closest(".custom-select")
}if(c.find("ul").find("li").length){c.toggleClass("open")
}$(".custom-select").not(c).removeClass("open")
});
$(document).off("click",".custom-select ul li");
$(document).on("click",".custom-select ul li",function(e){$(this).closest(".custom-select").removeClass("open");
var d=$(this).html();
var f=$(this).data("value");
var c=$(this).find("span").attr("class");
$(this).parents(".custom-select").find(".selected-value").empty().append(d).data("value",f);
$(this).parents("tr").prev("tr").find(".icons span").removeClass().addClass(c);
$(this).parent().find("li").removeClass("active");
$(this).addClass("active");
if($("body").hasClass("pws")){var b;
if($(".pws_multi_column").length>1){b=$(this).closest(".pws_multi_column").find(".box-content")
}else{if($(".pws_card_category").length>1){b=$(".pws_card_category")
}}if(b){filterElement(f,b)
}$(this).closest("form").find('input[type="hidden"]').attr("value",f)
}});
$(document).on("click",function(b){if(!$(b.target).closest(".custom-select").length){$(".custom-select").removeClass("open")
}});
$(document).off("click",".balance_smart_link_complex:not(.smart_open) .balance_smart_link_inside");
$(document).on("click",".balance_smart_link_complex:not(.smart_open) .balance_smart_link_inside",function(){$(".balance_smart_link_complex").addClass("smart_open");
$(".balance_obscure").css("display","block");
$(".balance_obscure").animate({"background-color":"rgba(0, 0, 0, 0.5)"},300)
});
$(document).off("click",".balance_smart_link_complex .select_balance_smart ul li");
$(document).on("click",".balance_smart_link_complex .select_balance_smart ul li",function(b){$(".balance_smart_link_complex .balance_box table").css("display","none");
$(".balance_obscure").animate({"background-color":"rgba(0, 0, 0, 0.0)"},300);
$(".balance_smart_link_complex .balance_box").animate({height:0},250,"swing",function(){$(".balance_smart_link_complex").slideUp(50,function(){$(".balance_obscure").css("display","none")
})
})
});
$(document).off("click",".inline_strip:not(.simple)");
$(document).on("click",".inline_strip:not(.simple)",function(){$(this).find(".simple").hide();
$(this).removeClass("inline_strip");
$(this).addClass("inline_strip_complex").animate({height:117},300,"swing",function(){$(this).find(".inline_strip_arrow.complex").show();
$(this).find(".bg_white").show()
})
});
$(document).off("click",".inline_strip_complex .select_inline_strip ul li");
$(document).on("click",".inline_strip_complex .select_inline_strip ul li",function(b){$(this).closest(".wrap_cta").css("position","relative");
$(this).closest(".inline_strip_arrow").removeClass("inline_strip_arrow");
$(this).closest(".complex").animate({height:0},300,"swing",function(){$(this).closest("tr").prev().find(".inline_strip_icon_wrapper").remove();
$(this).closest("tr").remove()
}).parent().animate({height:0},300,"swing",function(){})
});
$(document).off("click","#header .logout.showChooseDca a.logout-header-url");
$(document).on("click","#header .logout.showChooseDca a.logout-header-url",function(b){b.preventDefault();
if($("#header .logout-submenu").css("display")=="block"){$("#header .logout-submenu").slideUp(function(){$("#header .logout-titles").removeClass("logout-subtitles-hidden")
})
}else{$("#header .logout-submenu").slideDown(function(){$("#header .logout-titles").addClass("logout-subtitles-hidden")
})
}});
$(document).on("mouseleave","#header .logout",function(b){if($("#header .logout-titles").hasClass("logout-subtitles-hidden")){$("#header .logout-submenu").slideUp(function(){$("#header .logout-titles").removeClass("logout-subtitles-hidden")
})
}});
function startSpinner(b,c){b.append('<div class="pwsSpinner"><img src="'+c+'/etc/designs/gimb/img/blue-spinner.gif"></div>').addClass("positionRelative")
}function endSpinner(b){b.removeClass("positionRelative").children(".pwsSpinner").remove()
}function endsWith(c,b){return c.indexOf(b,c.length-b.length)!==-1
}function goToPublic(){try{$("head link[href$='bootstrap.css']").attr("disabled","disabled");
if($("head link[href$='main2.css']").length==0){var f=$("link[href*='etc/designs']").attr("href");
var b=f.split("/etc");
var c=b[0]+"/etc/designs/ucpublic/it/clientlibs/main2.css";
$("<link/>",{rel:"stylesheet",type:"text/css",href:c}).appendTo("head")
}else{if($("head link[href$='main2.css']").attr("disabled")=="disabled"){$("head link[href$='main2.css']").removeAttr("disabled")
}}$("body").addClass("pri_to_pub pws home");
$("body").removeClass("bvi pri_to_bvi")
}catch(d){console.log("Errore goToPrivate in engagement")
}}function goToPrivate(){try{$("head link[href$='bootstrap.css']").removeAttr("disabled");
if($("head link[href$='main2.css']").length>0){$("head link[href$='main2.css']").attr("disabled","disabled")
}$("body").removeClass("pri_to_pub pws home submenu_open pri_to_bvi");
$("body").addClass("bvi");
clearInjectContainer();
localStorage.removeItem("seamlessStatus");
console.log("*** GO TO PRIVATE ***")
}catch(b){console.log("Errore goToPrivate in engagement")
}}function goToBvi(){try{$("head link[href$='bootstrap.css']").removeAttr("disabled");
if($("head link[href$='main2.css']").length==0){var f=$("link[href*='etc/designs']").attr("href");
var b=f.split("/etc");
var c=b[0]+"/etc/designs/ucpublic/it/clientlibs/main2.css";
$("<link/>",{rel:"stylesheet",type:"text/css",href:c}).appendTo("head")
}else{if($("head link[href$='main2.css']").attr("disabled")=="disabled"){$("head link[href$='main2.css']").removeAttr("disabled")
}}$("body").removeClass("pri_to_pub pws home submenu_open");
$("body").addClass("bvi pri_to_bvi")
}catch(d){console.log("Errore goToBvi in engagement")
}}function showCurtainOverlay(){console.log("*** SHOW CURTAIN OVERLAY ??? ***");
if((localStorage.seamlessStatus!=undefined)&&(localStorage.seamlessStatus=="active")){if($(".curtainOverlay").length==0){$("body").css("background-color","white");
$("#injectedContent").parent().append('<div class="curtainOverlay"></div>');
$(".curtainOverlay").animate({opacity:1},1000);
console.log("*** CURTAIN OVERLAY ACTIVATED ***")
}else{console.log("*** CURTAIN OVERLAY ALREADY VISIBLE ***")
}}}function hideCurtainOverlay(){console.log("*** HIDE CURTAIN OVERLAY ??? ***");
if((localStorage.seamlessStatus!=undefined)&&(localStorage.seamlessStatus=="active")){if($(".curtainOverlay").length>0){$("body").css("background-color","");
$(".curtainOverlay").animate({opacity:0},1200,function(){$(".curtainOverlay").remove();
console.log("*** CURTAIN OVERLAY DELETED ***")
})
}}}function clearInjectContainer(){if((localStorage.seamlessStatus!=undefined)&&(localStorage.seamlessStatus=="active")){$("#injectedContent").empty();
$("#injectedContent").append('<div class="main_content"></div>');
console.log("*** INJECTEDCONTENT CLEARED ***")
}}function InjectModalError(){console.log("*** OPENING INJECT LOAD ERROR MODAL ***");
SinglePageNav.modalInject("/prv/publictoprv-error.modal");
clearInjectContainer();
hideCurtainOverlay();
localStorage.removeItem("seamlessStatus")
}(function(d){if(d.fn.style){return
}var c=function(e){return e.replace(/[-[\]{}()*+?.,\\^$|#\s]/g,"\\$&")
};
var b=!!CSSStyleDeclaration.prototype.getPropertyValue;
if(!b){CSSStyleDeclaration.prototype.getPropertyValue=function(e){return this.getAttribute(e)
};
CSSStyleDeclaration.prototype.setProperty=function(f,g,e){this.setAttribute(f,g);
var e=typeof e!="undefined"?e:"";
if(e!=""){var h=new RegExp(c(f)+"\\s*:\\s*"+c(g)+"(\\s*;)?","gmi");
this.cssText=this.cssText.replace(h,f+": "+g+" !"+e+";")
}};
CSSStyleDeclaration.prototype.removeProperty=function(e){return this.removeAttribute(e)
};
CSSStyleDeclaration.prototype.getPropertyPriority=function(e){var f=new RegExp(c(e)+"\\s*:\\s*[^\\s]*\\s*!important(\\s*;)?","gmi");
return f.test(this.cssText)?"important":""
}
}d.fn.style=function(f,k,e){var h=this.get(0);
if(typeof h=="undefined"){return this
}var g=this.get(0).style;
if(typeof f!="undefined"){if(typeof k!="undefined"){e=typeof e!="undefined"?e:"";
g.setProperty(f,k,e);
return this
}else{return g.getPropertyValue(f)
}}else{return g
}}
})(jQuery);
var injectModalPWS;
$(document).ready(function(){injectModalPWS=function(b){$.ajax({url:b,context:document.body,success:function(c){$("#modal-inject").html(c);
$("#cq-modal").modal({show:true,keyboard:true,backdrop:"static"})
}})
}
});
function dynamicCtaStart(f){console.log("Dynamic CTA Starting");
var b="GESTISCI";
function d(g){var h={};
location.search.replace(/[?&]+([^=&]+)=([^&]*)/gi,function(n,m,l){h[m]=l
});
return g?h[g]:h
}var c=d("profile");
var e="";
if(typeof c!="undefined"){e+="&profile="+c
}if(typeof seamlessSelector!="undefined"){e+="&sameless="+seamlessSelector.replace(".","")
}$(".ctaDynamicFixApp").each(function(h){var g=$(this);
g.removeClass("ctaDynamicFixApp");
var k=g.data("action");
var l=g.attr("id");
if(getProfileType()=="L"){g.attr("href",g.data("href"));
g.attr("target",g.data("target"));
if(typeof g.data("onClick")!="undefined"){g.attr("onClick",g.attr("onClick")+g.data("onClick"))
}if(typeof g.data("onclick")!="undefined"){g.attr("onClick",g.attr("onClick")+g.data("onclick"))
}g.html(g.data("text"));
g.attr("data-ctacode",g.data("ctacode2"));
$("."+l).each(function(m){var n=$(this);
n.removeClass("hidden");
n.attr("href",g.data("href"));
n.attr("target",g.data("target"));
n.attr("onclick",g.data("onClick"));
n.attr("data-ctacode",g.data("ctacode2"));
if(!n.hasClass("onlyLink")){n.html(g.data("text"));
n.removeClass("onlyLink")
}})
}else{g.click(function(){$.cookie("SMCP",JSON.stringify({url1:g.data("href"),url2:g.data(""),url3:g.data(""),url4:g.data(""),url5:"",PRODKEY:"",modal1:g.data("modal"),modal2:g.data(""),modal3:g.data(""),modal4:g.data(""),modal5:""}),{path:"/"})
})
}});
$(".ctaDynamicMain").each(function(k){var h=$(this);
h.removeClass("ctaDynamicMain");
if(h.parents("li.bx-clone").length){return true
}var m=h.data("action");
var n=h.attr("id");
var g=h.data("previewurl");
var l="";
if(typeof g!="undefined"){l+="&previewUrl="+g
}if(getProfileType()=="L"){$.ajax({url:"/bin/gimb/servlet/dynamicCtaServlet?dispatch=getCta&id="+m+l+e,success:function(r){if(r.length>0){var o=0;
var q=1;
if(r.length==2){if(typeof r[o].type!="undefined"&&r[o].type==b){o=1;
q=0
}}$("."+n).each(function(t){var v=$(this);
var s="";
var w="";
var u="";
if(typeof v.attr("onclick")!="undefined"){if(v.attr("onclick").indexOf("esitazioniPWS")!=-1){s=v.attr("onclick").substring(v.attr("onclick").indexOf("esitazioniPWS"))
}if(v.attr("onclick").indexOf("stopPropagation")!=-1){w="event.stopPropagation();"
}}if(r[o].target.indexOf("overlay")!=-1){u=w+"injectModalPWS('"+r[o].href+".modal.html');"+s;
v.attr("href","javascript:void(0)")
}else{u="event.stopPropagation();"+s;
u+=r[o].onclick;
v.attr("href",r[o].href)
}v.attr("target",r[o].target);
v.attr("onclick",u);
v.attr("onmousedown",r[o].onmousedown);
v.attr("data-ctacode",r[o].ctacode);
if(!v.hasClass("onlyLink")){v.html(r[o].label);
v.removeClass("onlyLink")
}v.removeClass("hidden")
});
var p=$(".gestisci-"+n);
if(r.length==2&&p.length>0){p.each(function(s){var t=$(this);
t.attr("href",r[q].href);
t.attr("target",r[q].target);
t.html(r[q].label);
t.removeClass("hidden");
$(".wrapper-gestisci-"+n).removeClass("hidden");
if(typeof r[q].additional!="undefined"){$(".gestisci-additional-"+n).html(r[q].additional)
}})
}}else{$("."+n).each(function(s){var t=$(this);
t.removeClass("hidden")
})
}if(typeof f!="undefined"){f()
}}})
}else{$("."+n).removeClass("hidden");
h.click(function(){$.ajax({url:"/bin/gimb/servlet/dynamicCtaServlet?dispatch=setCookie&id="+m,success:function(o){if(typeof o[0]!="undefined"){$.cookie("SMCP",JSON.stringify({url1:o[0].url1,url2:o[0].url2,url3:o[0].url3,url4:o[0].url4,url5:o[0].url5,url6:o[0].url6,PRODKEY:m}),{path:"/"})
}}})
})
}})
}$(document).ready(function(){$(document).on("SinglePageNav.inject.done.capcampaign",function(c,b){dynamicCtaStart()
})
});
var options={enableHighAccuracy:false,timeout:5000,maximumAge:60*60*1000};
function getLatitudeLongitude(){var c=sessionStorage.getItem("LATLONG");
if(c!=null){goCallCampaign="OK";
return c.split("_")
}try{navigator.geolocation.getCurrentPosition(getCurrentPositionSuccess,getCurrentPositionError,options)
}catch(b){console.log("navigator error");
return[null,null]
}var c=sessionStorage.getItem("LATLONG");
if(c!=null){goCallCampaign="OK";
return c.split("_")
}return[null,null]
}function getCurrentPositionSuccess(b){sessionStorage.setItem("LATLONG",b.coords.latitude+"_"+b.coords.longitude);
goCallCampaign="OK"
}function getCurrentPositionError(b){goCallCampaign="OK";
switch(b.code){case b.PERMISSION_DENIED:console.log("User denied the request for Geolocation.");
break;
case b.POSITION_UNAVAILABLE:console.log("Location information is unavailable.");
break;
case b.TIMEOUT:console.log("The request to get user location timed out.");
break;
case b.UNKNOWN_ERROR:console.log("An unknown error occurred.");
break
}}function getDevice(){var b=localStorage.getItem("DEV");
if(b!=null){return b
}var b="C";
if(isMobileOrTablet()){if(isMobile()){b="M"
}else{b="T"
}}localStorage.setItem("DEV",b);
return b
}function isMobile(){var b=false;
(function(c){if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(c)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(c.substr(0,4))){b=true
}})(navigator.userAgent||navigator.vendor||window.opera);
return b
}function isMobileOrTablet(){var b=false;
(function(c){if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(c)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(c.substr(0,4))){b=true
}})(navigator.userAgent||navigator.vendor||window.opera);
return b
}function getReferrer(){var b=sessionStorage.getItem("refSige");
if(b!=null){return b
}b=document.referrer;
sessionStorage.setItem("refSige",b);
return b
}function loadCampaignPositionClientlib(){var f="";
var l="/bin/gimb/servlet/campaignPosition";
var p="";
var n=99;
var m=false;
$(".campaign-position-check").each(function(q){var r=$(this).attr("id");
r=r.replace("container_","");
f+=r+",";
n=$(this).attr("data-campaignCap");
p=$(this).attr("data-campaignCurrentPath");
currentPageId=$(this).attr("data-currentPageId");
if($(this).attr("data-skip")){m=true
}});
f=f.slice(0,-1);
if(p!=""){var h=getLatitudeLongitude();
if(typeof goCallCampaign!=="undefined"){var e={url:p,positions:f,cap:n,device:getDevice(),lat:h[0],lon:h[1],refSige:getReferrer()};
if(m){e={url:p,positions:f,cap:n,device:getDevice(),lat:h[0],lon:h[1],refSige:getReferrer(),p:true}
}delete goCallCampaign;
$.ajax({method:"GET",url:l,dataType:"json",async:true,cache:false,data:e,success:function(q){if(!$.isEmptyObject(q)&&q.positions&&q.positions.length>0){g(q,m)
}else{$(".campaign-position-check").remove()
}},error:function(){}})
}else{var c=0;
var d=setInterval(function(){c++;
if(typeof goCallCampaign!=="undefined"||c>30){console.log("Parte campaign position al "+c);
var r=getLatitudeLongitude();
var q={url:p,positions:f,cap:n,device:getDevice(),lat:r[0],lon:r[1],refSige:getReferrer()};
if(m){q={url:p,positions:f,cap:n,device:getDevice(),lat:r[0],lon:r[1],refSige:getReferrer(),p:true}
}delete goCallCampaign;
$.ajax({method:"GET",url:l,dataType:"json",async:true,cache:false,data:q,success:function(s){if(!$.isEmptyObject(s)&&s.positions&&s.positions.length>0){g(s,m)
}else{$(".campaign-position-check").remove()
}},error:function(){}});
clearTimeout(d)
}},100)
}}function o(){output=".injectBanner.html";
var q=window.location.href;
if(q.indexOf(".prv")==q.length-4){output=".prv.html"
}else{if(q.indexOf(".bvi")==q.length-4){output=".bvi.html"
}}return output
}function g(r,q){if(r&&r.positions){var s=o();
$.each(r.positions,function(t,u){if(u.position!="MODAL"){$("#container_"+u.position).empty();
$.ajax({url:u.path+s,context:document.body,success:function(v){$("#container_"+u.position).html(k(v,q,u.position));
$("#container_"+u.position).removeClass("campaign-position-check");
successAjaxComponent($("#container_"+u.position).parent().attr("id"),false,u)
}})
}else{$.ajax({url:u.path+s,context:document.body,success:function(v){$("#modal-campaign-inject").html(k(v,q,u.position));
$("#cq-campaign-modal").modal({show:false,keyboard:true,backdrop:"static"});
$(document).off("focusin.modal");
$("#container_"+u.position).removeClass("campaign-position-check");
successAjaxComponent("cq-campaign-modal",false,u)
}})
}})
}}function k(r,s,t){var q=r;
q=b(t,q);
return q
}function b(q,r){var s=/esitazioniPWS.esita\('',/g;
return r.replace(s,"esitazioniPWS.esita('"+q+"',")
}}$(document).ready(function(){if($(".ceContent").length==0){loadCampaignPositionClientlib()
}});
var esitazioniPWS={getCookie:function(d){var c=document.cookie;
c=c.split(";");
for(var b=0;
b<c.length;
b++){unitCookie=c[b].split("=");
if(d==unitCookie[0].trim()){return unitCookie[1]
}}return""
},esitaCtaDynSave:function(d,e,c,b){sessionStorage.setItem("CtaDyn_CAMP",d);
sessionStorage.setItem("CtaDyn_CEID",e);
sessionStorage.setItem("CtaDyn_CETY",c);
sessionStorage.setItem("CtaDyn_CODE",b);
localStorage.setItem("campaign",d);
localStorage.setItem("CO_POSITION_01","PULL");
localStorage.setItem("CO_POSITION_02",c);
localStorage.setItem("CO_POSITION_03",e);
localStorage.setItem("CO_POSITION_04",$("#pageInfo").attr("data-currentPageId"))
},esitaCtaDyn:function(b,e){var c=sessionStorage.getItem("CtaDyn_CAMP");
var g=sessionStorage.getItem("CtaDyn_CEID");
var d=sessionStorage.getItem("CtaDyn_CETY");
var f=((b==null)?sessionStorage.getItem("CtaDyn_CODE"):b);
if(typeof e!="undefined"){f+=e
}sessionStorage.removeItem("CtaDyn_CAMP");
sessionStorage.removeItem("CtaDyn_CEID");
sessionStorage.removeItem("CtaDyn_CETY");
sessionStorage.removeItem("CtaDyn_CODE");
if(c!=null&&g!=null){esitazioniPWS.esita("PULL",g,c,f,d,"CTA","false","false",$(this).attr("href"))
}},esita:function(t,k,n,w,b,h,v,e,g){var o=$("#pageInfo").attr("data-currentPageId");
if(typeof o==="undefined"||o==null){o=k
}var u=getDevice();
var q=getLatitudeLongitude();
var p=new Date();
var d=$.datepicker.formatDate("yy-mm-dd",p);
var y=esitazioniPWS.format_two_digits(p.getHours())+":"+esitazioniPWS.format_two_digits(p.getMinutes())+":"+esitazioniPWS.format_two_digits(p.getSeconds());
var c="false";
if(typeof e!=="undefined"&&e!=null){c=e
}var m="";
var l="";
var z="";
var r="";
if(w!="VIEW"){if(t!="PULL"){sessionStorage.setItem("PbP",g);
sessionStorage.setItem("PbP_CAM",n);
sessionStorage.setItem("PbP_PAG",o);
sessionStorage.setItem("PbP_POS",t);
sessionStorage.setItem("PbP_CEID",k);
sessionStorage.setItem("PbP_CETY",b)
}else{var x=localStorage.getItem("PbP");
if(x!=null&&window.location.href.indexOf(x)!=-1){t="PULLBYPUSH";
n=sessionStorage.getItem("PbP_CAM");
m=sessionStorage.getItem("PbP_PAG");
l=sessionStorage.getItem("PbP_POS");
z=sessionStorage.getItem("PbP_CEID");
r=sessionStorage.getItem("PbP_CETY")
}sessionStorage.removeItem("PbP");
sessionStorage.removeItem("PbP_CAM");
sessionStorage.removeItem("PbP_PAG");
sessionStorage.removeItem("PbP_POS");
sessionStorage.removeItem("PbP_CEID");
sessionStorage.removeItem("PbP_CETY")
}}var s="";
try{s=ucaa.visitor.getMarketingCloudVisitorID()
}catch(f){console.log(" [ERROR] visitorId: utag -> ucca ")
}if(typeof seamlessSelector!=="undefined"&&seamlessSelector!=""){esitazioni.esita(w,b,t,n,o,k,$(this).attr("href"),false,"","","","","",false,c)
}jQuery.get("/bin/gimb/servlet/track?page_id="+o+"&pos_id="+t+"&ce_id="+k+"&campaign_id="+n+"&date_contact="+d+"&time_contact="+y+"&outcome_code="+w+"&ce_type="+b+"&cta_id="+h+"&device="+u+"&event="+v+"&lat="+q[0]+"&lon="+q[1]+"&dyn="+c+"&v_id="+s+"&page_id_from="+m+"&pos_id_from="+l+"&ce_id_from="+z+"&ce_type_from="+r+"&refSige="+getReferrer())
},format_two_digits:function(b){return b<10?"0"+b:b
}};
var renderCE_PWS={mobileAndTabletCheck:function(){var b=false;
(function(c){if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(c)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(c.substr(0,4))){b=true
}})(navigator.userAgent||navigator.vendor||window.opera);
return b
},retrieveDeviceInformation:function(){var c=localStorage.getItem("DEVICE");
if(c!=null){return c
}try{var b=renderCE_PWS.mobileAndTabletCheck();
if(b===false){c="C"
}else{c="T"
}}catch(d){console.log("error retrieve Device information");
c=""
}localStorage.setItem("DEVICE",c);
return c
}};
console.log("clientlib started");
$(document).ready(function(){doGhostTip()
});
function doGhostTip(){if($(".dynamicTab").length>0||$(".lab_container").length){var b;
b=sessionStorage.getItem("userCampaigns");
if(typeof isAuthor!="undefined"&&isAuthor==true){sessionStorage.removeItem("userCampaigns");
b=sessionStorage.getItem("userCampaigns")
}console.log("found LS");
console.log(b);
var e=getDevice();
var f=[];
if(location.href.indexOf("cq5")==-1){f=getLatitudeLongitude()
}else{f=[null,null]
}var d=getReferrer();
if(typeof b=="undefined"||b==null){$.ajax({url:"/bin/gimb/servlet/loadNdg?op=getCampaigns&device="+e+"&lat="+f[0]+"&lon="+f[1]+"&refSige="+d,success:function(g){console.log("result of servlet");
console.log(g);
b=g;
if(typeof b!=undefined&&b!=null&&$.isEmptyObject(b)!=true){sessionStorage.setItem("userCampaigns",JSON.stringify(b));
b=chooseWinningPage(b)
}chooseWinningTip(b)
},error:function(){console.log("error")
}})
}else{var c=chooseWinningPage(JSON.parse(b));
chooseWinningTip(c)
}$("#menu_tab_dropdown").click(function(){$("#contentTab li:visible:not(.noTrack)").each(function(l,o){var g=$(this).data("hrefpageid");
var p=$(this).data("campaigns");
esitazioniPWS.esita("GTABPUB",g,p,"VIEW","J","","false");
var m=sessionStorage.getItem("userCampaigns");
if(typeof m!="undefined"&&m!=null){m=JSON.parse(m);
var h=m[p];
if(h!="undefined"&&h!=null){h=h.split(",");
var k,n;
if(h.length>=1){k=h[0]
}if(h.length>=2){n=parseInt(h[1])-1
}h=k+","+n.toString();
m[p]=h;
sessionStorage.setItem("userCampaigns",JSON.stringify(m))
}}})
})
}}function chooseWinningTip(b){var c=b;
console.log("tip");
console.log("having as user");
console.log(c);
$(".lab_container").each(function(g,m){var l={};
$(this).children(".lab").each(function(q,t){var s=$(t).data("campaigns");
if(typeof s=="undefined"||s.length==0){if($.isEmptyObject(l)==true){l.id=t.id;
l.anom="true"
}else{if(typeof l.anom!="undefined"&&l.anom=="true"){l.id=t.id
}}}if(typeof s!="undefined"&&$.isEmptyObject(c)!=true&&c.hasOwnProperty(s)){if(typeof l.id=="undefined"||(typeof l.anom!="undefined"&&l.anom=="true")){var o=c[s].split(",");
var r;
if(o.length>=2){r=parseInt(o[1])
}if(typeof r!="undefined"&&r>0){l.id=t.id;
l.campaign=s;
l.priority=c[s];
l.anom="false"
}}else{var n=parseInt(l.priority);
var o=c[s].split(",");
var p;
var r;
if(o.length>=1){p=parseInt(o[0])
}if(o.length>=2){r=parseInt(o[1])
}if(p<=n&&r>0){l.id=t.id;
l.campaign=s;
l.priority=c[s];
l.anom="false"
}}}});
if(typeof l!="undefined"&&typeof l.id!="undefined"){if(typeof l.anom!="undefined"&&l.anom=="true"){var k=l.id;
$("#"+k).show()
}else{var e=c[l.campaign].split(",");
var f,h;
if(e.length>=1){f=e[0]
}if(e.length>=2){h=parseInt(e[1])-1
}e=f+","+h.toString();
c[l.campaign]=e;
var k=l.id;
$("#"+k).show();
var d=$("#"+k).data("hrefpageid");
if(d.length>0){esitazioniPWS.esita("PUBTIP",d,l.campaign,"VIEW","C","","false");
$("#"+k).closest(".item_in").find(".item_footer a.btn.border_info").attr("onclick","event.stopPropagation(); esitazioniPWS.esita('PUBTIP','"+d+"', '"+l.campaign+"','CTACAPTION','C','CTA','false');")
}}}});
if(typeof c!="undefined"&&$.isEmptyObject(c)!=true){console.log("saving");
console.log(c);
sessionStorage.setItem("userCampaigns",JSON.stringify(c))
}}function chooseWinningPage(c){var d=c;
var b="9999";
console.log("campaigns");
console.log("having as user");
console.log(d);
$(".dynamicTab").each(function(p,r){var q={};
var t=$(r).data("campaigns").split("|");
$("#"+r.id).data("priority",b);
var n=t.length;
for(var o=0;
o<n;
o++){var h=t[o];
if(d.hasOwnProperty(h)){if(typeof q.id=="undefined"){var s=d[h].split(",");
var l;
if(s.length>=2){l=parseInt(s[1])
}if(typeof l!="undefined"&&l>0){q.id=r.id;
q.campaign=h;
q.priority=d[h]
}}else{var m=parseInt(q.priority);
var s=d[h].split(",");
var k;
var l;
if(s.length>=1){k=parseInt(s[0])
}if(s.length>=2){l=parseInt(s[1])
}if(k<=m&&l>0){q.id=r.id;
q.campaign=h;
q.priority=d[h]
}}}}if(typeof q!="undefined"&&typeof q.id!="undefined"){var s=d[q.campaign].split(",");
var k,l;
if(s.length>=1){k=s[0]
}if(s.length>=2){l=parseInt(s[1])-1
}s=k+","+l.toString();
var g=q.id;
$("#"+g).data("priority",k);
$("#"+g).data("campaigns",q.campaign);
$("#"+g).attr("data-campaigns",q.campaign);
var u=$("#"+g).data("hrefpageid");
var f=$("#"+g+" a").attr("onclick").replace("{{campaign}}",q.campaign);
$("#"+g+" a").attr("onclick",f);
$("#menu_tab_dropdown").css("display","inline-block")
}else{if(t[0].length>0){$("#"+r.id+" a").attr("onclick","");
$("#"+r.id).addClass("skipPage")
}}});
$("#contentTab li").sort(e).appendTo("#contentTab");
function e(g,f){return($(f).data("priority"))<=($(g).data("priority"))?1:-1
}$("#contentTab li:not(.skipPage)").each(function(f,g){if(f<3){$(this).css("display","block")
}});
console.log("saving inside");
console.log(d);
return d
};