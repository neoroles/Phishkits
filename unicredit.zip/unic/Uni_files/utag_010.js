//tealium universal tag - utag.loader ut4.39.201801051549, Copyright 2018 Tealium.com Inc. All Rights Reserved. 

if(typeof utag_err=='undefined')var utag_err=[];window._tealium_old_error=window._tealium_old_error || window.onerror || function(){};window.onerror=function(m,u,l){if(typeof u !== 'undefined' && u.indexOf('/utag.')>0 && utag_err.length < 5)utag_err.push({e:m,s:u,l:l,t:'js'});window._tealium_old_error(m,u,l)};
var utag_condload=false;try{(function(){function ul(src,a,b){a=document;b=a.createElement('script');b.language='javascript';b.type='text/javascript';b.src=src;a.getElementsByTagName('head')[0].appendChild(b)};if((""+document.cookie).match("utag_env_unicredit_uc.it=(\/\/tags\.tiqcdn\.com\/utag\/unicredit\/[^\S;]*)")){if(RegExp.$1.indexOf("/prod/") === -1) {var s = RegExp.$1;while(s.indexOf("%") != -1) {s = decodeURIComponent(s);}s = s.replace(/\.\./g,"");ul(s);utag_condload=true;__tealium_default_path='//tags.tiqcdn.com/utag/unicredit/uc.it/prod/';}}})();}catch(e){};
if (typeof utag == "undefined" && !utag_condload) {
  var utag = {
    id:"unicredit.uc.it",
    o:{},
    sender: {},
    send: {},
    rpt: {
      ts: {
        a: new Date()
      }
    },
    dbi: [],
    loader: {
      q: [],
      lc: 0,
      f: {},
      p: 0,
      ol: 0,
      wq: [],
      lq: [],
      bq: {},
      bk: {},
      rf: 0,
      ri: 0,
      rp: 0,
      rq: [],
      ready_q : [], 
      sendq :{"pending":0},
      run_ready_q : function(){
        for(var i=0;i<utag.loader.ready_q.length;i++){
          utag.DB("READY_Q:"+i);
          try{utag.loader.ready_q[i]()}catch(e){utag.DB(e)};
        }
      },
      lh: function(a, b, c) {
        a = "" + location.hostname;
        b = a.split(".");
        c = (/\.co\.|\.com\.|\.org\.|\.edu\.|\.net\.|\.asn\./.test(a)) ? 3 : 2;
        return b.splice(b.length - c, c).join(".");
      },
      WQ: function(a, b, c, d, g) {
        utag.DB('WQ:' + utag.loader.wq.length);
        try {
          // this picks up a utag_data items added after utag.js was loaded
          // Gotcha: Data layer set after utag.js will not overwrite something already set via an extension.  Only "new" values are copied from utag_data
          // for case where utag_data is set after utag.js is loaded
          if(utag.udoname && utag.udoname.indexOf(".")<0){
            utag.ut.merge(utag.data,window[utag.udoname],0);
          }

          // TBD: utag.handler.RE('view',utag.data,"bwq");
          // process load rules again if this flag is set
          if(utag.cfg.load_rules_at_wait){
            utag.handler.LR(utag.data);
          }
        } catch (e) {utag.DB(e)};
	
	d=0;
        g=[]; 
        for (a = 0; a < utag.loader.wq.length; a++) {
          b = utag.loader.wq[a];
	  b.load = utag.loader.cfg[b.id].load;
          if (b.load == 4){
            //LOAD the bundled tag set to wait here
            this.f[b.id]=0;
            utag.loader.LOAD(b.id)
          }else if (b.load > 0) {
            g.push(b);
            //utag.loader.AS(b); // moved: defer loading until flags cleared
	    d++;
          }else{
            // clear flag for those set to wait that were not actually loaded
            this.f[b.id]=1;
          }
        }
        for (a = 0; a < g.length; a++) {
          utag.loader.AS(g[a]);
        }

	if(d==0){
	  utag.loader.END();
	}
      },
      AS: function(a, b, c, d) {
        utag.send[a.id] = a;
        if (typeof a.src == 'undefined') {
          a.src = utag.cfg.path + ((typeof a.name != 'undefined') ? a.name : 'ut' + 'ag.' + a.id + '.js')
        }
        a.src += (a.src.indexOf('?') > 0 ? '&' : '?') + 'utv=' + (a.v?utag.cfg.template+a.v:utag.cfg.v);
        utag.rpt['l_' + a.id] = a.src;
        b = document;
        this.f[a.id]=0;
        if (a.load == 2) {
          utag.DB("Attach sync: "+a.src);
          a.uid=a.id;
          b.write('<script id="utag_' + a.id + '" src="' + a.src + '"></scr' + 'ipt>')
          if(typeof a.cb!='undefined')a.cb();
        } else if(a.load==1 || a.load==3) {
          if (b.createElement) {
            c = 'utag_unicredit.uc.it_'+a.id;
            if (!b.getElementById(c)) {
	      d = {
	        src:a.src,
		id:c,
                uid:a.id,
		loc:a.loc
              }
              if(a.load == 3){d.type="iframe"};
	      if(typeof a.cb!='undefined')d.cb=a.cb;
              utag.ut.loader(d);
            }
          }
        }
      },
      GV: function(a, b, c) {
        b = {};
        for (c in a) {
          if (a.hasOwnProperty(c) && typeof a[c] != "function") b[c] = a[c];
        }
        return b
      },
      OU: function(a, b, c, d, f){
        try {
          if (typeof utag.data['cp.OPTOUTMULTI'] != 'undefined') {
            c = utag.loader.cfg;
            a = utag.ut.decode(utag.data['cp.OPTOUTMULTI']).split('|');
            for (d = 0; d < a.length; d++) {
              b = a[d].split(':');
              if (b[1] * 1 !== 0) {
                if (b[0].indexOf('c') == 0) {
                  for (f in utag.loader.GV(c)) {
                    if (c[f].tcat == b[0].substring(1)) c[f].load = 0
                  }
                } else if (b[0] * 1 == 0) {
                  utag.cfg.nocookie = true
                } else {
                  for (f in utag.loader.GV(c)) {
                    if (c[f].tid == b[0]) c[f].load = 0
                  }
                }
              }
            }
          }
        } catch (e) {utag.DB(e)}
      },
      RDdom: function(o){
        var d = document || {}, l = location || {};
        o["dom.referrer"] = eval("document." + "referrer");
        o["dom.title"] = "" + d.title;
        o["dom.domain"] = "" + l.hostname;
        o["dom.query_string"] = ("" + l.search).substring(1);
        o["dom.hash"] = ("" + l.hash).substring(1);
        o["dom.url"] = "" + d.URL;
        o["dom.pathname"] = "" + l.pathname;
        o["dom.viewport_height"] = window.innerHeight || (d.documentElement?d.documentElement.clientHeight:960);
        o["dom.viewport_width"] = window.innerWidth || (d.documentElement?d.documentElement.clientWidth:960);
      },
      RDcp: function(o, b, c, d){
        b = b || utag.loader.RC();
        for (d in b) {
          if (d.match(/utag_(.*)/)) {
            for (c in utag.loader.GV(b[d])) {
              o["cp.utag_" + RegExp.$1 + "_" + c] = b[d][c];
            }
          }
        }
        for (c in utag.loader.GV((utag.cl && !utag.cl['_all_']) ? utag.cl : b)) {
          if (c.indexOf("utag_") < 0 && typeof b[c] != "undefined") o["cp." + c] = b[c];
        }
        // temporary alias variables
        o["_t_visitor_id"]=o["cp.utag_main_v_id"];
        o["_t_session_id"]=o["cp.utag_main_ses_id"];
      },
      RDqp: function(o, a, b, c){
        a = location.search + (location.hash+'').replace("#","&");
        if(utag.cfg.lowerqp){a=a.toLowerCase()};
        if (a.length > 1) {
          b = a.substring(1).split('&');
          for (a = 0; a < b.length; a++) {
            c = b[a].split("=");
            if(c.length>1){
              o["qp." + c[0]] = utag.ut.decode(c[1])
            }
          }
        }
      },
      RDmeta: function(o, a, b, h){
        a = document.getElementsByTagName("meta");
        for (b = 0; b < a.length; b++) {
          try{
            h = a[b].name || a[b].getAttribute("property") || ""; 
          }catch(e){h="";utag.DB(e)};
          if (utag.cfg.lowermeta){h=h.toLowerCase()};
          if (h != ""){o["meta." + h] = a[b].content}
        }
      },
      RDva: function(o){
        // Read visitor attributes in local storage
        var readAttr = function(o, l ){
          var a = "", b;
          a = localStorage.getItem(l);
          if(!a || a=="{}")return;
          b = utag.ut.flatten({va : JSON.parse(a)});
          utag.ut.merge(o,b,1);
        }
        try{
          readAttr(o, "tealium_va" );
          readAttr(o, "tealium_va_" + o["ut.account"] + "_" + o["ut.profile"] );
        }catch(e){ utag.DB(e) }
      },
      RDut: function(o, a){
        // Add built-in data types to the data layer for use in mappings, extensions and RDva function.
        o["ut.domain"] = utag.cfg.domain;
        o["ut.version"] = utag.cfg.v;
        // i.e. "view" or "link"
        o["ut.event"] = a || "view";
        try{
          o["ut.account"] = utag.cfg.utid.split("/")[0];
          o["ut.profile"] = utag.cfg.utid.split("/")[1];
          o["ut.env"] = utag.cfg.path.split("/")[6];
        }catch(e){ utag.DB(e) }
      },
      RD: function(o, a, b, c, d) {
        utag.DB("utag.loader.RD");
        utag.DB(o);

        // only update cookie once per page
        if(!utag.loader.rd_flag){
          a = (new Date()).getTime();
          b = utag.loader.RC();
          c = a + parseInt(utag.cfg.session_timeout);
          d = a;
	
	  if(!b.utag_main){
	    b.utag_main={};
	  }else if(b.utag_main.ses_id&&typeof b.utag_main._st!="undefined"&&parseInt(b.utag_main._st)<a){
	    delete b.utag_main.ses_id;
	  }
	
          if(!b.utag_main.v_id){
            b.utag_main.v_id=utag.ut.vi(a);
          }

          if(!b.utag_main.ses_id){
            b.utag_main.ses_id=d+'';
            b.utag_main._ss=b.utag_main._pn=1;
            b.utag_main._sn=1+parseInt(b.utag_main._sn || 0);
          }else{
            d=b.utag_main.ses_id;
            b.utag_main._ss=0;
            b.utag_main._pn=1+parseInt(b.utag_main._pn);
            b.utag_main._sn=parseInt(b.utag_main._sn);
          }

          if(isNaN(b.utag_main._sn) || b.utag_main._sn<1){b.utag_main._sn=b.utag_main._pn=1}

          b.utag_main._st = c+'';

          utag.loader.SC("utag_main", {"v_id": b.utag_main.v_id, "_sn" : b.utag_main._sn, "_ss" : b.utag_main._ss, "_pn" : b.utag_main._pn + ";exp-session", "_st": c, "ses_id": d + ";exp-session"});
        }

        utag.loader.rd_flag=1;

        this.RDqp(o);
        this.RDmeta(o);
        this.RDcp(o,b);
        this.RDdom(o);
        this.RDut(o);
        this.RDva(o);
      },
      RC: function(a, x, b, c, d, e, f, g, h, i, j, k, l, m, n, o, v, ck, cv, r, s, t) {
        o = {};
        b = ("" + document.cookie != "") ? (document.cookie).split("; ") : [];
        r = /^(.*?)=(.*)$/;
        s = /^(.*);exp-(.*)$/;
        t = (new Date()).getTime();
        for (c = 0; c < b.length; c++) {
          if (b[c].match(r)) {
            ck = RegExp.$1;
            cv = RegExp.$2;
          }
          e = utag.ut.decode(cv);
          if (typeof ck!="undefined"){
            if (ck.indexOf("ulog") == 0 || ck.indexOf("utag_") == 0) {
              e = cv.split("$");
              g = [];
              j = {};
              for (f = 0; f < e.length; f++) {
                try{
                  g = e[f].split(":");
                  if (g.length > 2) {
                    g[1] = g.slice(1).join(":");
                  }
                  v = "";
                  if (("" + g[1]).indexOf("~") == 0) {
                    h = g[1].substring(1).split("|");
                    for (i = 0; i < h.length; i++) h[i] = utag.ut.decode(h[i]);
                    v = h
                  } else v = utag.ut.decode(g[1]);
                  j[g[0]] = v;
                }catch(er){utag.DB(er)};
              }
              o[ck] = {};
              for (f in utag.loader.GV(j)) {
                if (j[f] instanceof Array) {
                  n = [];
                  for (m = 0; m < j[f].length; m++) {
                    if (j[f][m].match(s)){
                      k = (RegExp.$2 == "session") ? (typeof j._st != "undefined" ? j._st : t - 1) : parseInt(RegExp.$2);
                      if (k > t) n[m] = (x == 0) ? j[f][m] : RegExp.$1;
                    }
                  }
                  j[f] = n.join("|");
                } else {
                  j[f] = "" + j[f];
                  if (j[f].match(s)) {
                    k = (RegExp.$2 == "session") ? (typeof j._st != "undefined" ? j._st : t - 1) : parseInt(RegExp.$2);
                    j[f] = (k < t) ? null : (x == 0 ? j[f] : RegExp.$1);
                  }
                }
                if (j[f]) o[ck][f] = j[f];
              }
            } else if (utag.cl[ck] || utag.cl['_all_']) {
              o[ck] = e
            }
          }
        }
        return (a) ? (o[a] ? o[a] : {}) : o;
      },
      SC: function(a, b, c, d, e, f, g, h, i, j, k, x, v) {
        if (!a) return 0;
        if (a=="utag_main" && utag.cfg.nocookie) return 0;
        v = "";
        var date = new Date();
        var exp = new Date();
        exp.setTime(date.getTime()+(365*24*60*60*1000));
        x = exp.toGMTString();
        if (c && c == "da") {
          x = "Thu, 31 Dec 2009 00:00:00 GMT";
        } else if (a.indexOf("utag_") != 0 && a.indexOf("ulog") != 0) {
          if (typeof b != "object") {
            v = b
          }
        } else {
          d = utag.loader.RC(a, 0);
          for (e in utag.loader.GV(b)) {
            f = "" + b[e];
            if (f.match(/^(.*);exp-(\d+)(\w)$/)) {
              g = date.getTime() + parseInt(RegExp.$2) * ((RegExp.$3 == "h") ? 3600000 : 86400000);
              if (RegExp.$3 == "u") g = parseInt(RegExp.$2);
              f = RegExp.$1 + ";exp-" + g;
            }
            if (c == "i") {
              if (d[e] == null) d[e] = f;
            } else if (c == "d") delete d[e];
            else if (c == "a") d[e] = (d[e] != null) ? (f - 0) + (d[e] - 0) : f;
            else if (c == "ap" || c == "au") {
              if (d[e] == null) d[e] = f;
              else {
                if (d[e].indexOf("|") > 0) {
                  d[e] = d[e].split("|")
                }
                g = (d[e] instanceof Array) ? d[e] : [d[e]];
                g.push(f);
                if (c == "au") {
                  h = {};
                  k = {};
                  for (i = 0; i < g.length; i++) {
                    if (g[i].match(/^(.*);exp-(.*)$/)) {
                      j = RegExp.$1;
                    }
                    if (typeof k[j] == "undefined") {
                      k[j] = 1;
                      h[g[i]] = 1;
                    }
                  }
                  g = [];
                  for (i in utag.loader.GV(h)) {
                    g.push(i);
                  }
                }
                d[e] = g
              }
            } else d[e] = f;
          }
          h = new Array();
          for (g in utag.loader.GV(d)) {
            if (d[g] instanceof Array) {
              for (c = 0; c < d[g].length; c++) {
                d[g][c] = encodeURIComponent(d[g][c])
              }
              h.push(g + ":~" + d[g].join("|"))
            } else h.push((g + ":").replace(/[\,\$\;\?]/g,"") + encodeURIComponent(d[g]))
          }
          if (h.length == 0) {
            h.push("");
            x = ""
          }
          v = (h.join("$"));
        }
        document.cookie = a + "=" + v + ";path=/;domain=" + utag.cfg.domain + ";expires=" + x;
        return 1
      },
      LOAD: function(a, b, c, d) {
        //utag.DB('utag.loader.LOAD:' + a);
        if(!utag.loader.cfg){
           return
        }
	if(this.ol==0){
          if(utag.loader.cfg[a].block && utag.loader.cfg[a].cbf){
            this.f[a] = 1;
	    delete utag.loader.bq[a];
          }
	  for(b in utag.loader.GV(utag.loader.bq)){
            if(utag.loader.cfg[a].load==4 && utag.loader.cfg[a].wait==0){
              utag.loader.bk[a]=1;
              utag.DB("blocked: "+ a);
            }
	    utag.DB("blocking: " + b);
	    return;
	  }
	  utag.loader.INIT();
	  return;
	}
        utag.DB('utag.loader.LOAD:' + a);

        if (this.f[a] == 0) {
          this.f[a] = 1;
      	
	  if(utag.cfg.noview!=true){
	    if(utag.loader.cfg[a].send){
              utag.DB("SENDING: "+a);
              try{
                if (utag.loader.sendq.pending > 0 && utag.loader.sendq[a]) {
                  utag.DB("utag.loader.LOAD:sendq: "+a);
                  while( d = utag.loader.sendq[a].shift() ) {
                    utag.DB(d);
                    utag.sender[a].send(d.event, utag.handler.C(d.data));
                    utag.loader.sendq.pending--;
                  }
                } else {
                  utag.sender[a].send('view',utag.handler.C(utag.data));
                }
		utag.rpt['s_' + a] = 0;
	      } catch (e) {
                utag.DB(e);
	        utag.rpt['s_' + a] = 1;
	      }
	    }
	  }
	  if(utag.loader.rf==0)return;
          for (b in utag.loader.GV(this.f)) {
            if (this.f[b] == 0 || this.f[b] == 2) return
          }
	  utag.loader.END();
        }
      },
      EV: function(a, b, c, d) {
        if (b == "ready") {
          if(!utag.data){
            try {
              utag.cl = {'_all_': 1};
              utag.loader.initdata();    
              utag.loader.RD(utag.data);
            }catch(e){ utag.DB(e) };
          }
          if ( (document.attachEvent || utag.cfg.dom_complete) ? document.readyState === "complete" : document.readyState !== "loading" ) setTimeout(c, 1);
          else {
            utag.loader.ready_q.push(c);
            var RH;

            if(utag.loader.ready_q.length<=1){
              if (document.addEventListener) {
                RH = function() {
                  document.removeEventListener("DOMContentLoaded", RH, false);
                  utag.loader.run_ready_q()
                };
                if(!utag.cfg.dom_complete)document.addEventListener("DOMContentLoaded", RH, false);
                window.addEventListener("load", utag.loader.run_ready_q, false);
              } else if (document.attachEvent) {
                RH = function() {
                  if (document.readyState === "complete") {
                    document.detachEvent("onreadystatechange", RH);
                    utag.loader.run_ready_q()
                  }
                };
                document.attachEvent("onreadystatechange", RH);
                window.attachEvent("onload", utag.loader.run_ready_q);
              }
            }
          }
        } else {
          if (a.addEventListener) {
            a.addEventListener(b, c, false)
          } else if (a.attachEvent) {
            a.attachEvent(((d == 1) ? "" : "on") + b, c)
          }
        }
      },
      END: function(b, c, d, e, v, w){
        if(this.ended){return};
        this.ended=1;
	utag.DB("loader.END");
        b = utag.data;
        // add the default values for future utag.link/view calls
	if(utag.handler.base && utag.handler.base!='*'){
          e = utag.handler.base.split(",");
          for (d = 0; d < e.length; d++) {
            if (typeof b[e[d]] != "undefined") utag.handler.df[e[d]] = b[e[d]]
          }
        }else if (utag.handler.base=='*'){
           utag.ut.merge(utag.handler.df,b,1);
        }

        utag.rpt['r_0']="t";
	for(var r in utag.loader.GV(utag.cond)){
          utag.rpt['r_'+r]=(utag.cond[r])?"t":"f";
        }

        utag.rpt.ts['s'] = new Date();
	(function(a,b,c,l){if(typeof utag_err!='undefined'&&utag_err.length>0){
                                                a='//uconnect.tealiumiq.com/ulog/_error?utid='+utag.cfg.utid;
                                                l=utag_err.length > 5 ? 5:utag_err.length;
                                                for(b=0;b<l;b++){
                                                    c=utag_err[b];
                                                    a+='&e'+b+'='+encodeURIComponent(c.t+'::'+c.l+'::'+c.s+'::'+c.e);
                                                }
                                                utag.dbi.push((new Image()).src=a);
                                            }})();

        v = ".tiqcdn.com";
        w = utag.cfg.path.indexOf(v);
        if(w>0 && b["cp.utag_main__ss"]==1 && !utag.cfg.no_session_count)utag.ut.loader({src:utag.cfg.path.substring(0,w)+v+"/ut"+"ag/tiqapp/ut"+"ag.v.js?a="+utag.cfg.utid+(utag.cfg.nocookie?"&nocookie=1":"&cb="+(new Date).getTime()),id:"tiqapp"})
        
        if(utag.cfg.noview!=true)utag.handler.RE('view',b,"end");
	utag.handler.INIT();
      }
    },
    DB: function(a, b) {
      // return right away if we've already checked the cookie
      if(utag.cfg.utagdb===false){
        return;
      }else if(typeof utag.cfg.utagdb=="undefined"){
        utag.db_log=[];
        b = document.cookie+'';
        utag.cfg.utagdb=((b.indexOf('utagdb=true') >= 0)?true:false);
      }
      if(utag.cfg.utagdb===true){
        var t;
        if(utag.ut.typeOf(a) == "object"){
          t=utag.handler.C(a)
        }else{
          t=a
        }
        utag.db_log.push(t);
        try{console.log(t)}catch(e){}
      }
    },
    RP: function(a, b, c) {
      if (typeof a != 'undefined' && typeof a.src != 'undefined' && a.src != '') {
        b = [];
        for (c in utag.loader.GV(a)) {
          if (c != 'src') b.push(c + '=' + escape(a[c]))
        }
        this.dbi.push((new Image()).src = a.src + '?utv=' + utag.cfg.v + '&utid=' + utag.cfg.utid + '&' + (b.join('&')))
      }
    },
    view: function(a,c,d) {
      return this.track({event:'view', data:a, cfg:{cb:c,uids:d}})
    },
    link: function(a,c,d) {
      return this.track({event:'link', data:a, cfg:{cb:c,uids:d}})
    },
    track: function(a,b,c,d) {
      if (typeof a == "string") a = { event: a, data: b, cfg: {cb: c} };

      for(d in utag.loader.GV(utag.o)){
        try{
          utag.o[d].handler.trigger(a.event || "view", a.data || a, a.cfg)
        }catch(e){utag.DB(e)};
      }
      if(a.cfg && a.cfg.cb)try{a.cfg.cb()}catch(e){utag.DB(e)};
      return true
    },
    handler: {
      base: "",
      df: {},
      o: {},
      send: {},
      iflag: 0,
      INIT: function(a, b, c) {
        utag.DB('utag.handler.INIT');
        if(utag.initcatch){
          utag.initcatch=0;
          return
        }
        this.iflag = 1;
        a = utag.loader.q.length;
        if (a > 0) {
          utag.DB("Loader queue");
          for (b = 0; b < a; b++) {
            c = utag.loader.q[b];
            utag.handler.trigger(c.a, c.b, c.c)
          }
        }
        //##UTABSOLUTELAST##
      },
      test: function() {
        return 1
      },
      // reset and run load rules
      LR: function(b){
        utag.DB("Load Rules");
        for(var d in utag.loader.GV(utag.cond)){
          utag.cond[d]=false;
        }
        utag.DB(utag.data);
        utag.loader.loadrules();
        utag.DB(utag.cond);
        utag.loader.initcfg();
        // use the OPTOUTMULTI cookie value to override load rules
        utag.loader.OU();
	for(var r in utag.loader.GV(utag.cond)){
          utag.rpt['r_'+r]=(utag.cond[r])?"t":"f";
        }
      },
      // The third param "c" is a string that defines the location i.e. "blr" == before load rules
      RE:function(a,b,c,d,e,f,g){
        if(c!="alr" && !this.cfg_extend){
          return 0; 
        }
        utag.DB("RE: "+c);
        if(c=="alr")utag.DB("All Tags EXTENSIONS");
        utag.DB(b);
        if(typeof this.extend != "undefined"){
          g=0;
          for (d = 0; d < this.extend.length; d++) {
            try {
              /* Extension Attributes */
              e=0;
              if(typeof this.cfg_extend!="undefined"){
                f=this.cfg_extend[d];
                if(typeof f.count == "undefined")f.count=0;
                if(f[a]==0 || (f.once==1 && f.count>0) || f[c]==0){
                  e=1
                }else{
                  if(f[c]==1){g=1};
                  f.count++
                }
              }
              if(e!=1){
                this.extend[d](a, b);
                utag.rpt['ex_' + d] = 0
              }
            } catch (er) {
              utag.DB(er);
              utag.rpt['ex_' + d] = 1;
	      utag.ut.error({e:er.message,s:utag.cfg.path+'utag.js',l:d,t:'ge'});
            }
          }
          utag.DB(b);
          return g;
        }
      },
      trigger: function(a, b, c, d, e, f) {
        utag.DB('trigger:'+a+(c && c.uids?":"+c.uids.join(","):""));
        b = b || {};
        utag.DB(b);

        if (!this.iflag) {
          utag.DB("trigger:called before tags loaded");
          for (d in utag.loader.f) {
            if (!(utag.loader.f[d] === 1)) utag.DB('Tag '+d+' did not LOAD')
          }
          utag.loader.q.push({
            a: a,
            b: utag.handler.C(b),
            c: c
          });
          return;
        }
        utag.cfg.noview = false;

        utag.ut.merge(b,this.df,0);
        // update values for AJAX pages
        utag.loader.RDqp(b);
        utag.loader.RDcp(b);
        utag.loader.RDdom(b);
        utag.loader.RDmeta(b);
        utag.loader.RDut(b,a);
        utag.loader.RDva(b);

        function sendTag(a, b, d){
          try {
            if(typeof utag.sender[d]!="undefined"){
              utag.DB("SENDING: "+d);
              utag.sender[d].send(a, utag.handler.C(b));
	      utag.rpt['s_' + d] = 0;
            }else if (utag.loader.cfg[d].load!=2 && utag.loader.cfg[d].s2s!=1){
              // utag.link calls can load in new tags
              utag.loader.sendq[d] = utag.loader.sendq[d] || [];
              utag.loader.sendq[d].push({"event":a, "data":utag.handler.C(b)});
              utag.loader.sendq.pending++;
              utag.loader.AS({id : d, load : 1}); 
            }
          }catch (e) {utag.DB(e)}
        }
        
        // utag.track( {event : ”view”, data: {myvar : “myval” }, cfg: {uids : [1,2,10] } } );
        if(c && c.uids){
          this.RE(a,b,"alr");
          for(f=0;f<c.uids.length;f++){
            d=c.uids[f];
            // bypass load rules
            sendTag(a, b, d);
          }
        }else if(utag.cfg.load_rules_ajax){
          // right now, load rules use utag.data (replace items in utag.data with items in b)
          this.RE(a,b,"blr");
          utag.ut.merge(utag.data,b,1);
          // clear and re-run load rules
          this.LR(b);
          this.RE(a,b,"alr");
          // TBD: Run through the "bwq" Extensions again here? (For now, require "bwq" is also set to "run once"?) 
          for(f = 0; f < utag.loader.cfgsort.length; f++){
            d = utag.loader.cfgsort[f];
            if(utag.loader.cfg[d].load && utag.loader.cfg[d].send){
              sendTag(a, b, d);
            }
          }
        }else{
          // legacy behavior
          this.RE(a,b,"alr");
          for (d in utag.loader.GV(utag.sender)) {
            sendTag(a, b, d);
          }
        }
        this.RE(a,b,"end");
        // update end of session timestamp in cookie
        utag.loader.SC("utag_main", { "_st": ((new Date()).getTime() + parseInt(utag.cfg.session_timeout)) });

      },
      // "sort-of" copy
      C: function(a, b, c) {
        b = {};
        for (c in utag.loader.GV(a)) {
          if(a[c] instanceof Array){
            b[c] = a[c].slice(0)
          }else{
            // objects are still references to the original (not copies)
            b[c] = a[c]
          }
        }
        return b
      }
    },
    ut:{
      pad: function(a,b,c,d){
        a=""+((a-0).toString(16));d='';if(b>a.length){for(c=0;c<(b-a.length);c++){d+='0'}}return ""+d+a
      },
      vi: function(t,a,b){
        if(!utag.v_id){
          a=this.pad(t,12);b=""+Math.random();a+=this.pad(b.substring(2,b.length),16);try{a+=this.pad((navigator.plugins.length?navigator.plugins.length:0),2);a+=this.pad(navigator.userAgent.length,3);a+=this.pad(document.URL.length,4);a+=this.pad(navigator.appVersion.length,3);a+=this.pad(screen.width+screen.height+parseInt((screen.colorDepth)?screen.colorDepth:screen.pixelDepth),5)}catch(e){utag.DB(e);a+="12345"};utag.v_id=a;
        }
        return utag.v_id
      },
      hasOwn: function(o, a) {
        return o != null && Object.prototype.hasOwnProperty.call(o, a)
      },
      isEmptyObject: function(o, a) {
	for (a in o) {
          if (utag.ut.hasOwn(o,a))return false
        }
        return true
      },
      isEmpty: function(o) {
        var t = utag.ut.typeOf(o);
        if ( t == "number" ){
          return isNaN(o)
        }else if ( t == "boolean" ){
          return false
        }else if ( t == "string" ){
          return o.length === 0
        }else return utag.ut.isEmptyObject(o)
      },
      typeOf: function(e) {
        return ({}).toString.call(e).match(/\s([a-zA-Z]+)/)[1].toLowerCase();
      },
      flatten: function(o){
        // stop when arriving at a string, array, boolean, number (float or integer)
        var a = {}; 
        function r(c, p) {
          if (Object(c) !== c || c instanceof Array) {
            a[p] = c;
          } else {
            if(utag.ut.isEmptyObject(c)){
              //a[p] = {};
            }else{
              for (var d in c) {
                r(c[d], p ? p+"."+d : d);
              }
            }
          }
        }
        r(o, "");

        return a;
      },
      merge: function(a, b, c, d) {
        if(c){
          for(d in utag.loader.GV(b)){
            a[d] = b[d]
          }
        }else{
          for(d in utag.loader.GV(b)){
            if(typeof a[d]=="undefined")a[d] = b[d]
          }
        }
      },
      decode: function(a, b) {
        b = "";
        try{b = decodeURIComponent(a)}catch(e){utag.DB(e)};
        if (b == ""){b = unescape(a)};
        return b
      },
      error: function(a, b, c){
        if(typeof utag_err!="undefined"){
          utag_err.push(a)
        }
      },
      loader: function(o, a, b, c, l) {
        a=document;
        if (o.type=="iframe") {
          b = a.createElement("iframe");
          o.attrs = o.attrs || { "height" : "1", "width" : "1", "style" : "display:none" };
          for( l in utag.loader.GV(o.attrs) ){
            b.setAttribute( l, o.attrs[l] )
          }
          b.setAttribute("src", o.src);
        }else if (o.type=="img"){
          utag.DB("Attach img: "+o.src);
          b=new Image();b.src=o.src;
          return;
        }else{
          b = a.createElement("script");b.language="javascript";b.type="text/javascript";b.async=1;b.charset="utf-8";
          for( l in utag.loader.GV(o.attrs) ){
            b[l] = o.attrs[l]
          }
          b.src = o.src;
        }
        if(o.id){b.id=o.id};
        if (typeof o.cb=="function") {
          if(b.addEventListener) {
            b.addEventListener("load",function(){o.cb()},false);
          }else {
            // old IE support
            b.onreadystatechange=function(){if(this.readyState=='complete'||this.readyState=='loaded'){this.onreadystatechange=null;o.cb()}};
          }
        }
        l = o.loc || "head";
        c = a.getElementsByTagName(l)[0];
        if (c) {
          utag.DB("Attach to "+l+": "+o.src);
          if (l == "script") {
            c.parentNode.insertBefore(b, c);
          } else {
            c.appendChild(b)
          }
        }
      }
    }
  };
  utag.o['unicredit.uc.it']=utag;
  utag.cfg = {
    template : "ut4.39.",
    // Enable load rules ajax feature by default
    load_rules_ajax: true,
    load_rules_at_wait: false,
    lowerqp: false,
    //noview: ##UTNOVIEW##,
    session_timeout: 1800000,
    readywait: 0,
    noload: 0,
    domain: utag.loader.lh(),
    path: "//tags.tiqcdn.com/utag/unicredit/uc.it/prod/",
    utid: "unicredit/uc.it/201801051549"
  };
  utag.cfg.v = utag.cfg.template + "201801051549";
  utag.cond={10:0,11:0,12:0,13:0,15:0,18:0,20:0,23:0,25:0,26:0,27:0,28:0,30:0,31:0,32:0,34:0,35:0,36:0,37:0,38:0,39:0,40:0,8:0,9:0};
utag.pagevars=function(ud){ud = ud || utag.data;try{ud['js_page.navigator.userAgent']=navigator.userAgent}catch(e){utag.DB(e)};try{ud['js_page.screen.width']=screen.width}catch(e){utag.DB(e)};try{ud['js_page.stream_channel']=stream_channel}catch(e){utag.DB(e)};try{ud['js_page.stream_pageName']=stream_pageName}catch(e){utag.DB(e)};try{ud['js_page.stream_prod']=stream_prod}catch(e){utag.DB(e)};try{ud['js_page.stream_ndg']=stream_ndg}catch(e){utag.DB(e)};try{ud['js_page.stream_timestamp_local']=stream_timestamp_local}catch(e){utag.DB(e)};try{ud['js_page.stream_resolution']=stream_resolution}catch(e){utag.DB(e)};try{ud['js_page.stream_userAgent']=stream_userAgent}catch(e){utag.DB(e)};try{ud['js_page.stream_toolFinalName']=stream_toolFinalName}catch(e){utag.DB(e)};try{ud['js_page.stream_tool_outResult']=stream_tool_outResult}catch(e){utag.DB(e)};try{ud['js_page.stream_cta']=stream_cta}catch(e){utag.DB(e)};try{ud['js_page.stream_tool_outPath']=stream_tool_outPath}catch(e){utag.DB(e)};try{ud['js_page.stream_trackType']=stream_trackType}catch(e){utag.DB(e)};try{ud['js_page.stream_trigger_1']=stream_trigger_1}catch(e){utag.DB(e)};try{ud['js_page.stream_trigger2']=stream_trigger2}catch(e){utag.DB(e)};try{ud['js_page.stream_trigger4']=stream_trigger4}catch(e){utag.DB(e)};try{ud['js_page.stream_trigger9']=stream_trigger9}catch(e){utag.DB(e)};try{ud['js_page.stream_trigger29']=stream_trigger29}catch(e){utag.DB(e)};try{ud['js_page.stream_trigger35']=stream_trigger35}catch(e){utag.DB(e)};try{ud['js_page.stream_trigger_download']=stream_trigger_download}catch(e){utag.DB(e)};try{ud['js_page.stream_map']=stream_map}catch(e){utag.DB(e)};try{ud['js_page.stream_versionInfo']=stream_versionInfo}catch(e){utag.DB(e)};try{ud['js_page.stream_uTokenId']=stream_uTokenId}catch(e){utag.DB(e)};try{ud['js_page.stream_uTokenProfile']=stream_uTokenProfile}catch(e){utag.DB(e)};try{ud['js_page.stream_sessionId']=stream_sessionId}catch(e){utag.DB(e)};try{ud['js_page.stream_events']=stream_events}catch(e){utag.DB(e)};try{ud['js_page.stream_download_path']=stream_download_path}catch(e){utag.DB(e)};try{ud['js_page.stream_timestamp_epoch']=stream_timestamp_epoch}catch(e){utag.DB(e)};try{ud['js_page.stream_section']=stream_section}catch(e){utag.DB(e)};try{ud['js_page.stream_menuGroup']=stream_menuGroup}catch(e){utag.DB(e)};try{ud['js_page.stream_trigger15_1']=stream_trigger15_1}catch(e){utag.DB(e)};try{ud['js_page.stream_trigger15']=stream_trigger15}catch(e){utag.DB(e)};try{ud['js_page.stream_Url']=stream_Url}catch(e){utag.DB(e)};try{ud['js_page.stream_server']=stream_server}catch(e){utag.DB(e)};};
utag.loader.initdata = function() {   try {       utag.data = (typeof dataLayer != 'undefined') ? dataLayer : {};       utag.udoname='dataLayer';    } catch (e) {       utag.data = {};       utag.DB('idf:'+e);   }};utag.loader.loadrules = function(_pd,_pc) {var d = _pd || utag.data; var c = _pc || utag.cond;for (var l in utag.loader.GV(c)) {switch(l){
case '10':try{c[10]|=(d['mediacom_activity_id'].toString().indexOf('notrack')<0)}catch(e){utag.DB(e)}; break;
case '11':try{c[11]|=(d['twitter_pid'].toString().indexOf('notrack')<0)}catch(e){utag.DB(e)}; break;
case '12':try{c[12]|=(d['ext_pageName'].toString().indexOf('ucps:privati+privati:mutui:')>-1)}catch(e){utag.DB(e)}; break;
case '13':try{c[13]|=(d['ext_pageName'].toString().indexOf('ucps:privati+privati:prestiti:')>-1)}catch(e){utag.DB(e)}; break;
case '15':try{c[15]|=(d['ext_pageName'].toString().indexOf('ucps:privati+privati:assicurazioni:tutteleassicurazioni:protezioneautoemoto:guidaprotetta')>-1)}catch(e){utag.DB(e)}; break;
case '18':try{c[18]|=(d['dom.url'].toString().indexOf('/www.unicredit.it/it/privati/logout-page.html')>-1)}catch(e){utag.DB(e)}; break;
case '20':try{c[20]|=(d['ext_pageName'].toString().indexOf('ucps:privati+privati:prestiti:tuttiiprestiti:altriprestiti:cessionedelquinto')>-1)||(d['ext_pageName'].toString().indexOf('ucps:privati+privati:prestiti:tuttiiprestiti:perleesigenzedituttiigiorni:cessionedelquinto')>-1)}catch(e){utag.DB(e)}; break;
case '23':try{c[23]|=(d['dom.pathname'].toString().indexOf('it/privati/investimenti-e-risparmio/')>-1)}catch(e){utag.DB(e)}; break;
case '25':try{c[25]|=(d['ext_pageName']=='ucps:privati+privati')||(d['ext_pageName'].toString().indexOf('ucps:privati+privati:carte')>-1)||(d['ext_pageName'].toString().indexOf('tuttiiserviziinternetemobile:altriservizi:mybusinessview')>-1)}catch(e){utag.DB(e)}; break;
case '26':try{c[26]|=(d['ext_pageName'].toString().indexOf('ucps:privati+privati:carte')>-1)||(d['ext_pageName'].toString().indexOf('ucps:privati+privati:prestiti')>-1)||(d['ext_pageName'].toString().indexOf('ucps:privati+privati:conticorrenti')>-1)}catch(e){utag.DB(e)}; break;
case '27':try{c[27]|=(d['flat_productCode'].toString().indexOf('SCOPERTOFACILE')>-1)}catch(e){utag.DB(e)}; break;
case '28':try{c[28]|=(d['flat_productCode'].toString().toLowerCase()!='SCOPERTOFACILE'.toLowerCase())}catch(e){utag.DB(e)}; break;
case '30':try{c[30]|=(d['ext_pageName'].toString().indexOf('ucps:privati+privati:investimentierisparmio:')>-1)}catch(e){utag.DB(e)}; break;
case '31':try{c[31]|=(d['ext_pageName'].toString().toLowerCase()=='ucps:privati+privati:carte:tuttelecarte:cartedicredito:unicreditcardflexiaclassic'.toLowerCase())}catch(e){utag.DB(e)}; break;
case '32':try{c[32]|=(d['ext_pageName']=='ucps:privati+privati:carte:tuttelecarte:carteprepagateiban:geniuscard')}catch(e){utag.DB(e)}; break;
case '34':try{c[34]|=(typeof d['floodlight_rem_type']!='undefined'&&d['floodlight_rem_type']!='')}catch(e){utag.DB(e)}; break;
case '35':try{c[35]|=(!/^ucps:privati\+privati:conticorrenti/i.test(d['ext_pageName'])&&d['ext_pageName'].toString().toLowerCase()!='ucps:privati+privati:logoutpage'.toLowerCase())}catch(e){utag.DB(e)}; break;
case '36':try{c[36]|=(d['ext_pageName'].toString().toLowerCase()=='ucps:imprese+piccoleimprese:incassiepagamenti:tuttiiprodottidiincassoepagamento:servizidiincasso:alipay'.toLowerCase())}catch(e){utag.DB(e)}; break;
case '37':try{c[37]|=(typeof d['floodlight_rem2_type']!='undefined'&&d['floodlight_rem2_type']!='')}catch(e){utag.DB(e)}; break;
case '38':try{c[38]|=(typeof d['sizmek_account']!='undefined'&&d['sizmek_account']!='')}catch(e){utag.DB(e)}; break;
case '39':try{c[39]|=(d['dom.pathname'].toString().indexOf('/it/piccole-imprese/')>-1)||(d['dom.pathname'].toString().indexOf('/it/chi-siamo/noi-e-il-sociale/social-impact-banking.html')>-1)}catch(e){utag.DB(e)}; break;
case '40':try{c[40]|=(typeof d['floodlight_gtag_account']!='undefined'&&d['floodlight_gtag_account']!='')}catch(e){utag.DB(e)}; break;
case '8':try{c[8]|=(/^async/i.test(d['trackType'])&&d['ut.event'].toString().indexOf('link')>-1&&d['ut.domain']!='cq5.internal.unicreditgroup.eu'&&d['js_page.navigator.userAgent'].toString().toLowerCase().indexOf('gomez'.toLowerCase())<0)}catch(e){utag.DB(e)}; break;
case '9':try{c[9]|=(d['ut.domain']!='cq5.internal.unicreditgroup.eu'&&d['js_page.navigator.userAgent'].toString().toLowerCase().indexOf('gomez'.toLowerCase())<0&&d['trackType'].toString().toLowerCase().indexOf('async'.toLowerCase())<0)}catch(e){utag.DB(e)}; break;}}};utag.pre=function() {    utag.loader.initdata();utag.pagevars();    try{utag.loader.RD(utag.data)}catch(e){utag.DB(e)};    utag.loader.loadrules();        };utag.loader.GET=function(){utag.cl={'_all_':1};utag.pre();
  utag.handler.extend=[function(a,b){ try{ if(1){
/*if(typeof window.dataLayer!="undefined" && typeof window.dataLayer["trackType"]!="undefined")
{
if(window.dataLayer["trackType"].search(/page/i)==0)
  window.dataLayer["page_type"] = window.dataLayer["trackType"];
else 
  window.dataLayer["event_name"] = window.dataLayer["trackType"];
}*/
if(typeof b.trackType!="undefined")
{
if(b["ut.event"]=="view")
  b["page_type"] = b.trackType;
else 
  b["event_name"] = b.trackType;
}
} } catch(e){ utag.DB(e) }  },
function(a,b,c,d){ try{ if(1){c=[b['ut.profile'],b['ut.env'],b['ut.event'],b['ut.version']];b['ext_tealiumInfo']=c.join(':')} } catch(e){ utag.DB(e) }  },
function(a,b){
var flattenObject = function(ob,res) {
	if(!res)
	  var toReturn = {};
        else
	  toReturn = res;
	
	for (var i in ob) {
		if (!ob.hasOwnProperty(i)) continue;
		
		if ((typeof ob[i]) == 'object') {
			var flatObject = flattenObject(ob[i]);
			for (var x in flatObject) {
				if (!flatObject.hasOwnProperty(x)) continue;
				
				toReturn[i + '_' + x] = flatObject[x];
			}
		} else {
			toReturn[i] = ob[i];
		}
	}
	return toReturn;
};

if(b.trackType.search(/async/i) >= 0 || b.trackType.search(/action/i) >= 0 || b.trackType.search(/page-inject/i) >= 0 || b.trackType.search(/page-view/i) >= 0)b = flattenObject(b,b);
else b = flattenObject(dataLayer,b);
},
function(a,b,c,d){c=['tech_site','page_segment','tech_environment','search_terms','trackType','tech_platform'];for(d=0;d<c.length;d++){try{b[c[d]] = (b[c[d]] instanceof Array || b[c[d]] instanceof Object) ? b[c[d]] : b[c[d]].toString().toLowerCase()}catch(e){}}},
function(a,b,c,d){ try{ if(1){c=[b['version'],b['tech_baselineId'],b['ext_tealiumInfo']];b['ext_versionInfo']=c.join('>')} } catch(e){ utag.DB(e) }  },
function(a,b,c,d){ try{ if(1){c=[b['tech_environment'],b['tech_platform'],b['tech_baselineId'],b['tech_applicationId']];b['ext_techInfo']=c.join('>')} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(typeof b['search_terms']!='undefined'){b['ext_pageType']='search'} } catch(e){ utag.DB(e) }  },
function(a,b,c,d){ try{ if((typeof b['tool_type']!='undefined'&&b['tool_type']!=''&&typeof b['tool_name']!='undefined'&&b['tool_name']!='')){c=[b['tool_type'],b['tool_name']];b['ext_toolFinalName']=c.join(':')} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if((typeof b['tool_start']!='undefined'&&b['tool_start'].toString().toLowerCase()=='true'.toLowerCase())){b['link_name']='Tool start'} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if((typeof b['tool_end']!='undefined'&&b['tool_end'].toString().toLowerCase()=='true'.toLowerCase())){b['link_name']='Tool end'} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(typeof b['qp.intscid']!='undefined'&&b['qp.intscid']!=''){b['ext_sponsoredIntSearchLinkEvent']='true'} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(b['page_template'].toString().indexOf('error')>-1){b['ext_errorPage']='errorPage'} } catch(e){ utag.DB(e) }  },
function(a,b,c,d,e,f,g){d=b['ut.env'];if(typeof d=='undefined')return;c=[{'dev':'unicreditretailcombined-dev'},{'qa':'unicreditretailcombined-dev'},{'prod':'unicreditretailcombined'}];var m=false;for(e=0;e<c.length;e++){for(f in c[e]){if(d==f){b['ext_reportSuite']=c[e][f];m=true};};if(m)break};if(!m)b['ext_reportSuite']='unicreditretailcombined-dev';},
function(a,b){
if(typeof nav_aBreadcrumb!="undefined")
b.ext_hier2 = nav_aBreadcrumb.join(",");
},
function(a,b){
var temp = b.page_pathUrl.replace(/\//gi,":").replace(/^:/gi,"").replace(/:$/gi,"").replace(/-/gi,"").replace(/_/gi,"");
var split = temp.split(":"); //split element
var noContent = split.slice(3,split.length) //remove "content" string present in each value
    
if(b.page_menuGroup && b.page_site=="ucpublic") //sito pubblico menuGroup presente
  b.ext_pageName = "ucps:"+b.page_menuGroup+"+"+noContent.join(":");
else if (!b.page_menuGroup && b.page_site=="ucpublic") //sito pubblico menuGroup assente
  b.ext_pageName = "ucps:"+noContent.join(":");
else if (b.page_menuGroup && b.page_site!="ucpublic") //sito privato menuGroup presente
  b.ext_pageName = b.page_site+":"+b.page_menuGroup+"+"+noContent.join(":");
else //sito privato menuGroup assente
  b.ext_pageName = b.page_site+":"+noContent.join(":");
//channel - Site Section
if(noContent.length>0)
  b.ext_channel = noContent[0];
if(b.page_site=="ebank")
  b.ext_channel = "loginout"
//rimozione pageName in caso di errorPage
if(b.ext_errorPage)
  b.ext_pageName = "";
//Hier
if(b.ext_pageName)
  b.ext_hier1 = b.ext_pageName.replace(/:/gi,",");
},
function(a,b){
if(b.trackType.search(/page-view/i) >= 0 && typeof b.viewStep_hier=="string")
{
  var vsh = "";
  var viewPagePath = "";
  if (b.viewStep_pagePath) {
    var tempv = b.viewStep_pagePath.replace(/\//gi, ":").replace(/^:/gi, "").replace(/:$/gi, "").replace(/-/gi, "").replace(/_/gi, "");
    var splitv = tempv.split(":"); //split element
    var noContentv = "";
    if (splitv[1]=="it")
        noContentv = splitv.slice(2, splitv.length) //remove "content:gimb_it:<lang>" string present in each value
    else
        noContentv = splitv.slice(1, splitv.length)
    viewPagePath = noContentv.join(":");
}
    vsh = b.viewStep_hier.split("|").join(":");
  b.ext_pageName = "ebank:" + viewPagePath + ":v:" + vsh.replace(/\s/gi,"").toLowerCase();
}
//rimozione pageName in caso di errorPage
if(b.ext_errorPage)
  b.ext_pageName = "";
//Hier
if(b.ext_pageName)
  b.ext_hier1 = b.ext_pageName.replace(/:/gi,",");
if(b.ext_pageName.indexOf("login")>=0 && !b.ext_channel)
  b.ext_channel = "loginout";


},
function(a,b){ try{ if(1){
var data = new Date();
var day = data.getDate();
	if (day < 10) day = "0"+day; 
var month = (data.getMonth()+1); 
	if (month < 10) month = "0"+month; 
var year = data.getFullYear();
var hours = data.getHours();
	if (hours < 10) hours = "0"+hours; 
var minutes = data.getMinutes();
	if (minutes < 10) minutes = "0"+minutes; 
var seconds = data.getSeconds();
	if (seconds < 10) seconds = "0"+seconds; 
b.ext_timeStamp = day+"/"+month+"/"+year+" "+hours+":"+minutes+":"+seconds; 
} } catch(e){ utag.DB(e) }  },
function(a,b){
if(typeof b.trackType!="undefined" && (b.trackType.indexOf("ACTION")>=0 || b.trackType.indexOf("action")>=0))
{
  b.ext_pageName = "";
  b.extAdobeURL = "";
  b.ext_hier1 = "";
  b.ext_hier2 = "";
  b.ext_channel = "";
  b.page_site = "";
  b.page_pathUrl = "";
  b.nav_language = "";
  b.page_segment = "";
  b.page_section = "";
  b.page_templateId = "";
  b.search_terms = "";
  b.search_resultCount = "";
  b.search_numPage = "";
  b.ext_bannerIds = "";
  b.ext_prodCode = "";
  b.ext_prodCat = "";
  b.ext_errorPage = "";
  b.ext_toolFinalName = "";
  b.ext_prodViewEvent = "";
  b.ext_techInfo = "";
}
},
function(a,b){ try{ if(1){
  var fired = false;
  if(typeof b.aProduct!="undefined" && !fired) {
	var code = [];
	var cat = [];
	var nam = [];
	for(i=0;i< b.aProduct.length;i++) {
	    code.push(b.aProduct[i].code);
            cat.push(b.aProduct[i].category);
            nam.push(b.aProduct[i].name);
	}
  
          b.flat_productName = nam.join(",");
	  b.flat_productCat = cat.join(",");
	  b.flat_productCode = code.join(",");
	  fired = !fired;
  } else if(!fired && new RegExp(/it\/privati\/conti\-correnti\/tutti\-i\-conti\/libretti\-di\-risparmio\-e\-altri\-conti\/scoperto\-facile\.html/gi).test(window.location.pathname)) {
    b.flat_productCat = "Conti";
    b.flat_productCode = "SCOPERTOFACILE";
    b.flat_productName = "Scoperto Facile";
    fired = !fired;
  }
} } catch(e){ utag.DB(e) }  },
function(a,b,c,d,e,f,g){d=b['ext_pageName'];if(typeof d=='undefined')return;c=[{'ucps:privati+privati:mutui':'430750'},{'ucps:privati+privati:assicurazioni:tutteleassicurazioni:protezioneautoemoto:guidaprotettamoto0':'567117'},{'ucps:privati+privati:carte:tuttelecarte:carteprepagateiban:geniuscarduefa':'575193'},{'ucps:privati+privati:carte:tuttelecarte:carteprepagateiban:geniuscard':'575194'},{'XXXucps:privati:mutui:tuttaunaltrastoria:tuttaunaltrastoriaperlacasa':'627103'},{'ucps:privati+privati:assicurazioni:tutteleassicurazioni:protezionecasaefamiglia:famigliaprotetta':'627110'},{'ucps:privati+privati:mutui:tuttiimutui:perlacasa:mutuovaloreitaliacambiocasa':'627108'},{'ucps:privati+privati:mutui:tuttiimutui:informazioniutili:vouchermutuo':'627109'},{'ucps:privati+privati:prestiti:tuttiiprestiti:perlacasa:ristrutturazione':'627113'},{'ucps:privati:serviziinnovativi:internetemobilebanking:iphonesmartphone:prelievosmart':'708468'},{'ucps:privati:serviziinnovativi:internetemobilebanking:iphonesmartphone:pagamentobollettinipostali':'708469'},{'ucps:privati:serviziinnovativi:internetemobilebanking:iphonesmartphone:fingerprint':'708471'},{'ucps:privati:serviziinnovativi:internetemobilebanking:iphonesmartphone':'708475'},{'ucps:privati:serviziinnovativi:pagamentidigitali:mobileplus':'708477'},{'ucps:privati:serviziinnovativi:domandeutilieassistenza:bancaviacellulare':'708478'},{'ucps:privati:serviziinnovativi:internetemobilebanking:iphonesmartphone:mobiletoken':'708480'},{'ucps:privati:serviziinnovativi:internetemobilebanking:cosaebancaviainternet':'708482'},{'ucps:privati:serviziinnovativi:internetemobilebanking:cosapuoifare:bilanciofamiliare':'708483'},{'ucps:privati:serviziinnovativi:internetemobilebanking:iphonesmartphone:ricaricareilcellulare':'708557'},{'ucps:privati:serviziinnovativi:internetemobilebanking:iphonesmartphone:controllaremovimenticarte':'708558'},{'ucps:privati:serviziinnovativi:domandeutilieassistenza:comeattivareilservizio':'710313'},{'ucps:privati:serviziinnovativi:tuttaunaltrastoria:tuttaunaltrastoriaapp':'708585'},{'ucps:privati+privati:mutui:tuttiimutui:perlacasa:mutuovaloreitaliagiovani':'708484'},{'ucps:privati+privati:mutui:tuttiimutui:altrimutui:traslocamutuo':'708557'},{'ucps:privati+privati:conticorrenti:tuttiiconti:contomodulare:contocorrentemygeniusunicredit':'818962'},{'ucps:privati:conti:imoduliaggiuntiviinvestimenti:moduliinvestimenticontocorrente':'818963'},{'ucps:privati+privati:carte:tuttelecarte:cartedicredito:unicreditcardflexiaclassic':'818964'},{'ucps:privati+privati:carte:tuttelecarte:informazioniutili:sicurezzaperlecarte:securecodemastercardeverifiedbyvisa':'818973'},{'ucps:privati+privati:conticorrenti:tuttiiconti:contomodulare:modulosilvercontocorrente':'818974'},{'ucps:privati:serviziinnovativi:servizisucellulare:servizisms':'818976'},{'ucps:privati+privati:conticorrenti:tuttiiconti:contomodulare:moduloplatinumcontocorrente':'818978'},{'ucps:privati+privati:carte:tuttelecarte:informazioniutili:sicurezzaperlecarte:smsalertsunicreditcard':'819081'},{'ucps:privati+privati:conticorrenti:tuttiiconti:contomodulare:modulogoldcontocorrente':'818977'},{'ucps:privati+privati:mutui:tuttiimutui:mutuivaloreitalia':'430751'},{'ucps:imprese+piccoleimprese:incassiepagamenti:tuttiiprodottidiincassoepagamento:servizidiincasso:alipay':'1056743'}];var m=false;for(e=0;e<c.length;e++){for(f in c[e]){if(d.toString().indexOf(f)>-1){b['mediacom_activity_id']=c[e][f];m=true};};if(m)break};if(!m)b['mediacom_activity_id']='notrack';},
function(a,b,c,d,e,f,g){d=b['ext_pageName'];if(typeof d=='undefined')return;c=[{'ucps:privati+privati:prestiti:tuttiiprestiti':'936738'},{'ucps:privati+privati:prestiti:tuttiiprestiti:perleesigenzedituttiigiorni:creditexpressmini':'936739'},{'ucps:privati+privati:prestiti:tuttiiprestiti:perleesigenzedituttiigiorni:creditexpresspremium':'936742'},{'ucps:privati+privati:prestiti:tuttiiprestiti:perleesigenzedituttiigiorni:creditexpresstop':'936745'},{'ucps:privati+privati:prestiti:tuttiiprestiti:perleesigenzedituttiigiorni:creditexpressgiovani':'936747'},{'ucps:privati+privati:prestiti:tuttiiprestiti:perleesigenzedituttiigiorni:creditexpressmaster':'936750'},{'ucps:privati+privati:prestiti:tuttiiprestiti:perleesigenzedituttiigiorni:unicreditadhonorem':'936753'},{'ucps:privati+privati:prestiti:tuttiiprestiti:perlacasa:prestitocasa':'936756'},{'ucps:privati+privati:prestiti:tuttiiprestiti:perlacasa:ristrutturazione':'936759'},{'ucps:privati+privati:prestiti:tuttiiprestiti:perlacasa:risparmioenergetico':'936762'},{'ucps:privati+privati:prestiti:tuttiiprestiti:altriprestiti:cessionedelquinto':'936765'},{'ucps:privati+privati:prestiti:tuttiiprestiti:altriprestiti:creditosupegno':'936768'},{'ucps:privati+privati:prestiti:tuttiiprestiti:altriprestiti:creditosupegno:calendarioaste':'936769'},{'ucps:privati+privati:prestiti:tuttiiprestiti:perleesigenzedituttiigiorni:creditexpressdynamic':'936770'},{'ucps:privati+privati:prestiti:tuttiiprestiti:perleesigenzedituttiigiorni:creditexpresscompact':'936775'},{'ucps:privati+privati:prestiti:tuttiiprestiti:perleesigenzedituttiigiorni:creditexpresseasy':'944455'},{'ucps:privati+privati:internetemobile:tuttiiserviziinternetemobile:internetemobilebanking:iphonesmartphone':'944453'},{'ucps:privati+privati:conticorrenti:tuttiiconti:librettidirisparmioealtriconti:scopertofacile':'992841'}];var m=false;for(e=0;e<c.length;e++){for(f in c[e]){if(d==f){b['mediacom_activity_id']=c[e][f];m=true};};if(m)break};},
function(a,b,c,d,e,f,g){d=b['ext_pageName'];if(typeof d=='undefined')return;c=[{'ucps:privati+privati:internetemobile:tuttiiserviziinternetemobile:pagamentidigitali:applepay':'1037903'},{'ucps:privati+privati:internetemobile:tuttiiserviziinternetemobile:pagamentidigitali:monhey':'1037904'},{'shop:privati:conto+corrente:selezione:scegli+il+tuo+conto':'1037905'},{'ucps:privati+privati:internetemobile:tuttiiserviziinternetemobile:domandeutilieassistenza:domandeerispostesuapplepay':'1037906'},{'ucps:privati+privati:carte:tuttelecarte:cartedidebito:cartamyone':'1037907'},{'ucps:privati+privati:carte:tuttelecarte:cartedidebito:cartamypay':'1037908'}];var m=false;for(e=0;e<c.length;e++){for(f in c[e]){if(d==f){b['mediacom_activity_id']=c[e][f];m=true};};if(m)break};},
function(a,b,c,d,e,f,g){d=b['ext_pageName'];if(typeof d=='undefined')return;c=[{'ucps:privati+privati:mutui:tuttiimutui:perlacasa:mutuovaloreitaliacambiocasa':'nubxe'},{'ucps:privati+privati:mutui:tuttiimutui:mutuivaloreitalia':'nubxe'},{'ucps:privati:mutui:tuttaunaltrastoria:tuttaunaltrastoriaperlacasa':'nubxe'}];var m=false;for(e=0;e<c.length;e++){for(f in c[e]){if(d.toString().indexOf(f)>-1){b['twitter_pid']=c[e][f];m=true};};if(m)break};if(!m)b['twitter_pid']='notrack';},
function(a,b){ try{ if(b['ext_pageName'].toString().indexOf('ucps:privati+privati:logoutpage')>-1||b['ext_pageName'].toString().indexOf('ucm+bvi:logout:logout')>-1){if(typeof b['cp.logout_segment']=='undefined'){document.cookie="logout_segment="+'retail_privati'+";path=/;domain="+utag.cfg.domain+";expires=";b['cp.logout_segment']='retail_privati';}}} catch(e){ utag.DB(e) } },
function(a,b){ try{ if(b['ext_pageName'].toString().indexOf('ucps:imprese+piccoleimprese:logoutpage')>-1){document.cookie="logout_segment="+'retail_imprese'+";path=/;domain="+utag.cfg.domain+";expires=";b['cp.logout_segment']='retail_imprese';}} catch(e){ utag.DB(e) } },
function(a,b){ try{ if(1){
if(typeof b["ext_pageName"] == "string" && new RegExp(/^ucps\:privati\+privati\:(mutui|conticorrenti|prestiti|carte)/gi).test(b["ext_pageName"])) {
  var tipo = new RegExp(/^ucps\:privati\+privati\:(mutui|conticorrenti|prestiti|carte)/gi).exec(b["ext_pageName"])[1];
  switch(tipo) {
    case "conticorrenti":
      b["floodlight_rem_type"] = "rem_cont";
      b["floodlight_rem_cat"] = "remar0";
      break;
    case "mutui":
      b["floodlight_rem_type"] = "rem_mutu";
      b["floodlight_rem_cat"] = "remar0";
      break;
    case "prestiti":
      if(new RegExp(/cessionedelquinto/gi).test(b["ext_pageName"])) {
	b["floodlight_rem_type"] = "rem_cqs";
	b["floodlight_rem_cat"] = "remar0";
      }
      else { 
	b["floodlight_rem_type"] = "rem_pres";
        b["floodlight_gtag_account"] = "6977905";
	b["floodlight_gtag_mode"] = "standard";
        b["floodlight_gtag_type"] = "rem_pres";
	b["floodlight_gtag_cat"] = "remar0";
      }     
      break;
    case "carte":
      if(new RegExp(/^ucps\:privati\+privati\:carte\:(tuttelecarte|trovalatuacarta)$/gi).test(b["ext_pageName"])) {
	b["floodlight_gtag_account"] = "6977905";
	b["floodlight_gtag_mode"] = "standard";
	b["floodlight_gtag_type"] = "rem_flex";
	b["floodlight_gtag_cat"] = "remar0";
	
	b["floodlight_rem2_type"] = "rem_gen";
	b["floodlight_rem2_cat"] = "remar0";
      }
      else if(new RegExp(/^ucps\:privati\+privati\:carte\:tuttelecarte\:cartedicredito($|\:)/gi).test(b["ext_pageName"])) {
	b["floodlight_gtag_account"] = "6977905";
	b["floodlight_gtag_mode"] = "standard";
        b["floodlight_gtag_type"] = "rem_flex";
	b["floodlight_gtag_cat"] = "remar0";
      }
      else if(new RegExp(/^ucps\:privati\+privati\:carte\:tuttelecarte\:carteprepagateiban($|\:)/gi).test(b["ext_pageName"])) {
        b["floodlight_rem_type"] = "rem_gen";
	b["floodlight_rem_cat"] = "remar0";
      }
      break;
  }

}
} } catch(e){ utag.DB(e) }  },
function(a,b){
utag.DB(b);
},
function(a,b){ try{ if(1){
if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/consulenza\-specialistica/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1099640";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/consulenza\-specialistica\/il\-modello\-di\-servizio\-la\-rete\-corporate/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1099641";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/consulenza\-specialistica\/family\-business/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1099644";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/consulenza\-specialistica\/specialista\-cash\-management/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1099645";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/consulenza\-specialistica\/retespecialistiinitalia/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1099648";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/consulenza\-specialistica\/specialisti\-corporate\-treasury\-sales/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1099651";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/consulenza\-specialistica\/finanza\-agevolata/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1099654";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/consulenza\-specialistica\/investment\-banking/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1099657";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/consulenza\-specialistica\/factoring/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1099660";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/consulenza\-specialistica\/leasing/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1099663";
	
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/consulenza\-specialistica\/servizi\-di\-intestazione\-fiduciaria/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1099666";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/consulenza\-specialistica\/settore\-immobiliare/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1099669";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/in\-primo\-piano/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100933";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100936";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/reteinternazionaleunicredit/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100937";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/unicredit\-international\-center\-italy/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100940";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/go\-international/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100943";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/incontri\-b2b/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100945";
}
else if(new RegExp(/^\/it\/piccole\-imprese\/international\/tutti\-i\-prodotti\-per\-l\-estero\/calendario\-eventi/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100948";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/settore\-pubblico1/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100949";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/prodotti\-di\-finanziamento/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100951";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/consulenza\-e\-servizi/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100952";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/i\-faber/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100953";
}
else if(new RegExp(/^\it\/corporate\/perche\-unicredit\/servizi\-offerti\/unicredit\-start\-lab/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100955";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/officinae\-verdi/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100957";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/non\-profit/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100960";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/enti\-ecclesiastici/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100963";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/tlq7enti.html$/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100966";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/tlq7enti\/tlqwebenti/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100967";
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/tlq7enti\/servizitlqwebenti/gi).test(window.location.pathname)) {
	b["sizmek_account"] = "1100968";
}
else if(new RegExp(/^\/it\/privati\/mutui\/tutti\-i\-mutui\/per\-la\-casa\/mutuo\-unicredit\-tasso\-fisso/gi).test(window.location.pathname)) {
  b["sizmek_account"] = "1108206";
  if(b["mediacom_activity_id"] == "430750") { delete b["mediacom_activity_id"]; delete utag.data["mediacom_activity_id"]; }
}
} } catch(e){ utag.DB(e) }  }];
  utag.handler.cfg_extend=[{"alr":0,"bwq":0,"id":"57","blr":1,"end":0},{"alr":0,"bwq":0,"id":"10","blr":1,"end":0},{"alr":0,"bwq":0,"id":"2","blr":1,"end":0},{"alr":0,"bwq":0,"id":"3","blr":1,"end":0},{"alr":0,"bwq":0,"id":"11","blr":1,"end":0},{"alr":0,"bwq":0,"id":"26","blr":1,"end":0},{"alr":0,"bwq":0,"id":"9","blr":1,"end":0},{"alr":0,"bwq":0,"id":"24","blr":1,"end":0},{"alr":0,"bwq":0,"id":"54","blr":1,"end":0},{"alr":0,"bwq":0,"id":"55","blr":1,"end":0},{"alr":0,"bwq":0,"id":"30","blr":1,"end":0},{"alr":0,"bwq":0,"id":"27","blr":1,"end":0},{"alr":0,"bwq":0,"id":"28","blr":1,"end":0},{"alr":0,"bwq":0,"id":"32","blr":1,"end":0},{"alr":0,"bwq":0,"id":"7","blr":1,"end":0},{"alr":1,"bwq":0,"id":"112","blr":0,"end":0},{"alr":1,"bwq":0,"id":"120","blr":0,"end":0},{"alr":1,"bwq":0,"id":"33","blr":0,"end":0},{"alr":0,"bwq":0,"id":"53","blr":1,"end":0},{"alr":0,"bwq":0,"id":"39","blr":1,"end":0},{"alr":0,"bwq":0,"id":"49","blr":1,"end":0},{"alr":0,"bwq":0,"id":"58","blr":1,"end":0},{"alr":0,"bwq":0,"id":"40","blr":1,"end":0},{"alr":0,"bwq":0,"id":"46","blr":1,"end":0},{"alr":0,"bwq":0,"id":"47","blr":1,"end":0},{"alr":0,"bwq":0,"id":"91","blr":1,"end":0},{"alr":1,"bwq":0,"id":"31","blr":0,"end":0},{"alr":0,"bwq":0,"id":"114","blr":1,"end":0}];
  utag.loader.initcfg = function(){
    utag.loader.cfg={"38":{load:utag.cond[26],send:1,v:201703270836,wait:1,tid:20010},"3":{load:utag.cond[9],send:1,v:201801051549,wait:1,tid:19063},"7":{load:utag.cond[8],send:1,v:201801051549,wait:1,tid:19063},"9":{load:utag.cond[10],send:1,v:201607191538,wait:1,tid:13032},"10":{load:utag.cond[11],send:1,v:201607191538,wait:1,tid:20078},"11":{load:(utag.cond[28] && utag.cond[35]),send:1,v:201706130854,wait:1,tid:7129},"12":{load:utag.cond[12],send:1,v:201607191538,wait:1,tid:7129},"13":{load:utag.cond[13],send:1,v:201607191538,wait:1,tid:7129},"15":{load:utag.cond[15],send:1,v:201607191538,wait:1,tid:7129},"25":{load:utag.cond[28],send:1,v:201703280837,wait:1,tid:7129},"31":{load:utag.cond[20],send:1,v:201609160948,wait:1,tid:7129},"26":{load:utag.cond[28],send:1,v:201703280837,wait:1,tid:6026},"20":{load:1,send:1,v:201607191538,wait:1,tid:23020},"22":{load:1,send:1,v:201705090843,wait:1,tid:20010},"23":{load:1,send:1,v:201703101647,wait:1,tid:20010},"24":{load:utag.cond[18],send:1,v:201703280837,wait:1,tid:20010},"30":{load:1,send:1,v:201703280837,wait:1,tid:20010},"32":{load:1,send:1,v:201703280837,wait:1,tid:2045},"35":{load:utag.cond[23],send:1,v:201703280837,wait:1,tid:7129},"39":{load:utag.cond[25],send:1,v:201703270836,wait:1,tid:3117},"43":{load:utag.cond[27],send:1,v:201703280837,wait:1,tid:7129},"44":{load:utag.cond[27],send:1,v:201703280837,wait:1,tid:6026},"46":{load:1,send:1,v:201705180958,wait:1,tid:1066},"47":{load:utag.cond[30],send:1,v:201705301536,wait:1,tid:7129},"48":{load:utag.cond[31],send:1,v:201706061321,wait:1,tid:6026},"49":{load:utag.cond[31],send:1,v:201706061321,wait:1,tid:7129},"50":{load:utag.cond[32],send:1,v:201706061321,wait:1,tid:6026},"51":{load:utag.cond[32],send:1,v:201706061321,wait:1,tid:7129},"53":{load:utag.cond[34],send:1,v:201708290729,wait:1,tid:4001},"57":{load:utag.cond[37],send:1,v:201708290729,wait:1,tid:4001},"54":{load:utag.cond[36],send:1,v:201706270839,wait:1,tid:7129},"55":{load:utag.cond[36],send:1,v:201706270839,wait:1,tid:6026},"61":{load:utag.cond[38],send:1,v:201711021511,wait:1,tid:20010},"62":{load:utag.cond[39],send:1,v:201712111332,wait:1,tid:7129},"63":{load:utag.cond[39],send:1,v:201712111332,wait:1,tid:6026},"64":{load:utag.cond[40],send:1,v:201801021048,wait:1,tid:20010}};
utag.loader.cfgsort=["38","3","7","9","10","11","12","13","15","25","31","26","20","22","23","24","30","32","35","39","43","44","46","47","48","49","50","51","53","57","54","55","61","62","63","64"];
  }
utag.loader.initcfg();
}

  if(typeof utag_cfg_ovrd!='undefined'){for(var i in utag.loader.GV(utag_cfg_ovrd))utag.cfg[i]=utag_cfg_ovrd[i]};
  utag.loader.PINIT = function(a,b,c){
    utag.DB("Pre-INIT");
    if (utag.cfg.noload) {
      return;
    }

    try {
      // Initialize utag.data
      this.GET();
      // Even if noview flag is set, we still want to load in tags and have them ready to fire
      // FUTURE: blr = "before load rules"
      if(utag.handler.RE('view',utag.data,"blr")){
        utag.handler.LR(utag.data);
      }
      
    }catch(e){utag.DB(e)};
    // process 'blocking' tags (tags that need to run first)
    a=this.cfg;
    c=0;
    for (b in this.GV(a)) {
      // external .js files (currency converter tag) are blocking
      if(a[b].block == 1 || (a[b].load>0 && (typeof a[b].src!='undefined'&&a[b].src!=''))){
        a[b].block = 1;
        c=1;
        this.bq[b]=1;
      }
    }
    if(c==1) {
      for (b in this.GV(a)) {
        if(a[b].block){
          // handle case of bundled and blocking (change 4 to 1)
          // (bundled tags that do not have a .src should really never be set to block... they just run first)
          a[b].id=b; 
          if(a[b].load==4)a[b].load=1; 
 	  a[b].cb=function(){
            var d=this.uid;
            utag.loader.cfg[d].cbf=1;
            utag.loader.LOAD(d)
          };
          this.AS(a[b]);
        }
      }
    }
    if(c==0)this.INIT();
  };
  utag.loader.INIT = function(a, b, c, d, e) {
    utag.DB('utag.loader.INIT');
    if (this.ol == 1) return -1;
    else this.ol = 1;
    // The All Tags scope extensions run after blocking tags complete
    // The noview flag means to skip these Extensions (will run later for manual utag.view call)
    if(utag.cfg.noview!=true)utag.handler.RE('view',utag.data,"alr"); 

    utag.rpt.ts['i'] = new Date();
     
    d = this.cfgsort;
    // TODO: Publish engine should sort the bundled tags first..
    for (a=0;a<d.length;a++){
      e = d[a];
      b = this.cfg[e];
      b.id = e;
      // s2s (ServerStream) tags do not load client-side
      if(b.block != 1 && b.s2s != 1){
        // do not wait if the utag.cfg.noview flag is set and the tag is bundled
        if (utag.loader.bk[b.id] || ((utag.cfg.readywait||utag.cfg.noview) && b.load==4)){
          this.f[b.id]=0;
          utag.loader.LOAD(b.id)
        }else if (b.wait == 1 && utag.loader.rf == 0) {
	  utag.DB('utag.loader.INIT: waiting ' + b.id);
          this.wq.push(b)
          this.f[b.id]=2;
        }else if (b.load>0){
	  utag.DB('utag.loader.INIT: loading ' + b.id);
	  this.lq.push(b);
          this.AS(b);
        }
      }
    }
          
    if (this.wq.length > 0) utag.loader.EV('', 'ready', function(a) {
      if(utag.loader.rf==0){
        utag.DB('READY:utag.loader.wq');
        utag.loader.rf=1;
        utag.loader.WQ();
      }
    });
    else if(this.lq.length>0)utag.loader.rf=1;
    else if(this.lq.length==0)utag.loader.END();

    return 1
  };
  utag.loader.EV('', 'ready', function(a) {if(utag.loader.efr!=1){utag.loader.efr=1;try{
if(typeof utag.data.aEngagement !="undefined")
{
var resId ="";
var tempDM;
var tempCC;
var tempHP;
var tempS;
var tempSIP;
var tempSFI;
var tempI;
var tempT;
var tempCCH;
var tempPC;
var tempIC;
for(i=0;i<utag.data.aEngagement.length;i++)
   {
     if(typeof utag.data.aEngagement[i].cmDeliveryMode=="undefined")
       tempDM = "";
     else
       tempDM = utag.data.aEngagement[i].cmDeliveryMode;
     if(typeof utag.data.aEngagement[i].cmCode=="undefined")
       tempCC = "";
     else
       tempCC = utag.data.aEngagement[i].cmCode;
     if(typeof utag.data.aEngagement[i].hashPage=="undefined")
       tempHP = "";
     else
       tempHP = utag.data.aEngagement[i].hashPage;
     if(typeof utag.data.aEngagement[i].space=="undefined")
       tempS = "";
     else
       tempS = utag.data.aEngagement[i].space;
     if(typeof utag.data.aEngagement[i].spaceFirstItem=="undefined")
       tempSFI = "";
     else
       tempSFI = utag.data.aEngagement[i].spaceFirstItem;
     if(typeof utag.data.aEngagement[i].spaceItemPosition=="undefined")
       tempSIP = "";
     else
       tempSIP = utag.data.aEngagement[i].spaceItemPosition;
     if(typeof utag.data.aEngagement[i].id=="undefined")
       tempI = "";
     else
       tempI = utag.data.aEngagement[i].id;
     if(typeof utag.data.aEngagement[i].type=="undefined")
       tempT = "";
     else
       tempT = utag.data.aEngagement[i].type;
      if(typeof utag.data.aEngagement[i].cmChannel=="undefined")
       tempCCH = "";
     else
       tempCCH = utag.data.aEngagement[i].cmChannel;
     if(typeof utag.data.aEngagement[i].prodCode=="undefined")
       tempPC = "";
     else
       tempPC = utag.data.aEngagement[i].prodCode;
     if(typeof utag.data.aEngagement[i].intcid=="undefined")
       tempIC = "";
     else
       tempIC = utag.data.aEngagement[i].intcid;
     
       if (resId)
       {
	 if(tempIC)
	     resId += "|"+tempIC;
	 else if (tempCC)
	   resId += "|"+tempDM+":"+tempCC+":"+tempHP+":"+tempS+":"+tempSIP+":"+tempSFI+":"+tempI+":"+tempT+":"+tempCCH+":"+tempPC+":"+tempIC;
	 else if (tempT && tempPC && tempT!="heroBanner" && tempT!="lineStrip" && tempT!="overlayBanner" && tempT!="slider" && tempT!="sliderAlt")
	   resId += "|INT-RR-"+ tempPC;
	 else
	   resId += "";
       }
	 else
	 {
	   if(tempIC)
	     resId = tempIC;
	   else if (tempCC)
	     resId = tempDM+":"+tempCC+":"+tempHP+":"+tempS+":"+tempSIP+":"+tempSFI+":"+tempI+":"+tempT+":"+tempCCH+":"+tempPC+":"+tempIC;
	    else if (tempT && tempPC && tempT!="heroBanner" && tempT!="lineStrip" && tempT!="overlayBanner" && tempT!="slider" && tempT!="sliderAlt")
	     resId = "INT-RR-"+ tempPC;
	   else
	      resId = "";
	 }
       }
 utag.data.ext_bannerIds = resId ;
}
  
}catch(e){utag.DB(e)};
try{
if(typeof utag.data.aProduct!="undefined")
{
utag.data.ext_prodCode = [];
var count = 0;
utag.data.ext_prodCat = [];
utag.data.ext_prodName = [];
var flagEvent = false;
for(i=0;i< utag.data.aProduct.length;i++)
   {
     utag.data.ext_prodCode[count] = utag.data.aProduct[i].code;
     utag.data.ext_prodCat[count] = utag.data.aProduct[i].category;
     utag.data.ext_prodName[count] = utag.data.aProduct[i].name;
     count++;
     flagEvent = true;
   }
if(utag.data.aProduct.length==1)
  utag.data.ext_productVar = utag.data.aProduct[0].category+";"+utag.data.aProduct[0].code;
  
utag.data.ext_productVar = utag.data.ext_productVar.toLowerCase();

  if (flagEvent)
  utag.data.ext_prodViewEvent = "true";
  
  utag.data.flat_productName = utag.data.ext_prodName.join(",")
  utag.data.flat_productCat = utag.data.ext_prodCat.join(",")
  utag.data.flat_productCode = utag.data.ext_prodCode.join(",")
}
else
  utag.data.ext_productVar="";
  
}catch(e){utag.DB(e)};
try{
if(utag.data.ext_pageName == "ucps:privati+privati:prestiti:tuttiiprestiti:perleesigenzedituttiigiorni:creditexpresseasy"){
  window.goog_snippet_vars = function() {
    var w = window;
    w.google_conversion_id = 994682926;
    w.google_conversion_label = "VKPrCNKQ2WsQrtCm2gM";
    w.google_remarketing_only = false;
  }
  // DO NOT CHANGE THE CODE BELOW.
  window.goog_report_conversion = function(url) {
    window.goog_snippet_vars();
    window.google_conversion_format = "3";
    var opt = new Object();
    /*opt.onload_callback = function() {
    if (typeof(url) != 'undefined') {
      window.location = url;
    }
  }*/
  var conv_handler = window['google_trackConversion'];
  if (typeof(conv_handler) == 'function') {
    conv_handler(opt);
  }
}
    
$('a[href="https://play.google.com/store/apps/details?id=com.unicredit"]').on('mousedown' , function(){window.goog_report_conversion('')})    
$('a[href="https://itunes.apple.com/it/app/unicredit/id396670008?mt=8"]').on('mousedown' , function(){goog_report_conversion('')})   
}
}catch(e){utag.DB(e)};
try{ try{ if(1){
if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/consulenza\-specialistica\/family\-business/gi).test(window.location.pathname) &&
   jQuery("a[href*='mailto:family.business@unicredit.eu']").length > 0 
  ) {
  jQuery("a[href*='mailto:family.business@unicredit.eu']").on("click", function() {
    utag.link({ "link_name" : "SizMek Unicredit Corporate", "sizmek_account" : "1099679", "sizmek_event" : "click" }, undefined, [61]);
  });
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/go\-international/gi).test(window.location.pathname) &&
        jQuery("a[href*='mailto:gointernational']").length > 0 
       ) {
  jQuery("a[href*='mailto:gointernational']").on("click", function() {
    utag.link({ "link_name" : "SizMek Unicredit Corporate", "sizmek_account" : "1100944", "sizmek_event" : "click" }, undefined, [61]);
  });
}
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/settore\-pubblico1/gi).test(window.location.pathname) &&
	jQuery("a[href*='mailto:enti.uccorporate.it@unicreditgroup.eu']").length > 0) {
  jQuery("a[href*='mailto:enti.uccorporate.it@unicreditgroup.eu']").on("click", function() {
    utag.link({ "link_name" : "SizMek Unicredit Corporate", "sizmek_account" : "1100950", "sizmek_event" : "click" }, undefined, [61]);
  });
  }
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/i\-faber/gi).test(window.location.pathname) &&
	jQuery("a[href*='mailto:marketing@i-faber.com']").length > 0) {
  jQuery("a[href*='mailto:marketing@i-faber.com']").on("click", function() {
    utag.link({ "link_name" : "SizMek Unicredit Corporate", "sizmek_account" : "1100954", "sizmek_event" : "click" }, undefined, [61]);
  });
  }
else if(new RegExp(/^\/it\/corporate\/perche\-unicredit\/servizi\-offerti\/unicredit\-start\-lab/gi).test(window.location.pathname) &&
	jQuery(".btn.border_info.m").length > 0) {
  jQuery(".btn.border_info.m").on("mousedown", function() {
    utag.link({ "link_name" : "SizMek Unicredit Corporate", "sizmek_account" : "1100956", "sizmek_event" : "click" }, undefined, [61]);
  });
  }

} } catch(e){ utag.DB(e) }  }catch(e){utag.DB(e)};}})

  if(utag.cfg.readywait || utag.cfg.waittimer){
    utag.loader.EV('', 'ready', function(a) {
      if(utag.loader.rf==0){
        utag.loader.rf=1;
        utag.cfg.readywait=1;
        utag.DB('READY:utag.cfg.readywait');
        setTimeout(function(){utag.loader.PINIT()}, utag.cfg.waittimer || 1);
      }
    })
  }else{
    utag.loader.PINIT()
  }
}

