/**
 * Javascript functions for locale selections
 */
var cookieUtils = (function(){
	var createCookie = function (name, value, days) {
	    var expires;

	    if (days) {
	        var date = new Date();
	        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
	        expires = "; expires=" + date.toGMTString();
	    } else {
	        expires = "";
	    }
	    
	    //change privacy mode intercept event - ee34086 - 01-03-2017
	    if(name == 'GIMB_PRIVACY_MODE'){
	    	if(value == 'true' || value == true){
	    		//activating privacy mode
	    		$.event.trigger('privacyModeActivated');
	    	}else{
	    		$.event.trigger('privacyModeDeactivated');
	    	}
	    }
	    
	    document.cookie = escape(name) + "=" + escape(value) + expires + "; path=/;";
	};

	var readCookie = function(name) {
	    var nameEQ = escape(name) + "=";
	    var ca = document.cookie.split(';');
	    for (var i = 0; i < ca.length; i++) {
	        var c = ca[i];
	        while (c.charAt(0) === ' ') c = c.substring(1, c.length);
	        if (c.indexOf(nameEQ) === 0) return unescape(c.substring(nameEQ.length, c.length));
	    }
	    return null;
	};

	var eraseCookie = function(name) {
	    createCookie(name, "", -1);
	};
	
	return {
		createCookie: createCookie,
		readCookie: readCookie,
		eraseCookie: eraseCookie
	};
})();

var langSelection = (function(){
	var setLocaleCookie = function(containerId){
		var selectedLang = $("#"+containerId+" select").val();
		var cookieName = "GIMB_LOCALE";
		cookieUtils.createCookie(cookieName, selectedLang, 2);
	};

    function _pageReload(){
			var urlToRedirect = window.location.href;
			urlToRedirect = urlToRedirect.substring(0, urlToRedirect.indexOf("/!ut") );
			window.location.href = urlToRedirect;
		}

	return{
		setLocaleCookie: setLocaleCookie,
		changeLangIt : function(){
			cookieUtils.createCookie("GIMB_LOCALE", "it");
			_pageReload();
		},
		changeLangEn : function(){
			cookieUtils.createCookie("GIMB_LOCALE", "en");
			_pageReload();
		},
        changeLangAtDe : function(){
			cookieUtils.createCookie("GIMB_LOCALE", "de");
			_pageReload();
    	},
        changeLangAtEn : function(){
			cookieUtils.createCookie("GIMB_LOCALE", "en");
			_pageReload();
    	}
	};
	
})();