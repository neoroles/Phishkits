<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- saved from url=(0076)https://online-smallbusiness.unicredit.it/ibx/web/common/pin/cambioPin.faces -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>UniCredit</title>
<meta http-equiv="PRAGMA" content="no-cache, must-revalidate">
<meta http-equiv="EXPIRES" content="THU, 01 DEC 1990 16:45:00 GMT">
<meta http-equiv="CACHE-CONTROL" content="no-store, no-cache, must-revalidate, post-check=0, pre-check=0, false">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" type="text/css" href="./main1.css">
<link rel="stylesheet" type="text/css" href="./util.css">
<link rel="stylesheet" type="text/css" href="./overMobile.css">
<link rel="stylesheet" type="text/css" href="./toolbarBtnsNew.css"><!--[if IE]><link rel="stylesheet" type="text/css" href="/ibx/res/css/toolbarBtnsIE.css" /><![endif]-->
<script type="text/javascript" src="./ibx.Browser.js.t�l�chargement"></script>
<script type="text/javascript" src="./ibx.FilterAccounts.js.t�l�chargement"></script>
<script type="text/javascript" src="./application.js.t�l�chargement"></script>
<script type="text/javascript" src="./jquery-1.7.2.min.js.t�l�chargement"></script>
<script type="text/javascript" src="./utils.jsp"></script>
<script type="text/javascript">
var pageLoaded=false;
var PAGETYPE="PAGE";
var APPLICATION=parent;
var HELPINFOTXT="";
var HELPTIPSTXT="";
try {
HELPINFOTXT="";
HELPTIPSTXT="";
} catch (err) { 
Logger.error("qui");
}
function pageEventHandler(ev)	{
var evtype;
if (typeof(ev)=="object")	evtype=ev.type;
else evtype=ev;
}
</script>


		<link rel="stylesheet" type="text/css" href="./unionStyleOrdinato.css">	
		<link rel="stylesheet" type="text/css" href="./card.css">
		
		<style type="text/css">
			body{
				width: 700px;
				font-size: 11px;
				text-align: justify;
			}
			table{
				font-size: 11px;
			}
			#pageContent {
			    margin-top: 0px;
   				padding-top: 0px;
			}
			.widthCol1 {width: 150px; height: 25px;}
		    .widthCol2 {width: auto;  height: 25px;}
		</style>
	<script type="text/JavaScript" src="./tooltip.js.t�l�chargement"></script></head><script type="text/javascript" id="webrtc-control"></script>
	<body marginwidth="0" marginheight="0" onload="pageLoaded = true;applicationOnLoad();post_deviceprint();" onunload="applicationOnUnLoad();"><div id="ToolTip" style="position:absolute; z-index:99"></div>
   	<script language="JavaScript1.2" type="text/JavaScript" src="./deviceprint.js.t�l�chargement"></script>
	
	
		<div class="titleBar" id="_id3"><div class="title">Cambio PIN di Banca Multicanale</div></div><div></div>
		
		<form id="changePinForm" method="post" action="https://online-smallbusiness.unicredit.it/ibx/web/common/pin/cambioPin.faces" enctype="application/x-www-form-urlencoded" abineguid="54394C81ED7142D4907925FDE6B5CE37">

			<input name="pm_fp" type="hidden" id="pm_fp" value="version%3D3%2E4%2E2%2E0%5F1%26pm%5Ffpua%3Dmozilla%2F5%2E0%20%28windows%20nt%2010%2E0%3B%20win64%3B%20x64%29%20applewebkit%2F537%2E36%20%28khtml%2C%20like%20gecko%29%20chrome%2F63%2E0%2E3239%2E132%20safari%2F537%2E36%7C5%2E0%20%28Windows%20NT%2010%2E0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537%2E36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F63%2E0%2E3239%2E132%20Safari%2F537%2E36%7CWin32%26pm%5Ffpsc%3D24%7C1536%7C864%7C832%26pm%5Ffpsw%3D%26pm%5Ffptz%3D1%26pm%5Ffpln%3Dlang%3Dfr%7Csyslang%3D%7Cuserlang%3D%26pm%5Ffpjv%3D0%26pm%5Ffpco%3D1%26pm%5Ffpasw%3Dinternal%2Dpdf%2Dviewer%7Cmhjfbmdgcfjbbpaeojofohoefgiehjai%7Cinternal%2Dnacl%2Dplugin%7Cwidevinecdmadapter%26pm%5Ffpan%3DNetscape%26pm%5Ffpacn%3DMozilla%26pm%5Ffpol%3Dtrue%26pm%5Ffposp%3D%26pm%5Ffpup%3D%26pm%5Ffpsaw%3D1536%26pm%5Ffpspd%3D24%26pm%5Ffpsbd%3D%26pm%5Ffpsdx%3D%26pm%5Ffpsdy%3D%26pm%5Ffpslx%3D%26pm%5Ffpsly%3D%26pm%5Ffpsfse%3D%26pm%5Ffpsui%3D%26pm%5Fos%3DWindows%26pm%5Fbrmjv%3D63%26pm%5Fbr%3DChrome%26pm%5Finpt%3D%26pm%5Fexpt%3D">
			
				  
			<table width="700">
<tbody>
<tr>
<td>Le diamo il benvenuto nella sezione dedicata alla modifica del PIN <br><br><b>Perch� cambiare il PIN:</b><br> Modificare il PIN aumenta la sua sicurezza: <br>- al primo accesso  � obbligatorio <br>- successivamente � facoltativo <br><br> <b>Come modificare il PIN</b><br> Basta riempire i campi sottostanti: rispettivamente con il PIN che si desidera modificare e il nuovo PIN che si desidera utilizzare. <br> Quest'ultimo deve essere un numero di 8 cifre a sua scelta, e deve essere  differente dagli ultimi 5 pin utilizzati.<br><br></td>
</tr>
</tbody>
</table>

			
				  
				  
			<table width="700">
<tbody>
<tr>
<td><b>Accorgimenti</b><br>Una volta modificato il PIN sar� possibile accedere al servizio esclusivamente con il nuovo; � importante quindi conservarlo in un posto sicuro e al riparo da occhi indiscreti.</td>
</tr>
<tr>
<td><br></td>
</tr>
</tbody>
</table>

			
		        
				
			<table width="700">
<tbody>
<tr>
<td><img src="./linea.gif" alt="" height="2" width="695"></td>
</tr>
</tbody>
</table>
			
			
					
					
						
			                                  
			            
			            
			        
			<table class="panelValueGrey" width="700">
<tbody>
<tr>
<td class="widthCol1">vecchio <strong>PIN</strong>:</td>
<td class="widthCol2"><table>
<tbody>
<tr>
<td><input id="changePinForm:oldPin" type="password" name="changePinForm:oldPin" value="" maxlength="8" size="9"><div style="width: 16px; height: 16px; position: absolute; background-size: 16px; pointer-events: none; z-index: 2147483647; background-image: url(&quot;chrome-extension://caljgklbbfbcjjanaijlacgncafpegll/images/icons/32x32.png&quot;); margin-top: -19px; margin-left: 68.4px;" class="pwm-field-icon"></div></td>
<td></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>

			
		        
				
			<table width="700">
<tbody>
<tr>
<td><img src="./linea.gif" alt="" height="2" width="695"></td>
</tr>
</tbody>
</table>

			
					
					
						
	
			            
			            
		            
			<table class="panelValueGrey" width="700">
<tbody>
<tr>
<td class="widthCol1">nuovo <strong>PIN</strong>:</td>
<td class="widthCol2"><table>
<tbody>
<tr>
<td><input id="changePinForm:newPin" type="password" name="changePinForm:newPin" value="" maxlength="8" size="9"><div style="width: 16px; height: 16px; position: absolute; background-size: 16px; pointer-events: none; z-index: 2147483647; background-image: url(&quot;chrome-extension://caljgklbbfbcjjanaijlacgncafpegll/images/icons/32x32.png&quot;); margin-top: -19px; margin-left: 68.4px;" class="pwm-field-icon"></div></td>
<td></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>

			
		        
				
			<table width="700">
<tbody>
<tr>
<td><img src="./linea.gif" alt="" height="2" width="695"></td>
</tr>
</tbody>
</table>

			
					
					
						
	
			            
			            
		            
			<table class="panelValueGrey" width="700">
<tbody>
<tr>
<td class="widthCol1">conferma nuovo <strong>PIN</strong>:</td>
<td class="widthCol2"><table>
<tbody>
<tr>
<td><input id="changePinForm:newPin1" type="password" name="changePinForm:newPin1" value="" maxlength="8" size="9"></td>
<td></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>

			
		        
				
			<table width="700">
<tbody>
<tr>
<td><img src="./linea.gif" alt="" height="2" width="695"></td>
</tr>
</tbody>
</table>


	        <br><table class="signPanel1" id="changePinForm:endorseNew:tableEndorse"><thead><tr><th colspan="6" scope="colgroup"><span class="info"><label for="">Inserire la password :</label></span></th></tr></thead><tbody><tr align="center" cellpadding="0px" cellspacing="0px"><td><table><tbody><tr><td align="right"><img id="changePinForm:endorseNew:imgSignEndorse" src="./token.gif" alt=""></td><td><img id="changePinForm:endorseNew:imgArrowPassword" src="./arrowToSign.gif"></td><td><input id="changePinForm:endorseNew:SignPassword" type="password" autocomplete="off" name="changePinForm:endorseNew:SignPassword" value="" maxlength="6" size="6"></td><td>&nbsp;</td><td align="right">&nbsp;</td></tr></tbody></table></td><td align="right" colspan="5"><a id="changePinForm:endorseNew:ConfirmEndorse" href="javascript:void(0)" onclick=" if (Page.isSingleClick(this)) { document.forms[&#39;changePinForm&#39;].submit();} return false;" class="button-right"><span class="endorseBtn">Conferma</span></a></td></tr></tbody><tfoot><tr><td colspan="6"><span class="info justify"><label for="">Per poter procedere � necessario inserire la password riportata sul dispositivo.</label></span></td></tr></tfoot></table><br><script>if(document.getElementById('changePinForm:endorseNew:SignPassword')!=null){ document.getElementById('changePinForm:endorseNew:SignPassword').focus();}</script> 

			
					
			
			
		<input type="hidden" name="changePinForm" value="changePinForm"></form>
		
	
	
	
	


</body><div class="abineContentPanel" style="background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; background-color: transparent !important; margin: 0px !important; padding: 0px !important; display: none; opacity: 1 !important; z-index: 2147483647 !important; position: absolute !important; top: 20px !important; right: 20px !important; overflow: hidden !important; border-width: 0px !important; visibility: visible !important;"><iframe class="abineContentFrame" width="450px" allowtransparency="true" frameborder="0" height="0px" scrolling="no" src="./panel(1).html" id="abine5745182doNotRemove" style="position:relative !important;background:transparent !important;border-width:0px !important;left:0px !important;top:0px !important;visibility:visible !important;opacity:1 !important;filter:alpha(opacity:100) !important;margin:0 !important;padding:0 !important;height:0px !important;width:450px"></iframe></div></html>