//prevent full caching page on safari for ios instead of do an http get when user clicks on browser back button
window.onpageshow = function(event) {
    if (event.persisted) {
        window.location.reload() 
    }
};