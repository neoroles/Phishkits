//~~tv:19063.am160.20160510
//~~tc: Add VALUE_event## tab in toolbox
//~~tc: Fixed issue of non-mobile calls having undefined u.data.a
//~~tc: Add Mobile App support


var ucaa = new AppMeasurement();
ucaa.account="";

/************************** CONFIG SECTION **************************/
ucaa.trackDownloadLinks=true;
ucaa.trackExternalLinks=true;
ucaa.trackInlineStats=true;
ucaa.linkInternalFilters="javascript:,.unicredit.it,.usinet.it";
ucaa.linkLeaveQueryString=false;
ucaa.linkTrackVars="None";
ucaa.linkTrackEvents="None";
ucaa.usePlugins=false;
ucaa.currencyCode="USD"; // override default with E-Commerce Extension
ucaa.visitorNamespace = "";
ucaa.trackingServer="ucmetrics.unicredit.it";
ucaa.trackingServerSecure="sucmetrics.unicredit.it";

ucaa.debugTracking=utag.cfg.utagdb;

if ("C7415A4E52E186480A490D4D@AdobeOrg") {
// NOTE: Modified API to put Visitor in window scope so it is only declared if cloudid value specificed (removes hoisting)
/*
 ============== DO NOT ALTER ANYTHING BELOW THIS LINE ! ============

 Adobe Visitor API for JavaScript version: 1.5.4
 Copyright 1996-2015 Adobe, Inc. All Rights Reserved
 More info available at http://www.omniture.com
*/
function Visitor(m,t){if(!m)throw"Visitor requires Adobe Marketing Cloud Org ID";var a=this;a.version="1.5.4";var l=window,i=l.Visitor;i.version=a.version;l.s_c_in||(l.s_c_il=[],l.s_c_in=0);a._c="Visitor";a._il=l.s_c_il;a._in=l.s_c_in;a._il[a._in]=a;l.s_c_in++;a.pa={Ka:[]};var o=l.document,h=i.Ma;h||(h=null);var z=i.Na;z||(z=void 0);var j=i.ja;j||(j=!0);var k=i.La;k||(k=!1);a.S=function(a){var c=0,b,e;if(a)for(b=0;b<a.length;b++)e=a.charCodeAt(b),c=(c<<5)-c+e,c&=c;return c};a.r=function(a){var c=
"0123456789",b="",e="",f,g=8,n=10,h=10;if(1==a){c+="ABCDEF";for(a=0;16>a;a++)f=Math.floor(Math.random()*g),b+=c.substring(f,f+1),f=Math.floor(Math.random()*g),e+=c.substring(f,f+1),g=16;return b+"-"+e}for(a=0;19>a;a++)f=Math.floor(Math.random()*n),b+=c.substring(f,f+1),0==a&&9==f?n=3:(1==a||2==a)&&10!=n&&2>f?n=10:2<a&&(n=10),f=Math.floor(Math.random()*h),e+=c.substring(f,f+1),0==a&&9==f?h=3:(1==a||2==a)&&10!=h&&2>f?h=10:2<a&&(h=10);return b+e};a.ma=function(){var a;!a&&l.location&&(a=l.location.hostname);
if(a)if(/^[0-9.]+$/.test(a))a="";else{var c=a.split("."),b=c.length-1,e=b-1;1<b&&2>=c[b].length&&(2==c[b-1].length||0>",ac,ad,ae,af,ag,ai,al,am,an,ao,aq,ar,as,at,au,aw,ax,az,ba,bb,be,bf,bg,bh,bi,bj,bm,bo,br,bs,bt,bv,bw,by,bz,ca,cc,cd,cf,cg,ch,ci,cl,cm,cn,co,cr,cu,cv,cw,cx,cz,de,dj,dk,dm,do,dz,ec,ee,eg,es,et,eu,fi,fm,fo,fr,ga,gb,gd,ge,gf,gg,gh,gi,gl,gm,gn,gp,gq,gr,gs,gt,gw,gy,hk,hm,hn,hr,ht,hu,id,ie,im,in,io,iq,ir,is,it,je,jo,jp,kg,ki,km,kn,kp,kr,ky,kz,la,lb,lc,li,lk,lr,ls,lt,lu,lv,ly,ma,mc,md,me,mg,mh,mk,ml,mn,mo,mp,mq,mr,ms,mt,mu,mv,mw,mx,my,na,nc,ne,nf,ng,nl,no,nr,nu,nz,om,pa,pe,pf,ph,pk,pl,pm,pn,pr,ps,pt,pw,py,qa,re,ro,rs,ru,rw,sa,sb,sc,sd,se,sg,sh,si,sj,sk,sl,sm,sn,so,sr,st,su,sv,sx,sy,sz,tc,td,tf,tg,th,tj,tk,tl,tm,tn,to,tp,tr,tt,tv,tw,tz,ua,ug,uk,us,uy,uz,va,vc,ve,vg,vi,vn,vu,wf,ws,yt,".indexOf(","+
c[b]+","))&&e--;if(0<e)for(a="";b>=e;)a=c[b]+(a?".":"")+a,b--}return a};a.cookieRead=function(a){var a=encodeURIComponent(a),c=(";"+o.cookie).split(" ").join(";"),b=c.indexOf(";"+a+"="),e=0>b?b:c.indexOf(";",b+1);return 0>b?"":decodeURIComponent(c.substring(b+2+a.length,0>e?c.length:e))};a.cookieWrite=function(d,c,b){var e=a.cookieLifetime,f,c=""+c,e=e?(""+e).toUpperCase():"";b&&"SESSION"!=e&&"NONE"!=e?(f=""!=c?parseInt(e?e:0,10):-60)?(b=new Date,b.setTime(b.getTime()+1E3*f)):1==b&&(b=new Date,f=
b.getYear(),b.setYear(f+2+(1900>f?1900:0))):b=0;return d&&"NONE"!=e?(o.cookie=encodeURIComponent(d)+"="+encodeURIComponent(c)+"; path=/;"+(b?" expires="+b.toGMTString()+";":"")+(a.cookieDomain?" domain="+a.cookieDomain+";":""),a.cookieRead(d)==c):0};a.g=h;a.A=function(a,c){try{"function"==typeof a?a.apply(l,c):a[1].apply(a[0],c)}catch(b){}};a.ra=function(d,c){c&&(a.g==h&&(a.g={}),a.g[d]==z&&(a.g[d]=[]),a.g[d].push(c))};a.m=function(d,c){if(a.g!=h){var b=a.g[d];if(b)for(;0<b.length;)a.A(b.shift(),
c)}};a.j=h;a.oa=function(d,c,b){var e=0,f=0,g;if(c&&o){for(g=0;!e&&2>g;){try{e=(e=o.getElementsByTagName(0<g?"HEAD":"head"))&&0<e.length?e[0]:0}catch(n){e=0}g++}if(!e)try{o.body&&(e=o.body)}catch(j){e=0}if(e)for(g=0;!f&&2>g;){try{f=o.createElement(0<g?"SCRIPT":"script")}catch(i){f=0}g++}}!c||!e||!f?b&&b():(f.type="text/javascript",f.setAttribute("async","async"),f.src=c,e.firstChild?e.insertBefore(f,e.firstChild):e.appendChild(f),a.pa.Ka.push(c),b&&(a.j==h&&(a.j={}),a.j[d]=setTimeout(b,a.loadTimeout)))};
a.ka=function(d){a.j!=h&&a.j[d]&&(clearTimeout(a.j[d]),a.j[d]=0)};a.T=k;a.U=k;a.isAllowed=function(){if(!a.T&&(a.T=j,a.cookieRead(a.cookieName)||a.cookieWrite(a.cookieName,"T",1)))a.U=j;return a.U};a.a=h;a.d=h;var B=i.$a;B||(B="MC");var r=i.fb;r||(r="MCMID");var C=i.ab;C||(C="MCCIDH");var D=i.eb;D||(D="MCSYNCS");var F=i.bb;F||(F="MCIDTS");var x=i.cb;x||(x="MCOPTOUT");var A=i.Ya;A||(A="A");var p=i.Va;p||(p="MCAID");var y=i.Za;y||(y="AAM");var w=i.Xa;w||(w="MCAAMLH");var q=i.Wa;q||(q="MCAAMB");var s=
i.gb;s||(s="NONE");a.C=0;a.R=function(){if(!a.C){var d=a.version;a.audienceManagerServer&&(d+="|"+a.audienceManagerServer);a.audienceManagerServerSecure&&(d+="|"+a.audienceManagerServerSecure);a.C=a.S(d)}return a.C};a.V=k;a.f=function(){if(!a.V){a.V=j;var d=a.R(),c=k,b=a.cookieRead(a.cookieName),e,f,g,n,i=new Date;a.a==h&&(a.a={});if(b&&"T"!=b){b=b.split("|");b[0].match(/^[\-0-9]+$/)&&(parseInt(b[0],10)!=d&&(c=j),b.shift());1==b.length%2&&b.pop();for(d=0;d<b.length;d+=2)if(e=b[d].split("-"),f=e[0],
g=b[d+1],1<e.length?(n=parseInt(e[1],10),e=0<e[1].indexOf("s")):(n=0,e=k),c&&(f==C&&(g=""),0<n&&(n=i.getTime()/1E3-60)),f&&g&&(a.c(f,g,1),0<n&&(a.a["expire"+f]=n+(e?"s":""),i.getTime()>=1E3*n||e&&!a.cookieRead(a.sessionCookieName))))a.d||(a.d={}),a.d[f]=j}if(!a.b(p)&&(b=a.cookieRead("s_vi")))b=b.split("|"),1<b.length&&0<=b[0].indexOf("v1")&&(g=b[1],d=g.indexOf("["),0<=d&&(g=g.substring(0,d)),g&&g.match(/^[0-9a-fA-F\-]+$/)&&a.c(p,g))}};a.ta=function(){var d=a.R(),c,b;for(c in a.a)!Object.prototype[c]&&
a.a[c]&&"expire"!=c.substring(0,6)&&(b=a.a[c],d+=(d?"|":"")+c+(a.a["expire"+c]?"-"+a.a["expire"+c]:"")+"|"+b);a.cookieWrite(a.cookieName,d,1)};a.b=function(d,c){return a.a!=h&&(c||!a.d||!a.d[d])?a.a[d]:h};a.c=function(d,c,b){a.a==h&&(a.a={});a.a[d]=c;b||a.ta()};a.na=function(d,c){var b=a.b(d,c);return b?b.split("*"):h};a.sa=function(d,c,b){a.c(d,c?c.join("*"):"",b)};a.Sa=function(d,c){var b=a.na(d,c);if(b){var e={},f;for(f=0;f<b.length;f+=2)e[b[f]]=b[f+1];return e}return h};a.Ua=function(d,c,b){var e=
h,f;if(c)for(f in e=[],c)Object.prototype[f]||(e.push(f),e.push(c[f]));a.sa(d,e,b)};a.k=function(d,c,b){var e=new Date;e.setTime(e.getTime()+1E3*c);a.a==h&&(a.a={});a.a["expire"+d]=Math.floor(e.getTime()/1E3)+(b?"s":"");0>c?(a.d||(a.d={}),a.d[d]=j):a.d&&(a.d[d]=k);b&&(a.cookieRead(a.sessionCookieName)||a.cookieWrite(a.sessionCookieName,"1"))};a.Q=function(a){if(a&&("object"==typeof a&&(a=a.d_mid?a.d_mid:a.visitorID?a.visitorID:a.id?a.id:a.uuid?a.uuid:""+a),a&&(a=a.toUpperCase(),"NOTARGET"==a&&(a=
s)),!a||a!=s&&!a.match(/^[0-9a-fA-F\-]+$/)))a="";return a};a.i=function(d,c){a.ka(d);a.h!=h&&(a.h[d]=k);if(d==B){var b=a.b(r);if(!b){b="object"==typeof c&&c.mid?c.mid:a.Q(c);if(!b){if(a.v){a.getAnalyticsVisitorID(h,k,j);return}b=a.r()}a.c(r,b)}if(!b||b==s)b="";"object"==typeof c&&((c.d_region||c.dcs_region||c.d_blob||c.blob)&&a.i(y,c),a.v&&c.mid&&a.i(A,{id:c.id}));a.m(r,[b])}if(d==y&&"object"==typeof c){b=604800;c.id_sync_ttl!=z&&c.id_sync_ttl&&(b=parseInt(c.id_sync_ttl,10));var e=a.b(w);e||((e=c.d_region)||
(e=c.dcs_region),e&&(a.k(w,b),a.c(w,e)));e||(e="");a.m(w,[e]);e=a.b(q);if(c.d_blob||c.blob)(e=c.d_blob)||(e=c.blob),a.k(q,b),a.c(q,e);e||(e="");a.m(q,[e]);!c.error_msg&&a.t&&a.c(C,a.t)}if(d==A){b=a.b(p);b||((b=a.Q(c))?a.k(q,-1):b=s,a.c(p,b));if(!b||b==s)b="";a.m(p,[b])}a.idSyncDisableSyncs?u.ba=j:(u.ba=k,b={},b.ibs=c.ibs,b.subdomain=c.subdomain,u.Ia(b));c===Object(c)&&(b=s,c.d_optout&&c.d_optout instanceof Array&&(b=c.d_optout.join(",")),e=parseInt(c.d_ottl,10),isNaN(e)&&(e=7200),a.k(x,e,!0),a.c(x,
b),a.m(x,[b]))};a.h=h;a.n=function(d,c,b,e){var f="",g;if(a.isAllowed()&&(a.f(),f=a.b(d),!f&&(d==r||d==x?g=B:d==w||d==q?g=y:d==p&&(g=A),g))){if(c&&(a.h==h||!a.h[g]))a.h==h&&(a.h={}),a.h[g]=j,a.oa(g,c,function(){if(!a.b(d)){var b="";d==r?b=a.r():g==y&&(b={error_msg:"timeout"});a.i(g,b)}});a.ra(d,b);c||a.i(g,{id:s});return""}if((d==r||d==p)&&f==s)f="",e=j;b&&e&&a.A(b,[f]);return f};a._setMarketingCloudFields=function(d){a.f();a.i(B,d)};a.setMarketingCloudVisitorID=function(d){a._setMarketingCloudFields(d)};
a.v=k;a.getMarketingCloudVisitorID=function(d,c){if(a.isAllowed()){a.marketingCloudServer&&0>a.marketingCloudServer.indexOf(".demdex.net")&&(a.v=j);var b=a.s("_setMarketingCloudFields");return a.n(r,b,d,c)}return""};a.qa=function(){a.getAudienceManagerBlob()};i.AuthState={UNKNOWN:0,AUTHENTICATED:1,LOGGED_OUT:2};a.q={};a.P=k;a.t="";a.setCustomerIDs=function(d){if(a.isAllowed()&&d){a.f();var c,b;for(c in d)if(!Object.prototype[c]&&(b=d[c]))if("object"==typeof b){var e={};b.id&&(e.id=b.id);b.authState!=
z&&(e.authState=b.authState);a.q[c]=e}else a.q[c]={id:b};var d=a.getCustomerIDs(),e=a.b(C),f="";e||(e=0);for(c in d)Object.prototype[c]||(b=d[c],f+=(f?"|":"")+c+"|"+(b.id?b.id:"")+(b.authState?b.authState:""));a.t=a.S(f);a.t!=e&&(a.P=j,a.qa())}};a.getCustomerIDs=function(){a.f();var d={},c,b;for(c in a.q)Object.prototype[c]||(b=a.q[c],d[c]||(d[c]={}),b.id&&(d[c].id=b.id),d[c].authState=b.authState!=z?b.authState:i.AuthState.UNKNOWN);return d};a._setAnalyticsFields=function(d){a.f();a.i(A,d)};a.setAnalyticsVisitorID=
function(d){a._setAnalyticsFields(d)};a.getAnalyticsVisitorID=function(d,c,b){if(a.isAllowed()){var e="";b||(e=a.getMarketingCloudVisitorID(function(){a.getAnalyticsVisitorID(d,j)}));if(e||b){var f=b?a.marketingCloudServer:a.trackingServer,g="";a.loadSSL&&(b?a.marketingCloudServerSecure&&(f=a.marketingCloudServerSecure):a.trackingServerSecure&&(f=a.trackingServerSecure));f&&(g="http"+(a.loadSSL?"s":"")+"://"+f+"/id?d_visid_ver="+a.version+"&callback=s_c_il%5B"+a._in+"%5D._set"+(b?"MarketingCloud":
"Analytics")+"Fields&mcorgid="+encodeURIComponent(a.marketingCloudOrgID)+(e?"&mid="+e:"")+(a.idSyncDisable3rdPartySyncing?"&d_coppa=true":""));return a.n(b?r:p,g,d,c)}}return""};a._setAudienceManagerFields=function(d){a.f();a.i(y,d)};a.s=function(d){var c=a.audienceManagerServer,b="",e=a.b(r),f=a.b(q,j),g=a.b(p),g=g&&g!=s?"&d_cid_ic=AVID%01"+encodeURIComponent(g):"";a.loadSSL&&a.audienceManagerServerSecure&&(c=a.audienceManagerServerSecure);if(c){var b=a.getCustomerIDs(),h,i;if(b)for(h in b)Object.prototype[h]||
(i=b[h],g+="&d_cid_ic="+encodeURIComponent(h)+"%01"+encodeURIComponent(i.id?i.id:"")+(i.authState?"%01"+i.authState:""));d||(d="_setAudienceManagerFields");b="http"+(a.loadSSL?"s":"")+"://"+c+"/id?d_visid_ver="+a.version+"&d_rtbd=json&d_ver=2"+(!e&&a.v?"&d_verify=1":"")+"&d_orgid="+encodeURIComponent(a.marketingCloudOrgID)+"&d_nsid="+(a.idSyncContainerID||0)+(e?"&d_mid="+e:"")+(a.idSyncDisable3rdPartySyncing?"&d_coppa=true":"")+(f?"&d_blob="+encodeURIComponent(f):"")+g+"&d_cb=s_c_il%5B"+a._in+"%5D."+
d}return b};a.getAudienceManagerLocationHint=function(d,c){if(a.isAllowed()&&a.getMarketingCloudVisitorID(function(){a.getAudienceManagerLocationHint(d,j)})){var b=a.b(p);b||(b=a.getAnalyticsVisitorID(function(){a.getAudienceManagerLocationHint(d,j)}));if(b)return b=a.s(),a.n(w,b,d,c)}return""};a.getAudienceManagerBlob=function(d,c){if(a.isAllowed()&&a.getMarketingCloudVisitorID(function(){a.getAudienceManagerBlob(d,j)})){var b=a.b(p);b||(b=a.getAnalyticsVisitorID(function(){a.getAudienceManagerBlob(d,
j)}));if(b)return b=a.s(),a.P&&a.k(q,-1),a.n(q,b,d,c)}return""};a.o="";a.u={};a.D="";a.F={};a.getSupplementalDataID=function(d,c){!a.o&&!c&&(a.o=a.r(1));var b=a.o;a.D&&!a.F[d]?(b=a.D,a.F[d]=j):b&&(a.u[d]&&(a.D=a.o,a.F=a.u,a.o=b=!c?a.r(1):"",a.u={}),b&&(a.u[d]=j));return b};i.OptOut={GLOBAL:"global"};a.getOptOut=function(d,c){if(a.isAllowed()){var b=a.s("_setMarketingCloudFields");return a.n(x,b,d,c)}return""};a.isOptedOut=function(d,c,b){return a.isAllowed()?(c||(c=i.OptOut.GLOBAL),(b=a.getOptOut(function(b){a.A(d,
[b==i.OptOut.GLOBAL||0<=b.indexOf(c)])},b))?b==i.OptOut.GLOBAL||0<=b.indexOf(c):h):k};var v={l:!!l.postMessage,ha:1,O:864E5};a.Oa=v;a.X={postMessage:function(a,c,b){var e=1;c&&(v.l?b.postMessage(a,c.replace(/([^:]+:\/\/[^\/]+).*/,"$1")):c&&(b.location=c.replace(/#.*$/,"")+"#"+ +new Date+e++ +"&"+a))},K:function(a,c){var b;try{if(v.l)if(a&&(b=function(b){if("string"===typeof c&&b.origin!==c||"[object Function]"===Object.prototype.toString.call(c)&&!1===c(b.origin))return!1;a(b)}),window.addEventListener)window[a?
"addEventListener":"removeEventListener"]("message",b,!1);else window[a?"attachEvent":"detachEvent"]("onmessage",b)}catch(e){}}};var G={Y:function(){if(o.addEventListener)return function(a,c,b){a.addEventListener(c,function(a){"function"===typeof b&&b(a)},k)};if(o.attachEvent)return function(a,c,b){a.attachEvent("on"+c,function(a){"function"===typeof b&&b(a)})}}(),map:function(a,c){if(Array.prototype.map)return a.map(c);if(void 0===a||a===h)throw new TypeError;var b=Object(a),e=b.length>>>0;if("function"!==
typeof c)throw new TypeError;for(var f=Array(e),g=0;g<e;g++)g in b&&(f[g]=c.call(c,b[g],g,b));return f},za:function(a,c){return this.map(a,function(a){return encodeURIComponent(a)}).join(c)}};a.Ta=G;var u={ia:3E4,N:649,fa:k,id:h,I:h,aa:function(a){if("string"===typeof a)return a=a.split("/"),a[0]+"//"+a[2]},e:h,url:h,Aa:function(){var d="http://fast.",c="?d_nsid="+a.idSyncContainerID+"#"+encodeURIComponent(o.location.href);this.e||(this.e="nosubdomainreturned");a.loadSSL&&(d=a.idSyncSSLUseAkamai?
"https://fast.":"https://");d=d+this.e+".demdex.net/dest5.html"+c;this.I=this.aa(d);this.id="destination_publishing_iframe_"+this.e+"_"+a.idSyncContainerID;return d},va:function(){var d="?d_nsid="+a.idSyncContainerID+"#"+encodeURIComponent(o.location.href);"string"===typeof a.B&&a.B.length&&(this.id="destination_publishing_iframe_"+(new Date).getTime()+"_"+a.idSyncContainerID,this.I=this.aa(a.B),this.url=a.B+d)},ba:h,H:k,M:k,w:h,hb:h,Ga:h,ib:h,L:k,z:[],Ea:[],Fa:[],ca:v.l?15:100,J:[],Ca:[],$:j,da:k,
Z:function(){function a(){e=document.createElement("iframe");e.id=b.id;e.style.cssText="display: none; width: 0; height: 0;";e.src=b.url;b.Ga=j;c();document.body.appendChild(e)}function c(){G.Y(e,"load",function(){e.className="aamIframeLoaded";b.w=j;b.p()})}this.M=j;var b=this,e=document.getElementById(this.id);e?"IFRAME"!==e.nodeName?(this.id+="_2",a()):"aamIframeLoaded"!==e.className?c():(this.w=j,this.p()):a();this.Ba=e},p:function(d){var c=this;d===Object(d)&&this.J.push(d);if((this.da||!v.l||
this.w)&&this.J.length)this.Ha(this.J.shift()),this.p();!a.idSyncDisableSyncs&&this.w&&this.z.length&&!this.L&&(this.fa||(this.fa=j,setTimeout(function(){c.ca=v.l?15:150},this.ia)),this.L=j,this.ea())},Ha:function(a){var c=encodeURIComponent,b,e,f,g,h;if((b=a.ibs)&&b instanceof Array&&(e=b.length))for(f=0;f<e;f++)g=b[f],h=[c("ibs"),c(g.id||""),c(g.tag||""),G.za(g.url||[],","),c(g.ttl||""),"","",g.fireURLSync?"true":"false"],this.$?this.G(h.join("|")):g.fireURLSync&&this.wa(g,h.join("|"));this.Ca.push(a)},
wa:function(d,c){a.f();var b=a.b(D),e=k,f=k,g=Math.ceil((new Date).getTime()/v.O);if(b){if(b=b.split("*"),f=this.Ja(b,d.id,g),e=f.xa,f=f.ya,!e||!f)this.G(c),b.push(d.id+"-"+(g+Math.ceil(d.ttl/60/24))),this.Da(b),a.c(D,b.join("*"))}else this.G(c),a.c(D,d.id+"-"+(g+Math.ceil(d.ttl/60/24)))},Ja:function(a,c,b){var e=k,f=k,g,h,i;for(h=0;h<a.length;h++)g=a[h],i=parseInt(g.split("-")[1],10),g.match("^"+c+"-")?(e=j,b<i?f=j:(a.splice(h,1),h--)):b>=i&&(a.splice(h,1),h--);return{xa:e,ya:f}},Da:function(a){if(a.join("*").length>
this.N)for(a.sort(function(a,b){return parseInt(a.split("-")[1],10)-parseInt(b.split("-")[1],10)});a.join("*").length>this.N;)a.shift()},G:function(d){var c=encodeURIComponent;this.z.push((a.Qa?c("---destpub-debug---"):c("---destpub---"))+d)},ea:function(){var d=this,c;this.z.length?(c=this.z.shift(),a.X.postMessage(c,this.url,this.Ba.contentWindow),this.Ea.push(c),setTimeout(function(){d.ea()},this.ca)):this.L=k},K:function(a){var c=/^---destpub-to-parent---/;"string"===typeof a&&c.test(a)&&(c=a.replace(c,
"").split("|"),"canSetThirdPartyCookies"===c[0]&&(this.$="true"===c[1]?j:k,this.da=j,this.p()),this.Fa.push(a))},Ia:function(d){this.url===h&&(this.e="string"===typeof a.W&&a.W.length?a.W:d.subdomain||"",this.url=this.Aa());d.ibs instanceof Array&&d.ibs.length&&(this.H=j);if(!a.idSyncDisable3rdPartySyncing&&(this.H||a.la)&&this.e&&"nosubdomainreturned"!==this.e&&!this.M)(i.ga||"complete"===o.readyState||"loaded"===o.readyState)&&this.Z();"function"===typeof a.idSyncIDCallResult?a.idSyncIDCallResult(d):
this.p(d);"function"===typeof a.idSyncAfterIDCallResult&&a.idSyncAfterIDCallResult(d)},ua:function(d,c){return a.Ra||!d||c-d>v.ha}};a.Pa=u;0>m.indexOf("@")&&(m+="@AdobeOrg");a.marketingCloudOrgID=m;a.cookieName="AMCV_"+m;a.sessionCookieName="AMCVS_"+m;a.cookieDomain=a.ma();a.cookieDomain==l.location.hostname&&(a.cookieDomain="");a.loadSSL=0<=l.location.protocol.toLowerCase().indexOf("https");a.loadTimeout=500;a.marketingCloudServer=a.audienceManagerServer="dpm.demdex.net";if(t&&"object"==typeof t){for(var E in t)!Object.prototype[E]&&
(a[E]=t[E]);a.idSyncContainerID=a.idSyncContainerID||0;a.f();E=a.b(F);var H=Math.ceil((new Date).getTime()/v.O);!a.idSyncDisableSyncs&&u.ua(E,H)&&(a.k(q,-1),a.c(F,H));a.getMarketingCloudVisitorID();a.getAudienceManagerLocationHint();a.getAudienceManagerBlob()}if(!a.idSyncDisableSyncs){u.va();G.Y(window,"load",function(){var d=u;i.ga=j;!a.idSyncDisable3rdPartySyncing&&(d.H||a.la)&&d.e&&"nosubdomainreturned"!==d.e&&d.url&&!d.M&&d.Z()});try{a.X.K(function(a){u.K(a.data)},u.I)}catch(I){}}}
Visitor.getInstance=function(m,t){var a,l=window.s_c_il,i;0>m.indexOf("@")&&(m+="@AdobeOrg");if(l)for(i=0;i<l.length;i++)if((a=l[i])&&"Visitor"==a._c&&a.marketingCloudOrgID==m)return a;return new Visitor(m,t)};

/*
(function(){function m(){t.ga=a}var t=window.Visitor,a=t.ja;a||(a=!0);window.addEventListener?window.addEventListener("load",m):window.attachEvent&&window.attachEvent("onload",m)})();
*/

  // End Visitor API

  window.visitor = new Visitor("C7415A4E52E186480A490D4D@AdobeOrg");
  window.visitor.trackingServer = ucaa.trackingServer;
  window.visitor.trackingServerSecure = ucaa.trackingServerSecure;

  ucaa.visitor = Visitor.getInstance("C7415A4E52E186480A490D4D@AdobeOrg");
}

// Start AppMeasurement
/*
============== DO NOT ALTER ANYTHING BELOW THIS LINE ! ===============

AppMeasurement for JavaScript version: 1.6
Copyright 1996-2016 Adobe, Inc. All Rights Reserved
More info available at http://www.adobe.com/marketing-cloud.html
*/
function AppMeasurement(){var a=this;a.version="1.6";var k=window;k.s_c_in||(k.s_c_il=[],k.s_c_in=0);a._il=k.s_c_il;a._in=k.s_c_in;a._il[a._in]=a;k.s_c_in++;a._c="s_c";var q=k.AppMeasurement.Db;q||(q=null);var r=k,n,t;try{for(n=r.parent,t=r.location;n&&n.location&&t&&""+n.location!=""+t&&r.location&&""+n.location!=""+r.location&&n.location.host==t.host;)r=n,n=r.parent}catch(u){}a.sb=function(a){try{console.log(a)}catch(b){}};a.Ba=function(a){return""+parseInt(a)==""+a};a.replace=function(a,b,d){return!a||
0>a.indexOf(b)?a:a.split(b).join(d)};a.escape=function(c){var b,d;if(!c)return c;c=encodeURIComponent(c);for(b=0;7>b;b++)d="+~!*()'".substring(b,b+1),0<=c.indexOf(d)&&(c=a.replace(c,d,"%"+d.charCodeAt(0).toString(16).toUpperCase()));return c};a.unescape=function(c){if(!c)return c;c=0<=c.indexOf("+")?a.replace(c,"+"," "):c;try{return decodeURIComponent(c)}catch(b){}return unescape(c)};a.kb=function(){var c=k.location.hostname,b=a.fpCookieDomainPeriods,d;b||(b=a.cookieDomainPeriods);if(c&&!a.cookieDomain&&
!/^[0-9.]+$/.test(c)&&(b=b?parseInt(b):2,b=2<b?b:2,d=c.lastIndexOf("."),0<=d)){for(;0<=d&&1<b;)d=c.lastIndexOf(".",d-1),b--;a.cookieDomain=0<d?c.substring(d):c}return a.cookieDomain};a.c_r=a.cookieRead=function(c){c=a.escape(c);var b=" "+a.d.cookie,d=b.indexOf(" "+c+"="),f=0>d?d:b.indexOf(";",d);c=0>d?"":a.unescape(b.substring(d+2+c.length,0>f?b.length:f));return"[[B]]"!=c?c:""};a.c_w=a.cookieWrite=function(c,b,d){var f=a.kb(),e=a.cookieLifetime,g;b=""+b;e=e?(""+e).toUpperCase():"";d&&"SESSION"!=
e&&"NONE"!=e&&((g=""!=b?parseInt(e?e:0):-60)?(d=new Date,d.setTime(d.getTime()+1E3*g)):1==d&&(d=new Date,g=d.getYear(),d.setYear(g+5+(1900>g?1900:0))));return c&&"NONE"!=e?(a.d.cookie=c+"="+a.escape(""!=b?b:"[[B]]")+"; path=/;"+(d&&"SESSION"!=e?" expires="+d.toGMTString()+";":"")+(f?" domain="+f+";":""),a.cookieRead(c)==b):0};a.G=[];a.da=function(c,b,d){if(a.va)return 0;a.maxDelay||(a.maxDelay=250);var f=0,e=(new Date).getTime()+a.maxDelay,g=a.d.visibilityState,m=["webkitvisibilitychange","visibilitychange"];
g||(g=a.d.webkitVisibilityState);if(g&&"prerender"==g){if(!a.ea)for(a.ea=1,d=0;d<m.length;d++)a.d.addEventListener(m[d],function(){var c=a.d.visibilityState;c||(c=a.d.webkitVisibilityState);"visible"==c&&(a.ea=0,a.delayReady())});f=1;e=0}else d||a.l("_d")&&(f=1);f&&(a.G.push({m:c,a:b,t:e}),a.ea||setTimeout(a.delayReady,a.maxDelay));return f};a.delayReady=function(){var c=(new Date).getTime(),b=0,d;for(a.l("_d")?b=1:a.pa();0<a.G.length;){d=a.G.shift();if(b&&!d.t&&d.t>c){a.G.unshift(d);setTimeout(a.delayReady,
parseInt(a.maxDelay/2));break}a.va=1;a[d.m].apply(a,d.a);a.va=0}};a.setAccount=a.sa=function(c){var b,d;if(!a.da("setAccount",arguments))if(a.account=c,a.allAccounts)for(b=a.allAccounts.concat(c.split(",")),a.allAccounts=[],b.sort(),d=0;d<b.length;d++)0!=d&&b[d-1]==b[d]||a.allAccounts.push(b[d]);else a.allAccounts=c.split(",")};a.foreachVar=function(c,b){var d,f,e,g,m="";e=f="";if(a.lightProfileID)d=a.K,(m=a.lightTrackVars)&&(m=","+m+","+a.ia.join(",")+",");else{d=a.e;if(a.pe||a.linkType)m=a.linkTrackVars,
f=a.linkTrackEvents,a.pe&&(e=a.pe.substring(0,1).toUpperCase()+a.pe.substring(1),a[e]&&(m=a[e].Cb,f=a[e].Bb));m&&(m=","+m+","+a.B.join(",")+",");f&&m&&(m+=",events,")}b&&(b=","+b+",");for(f=0;f<d.length;f++)e=d[f],(g=a[e])&&(!m||0<=m.indexOf(","+e+","))&&(!b||0<=b.indexOf(","+e+","))&&c(e,g)};a.o=function(c,b,d,f,e){var g="",m,p,k,w,n=0;"contextData"==c&&(c="c");if(b){for(m in b)if(!(Object.prototype[m]||e&&m.substring(0,e.length)!=e)&&b[m]&&(!d||0<=d.indexOf(","+(f?f+".":"")+m+","))){k=!1;if(n)for(p=
0;p<n.length;p++)m.substring(0,n[p].length)==n[p]&&(k=!0);if(!k&&(""==g&&(g+="&"+c+"."),p=b[m],e&&(m=m.substring(e.length)),0<m.length))if(k=m.indexOf("."),0<k)p=m.substring(0,k),k=(e?e:"")+p+".",n||(n=[]),n.push(k),g+=a.o(p,b,d,f,k);else if("boolean"==typeof p&&(p=p?"true":"false"),p){if("retrieveLightData"==f&&0>e.indexOf(".contextData."))switch(k=m.substring(0,4),w=m.substring(4),m){case "transactionID":m="xact";break;case "channel":m="ch";break;case "campaign":m="v0";break;default:a.Ba(w)&&("prop"==
k?m="c"+w:"eVar"==k?m="v"+w:"list"==k?m="l"+w:"hier"==k&&(m="h"+w,p=p.substring(0,255)))}g+="&"+a.escape(m)+"="+a.escape(p)}}""!=g&&(g+="&."+c)}return g};a.mb=function(){var c="",b,d,f,e,g,m,p,k,n="",r="",s=e="";if(a.lightProfileID)b=a.K,(n=a.lightTrackVars)&&(n=","+n+","+a.ia.join(",")+",");else{b=a.e;if(a.pe||a.linkType)n=a.linkTrackVars,r=a.linkTrackEvents,a.pe&&(e=a.pe.substring(0,1).toUpperCase()+a.pe.substring(1),a[e]&&(n=a[e].Cb,r=a[e].Bb));n&&(n=","+n+","+a.B.join(",")+",");r&&(r=","+r+",",
n&&(n+=",events,"));a.events2&&(s+=(""!=s?",":"")+a.events2)}if(a.visitor&&1.5<=parseFloat(a.visitor.version)&&a.visitor.getCustomerIDs){e=q;if(g=a.visitor.getCustomerIDs())for(d in g)Object.prototype[d]||(f=g[d],e||(e={}),f.id&&(e[d+".id"]=f.id),f.authState&&(e[d+".as"]=f.authState));e&&(c+=a.o("cid",e))}a.AudienceManagement&&a.AudienceManagement.isReady()&&(c+=a.o("d",a.AudienceManagement.getEventCallConfigParams()));for(d=0;d<b.length;d++){e=b[d];g=a[e];f=e.substring(0,4);m=e.substring(4);!g&&
"events"==e&&s&&(g=s,s="");if(g&&(!n||0<=n.indexOf(","+e+","))){switch(e){case "supplementalDataID":e="sdid";break;case "timestamp":e="ts";break;case "dynamicVariablePrefix":e="D";break;case "visitorID":e="vid";break;case "marketingCloudVisitorID":e="mid";break;case "analyticsVisitorID":e="aid";break;case "audienceManagerLocationHint":e="aamlh";break;case "audienceManagerBlob":e="aamb";break;case "authState":e="as";break;case "pageURL":e="g";255<g.length&&(a.pageURLRest=g.substring(255),g=g.substring(0,
255));break;case "pageURLRest":e="-g";break;case "referrer":e="r";break;case "vmk":case "visitorMigrationKey":e="vmt";break;case "visitorMigrationServer":e="vmf";a.ssl&&a.visitorMigrationServerSecure&&(g="");break;case "visitorMigrationServerSecure":e="vmf";!a.ssl&&a.visitorMigrationServer&&(g="");break;case "charSet":e="ce";break;case "visitorNamespace":e="ns";break;case "cookieDomainPeriods":e="cdp";break;case "cookieLifetime":e="cl";break;case "variableProvider":e="vvp";break;case "currencyCode":e=
"cc";break;case "channel":e="ch";break;case "transactionID":e="xact";break;case "campaign":e="v0";break;case "latitude":e="lat";break;case "longitude":e="lon";break;case "resolution":e="s";break;case "colorDepth":e="c";break;case "javascriptVersion":e="j";break;case "javaEnabled":e="v";break;case "cookiesEnabled":e="k";break;case "browserWidth":e="bw";break;case "browserHeight":e="bh";break;case "connectionType":e="ct";break;case "homepage":e="hp";break;case "events":s&&(g+=(""!=g?",":"")+s);if(r)for(m=
g.split(","),g="",f=0;f<m.length;f++)p=m[f],k=p.indexOf("="),0<=k&&(p=p.substring(0,k)),k=p.indexOf(":"),0<=k&&(p=p.substring(0,k)),0<=r.indexOf(","+p+",")&&(g+=(g?",":"")+m[f]);break;case "events2":g="";break;case "contextData":c+=a.o("c",a[e],n,e);g="";break;case "lightProfileID":e="mtp";break;case "lightStoreForSeconds":e="mtss";a.lightProfileID||(g="");break;case "lightIncrementBy":e="mti";a.lightProfileID||(g="");break;case "retrieveLightProfiles":e="mtsr";break;case "deleteLightProfiles":e=
"mtsd";break;case "retrieveLightData":a.retrieveLightProfiles&&(c+=a.o("mts",a[e],n,e));g="";break;default:a.Ba(m)&&("prop"==f?e="c"+m:"eVar"==f?e="v"+m:"list"==f?e="l"+m:"hier"==f&&(e="h"+m,g=g.substring(0,255)))}g&&(c+="&"+e+"="+("pev"!=e.substring(0,3)?a.escape(g):g))}"pev3"==e&&a.c&&(c+=a.c)}return c};a.v=function(a){var b=a.tagName;if("undefined"!=""+a.Gb||"undefined"!=""+a.wb&&"HTML"!=(""+a.wb).toUpperCase())return"";b=b&&b.toUpperCase?b.toUpperCase():"";"SHAPE"==b&&(b="");b&&(("INPUT"==b||
"BUTTON"==b)&&a.type&&a.type.toUpperCase?b=a.type.toUpperCase():!b&&a.href&&(b="A"));return b};a.xa=function(a){var b=a.href?a.href:"",d,f,e;d=b.indexOf(":");f=b.indexOf("?");e=b.indexOf("/");b&&(0>d||0<=f&&d>f||0<=e&&d>e)&&(f=a.protocol&&1<a.protocol.length?a.protocol:l.protocol?l.protocol:"",d=l.pathname.lastIndexOf("/"),b=(f?f+"//":"")+(a.host?a.host:l.host?l.host:"")+("/"!=h.substring(0,1)?l.pathname.substring(0,0>d?0:d)+"/":"")+b);return b};a.H=function(c){var b=a.v(c),d,f,e="",g=0;return b&&
(d=c.protocol,f=c.onclick,!c.href||"A"!=b&&"AREA"!=b||f&&d&&!(0>d.toLowerCase().indexOf("javascript"))?f?(e=a.replace(a.replace(a.replace(a.replace(""+f,"\r",""),"\n",""),"\t","")," ",""),g=2):"INPUT"==b||"SUBMIT"==b?(c.value?e=c.value:c.innerText?e=c.innerText:c.textContent&&(e=c.textContent),g=3):c.src&&"IMAGE"==b&&(e=c.src):e=a.xa(c),e)?{id:e.substring(0,100),type:g}:0};a.Eb=function(c){for(var b=a.v(c),d=a.H(c);c&&!d&&"BODY"!=b;)if(c=c.parentElement?c.parentElement:c.parentNode)b=a.v(c),d=a.H(c);
d&&"BODY"!=b||(c=0);c&&(b=c.onclick?""+c.onclick:"",0<=b.indexOf(".tl(")||0<=b.indexOf(".trackLink("))&&(c=0);return c};a.vb=function(){var c,b,d=a.linkObject,f=a.linkType,e=a.linkURL,g,m;a.ja=1;d||(a.ja=0,d=a.clickObject);if(d){c=a.v(d);for(b=a.H(d);d&&!b&&"BODY"!=c;)if(d=d.parentElement?d.parentElement:d.parentNode)c=a.v(d),b=a.H(d);b&&"BODY"!=c||(d=0);if(d&&!a.linkObject){var p=d.onclick?""+d.onclick:"";if(0<=p.indexOf(".tl(")||0<=p.indexOf(".trackLink("))d=0}}else a.ja=1;!e&&d&&(e=a.xa(d));e&&
!a.linkLeaveQueryString&&(g=e.indexOf("?"),0<=g&&(e=e.substring(0,g)));if(!f&&e){var n=0,r=0,q;if(a.trackDownloadLinks&&a.linkDownloadFileTypes)for(p=e.toLowerCase(),g=p.indexOf("?"),m=p.indexOf("#"),0<=g?0<=m&&m<g&&(g=m):g=m,0<=g&&(p=p.substring(0,g)),g=a.linkDownloadFileTypes.toLowerCase().split(","),m=0;m<g.length;m++)(q=g[m])&&p.substring(p.length-(q.length+1))=="."+q&&(f="d");if(a.trackExternalLinks&&!f&&(p=e.toLowerCase(),a.Aa(p)&&(a.linkInternalFilters||(a.linkInternalFilters=k.location.hostname),
g=0,a.linkExternalFilters?(g=a.linkExternalFilters.toLowerCase().split(","),n=1):a.linkInternalFilters&&(g=a.linkInternalFilters.toLowerCase().split(",")),g))){for(m=0;m<g.length;m++)q=g[m],0<=p.indexOf(q)&&(r=1);r?n&&(f="e"):n||(f="e")}}a.linkObject=d;a.linkURL=e;a.linkType=f;if(a.trackClickMap||a.trackInlineStats)a.c="",d&&(f=a.pageName,e=1,d=d.sourceIndex,f||(f=a.pageURL,e=0),k.s_objectID&&(b.id=k.s_objectID,d=b.type=1),f&&b&&b.id&&c&&(a.c="&pid="+a.escape(f.substring(0,255))+(e?"&pidt="+e:"")+
"&oid="+a.escape(b.id.substring(0,100))+(b.type?"&oidt="+b.type:"")+"&ot="+c+(d?"&oi="+d:"")))};a.nb=function(){var c=a.ja,b=a.linkType,d=a.linkURL,f=a.linkName;b&&(d||f)&&(b=b.toLowerCase(),"d"!=b&&"e"!=b&&(b="o"),a.pe="lnk_"+b,a.pev1=d?a.escape(d):"",a.pev2=f?a.escape(f):"",c=1);a.abort&&(c=0);if(a.trackClickMap||a.trackInlineStats||a.ActivityMap){var b={},d=0,e=a.cookieRead("s_sq"),g=e?e.split("&"):0,m,p,k,e=0;if(g)for(m=0;m<g.length;m++)p=g[m].split("="),f=a.unescape(p[0]).split(","),p=a.unescape(p[1]),
b[p]=f;f=a.account.split(",");m={};for(k in a.contextData)k&&!Object.prototype[k]&&"a.activitymap."==k.substring(0,14)&&(m[k]=a.contextData[k],a.contextData[k]="");a.c=a.o("c",m)+(a.c?a.c:"");if(c||a.c){c&&!a.c&&(e=1);for(p in b)if(!Object.prototype[p])for(k=0;k<f.length;k++)for(e&&(g=b[p].join(","),g==a.account&&(a.c+=("&"!=p.charAt(0)?"&":"")+p,b[p]=[],d=1)),m=0;m<b[p].length;m++)g=b[p][m],g==f[k]&&(e&&(a.c+="&u="+a.escape(g)+("&"!=p.charAt(0)?"&":"")+p+"&u=0"),b[p].splice(m,1),d=1);c||(d=1);if(d){e=
"";m=2;!c&&a.c&&(e=a.escape(f.join(","))+"="+a.escape(a.c),m=1);for(p in b)!Object.prototype[p]&&0<m&&0<b[p].length&&(e+=(e?"&":"")+a.escape(b[p].join(","))+"="+a.escape(p),m--);a.cookieWrite("s_sq",e)}}}return c};a.ob=function(){if(!a.Ab){var c=new Date,b=r.location,d,f,e=f=d="",g="",m="",k="1.2",n=a.cookieWrite("s_cc","true",0)?"Y":"N",q="",s="";if(c.setUTCDate&&(k="1.3",(0).toPrecision&&(k="1.5",c=[],c.forEach))){k="1.6";f=0;d={};try{f=new Iterator(d),f.next&&(k="1.7",c.reduce&&(k="1.8",k.trim&&
(k="1.8.1",Date.parse&&(k="1.8.2",Object.create&&(k="1.8.5")))))}catch(t){}}d=screen.width+"x"+screen.height;e=navigator.javaEnabled()?"Y":"N";f=screen.pixelDepth?screen.pixelDepth:screen.colorDepth;g=a.w.innerWidth?a.w.innerWidth:a.d.documentElement.offsetWidth;m=a.w.innerHeight?a.w.innerHeight:a.d.documentElement.offsetHeight;try{a.b.addBehavior("#default#homePage"),q=a.b.Fb(b)?"Y":"N"}catch(u){}try{a.b.addBehavior("#default#clientCaps"),s=a.b.connectionType}catch(x){}a.resolution=d;a.colorDepth=
f;a.javascriptVersion=k;a.javaEnabled=e;a.cookiesEnabled=n;a.browserWidth=g;a.browserHeight=m;a.connectionType=s;a.homepage=q;a.Ab=1}};a.L={};a.loadModule=function(c,b){var d=a.L[c];if(!d){d=k["AppMeasurement_Module_"+c]?new k["AppMeasurement_Module_"+c](a):{};a.L[c]=a[c]=d;d.Qa=function(){return d.Ua};d.Va=function(b){if(d.Ua=b)a[c+"_onLoad"]=b,a.da(c+"_onLoad",[a,d],1)||b(a,d)};try{Object.defineProperty?Object.defineProperty(d,"onLoad",{get:d.Qa,set:d.Va}):d._olc=1}catch(f){d._olc=1}}b&&(a[c+"_onLoad"]=
b,a.da(c+"_onLoad",[a,d],1)||b(a,d))};a.l=function(c){var b,d;for(b in a.L)if(!Object.prototype[b]&&(d=a.L[b])&&(d._olc&&d.onLoad&&(d._olc=0,d.onLoad(a,d)),d[c]&&d[c]()))return 1;return 0};a.qb=function(){var c=Math.floor(1E13*Math.random()),b=a.visitorSampling,d=a.visitorSamplingGroup,d="s_vsn_"+(a.visitorNamespace?a.visitorNamespace:a.account)+(d?"_"+d:""),f=a.cookieRead(d);if(b){f&&(f=parseInt(f));if(!f){if(!a.cookieWrite(d,c))return 0;f=c}if(f%1E4>v)return 0}return 1};a.M=function(c,b){var d,
f,e,g,m,k;for(d=0;2>d;d++)for(f=0<d?a.qa:a.e,e=0;e<f.length;e++)if(g=f[e],(m=c[g])||c["!"+g]){if(!b&&("contextData"==g||"retrieveLightData"==g)&&a[g])for(k in a[g])m[k]||(m[k]=a[g][k]);a[g]=m}};a.Ja=function(c,b){var d,f,e,g;for(d=0;2>d;d++)for(f=0<d?a.qa:a.e,e=0;e<f.length;e++)g=f[e],c[g]=a[g],b||c[g]||(c["!"+g]=1)};a.ib=function(a){var b,d,f,e,g,m=0,k,n="",q="";if(a&&255<a.length&&(b=""+a,d=b.indexOf("?"),0<d&&(k=b.substring(d+1),b=b.substring(0,d),e=b.toLowerCase(),f=0,"http://"==e.substring(0,
7)?f+=7:"https://"==e.substring(0,8)&&(f+=8),d=e.indexOf("/",f),0<d&&(e=e.substring(f,d),g=b.substring(d),b=b.substring(0,d),0<=e.indexOf("google")?m=",q,ie,start,search_key,word,kw,cd,":0<=e.indexOf("yahoo.co")&&(m=",p,ei,"),m&&k)))){if((a=k.split("&"))&&1<a.length){for(f=0;f<a.length;f++)e=a[f],d=e.indexOf("="),0<d&&0<=m.indexOf(","+e.substring(0,d)+",")?n+=(n?"&":"")+e:q+=(q?"&":"")+e;n&&q?k=n+"&"+q:q=""}d=253-(k.length-q.length)-b.length;a=b+(0<d?g.substring(0,d):"")+"?"+k}return a};a.Pa=function(c){var b=
a.d.visibilityState,d=["webkitvisibilitychange","visibilitychange"];b||(b=a.d.webkitVisibilityState);if(b&&"prerender"==b){if(c)for(b=0;b<d.length;b++)a.d.addEventListener(d[b],function(){var b=a.d.visibilityState;b||(b=a.d.webkitVisibilityState);"visible"==b&&c()});return!1}return!0};a.Z=!1;a.D=!1;a.Xa=function(){a.D=!0;a.i()};a.X=!1;a.Q=!1;a.Ta=function(c){a.marketingCloudVisitorID=c;a.Q=!0;a.i()};a.aa=!1;a.R=!1;a.Ya=function(c){a.visitorOptedOut=c;a.R=!0;a.i()};a.U=!1;a.N=!1;a.La=function(c){a.analyticsVisitorID=
c;a.N=!0;a.i()};a.W=!1;a.P=!1;a.Na=function(c){a.audienceManagerLocationHint=c;a.P=!0;a.i()};a.V=!1;a.O=!1;a.Ma=function(c){a.audienceManagerBlob=c;a.O=!0;a.i()};a.Oa=function(c){a.maxDelay||(a.maxDelay=250);return a.l("_d")?(c&&setTimeout(function(){c()},a.maxDelay),!1):!0};a.Y=!1;a.C=!1;a.pa=function(){a.C=!0;a.i()};a.isReadyToTrack=function(){var c=!0,b=a.visitor;a.Z||a.D||(a.Pa(a.Xa)?a.D=!0:a.Z=!0);if(a.Z&&!a.D)return!1;b&&b.isAllowed()&&(a.X||a.marketingCloudVisitorID||!b.getMarketingCloudVisitorID||
(a.X=!0,a.marketingCloudVisitorID=b.getMarketingCloudVisitorID([a,a.Ta]),a.marketingCloudVisitorID&&(a.Q=!0)),a.aa||a.visitorOptedOut||!b.isOptedOut||(a.aa=!0,a.visitorOptedOut=b.isOptedOut([a,a.Ya]),a.visitorOptedOut!=q&&(a.R=!0)),a.U||a.analyticsVisitorID||!b.getAnalyticsVisitorID||(a.U=!0,a.analyticsVisitorID=b.getAnalyticsVisitorID([a,a.La]),a.analyticsVisitorID&&(a.N=!0)),a.W||a.audienceManagerLocationHint||!b.getAudienceManagerLocationHint||(a.W=!0,a.audienceManagerLocationHint=b.getAudienceManagerLocationHint([a,
a.Na]),a.audienceManagerLocationHint&&(a.P=!0)),a.V||a.audienceManagerBlob||!b.getAudienceManagerBlob||(a.V=!0,a.audienceManagerBlob=b.getAudienceManagerBlob([a,a.Ma]),a.audienceManagerBlob&&(a.O=!0)),a.X&&!a.Q&&!a.marketingCloudVisitorID||a.U&&!a.N&&!a.analyticsVisitorID||a.W&&!a.P&&!a.audienceManagerLocationHint||a.V&&!a.O&&!a.audienceManagerBlob||a.aa&&!a.R)&&(c=!1);a.Y||a.C||(a.Oa(a.pa)?a.C=!0:a.Y=!0);a.Y&&!a.C&&(c=!1);return c};a.k=q;a.p=0;a.callbackWhenReadyToTrack=function(c,b,d){var f;f={};
f.bb=c;f.ab=b;f.Za=d;a.k==q&&(a.k=[]);a.k.push(f);0==a.p&&(a.p=setInterval(a.i,100))};a.i=function(){var c;if(a.isReadyToTrack()&&(a.Wa(),a.k!=q))for(;0<a.k.length;)c=a.k.shift(),c.ab.apply(c.bb,c.Za)};a.Wa=function(){a.p&&(clearInterval(a.p),a.p=0)};a.Ra=function(c){var b,d,f=q,e=q;if(!a.isReadyToTrack()){b=[];if(c!=q)for(d in f={},c)f[d]=c[d];e={};a.Ja(e,!0);b.push(f);b.push(e);a.callbackWhenReadyToTrack(a,a.track,b);return!0}return!1};a.lb=function(){var c=a.cookieRead("s_fid"),b="",d="",f;f=8;
var e=4;if(!c||0>c.indexOf("-")){for(c=0;16>c;c++)f=Math.floor(Math.random()*f),b+="0123456789ABCDEF".substring(f,f+1),f=Math.floor(Math.random()*e),d+="0123456789ABCDEF".substring(f,f+1),f=e=16;c=b+"-"+d}a.cookieWrite("s_fid",c,1)||(c=0);return c};a.t=a.track=function(c,b){var d,f=new Date,e="s"+Math.floor(f.getTime()/108E5)%10+Math.floor(1E13*Math.random()),g=f.getYear(),g="t="+a.escape(f.getDate()+"/"+f.getMonth()+"/"+(1900>g?g+1900:g)+" "+f.getHours()+":"+f.getMinutes()+":"+f.getSeconds()+" "+
f.getDay()+" "+f.getTimezoneOffset());a.visitor&&(a.visitor.jb&&(a.authState=a.visitor.jb()),!a.supplementalDataID&&a.visitor.getSupplementalDataID&&(a.supplementalDataID=a.visitor.getSupplementalDataID("AppMeasurement:"+a._in,a.expectSupplementalData?!1:!0)));a.l("_s");a.Ra(c)||(b&&a.M(b),c&&(d={},a.Ja(d,0),a.M(c)),a.qb()&&!a.visitorOptedOut&&(a.analyticsVisitorID||a.marketingCloudVisitorID||(a.fid=a.lb()),a.vb(),a.usePlugins&&a.doPlugins&&a.doPlugins(a),a.account&&(a.abort||(a.trackOffline&&!a.timestamp&&
(a.timestamp=Math.floor(f.getTime()/1E3)),f=k.location,a.pageURL||(a.pageURL=f.href?f.href:f),a.referrer||a.Ka||(a.referrer=r.document.referrer),a.Ka=1,a.referrer=a.ib(a.referrer),a.l("_g")),a.nb()&&!a.abort&&(a.ob(),g+=a.mb(),a.ub(e,g),a.l("_t"),a.referrer=""))),c&&a.M(d,1));a.abort=a.supplementalDataID=a.timestamp=a.pageURLRest=a.linkObject=a.clickObject=a.linkURL=a.linkName=a.linkType=k.s_objectID=a.pe=a.pev1=a.pev2=a.pev3=a.c=a.lightProfileID=0};a.tl=a.trackLink=function(c,b,d,f,e){a.linkObject=
c;a.linkType=b;a.linkName=d;e&&(a.j=c,a.r=e);return a.track(f)};a.trackLight=function(c,b,d,f){a.lightProfileID=c;a.lightStoreForSeconds=b;a.lightIncrementBy=d;return a.track(f)};a.clearVars=function(){var c,b;for(c=0;c<a.e.length;c++)if(b=a.e[c],"prop"==b.substring(0,4)||"eVar"==b.substring(0,4)||"hier"==b.substring(0,4)||"list"==b.substring(0,4)||"channel"==b||"events"==b||"eventList"==b||"products"==b||"productList"==b||"purchaseID"==b||"transactionID"==b||"state"==b||"zip"==b||"campaign"==b)a[b]=
void 0};a.tagContainerMarker="";a.ub=function(c,b){var d,f=a.trackingServer;d="";var e=a.dc,g="sc.",k=a.visitorNamespace;f?a.trackingServerSecure&&a.ssl&&(f=a.trackingServerSecure):(k||(k=a.account,f=k.indexOf(","),0<=f&&(k=k.substring(0,f)),k=k.replace(/[^A-Za-z0-9]/g,"")),d||(d="2o7.net"),e=e?(""+e).toLowerCase():"d1","2o7.net"==d&&("d1"==e?e="112":"d2"==e&&(e="122"),g=""),f=k+"."+e+"."+g+d);d=a.ssl?"https://":"http://";e=a.AudienceManagement&&a.AudienceManagement.isReady();d+=f+"/b/ss/"+a.account+
"/"+(a.mobile?"5.":"")+(e?"10":"1")+"/JS-"+a.version+(a.zb?"T":"")+(a.tagContainerMarker?"-"+a.tagContainerMarker:"")+"/"+c+"?AQB=1&ndh=1&pf=1&"+(e?"callback=s_c_il["+a._in+"].AudienceManagement.passData&":"")+b+"&AQE=1";a.gb(d);a.fa()};a.gb=function(c){a.g||a.pb();a.g.push(c);a.ha=a.u();a.Ha()};a.pb=function(){a.g=a.rb();a.g||(a.g=[])};a.rb=function(){var c,b;if(a.ma()){try{(b=k.localStorage.getItem(a.ka()))&&(c=k.JSON.parse(b))}catch(d){}return c}};a.ma=function(){var c=!0;a.trackOffline&&a.offlineFilename&&
k.localStorage&&k.JSON||(c=!1);return c};a.ya=function(){var c=0;a.g&&(c=a.g.length);a.A&&c++;return c};a.fa=function(){if(!a.A)if(a.za=q,a.la)a.ha>a.J&&a.Fa(a.g),a.oa(500);else{var c=a.$a();if(0<c)a.oa(c);else if(c=a.wa())a.A=1,a.tb(c),a.xb(c)}};a.oa=function(c){a.za||(c||(c=0),a.za=setTimeout(a.fa,c))};a.$a=function(){var c;if(!a.trackOffline||0>=a.offlineThrottleDelay)return 0;c=a.u()-a.Ea;return a.offlineThrottleDelay<c?0:a.offlineThrottleDelay-c};a.wa=function(){if(0<a.g.length)return a.g.shift()};
a.tb=function(c){if(a.debugTracking){var b="AppMeasurement Debug: "+c;c=c.split("&");var d;for(d=0;d<c.length;d++)b+="\n\t"+a.unescape(c[d]);a.sb(b)}};a.Sa=function(){return a.marketingCloudVisitorID||a.analyticsVisitorID};a.T=!1;var s;try{s=JSON.parse('{"x":"y"}')}catch(x){s=null}s&&"y"==s.x?(a.T=!0,a.S=function(a){return JSON.parse(a)}):k.$&&k.$.parseJSON?(a.S=function(a){return k.$.parseJSON(a)},a.T=!0):a.S=function(){return null};a.xb=function(c){var b,d,f;a.Sa()&&2047<c.length&&("undefined"!=
typeof XMLHttpRequest&&(b=new XMLHttpRequest,"withCredentials"in b?d=1:b=0),b||"undefined"==typeof XDomainRequest||(b=new XDomainRequest,d=2),b&&a.AudienceManagement&&a.AudienceManagement.isReady()&&(a.T?b.ra=!0:b=0));!b&&a.Ia&&(c=c.substring(0,2047));!b&&a.d.createElement&&a.AudienceManagement&&a.AudienceManagement.isReady()&&(b=a.d.createElement("SCRIPT"))&&"async"in b&&((f=(f=a.d.getElementsByTagName("HEAD"))&&f[0]?f[0]:a.d.body)?(b.type="text/javascript",b.setAttribute("async","async"),d=3):b=
0);b||(b=new Image,b.alt="");b.ua=function(){try{a.na&&(clearTimeout(a.na),a.na=0),b.timeout&&(clearTimeout(b.timeout),b.timeout=0)}catch(c){}};b.onload=b.yb=function(){b.ua();a.fb();a.ba();a.A=0;a.fa();if(b.ra){b.ra=!1;try{var c=a.S(b.responseText);a.AudienceManagement.passData(c)}catch(d){}}};b.onabort=b.onerror=b.hb=function(){b.ua();(a.trackOffline||a.la)&&a.A&&a.g.unshift(a.eb);a.A=0;a.ha>a.J&&a.Fa(a.g);a.ba();a.oa(500)};b.onreadystatechange=function(){4==b.readyState&&(200==b.status?b.yb():
b.hb())};a.Ea=a.u();if(1==d||2==d){var e=c.indexOf("?");f=c.substring(0,e);e=c.substring(e+1);e=e.replace(/&callback=[a-zA-Z0-9_.\[\]]+/,"");1==d?(b.open("POST",f,!0),b.send(e)):2==d&&(b.open("POST",f),b.send(e))}else if(b.src=c,3==d){if(a.Ca)try{f.removeChild(a.Ca)}catch(g){}f.firstChild?f.insertBefore(b,f.firstChild):f.appendChild(b);a.Ca=a.cb}b.abort&&(a.na=setTimeout(b.abort,5E3));a.eb=c;a.cb=k["s_i_"+a.replace(a.account,",","_")]=b;if(a.useForcedLinkTracking&&a.F||a.r)a.forcedLinkTrackingTimeout||
(a.forcedLinkTrackingTimeout=250),a.ca=setTimeout(a.ba,a.forcedLinkTrackingTimeout)};a.fb=function(){if(a.ma()&&!(a.Da>a.J))try{k.localStorage.removeItem(a.ka()),a.Da=a.u()}catch(c){}};a.Fa=function(c){if(a.ma()){a.Ha();try{k.localStorage.setItem(a.ka(),k.JSON.stringify(c)),a.J=a.u()}catch(b){}}};a.Ha=function(){if(a.trackOffline){if(!a.offlineLimit||0>=a.offlineLimit)a.offlineLimit=10;for(;a.g.length>a.offlineLimit;)a.wa()}};a.forceOffline=function(){a.la=!0};a.forceOnline=function(){a.la=!1};a.ka=
function(){return a.offlineFilename+"-"+a.visitorNamespace+a.account};a.u=function(){return(new Date).getTime()};a.Aa=function(a){a=a.toLowerCase();return 0!=a.indexOf("#")&&0!=a.indexOf("about:")&&0!=a.indexOf("opera:")&&0!=a.indexOf("javascript:")?!0:!1};a.setTagContainer=function(c){var b,d,f;a.zb=c;for(b=0;b<a._il.length;b++)if((d=a._il[b])&&"s_l"==d._c&&d.tagContainerName==c){a.M(d);if(d.lmq)for(b=0;b<d.lmq.length;b++)f=d.lmq[b],a.loadModule(f.n);if(d.ml)for(f in d.ml)if(a[f])for(b in c=a[f],
f=d.ml[f],f)!Object.prototype[b]&&("function"!=typeof f[b]||0>(""+f[b]).indexOf("s_c_il"))&&(c[b]=f[b]);if(d.mmq)for(b=0;b<d.mmq.length;b++)f=d.mmq[b],a[f.m]&&(c=a[f.m],c[f.f]&&"function"==typeof c[f.f]&&(f.a?c[f.f].apply(c,f.a):c[f.f].apply(c)));if(d.tq)for(b=0;b<d.tq.length;b++)a.track(d.tq[b]);d.s=a;break}};a.Util={urlEncode:a.escape,urlDecode:a.unescape,cookieRead:a.cookieRead,cookieWrite:a.cookieWrite,getQueryParam:function(c,b,d){var f;b||(b=a.pageURL?a.pageURL:k.location);d||(d="&");return c&&
b&&(b=""+b,f=b.indexOf("?"),0<=f&&(b=d+b.substring(f+1)+d,f=b.indexOf(d+c+"="),0<=f&&(b=b.substring(f+d.length+c.length+1),f=b.indexOf(d),0<=f&&(b=b.substring(0,f)),0<b.length)))?a.unescape(b):""}};a.B="supplementalDataID timestamp dynamicVariablePrefix visitorID marketingCloudVisitorID analyticsVisitorID audienceManagerLocationHint authState fid vmk visitorMigrationKey visitorMigrationServer visitorMigrationServerSecure charSet visitorNamespace cookieDomainPeriods fpCookieDomainPeriods cookieLifetime pageName pageURL referrer contextData currencyCode lightProfileID lightStoreForSeconds lightIncrementBy retrieveLightProfiles deleteLightProfiles retrieveLightData".split(" ");
a.e=a.B.concat("purchaseID variableProvider channel server pageType transactionID campaign state zip events events2 products audienceManagerBlob tnt".split(" "));a.ia="timestamp charSet visitorNamespace cookieDomainPeriods cookieLifetime contextData lightProfileID lightStoreForSeconds lightIncrementBy".split(" ");a.K=a.ia.slice(0);a.qa="account allAccounts debugTracking visitor trackOffline offlineLimit offlineThrottleDelay offlineFilename usePlugins doPlugins configURL visitorSampling visitorSamplingGroup linkObject clickObject linkURL linkName linkType trackDownloadLinks trackExternalLinks trackClickMap trackInlineStats linkLeaveQueryString linkTrackVars linkTrackEvents linkDownloadFileTypes linkExternalFilters linkInternalFilters useForcedLinkTracking forcedLinkTrackingTimeout trackingServer trackingServerSecure ssl abort mobile dc lightTrackVars maxDelay expectSupplementalData AudienceManagement".split(" ");
for(n=0;250>=n;n++)76>n&&(a.e.push("prop"+n),a.K.push("prop"+n)),a.e.push("eVar"+n),a.K.push("eVar"+n),6>n&&a.e.push("hier"+n),4>n&&a.e.push("list"+n);n="pe pev1 pev2 pev3 latitude longitude resolution colorDepth javascriptVersion javaEnabled cookiesEnabled browserWidth browserHeight connectionType homepage pageURLRest".split(" ");a.e=a.e.concat(n);a.B=a.B.concat(n);a.ssl=0<=k.location.protocol.toLowerCase().indexOf("https");a.charSet="UTF-8";a.contextData={};a.offlineThrottleDelay=0;a.offlineFilename=
"AppMeasurement.offline";a.Ea=0;a.ha=0;a.J=0;a.Da=0;a.linkDownloadFileTypes="exe,zip,wav,mp3,mov,mpg,avi,wmv,pdf,doc,docx,xls,xlsx,ppt,pptx";a.w=k;a.d=k.document;try{if(a.Ia=!1,navigator){var y=navigator.userAgent;if("Microsoft Internet Explorer"==navigator.appName||0<=y.indexOf("MSIE ")||0<=y.indexOf("Trident/")&&0<=y.indexOf("Windows NT 6"))a.Ia=!0}}catch(z){}a.ba=function(){a.ca&&(k.clearTimeout(a.ca),a.ca=q);a.j&&a.F&&a.j.dispatchEvent(a.F);a.r&&("function"==typeof a.r?a.r():a.j&&a.j.href&&(a.d.location=
a.j.href));a.j=a.F=a.r=0};a.Ga=function(){a.b=a.d.body;a.b?(a.q=function(c){var b,d,f,e,g;if(!(a.d&&a.d.getElementById("cppXYctnr")||c&&c["s_fe_"+a._in])){if(a.ta)if(a.useForcedLinkTracking)a.b.removeEventListener("click",a.q,!1);else{a.b.removeEventListener("click",a.q,!0);a.ta=a.useForcedLinkTracking=0;return}else a.useForcedLinkTracking=0;a.clickObject=c.srcElement?c.srcElement:c.target;try{if(!a.clickObject||a.I&&a.I==a.clickObject||!(a.clickObject.tagName||a.clickObject.parentElement||a.clickObject.parentNode))a.clickObject=
0;else{var m=a.I=a.clickObject;a.ga&&(clearTimeout(a.ga),a.ga=0);a.ga=setTimeout(function(){a.I==m&&(a.I=0)},1E4);f=a.ya();a.track();if(f<a.ya()&&a.useForcedLinkTracking&&c.target){for(e=c.target;e&&e!=a.b&&"A"!=e.tagName.toUpperCase()&&"AREA"!=e.tagName.toUpperCase();)e=e.parentNode;if(e&&(g=e.href,a.Aa(g)||(g=0),d=e.target,c.target.dispatchEvent&&g&&(!d||"_self"==d||"_top"==d||"_parent"==d||k.name&&d==k.name))){try{b=a.d.createEvent("MouseEvents")}catch(n){b=new k.MouseEvent}if(b){try{b.initMouseEvent("click",
c.bubbles,c.cancelable,c.view,c.detail,c.screenX,c.screenY,c.clientX,c.clientY,c.ctrlKey,c.altKey,c.shiftKey,c.metaKey,c.button,c.relatedTarget)}catch(q){b=0}b&&(b["s_fe_"+a._in]=b.s_fe=1,c.stopPropagation(),c.stopImmediatePropagation&&c.stopImmediatePropagation(),c.preventDefault(),a.j=c.target,a.F=b)}}}}}catch(r){a.clickObject=0}}},a.b&&a.b.attachEvent?a.b.attachEvent("onclick",a.q):a.b&&a.b.addEventListener&&(navigator&&(0<=navigator.userAgent.indexOf("WebKit")&&a.d.createEvent||0<=navigator.userAgent.indexOf("Firefox/2")&&
k.MouseEvent)&&(a.ta=1,a.useForcedLinkTracking=1,a.b.addEventListener("click",a.q,!0)),a.b.addEventListener("click",a.q,!1))):setTimeout(a.Ga,30)};a.Ga();a.loadModule("ActivityMap")}
function s_gi(a){var k,q=window.s_c_il,r,n,t=a.split(","),u,s,x=0;if(q)for(r=0;!x&&r<q.length;){k=q[r];if("s_c"==k._c&&(k.account||k.oun))if(k.account&&k.account==a)x=1;else for(n=k.account?k.account:k.oun,n=k.allAccounts?k.allAccounts:n.split(","),u=0;u<t.length;u++)for(s=0;s<n.length;s++)t[u]==n[s]&&(x=1);r++}x||(k=new AppMeasurement);k.setAccount?k.setAccount(a):k.sa&&k.sa(a);return k}AppMeasurement.getInstance=s_gi;window.s_objectID||(window.s_objectID=0);
function s_pgicq(){var a=window,k=a.s_giq,q,r,n;if(k)for(q=0;q<k.length;q++)r=k[q],n=s_gi(r.oun),n.setAccount(r.un),n.setTagContainer(r.tagContainerName);a.s_giq=0}s_pgicq();

// End AppMeasurement

// Integrate Module

function AppMeasurement_Module_Integrate(l){var c=this;c.s=l;var e=window;e.s_c_in||(e.s_c_il=[],e.s_c_in=0);c._il=e.s_c_il;c._in=e.s_c_in;c._il[c._in]=c;e.s_c_in++;c._c="s_m";c.list=[];c.add=function(d,b){var a;b||(b="s_Integrate_"+d);e[b]||(e[b]={});a=c[d]=e[b];a.a=d;a.e=c;a._c=0;a._d=0;void 0==a.disable&&(a.disable=0);a.get=function(b,d){var f=document,h=f.getElementsByTagName("HEAD"),k;if(!a.disable&&(d||(v="s_"+c._in+"_Integrate_"+a.a+"_get_"+a._c),a._c++,a.VAR=v,a.CALLBACK="s_c_il["+c._in+"]."+
a.a+".callback",a.delay(),h=h&&0<h.length?h[0]:f.body))try{k=f.createElement("SCRIPT"),k.type="text/javascript",k.setAttribute("async","async"),k.src=c.c(a,b),0>b.indexOf("[CALLBACK]")&&(k.onload=k.onreadystatechange=function(){a.callback(e[v])}),h.firstChild?h.insertBefore(k,h.firstChild):h.appendChild(k)}catch(l){}};a.callback=function(b){var c;if(b)for(c in b)Object.prototype[c]||(a[c]=b[c]);a.ready()};a.beacon=function(b){var d="s_i_"+c._in+"_Integrate_"+a.a+"_"+a._c;a.disable||(a._c++,d=e[d]=
new Image,d.src=c.c(a,b))};a.script=function(b){a.get(b,1)};a.delay=function(){a._d++};a.ready=function(){a._d--;a.disable||l.delayReady()};c.list.push(d)};c._g=function(d){var b,a=(d?"use":"set")+"Vars";for(d=0;d<c.list.length;d++)if((b=c[c.list[d]])&&!b.disable&&b[a])try{b[a](l,b)}catch(e){}};c._t=function(){c._g(1)};c._d=function(){var d,b;for(d=0;d<c.list.length;d++)if((b=c[c.list[d]])&&!b.disable&&0<b._d)return 1;return 0};c.c=function(c,b){var a,e,g,f;"http"!=b.toLowerCase().substring(0,4)&&
(b="http://"+b);l.ssl&&(b=l.replace(b,"http:","https:"));c.RAND=Math.floor(1E13*Math.random());for(a=0;0<=a;)a=b.indexOf("[",a),0<=a&&(e=b.indexOf("]",a),e>a&&(g=b.substring(a+1,e),2<g.length&&"s."==g.substring(0,2)?(f=l[g.substring(2)])||(f=""):(f=""+c[g],f!=c[g]&&parseFloat(f)!=c[g]&&(g=0)),g&&(b=b.substring(0,a)+encodeURIComponent(f)+b.substring(e+1)),a=e));return b}}

// End Integrate Module

// ActivityMap Module

function AppMeasurement_Module_ActivityMap(f){function g(a,d){var b,c,n;if(a&&d&&(b=e.c[d]||(e.c[d]=d.split(","))))for(n=0;n<b.length&&(c=b[n++]);)if(-1<a.indexOf(c))return null;p=1;return a}function q(a,d,b,c,e){var g,h;if(a.dataset&&(h=a.dataset[d]))g=h;else if(a.getAttribute)if(h=a.getAttribute("data-"+b))g=h;else if(h=a.getAttribute(b))g=h;if(!g&&f.useForcedLinkTracking&&e&&(g="",d=a.onclick?""+a.onclick:"")){b=d.indexOf(c);var l,k;if(0<=b){for(b+=10;b<d.length&&0<="= \t\r\n".indexOf(d.charAt(b));)b++;
if(b<d.length){h=b;for(l=k=0;h<d.length&&(";"!=d.charAt(h)||l);)l?d.charAt(h)!=l||k?k="\\"==d.charAt(h)?!k:0:l=0:(l=d.charAt(h),'"'!=l&&"'"!=l&&(l=0)),h++;if(d=d.substring(b,h))a.e=new Function("s","var e;try{s.w."+c+"="+d+"}catch(e){}"),a.e(f)}}}return g||e&&f.w[c]}function r(a,d,b){var c;return(c=e[d](a,b))&&(p?(p=0,c):g(k(c),e[d+"Exclusions"]))}function s(a,d,b){var c;if(a&&!(1===(c=a.nodeType)&&(c=a.nodeName)&&(c=c.toUpperCase())&&t[c])&&(1===a.nodeType&&(c=a.nodeValue)&&(d[d.length]=c),b.a||
b.t||b.s||!a.getAttribute||((c=a.getAttribute("alt"))?b.a=c:(c=a.getAttribute("title"))?b.t=c:"IMG"==(""+a.nodeName).toUpperCase()&&(c=a.getAttribute("src")||a.src)&&(b.s=c)),(c=a.childNodes)&&c.length))for(a=0;a<c.length;a++)s(c[a],d,b)}function k(a){if(null==a||void 0==a)return a;try{return a.replace(RegExp("^[\\s\\n\\f\\r\\t\t-\r \u00a0\u1680\u180e\u2000-\u200a\u2028\u2029\u205f\u3000\ufeff]+","mg"),"").replace(RegExp("[\\s\\n\\f\\r\\t\t-\r \u00a0\u1680\u180e\u2000-\u200a\u2028\u2029\u205f\u3000\ufeff]+$",
"mg"),"").replace(RegExp("[\\s\\n\\f\\r\\t\t-\r \u00a0\u1680\u180e\u2000-\u200a\u2028\u2029\u205f\u3000\ufeff]{1,}","mg")," ").substring(0,254)}catch(d){}}var e=this;e.s=f;var m=window;m.s_c_in||(m.s_c_il=[],m.s_c_in=0);e._il=m.s_c_il;e._in=m.s_c_in;e._il[e._in]=e;m.s_c_in++;e._c="s_m";e.c={};var p=0,t={SCRIPT:1,STYLE:1,LINK:1,CANVAS:1};e._g=function(){var a,d,b,c=f.contextData,e=f.linkObject;(a=f.pageName||f.pageURL)&&(d=r(e,"link",f.linkName))&&(b=r(e,"region"))&&(c["a.activitymap.page"]=a.substring(0,
255),c["a.activitymap.link"]=128<d.length?d.substring(0,128):d,c["a.activitymap.region"]=127<b.length?b.substring(0,127):b,c["a.activitymap.pageIDType"]=f.pageName?1:0)};e.link=function(a,d){var b;if(d)b=g(k(d),e.linkExclusions);else if((b=a)&&!(b=q(a,"sObjectId","s-object-id","s_objectID",1))){var c,f;(f=g(k(a.innerText||a.textContent),e.linkExclusions))||(s(a,c=[],b={a:void 0,t:void 0,s:void 0}),(f=g(k(c.join(""))))||(f=g(k(b.a?b.a:b.t?b.t:b.s?b.s:void 0)))||!(c=(c=a.tagName)&&c.toUpperCase?c.toUpperCase():
"")||("INPUT"==c||"SUBMIT"==c&&a.value?f=g(k(a.value)):a.src&&"IMAGE"==c&&(f=g(k(a.src)))));b=f}return b};e.region=function(a){for(var d,b=e.regionIDAttribute||"id";a&&(a=a.parentNode);){if(d=q(a,b,b,b))return d;if("BODY"==a.nodeName)return"BODY"}}}
// End ActivityMap Module 


//tealium universal tag - utag.sender.19063.am160 v4.0.201801051549, Copyright 2018 Tealium.com Inc. All Rights Reserved.
try{
(function(id,loader,u){
  try{u=utag.o[loader].sender[id]={}}catch(e){u=utag.sender[id]};
  u.ev={'view':1,'link':1,'video':1};
  u.o=ucaa;
  u.varlist={pageName:'pageName',channel:'ch',campaign:'v0',hier1:'h1',hier2:'h2',hier3:'h3',hier4:'h4'};for(var i=1;i<76;i++){u.varlist['prop'+i]='c'+i;u.varlist['eVar'+i]='v'+i};
  u.pushlt=function(l,v){if(typeof l!="undefined")l.push(v)};
  u.map={"ext_pageName":"pageName,eVar7,prop7","nav_language":"eVar6,prop6","page_segment":"prop11,eVar11","ext_adobeURL":"eVar8,prop8","search_terms":"eVar22,prop22","search_resultCount":"eVar23,prop23","search_numPage":"eVar24","ext_pageSite":"server","page_templateId":"eVar60,prop60","ext_bannerIds":"list2","ext_searchEvent:true":"event7","ext_prodCode":"PRODUCTS_id","ext_prodCat":"PRODUCTS_category","ext_prodViewEvent:true":"prodView","page_section":"eVar69","ext_customPageViewEvent:true":"event12","ext_versionInfo":"prop30,eVar30","ext_engClickTotal":"eVar25","ext_engClickEvent:true":"event1","ext_errorPage":"pageType","ext_reportSuite":"s_account","ext_branchFinderEvent:true":"event6","ext_sponsoredIntSearchLinkEvent:true":"event8","qp.intscid":"eVar21,prop21","tool_end:true":"event30","ext_toolFinalName":"eVar33,prop33","tool_outResult":"eVar31","ext_channel":"channel","ext_hier1":"hier1","ext_techInfo":"prop31","ext_engagementImpression:true":"event2","user_uTokenId":"eVar56","user_uTokenProfile":"eVar57","ext_timeStamp":"eVar79"};
  u.extend=[function(a,b){
var s = ucaa;

//Configurazione validazione DL
ucaa.contextData["validationVar"] = "prop75";    // customizzare
ucaa.linkTrackVars = ucaa.contextData["validationVar"];
ucaa.contextData.troubles = {}

s.rwdTrackChange = function () {
    s.contextData[s._rwdNamespace+'.evento'] = "";
    var events = "";
    
    if(!s._rwdUseContextData){
        
        // Events
        if (this.rwdGetRenderedExperience() && (this.rwdGetRenderedExperience() != this._rwdLastRE)) {
            events = this.apl(events,this._rwdRenderedExperienceChangeEvent,',',2);
        }

        if (this.rwdGetPortaitLandscape() != this._rwdLastPL) {
            var pl_change_event = this.rwdGetPortaitLandscape() == "Portrait" ? this._rwdLandscapeToPortraitEvent : this._rwdPortraitToLandscapeEvent;
            events = this.apl(events,pl_change_event,',',2);
        }
    
    
    }else{
        // Events
        if (s.rwdGetRenderedExperience() && (s.rwdGetRenderedExperience() != s._rwdLastRE)) {
            s.contextData[s._rwdNamespace+'.evento'] = s.apl(s.contextData['[CLIENT NAMESPACE].evento'],'rwdRenderedExperienceChangeEvent',',',2);
            //events = this.apl(events,this._rwdRenderedExperienceChangeEvent,',',2);
        }
        
        if (s.rwdGetPortaitLandscape() != s_rwdLastPL) {
            var pl_change_event = s.rwdGetPortaitLandscape() == "Portrait" ? 'rwdLandscapeToPortraitEvent' : 'rwdPortraitToLandscapeEvent';
            s.contextData[s._rwdNamespace+'.evento'] = s.apl(s.contextData[s._rwdNamespace+'.evento'],pl_change_event,',',2);
        }
    }
    
    if (s.contextData[s._rwdNamespace+'.evento'] || events) {
        var tmp_linkTrackVars = s.linkTrackVars;
        var tmp_linkTrackEvents = s.linkTrackEvents;
        var tmp_events = s.events;
    
        s.linkTrackVars = "";
        s.linkTrackEvents = "";
        s.events = events;
        s.tl(true, 'o', 'RWD Change');
        
        s.events = tmp_events;
        s.linkTrackEvents = tmp_linkTrackEvents;
        s.linkTrackVars = tmp_linkTrackVars;
    }   
}
window.smartresize = function () {
                        srwdTrackChange();
                    };

var debounce = function (func, threshold, execAsap) {
    var timeout;
                    
    return function debounced() {
        var obj = this,
        args = arguments;
                    
        function delayed() {
            if (!execAsap) func.apply(obj, args);
                timeout = null;
        };
                    
        if (timeout) clearTimeout(timeout);
        else if (execAsap) func.apply(obj, args);
                    
        timeout = setTimeout(delayed, threshold || 500);
    };
}

s.rwdSetupSmartresize = function(){
    // Utilizzo di jQuery
    try {
        // Controlla se jQuery Ã?Â¨ disponibile
        if (jQueryIsAvailable() && !s.smartResizeAdded) {
            // Run a function when the page is fully loaded including graphics.
                    // Invoca il metodo di tracciamento per il Responsive Web Design
                    s.smartResizeAdded = true;
                    jQuery(window).resize(debounce(s.rwdTrackChange));
        }
    } catch(e) {}
}
  
/*
 * Returns true wether jQuery is available
 */
function jQueryIsAvailable() {
    return typeof jQuery != 'undefined';
}
/* 
 * Responsive Web Desing Plugin (rwd) v0.1
 * Requires apl v1.1 and split v1.5 plugins
 */
s.rwdGetScreenSize = function () {
    return document.documentElement.clientWidth + 'x' + document.documentElement.clientHeight;
}
s.rwdGetRenderedExperience = function () {
    var current_width = document.documentElement.clientWidth;
    var breakpoints = this._rwdBreakpoints;
    for (var layout_type in breakpoints) {
        var min_width = breakpoints[layout_type][0];
        var max_width = breakpoints[layout_type][1];
        if (current_width >= min_width && current_width <= max_width) {
            return layout_type;
        }
    }
    return "Undefined";
}
s.rwdGetPortaitLandscape = function () {
    var current_width = document.documentElement.clientWidth;
    var current_height = document.documentElement.clientHeight;
    return ( current_width > current_height ) ? "Landscape" : "Portrait";
}
  
s.rwdSetupTrack = function () {
    if(!s._rwdUseContextData){
        var evars_array = s._rwdDimensionsEVars.split(",");
        var props_array = s._rwdDimensionsProps.split(",");
        
        // Rendered Experience
        if (evars_array[0]) s[evars_array[0]] = this.rwdGetRenderedExperience();
        if (props_array[0]) s[props_array[0]] = this.rwdGetRenderedExperience();

        // Screen Size
        if (evars_array[1]) s[evars_array[1]] = this.rwdGetScreenSize();
        if (props_array[1]) s[props_array[1]] = this.rwdGetScreenSize();
        
        // Portrait/Landscape
        if (evars_array[2]) s[evars_array[2]] = this.rwdGetPortaitLandscape();
        if (props_array[2]) s[props_array[2]] = this.rwdGetPortaitLandscape();
        
        // Page Name or Page URL
        var dynamic_copy = "D=pageName";
        if (!s.pageName) dynamic_copy = "D=g";
        if (evars_array[3]) s[evars_array[3]] = dynamic_copy;
        if (props_array[3]) s[props_array[3]] = dynamic_copy;
    }else{
        // Rendered Experience
        s.contextData[s._rwdNamespace+'.renderedExp'] = this.rwdGetRenderedExperience();

        // Screen Size
        s.contextData[s._rwdNamespace+'.screenSize'] = this.rwdGetScreenSize();
        
        // Portrait/Landscape
        s.contextData[s._rwdNamespace+'.screenFormat'] = this.rwdGetPortaitLandscape();
    }
    
    
    // Save last dimensions value to prevent the custom link to be sent against same values
    this._rwdLastRE = this.rwdGetRenderedExperience();
    this._rwdLastPL = this.rwdGetPortaitLandscape();
}    
  
s.channelManagerBB = function () {

    var s = this;
    
    // Rendo compatibile il channel manager per le diverse versioni 
    // del codice 
    // Se codice js di SC è Legacy allora definisco la funzione s.Util.getQueryParam
    if(!s.Util || !s.Util.getQueryParam){
        s.Util = {};
        s.Util.getQueryParam = function(keyparam, url, sep){
            return s.getQueryParam(keyparam,sep,url);
        }; 
    }
    
    // instanzio l'oggetto per il channel Manager  
    cm = {};
    //richiamo il metodo per il carimento della configurazione del channel Manager 
    CMConfiguration();

    var sepChannel = cm.separatore['channel'];
    
    // verifico se è presente il cookie del channel manager
    var existsChannel = s.c_r(cm.cookie['channel']);

    var cookieChannel = {};

     //recupero il channel completo : tipo campagna, referrer, searchEngines ... se esiste. Dopo vedrò se utilizzarlo o sovrascriverlo
    if(existsChannel != "")
    {
    // il cookie è già settato leggo le informazioni salvate
    var arrCh = existsChannel.split(sepChannel);

    if(arrCh[0])
        {
            cookieChannel.name = arrCh[0];
            cookieChannel.full = cookieChannel.name;
        }
    if(arrCh[1])
        {
            cookieChannel.referrer = arrCh[1];
            cookieChannel.full += sepChannel + cookieChannel.referrer;
        }
    if(arrCh[2])
        {
            cookieChannel.searchEngines = arrCh[2];
            cookieChannel.full += sepChannel + cookieChannel.searchEngines;
        }
    if(arrCh[3])
        {
            cookieChannel.searchKeyword = arrCh[3];
            cookieChannel.full += sepChannel + cookieChannel.searchKeyword;
        }   
    if(arrCh[4])
        {
            cookieChannel.socialNetwork = arrCh[4];
            cookieChannel.full += sepChannel + cookieChannel.socialNetwork;
        } 
    }
    
  
    
    // verifico se è una nuova visita 
    var isNewVisit="";
    switch (cm.newVisit) 
    {
            case "standard": //plugin standard Adobe (nuova visita dopo 30 minuti di inattivita)
                isNewVisit = s.getVisitStart(cm.cookie['newVisit']['n']);
                break;
            case "custom":  //plugin custom BitBang (nuova visita ad ogni nuovo touch con referrer o tracking code)
                isNewVisit=s.newVisit(cm.cookie['newVisit']['n'],cm.trackingCode);
    }
    
    var channel = {};
    var referrer = {};
    
    referrer.url = document.referrer;
        
    if(referrer.url)
    {
        referrer.domain = s.getDomain(referrer.url).toLowerCase();
        if (referrer.url.indexOf("?") >= 0) 
            referrer.page = referrer.url.substring(0, referrer.url.indexOf("?"));
        else
            referrer.page = referrer.url;
    }

    // Verifico se referrer.url è presente il parametro che identifica una campagna
    for(var i=0;i<cm.trackingCode.length;i++)
    {
        channel.campaign = s.Util.getQueryParam(cm.trackingCode[i]);
        if(channel.campaign)
            break;
    }

      // Verifico la fonte da cui recuperare il tracking code
    if(cm.source=="qs")
    {
         // Verifico se referrer.url è presente il parametro che identifica una campagna
        for(var i=0;i<cm.trackingCode.length;i++)
            {
                channel.campaign = s.Util.getQueryParam(cm.trackingCode[i]);
                if(channel.campaign)
                    break;
            }
    }
    else if (cm.source=="var")
    {
        if(cm.sourceVar)
            channel.campaign = s[cm.sourceVar];
    }
    
    // imposto i parametri di default
    channel.version = "2.3";
    channel.name = "";
    channel.referrer = "";
    channel.searchEngines = "";
    channel.searchKeyword = "";
    channel.socialNetwork = "";
    channel.enable = false;

    var flag_enable = true;

    //Se il dominio corrente è interno, in modalità standard ed è una nuova visita
    if((cm.newVisit=="standard" && isNewVisit) && s.contextData["channelmanagerBB_switch"]=="del")
        {
            s.c_w(cm.cookie['newVisit']['n'],"",-1);
            flag_enable = false;
        }

     s.contextData["channelmanagerBB_switch"]="del";

    if((cm.newVisit=="custom" || cm.newVisit=="standard") && isNewVisit)
    {
        if(flag_enable)
            channel.enable = true;
        channel.name = cm.fontiTraffico['erroreNoChannel']['n'];
        channel.full = cm.fontiTraffico['erroreNoChannel']['n'];
        
        /*************************CAMPAIGN************************************************/
        // se è presente channel.campaign
        if(channel.campaign)
        {
            // ciclo tutti i tipi di campagna definiti
            for (var id in cm.campagna){
                // creo un pattern per la ricerca del tipo campagna nel channel.campaign
                // utilizzo un regex che mi permette di avere più flessibilita 
                var patt=new RegExp(id,cm.campagna[id]['c']);
                // cerco nel channel.campaign il pattern creato  
                if(channel.campaign.search(patt) >= 0){
                    // setto il channel name con il tipo di campagna
                    channel.name = cm.campagna[id]['n'];
                    //verifico che la campagna sia un paid search, verifico il referrer
                    if (referrer.domain)
                    {
                        // Cerco da quale motore di ricerca sono arrivato
                        for (var motore in cm.searchEngines){
                            //cerco il dominio del motore di ricerca dal quale sono arrivato
                            var dom = cm.searchEngines[motore]['tl'][0];
                            var keyNum = 0;
                            //ricerca della keyword: 'kw' è il nome del parametro per ogni differente motore di ricerca
                            //ciclo ogni motore di ricerca perchè potrebbe avere avere una o più keyword
                            for (keyNum; keyNum < cm.searchEngines[motore]['kw'].length; keyNum++) {
                                // recupero il nome del parametro della keyword da trovare nel referrer.url
                                var keyparam = cm.searchEngines[motore]['kw'][keyNum];
                                // verifico che nel referrer sia presente il dominio del motore di ricerca 
                                if (referrer.domain.indexOf(dom) >= 0){
                                    // setto motore di ricerca trovato
                                    channel.searchEngines = motore;
                                    // con il nome della keyword cerco nel referrer.url la searchKeyword    
                                    channel.searchKeyword = s.Util.getQueryParam(keyparam, referrer.url, null).toLowerCase();  
                                    // setto la pagina del referrer trovato 
                                    channel.referrer = referrer.page;
                                    break;
                                }
                            }
                            // se il channel.searchEngines è settato allora esco anche dal ciclo superiore
                            if (channel.searchEngines) break;
                        }
                    }
                    //salvo il channel completo a seconda che sia presente un motore di ricerca: tipo campagna, referrer, searchEngines ... 
                    if (channel.searchEngines)
                        channel.full = channel.name + sepChannel + channel.referrer+ sepChannel + channel.searchEngines + sepChannel +  channel.searchKeyword; 
                    else if (!channel.searchEngines)
                        channel.full = channel.name + sepChannel + channel.campaign;
                    s.c_w(cm.cookie['channel'], channel.full);
                    return channel;     
                }
            }
            // Non ho trovato nessuna campagna tra quelle settate, è una other campaign
            channel.name = cm.fontiTraffico['otherCampaign']['n'];
            //salvo nel channel completo solo la campagna
            channel.full = channel.name + sepChannel + channel.campaign; 
            s.c_w(cm.cookie['channel'], channel.full);
            return channel;     
        }
        // Caso non sia una campagna ed è presente il referrer domain
        else if ((!channel.campaign || channel.campaign=="") &&  referrer.domain)
        {
            // se presente un referrer      
            if(referrer.domain)
            {
                // verifico che non sia un internal referrer
                var arrInterni = new Array();
                channel.referrer = referrer.page;
                // se è settato e non vuoto l'internalFilters leggo i domini interni
                if(s.linkInternalFilters)
                    arrInterni = s.linkInternalFilters.toLowerCase().split(',');
                /*************************INTERNAL************************************************/
                // scorro i domini interni per verificare che il referrer sia una pagina interna            
                for(var linkInterni = 0 ; linkInterni < arrInterni.length ; linkInterni++)
                {
                    //controllo che il referrer domain sia contenuto nella lista linkInternalFilters
                    if (referrer.domain.indexOf(arrInterni[linkInterni]) >= 0) 
                    {
                        // se questa è la prima pagina della visita allora ho perso per qualche motivo il referrer originale
                        // devo quindi segnalare il problema 
                        if(cm.fontiTraffico['internal']['o']=='y')
                        {
                            // setto il channel name con internal referrer
                            channel.name = cm.fontiTraffico['internal']['n'];
                            //salvo il channel completo con solo il referrer 
                            channel.full = channel.name + sepChannel + channel.referrer; 
                            // il channel manager è stato settato, scrivo il cookie e ritorno l'oggetto
                            s.c_w(cm.cookie['channel'], channel.full);
                            return channel;
                        }
                        else
                        {
                            if (existsChannel != "" && typeof cookieChannel.name != "undefined")
                            {
                                cookieChannel.enable = channel.enable; 
                                return cookieChannel;
                            }
                            else{
                                // setto il channel name con internal referrer
                                channel.name = cm.fontiTraffico['internal']['n'];
                                //salvo il channel completo con solo il referrer 
                                channel.full = channel.name + sepChannel + channel.referrer; 
                                // il channel manager è stato settato, scrivo il cookie e ritorno l'oggetto
                                s.c_w(cm.cookie['channel'], channel.full);
                                return channel;
                            }
                        }
                    }
                }
                /*************************SEARCH ENGINES************************************************/
                 if(cm.fontiTraffico['searchOrganic']['o']=='y') //se sono in modalità overwrite channel
                {
                    // Controllo motore di ricerca
                    for (var motore in cm.searchEngines) 
                    {
                        // recupero il dominio dei searchEngines che sto scorrendo
                        var dom = cm.searchEngines[motore]['tl'][0];
                        var keyNum = 0;
                        
                        //controllo che il referrer domain sia contenuto nel dominio dei searchEngines che sto scorrendo
                        if (referrer.domain.indexOf(dom) >= 0 ) {

                           
                            // setto il channel name con Organic
                            channel.name = cm.fontiTraffico['searchOrganic']['n'];
                            // setto searchEngines con il motore di ricerca trovato 
                            channel.searchEngines = motore;
                            // scorro la lista delle key di ricerca per ogni motore di ricerca trovato 
                            for (keyNum; keyNum < cm.searchEngines[motore]['kw'].length; keyNum++) {
                                // recupero il nome del parametro della keyword da trovare nel referrer.url
                                var keyparam = cm.searchEngines[motore]['kw'][keyNum];
                                // con il nome della keyword cerco nel referrer.url la searchKeyword
                                channel.searchKeyword = s.Util.getQueryParam(keyparam,referrer.url, null).toLowerCase();
                                // se searchKeyword è stata trovata allora esco dal ciclo
                                if (channel.searchKeyword != "") break;
                            }
                            // Non è stato possibile recuperare la searchKeyword e setto la variabile segnalando il problema 
                            if (channel.searchKeyword == ""){ 
                                channel.searchKeyword = "No Keyword";
                            }
                            //salvo il channel completo : tipo campagna, referrer, searchEngines ... 
                            channel.full = channel.name + sepChannel + channel.referrer+ sepChannel + channel.searchEngines + sepChannel +  channel.searchKeyword; 
                            // il channel manager è stato settato, scrivo il cookie e ritorno l'oggetto
                            s.c_w(cm.cookie['channel'], channel.full);
                                return channel;
                           

                        }
                    }   
                    if(cm.searchMode=="domain-search")
                    {
                        if (referrer.domain.indexOf("search") >= 0) 
                        {
                              channel.name = cm.fontiTraffico['searchOrganic']['n'];
                              channel.searchEngines = referrer.domain;
                              channel.searchKeyword = "No Keyword";
                              channel.full = channel.name + sepChannel + channel.referrer+ sepChannel + channel.searchEngines + sepChannel +  channel.searchKeyword; 
                              // il channel manager è stato settato, scrivo il cookie e ritorno l'oggetto
                              s.c_w(cm.cookie['channel'], channel.full);
                            return channel;
                        }
                    }
                }   
                else if (cm.fontiTraffico['searchOrganic']['o']=='n' && typeof cookieChannel.name != "undefined") //ritorno il valore nel cookie
                    {
                        cookieChannel.enable = channel.enable; 
                        return cookieChannel;
                    }
            /*************************SOCIAL************************************************/
            //Non ho trovato altri referrer allora verifico che non si tratti di un social network
             if(cm.fontiTraffico['searchSocialOrganic']['o']=='y') //se sono in modalità overwrite channel
                {
                    for (var snet in cm.social) 
                    {
                        // recupero il dominio del social che sto scorrendo
                        var sdom = cm.social[snet];
                        var patt=new RegExp(sdom+"$");
                        //controllo che il referrer domain sia uguale al dominio dei social che sto scorrendo
                        if (referrer.domain.search(patt) >= 0) 
                        {
                            // setto il channel name con Social Organic
                            channel.name = cm.fontiTraffico['searchSocialOrganic']['n'];
                            // setto il tipo di Social trovato
                            channel.socialNetwork = snet;
                            //setto il referrer
                            channel.referrer = referrer.domain;
                            //salvo il channel completo : tipo campagna, referrer, searchEngines ... 
                            channel.full = channel.name + sepChannel + channel.referrer + sepChannel + channel.socialNetwork; 
                            // il channel manager è stato settato, scrivo il cookie e ritorno l'oggetto
                            s.c_w(cm.cookie['channel'], channel.full);
                            return channel;
                        }
                    }
                }   
                else if (cm.fontiTraffico['searchSocialOrganic']['o']=='n' && typeof cookieChannel.name != "undefined") //ritorno il valore nel cookie
                    return cookieChannel;
        /*************************OTHER REFERRER************************************************/
                if(cm.fontiTraffico['otherReferrer']['o']=='y') //se sono in modalità overwrite channel
                {
                    
                    if (!channel.name || cm.fontiTraffico['erroreNoChannel']['n']) 
                    {
                        // setto il channel name con Referrer
                        channel.name = cm.fontiTraffico['otherReferrer']['n'];
                        channel.full = channel.name + sepChannel + channel.referrer;
                        s.c_w(cm.cookie['channel'], channel.full);
                        return channel;
                    }
                }
                else if (cm.fontiTraffico['otherReferrer']['o']=='n' && typeof cookieChannel.name != "undefined") //ritorno il valore nel cookie
                            {
                                cookieChannel.enable = channel.enable; 
                                return cookieChannel;
                            }
            }
            
        }
        /*************************DIRECT********************************************************/
        //Non è una campagna e non ho il referrer domain allora è un direct load o bookmarks
        else if (!s.campaign && !referrer.domain) {
            //verifico che sia la prima volta che atterro sul sito oppure il settaggio che permette al diretto di sovrascrivere
            if (isNewVisit || cm.fontiTraffico['direct']['o']=='y') 
            {
                // setto il channel name con Direct Load
                channel.name = cm.fontiTraffico['direct']['n'];
                // setto il referrer, in questo caso vengo da un  direct load lo definisco come No referrer
                channel.referrer = 'No referrer';
                //salvo il channel completo : tipo campagna, referrer, searchEngines ... 
                channel.full = channel.name;    
                // il channel manager è stato settato, scrivo il cookie e ritorno l'oggetto
                s.c_w(cm.cookie['channel'], channel.full);
                return channel;
            }
            else if(cm.fontiTraffico['direct']['o']=='n')
            {
                if(existsChannel != "" && typeof cookieChannel.name != "undefined")
                { 
                    cookieChannel.enable = channel.enable; 
                    return cookieChannel;
                }
                else // aggiunto nella versione 2.2
                {
                        // setto il channel name con Direct Load
                    channel.name = cm.fontiTraffico['direct']['n'];
                    // setto il referrer, in questo caso vengo da un  direct load lo definisco come No referrer
                    channel.referrer = 'No referrer';
                    //salvo il channel completo : tipo campagna, referrer, searchEngines ... 
                    channel.full = channel.name;    
                    // il channel manager è stato settato, scrivo il cookie e ritorno l'oggetto
                    s.c_w(cm.cookie['channel'], channel.full);
                    return channel;
                }

            }
        }
    }
    if(existsChannel != "" && typeof cookieChannel.name != "undefined")
                { 
                    cookieChannel.enable = channel.enable; 
                    return cookieChannel;
                }
    else
    //ritorno channel in ogni caso
        return channel; 
};

// Da configurare in base all'indicazioni del cliente 
// i parametri configurabili sono: 
// - cm.newVisit = determina la gestione di una nuova visita ('standard':plugin SC o 'custom':plugin BB ) 
// - cm.searchMode = modalità di riconoscimento dei domini search ('domains-only': solo domini elencati o 'domain-search')
// - cm.trackingCode = Nome del parametro della campagna da ricercare 
// - cm.cookie = Nomi dei cookie definiti e utilizzati dentro al channel manager
// - cm.fontitraffico = fonti di traffico, le voci definite verranno visualizzate nei report (N.B.: DA MODIFICARE IN BASE ALLE RICHIESTE DEL CLIENTE) 
// - cm.separatore = Separatori per la concatenazione delle stringhe  dentro al channel manager
// - cm.campagna = regex per la definizione delle campagne del cliente (N.B.: DA MODIFICARE IN BASE ALLE RICHIESTE DEL CLIENTE) 
// - cm.source = fonte del tracking code 
// - cm.sourceVar = eventuale fonte source (variabile)
function CMConfiguration() {

    // modalità di riconoscimento della new visit
    cm.newVisit = 'custom';

    // modalità di riconoscimento dei domini search
    cm.searchMode = 'domains-only';

    // fonte del tracking code
    cm.source = 'var';

    //Nome della variabile (appartenente all'oggetto s) da cui leggere il tracking code, SOLO CON cm.source='var'
    cm.sourceVar = 'campaign';

       
    //Nome dei parametri della campagna da ricercare
    cm.trackingCode = [
        'ucid'
    ];

    // Nomi dei cookie definiti e utilizzati dentro al channel manager
    cm.cookie = {
        'channel' : 'channel',
        'newVisit' : {n:'gvsC'}
    }; 

    // Separatori per la concatenazione delle stringhe dentro al channel manager: si consiglia di evitare - perchè potrebbe essere anche nel nome del Motore di Ricerca
    cm.separatore = {
        'channel' : '_'
    };
    
    // fonti di traffico, le voci definite verranno visualizzate nei report 
    cm.fontiTraffico = {
        'direct' : { n: 'Direct', o: ['n'] },
        'internal' : { n: 'Internal', o: ['n'] },
        'searchOrganic' : { n: 'Natural Search', o: ['y'] },
        'searchSocialOrganic' : { n: 'Social Networks', o: ['y'] },
        'otherReferrer' : { n: 'Referring Domains', o: ['y'] },
        'otherCampaign' : { n:'Other Campaign', o: ['y'] },
        'erroreNoChannel' : { n: 'Direct', o: ['n'] }      
    }
    
    // regex per la definizione per la ricerca delle campagne del cliente 
    // DA MODIFICARE IN BASE ALLE RICHIESTE DEL CLIENTE 
    // '<regular expression>' : {n: [<nome campagna da visualizzare nei report>], c: ['<configurazione della regex (g=global,i=ignore,...)>']}
     cm.campagna = {
        '(KNC-IR30(1|2))|(ULA)' : { n: 'Paid Search', c: ['i'] },
        '(KNC-IR305)|(ULB)' : { n: 'Remarketing', c: ['i'] },
        '(AFC-)|(upc.emessaging.nl)' : { n: 'Affiliate', c: ['i'] },
        '(LEC-)|(facebook.com)|(linkedin.com)|(twitter.com)|(orkut.com)|(friendster.com)|(friendster.com)|(livejournal.com)|(livejournal.com)|(blogspot.com)|(wordpress.com)|(friendfeed.com)' : { n: 'External Link Exchange', c: ['i'] },
        'ILC-' : { n: 'Internal Link Exchange', c: ['i'] },
        'BAC-' : { n: 'Display', c: ['i'] },
        'EMC-' : { n: 'Email Marketing', c: ['i'] },
        'DMC-' : { n: 'Vanity URL', c: ['i'] },
        'SAC-' : { n: 'Paid Social Ad', c: ['i'] },
        'DEM-' : { n: 'Paid Mail', c: ['i'] },
        'SOC(-|_)' : { n: 'Non Paid Social', c: ['i'] },
        'NLC(-|_)' : { n: 'Newsletter', c: ['i'] },
        'QRC-' : { n: 'QR Code', c: ['i'] },
        '^MLC-IR' : { n: 'Mail Alert', c: ['i'] }
     };

    // Social network 
    cm.social = {Facebook:"facebook.com",Twitter:"t.co",MySpace:"myspace.com",LinkedIn:"linkedin.com",Classmates:"classmates.com",Tagged:"tagged.com",Hi5:"hi5.com",Orkut:"orkut.com",Flixster:"flixster.com","My Year Book":"myyearbook.com",NetLog:"netlog.com",Flickr:"flickr.com",Badoo:"badoo.com",Ning:"ning.com",Dada:"dada.net",Veoh:"veoh.com",LastFM:"last.fm",Xing:"xing.com",SlideShare:"slideshare.net","Google Plus":"plus.google.com",Pinterest:"pinterest.com",Weibo:"weibo.com",Blogspot:"blogspot.com",Wordpress:"wordpress.com",Tumblr:"tumblr.com",Vkontakte:"vkontakte.ru",Vk:"vk.com",Vimeo:"vimeo.com",Youtube:"youtube.com",Friendster:"friendster.com",Livejournal:"livejournal.com",Dailymotion:"dailymotion.com",Photobucket:"photobucket.com",Meetup:"meetup.com"},cm.searchEngines={"Google - Italy":{kw:["q"],tl:["google.it"]},"Microsoft Bing":{kw:["q"],tl:["bing.com"]},"Ask Jeeves":{kw:["ask","q"],tl:["ask.com","ask.co.uk"]},Libero:{kw:["query"],tl:["libero.it"]},MSN:{kw:["q"],tl:["msn.com"]},Tiscali:{kw:["key"],tl:["tiscali.it"]},Virgilio:{kw:["qs"],tl:["virgilio.it"]},"Yahoo! - Italy":{kw:["p"],tl:["it.yahoo.com","it.search.yahoo.com"]},"Yandex.ru":{kw:["text"],tl:["yandex.ru"]},"AOL - France":{kw:["q"],tl:["aol.fr"]},"AOL - Germany":{kw:["q"],tl:["suche.aol.de","suche.aolsvc.de"]},"AOL - United Kingdom":{kw:["query"],tl:["aol.co.uk","search.aol.co.uk"]},"AOL.com Search":{kw:["query"],tl:["search.aol.com","search.aol.ca"]},"au.Anzwers":{kw:["p"],tl:["au.anzwers.yahoo.com"]},Baidu:{kw:["wd","s"],tl:["http://www.baidu.com"]},"BeGuide.com":{kw:["search"],tl:["beguide.com"]},"Blue Window":{kw:["q","qry"],tl:["search.bluewin.ch","search.bluewindow.ch"]},"Business.com":{kw:["query"],tl:["business.com/search"]},BuyersIndex:{kw:["query"],tl:["buyersindex.com"]},ByteSearch:{kw:["search","q"],tl:["bytesearch.com"]},Cafesta:{kw:["keyword","keywords"],tl:["cafesta.com"]},"CNET Search.com":{kw:["q"],tl:["cnet.search.com"]},ComFind:{kw:[""],tl:["debriefing.com","allbusiness.comfind.com"]},Crooz:{kw:["query"],tl:["crooz.jp"]},"CyberBritain.com":{kw:["qry"],tl:["hermia.com","cyberbritain.co.uk"]},"Dazzo!":{kw:["search"],tl:["dazzo.com"]},DejaNews:{kw:["QRY"],tl:["www.dejanews.com"]},Deoji:{kw:["search","k"],tl:["deoji.com"]},"Dictionary.com":{kw:["term","query"],tl:["Dictionary.com","Dictionary"]},"Dino Online":{kw:["query"],tl:["www.dino-online.de"]},DirectHit:{kw:["qry","q"],tl:["directhit.com"]},Dmoz:{kw:["search"],tl:["search.dmoz.com","dmoz.com"]},"dog.com":{kw:["search"],tl:["doginfo.com"]},Dogpile:{kw:["q","/search/web/"],tl:["dogpile.com"]},"eerstekeuze.nl":{kw:["Terms"],tl:["http://www.eerstekeuze.nl/"]},'Fansi"tes.com':{kw:["q1"],tl:["fansites.com"]},"Final Search":{kw:["pattern"],tl:["finalsearch.com"]},FindLink:{kw:[""],tl:['"findlink.com']},Fireball:{kw:["q","query"],tl:["fireball.de"]},"FishHoo!":{kw:["query"],tl:["fishhoo.com"]},FreshEye:{kw:["ord","kw"],tl:["search.fresheye.com"]},Froute:{kw:["k"],tl:["item.froute.jp","search.froute.jp"]},"FullWebinfo Directory & Search Engine":{kw:["k","s"],tl:["fullwebinfo.com"]},Galaxy:{kw:[""],tl:["galaxy.tradewave.com"]},"General Search":{kw:["keyword"],tl:["generalsearch.com"]},"GeoBoz Search":{kw:["search"],tl:["geoboz.com"]},"Globe Crawler":{kw:["search"],tl:["globecrawler.com"]},"Go (Infoseek)":{kw:["qt"],tl:["infoseek.go.com"]},"Go2net Metacrawler":{kw:["general"],tl:["go2net.com"]},GoButton:{kw:[""],tl:["gobutton.com"]},Godado:{kw:["Keywords"],tl:["godado.it"]},GoEureka:{kw:["q","key"],tl:["goeureka.com.au"]},"Goo (Japan)":{kw:["MT"],tl:["search.mobile.goo.ne.jp"]},"Goo (Jp.)":{kw:["MT"],tl:["goo.ne.jp"]},"Google - Afghanistan":{kw:["q"],tl:["google.com.af"]},"Google - Argentina":{kw:["q"],tl:["google.com.ar"]},"Google - Armenia":{kw:["q"],tl:["google.am"]},"Google - Australia":{kw:["q"],tl:["google.com.au"]},"Google - Austria":{kw:["q"],tl:["google.at"]},"Google - Azerbaijan":{kw:["q"],tl:["google.az"]},"Google - Bahrain":{kw:["q"],tl:["google.com.bh"]},"Google - Bangladesh":{kw:["q"],tl:["google.com.bd"]},"Google - Belarus":{kw:["q"],tl:["google.com.by"]},"Google - Belgium":{kw:["q"],tl:["google.be"]},"Google - Bolivia":{kw:["q"],tl:["google.com.bo"]},"Google - Bosnia-Hercegovina":{kw:["q"],tl:["google.ba"]},"Google - Brasil":{kw:["q"],tl:["google.com.br"]},"Google - Brunei":{kw:["q"],tl:["google.com.bn"]},"Google - Bulgaria":{kw:["q"],tl:["google.bg"]},"Google - Burundi":{kw:["q"],tl:["google.bi"]},"Google - Cambodia":{kw:["q"],tl:["google.com.kh"]},"Google - Canada":{kw:["q"],tl:["google.ca"]},"Google - Chile":{kw:["q"],tl:["google.cl"]},"Google - China":{kw:["q"],tl:["google.cn"]},"Google - Colombia":{kw:["q"],tl:["google.com.co"]},"Google - Costa Rica":{kw:["q"],tl:['go"ogle.co.cr']},"Google - Cote D'Ivoire":{kw:["q"],tl:["google.ci"]},"Google - Croatia":{kw:["q"],tl:["google.hr"]},"Google - Cuba":{kw:["q"],tl:["google.com.cu"]},"Google - Czech Republic":{kw:["q"],tl:["google.cz"]},"Google - Denmark":{kw:["q"],tl:["google.dk"]},"Google - Dominica":{kw:["q"],tl:["google.dm"]},"Google - Dominican Republic":{kw:["q"],tl:["google.com.do"]},"Google - Ecuador":{kw:["q"],tl:["google.com.ec"]},"Google - Egypt":{kw:["q"],tl:["google.com.eg"]},"Google - El Salvador":{kw:["q"],tl:["google.com.sv"]},"Google - Estonia":{kw:["q"],tl:["google.ee"]},"Google - Ethiopia":{kw:["q"],tl:["google.com.et"]},"Google - Fiji":{kw:["q"],tl:["google.com.fj"]},"Google - Finland":{kw:["q"],tl:["google.fi"]},"Google - France":{kw:["q"],tl:["google.fr"]},"Google - Germany":{kw:["q"],tl:["google.de"]},"Google - Greece":{kw:["q"],tl:["google.gr"]},"Google - Greenland":{kw:["q"],tl:["google.gl"]},"Google - Guadeloupe":{kw:["q"],tl:["google.gp"]},"Google - Guatemala":{kw:["q"],tl:["google.com.gt"]},"Google - Haiti":{kw:["q"],tl:["google.ht"]},"Google - Honduras":{kw:["q"],tl:["google.hn"]},"Google - Hong Kong":{kw:["q"],tl:["google.com.hk"]},"Google - Hungary":{kw:["q"],tl:["google.hu"]},"Google - India":{kw:["q"],tl:["google.co.in"]},"Google - Indonesia":{kw:["q"],tl:["google.co.id"]},"Google - Ireland":{kw:["q"],tl:["google.ie"]},"Google - Island":{kw:["q"],tl:["google.is"]},"Google - Isle of Gibraltar":{kw:["q"],tl:["google.com.gi"]},"Google - Israel":{kw:["q"],tl:["google.co.il"]},"Google - Jamaica":{kw:["q"],tl:["google.com.jm"]},"Google - Japan":{kw:["q"],tl:["google.co.jp"]},"Google - Jordan":{kw:["q"],tl:["google.jo"]},"Google - Kazakhstan":{kw:["q"],tl:["google.kz"]},"Google - Kenya":{kw:["q"],tl:["google.co.ke"]},"Google - Korea":{kw:["q"],tl:["google.co.kr"]},"Google - Latvia":{kw:["q"],tl:["google.lv"]},"Google - Libya":{kw:["q"],tl:["google.com.ly"]},"Google - Liechtenstein":{kw:["q"],tl:["google.li"]},"Google - Lithuania":{kw:["q"],tl:["google.lt"]},"Google - Luxembourg":{kw:["q"],tl:["google.lu"]},"Google - Malaysia":{kw:["q"],tl:["google.com.my"]},"Google - Maldives":{kw:["q"],tl:["google.mv"]},"Google - Malta":{kw:["q"],tl:["google.com.mt"]},"Google - Mauritius":{kw:["q"],tl:["google.mu"]},"Google - Mexico":{kw:["q"],tl:["google.com.mx"]},"Google - Moldova":{kw:["q"],tl:["google.md"]},"Google - Mongolia":{kw:["q"],tl:["google.mn"]},"Google - Morocco":{kw:["q"],tl:["google.co.ma"]},"Google - Nepal":{kw:["q"],tl:["google.com.np"]},"Google - Netherlands":{kw:["q"],tl:["google.nl"]},"Google - New Zealand":{kw:["q"],tl:["google.co.nz"]},"Google - Nicaragua":{kw:["q"],tl:["google.com.ni"]},"Google - Nigeria":{kw:["q"],tl:["google.com.ng"]},"Google - Norway (Startsiden)":{kw:["q"],tl:["google.startsiden.no"]},"Google - Norway":{kw:["q"],tl:["google.no"]},"Google - Pakistan":{kw:["q"],tl:["google.com.pk"]},"Google - Panama":{kw:["q"],tl:["google.com.pa"]},"Google - Paraguay":{kw:["q"],tl:["google.com.py"]},"Google - Peru":{kw:["q"],tl:["google.com.pe"]},"Google - Philippines":{kw:["q"],tl:["google.com.ph"]},"Google - Poland":{kw:["q"],tl:["google.pl"]},"Google - Portugal":{kw:["q"],tl:["google.pt"]},"Google - Puerto Rico":{kw:["q"],tl:["google.com.pr"]},"Google - Qatar":{kw:["q"],tl:["google.com.qa"]},"Google - Rep. Dem. du Congo":{kw:["q"],tl:["google.cd"]},"Google - Rep. du Congo":{kw:["q"],tl:["google.cg"]},"Google - Repulic of Georgia":{kw:["q"],tl:["google.ge"]},"Google - Romania":{kw:["q"],tl:["google.ro"]},"Google - Russia":{kw:["q"],tl:["google.ru"]},"Google - Saint Helena":{kw:["q"],tl:["google.sh"]},"Google - Samoa":{kw:["q"],tl:["google.ws"]},"Google - San Marino":{kw:["q"],tl:["google.sm"]},"Google - Saudi Arabia":{kw:["q"],tl:["google.com.sa"]},"Google - Senegal":{kw:["q"],tl:["google.sn"]},"Google - Seychelles":{kw:["q"],tl:["google.sc"]},"Google - Singapore":{kw:["q"],tl:["google.com.sg"]},"Google - Slovakia":{kw:["q"],tl:["google.sk"]},"Google - Slovenia":{kw:["q"],tl:["google.si"]},"Google - South Africa":{kw:["q"],tl:["google.co.za"]},"Google - Spain":{kw:["q"],tl:["google.es"]},"Google - Sri Lanka":{kw:["q"],tl:["google.lk"]},"Google - Sweden":{kw:["q"],tl:["google.se"]},"Google - Switzerland":{kw:["q"],tl:["google.ch"]},"Google - Taiwan":{kw:["q"],tl:["google.com.tw"]},"Google - Thailand":{kw:["q"],tl:["google.co.th"]},"Google - The Bahamas":{kw:["q"],tl:["google.bs"]},"Google - Turkey":{kw:["q"],tl:["google.com.tr"]},"Google - Ukraine":{kw:["q"],tl:["google.com.ua"]},"Google - United Arab Emirates":{kw:["q"],tl:["google.ae"]},"Google - United Kingdom":{kw:["q"],tl:["google.co.uk"]},"Google - Uruguay":{kw:["q"],tl:["google.com.uy"]},"Google - US":{kw:["q"],tl:["google.com"]},"Google - Venezuela":{kw:["q"],tl:["google.co.ve"]},"Google - Viet Nam":{kw:["q"],tl:["google.com.vn"]},"Google - Yugoslavia":{kw:["q"],tl:["google.co.yu"]},"Google - Zambia":{kw:["q"],tl:["google.co.zm"]},"Google Images":{kw:["q"],tl:["images.google.com"]},"Google Video":{kw:["q"],tl:["video.google.com"]},Google:{kw:["q"],tl:["google.co","googlesyndication.com"]},"ilse.nl":{kw:["search_for"],tl:["search.ilse.nl"]},InfoSpace:{kw:["QKW","qhqn"],tl:["infospace.com"]},InfoTiger:{kw:["qs"],tl:["infotiger.com"]},"Internet Times":{kw:["search","query"],tl:["internet-times.com"]},InternetTrash:{kw:["words"],tl:["internettrash.com"]},"Live.com":{kw:["q"],tl:["search.live.com"]},"Livedoor - Mobile":{kw:["q","keyword"],tl:["dir.m.livedoor.com"]},LookSmart:{kw:["key","qt"],tl:["looksmart.com","looksmart.co.uk"]},"Loquax Open Directory":{kw:["search"],tl:["loquax.co.uk"]},"Lycos - Italy":{kw:["query"],tl:["lycos.it"]},Lycos:{kw:["query"],tl:["www.lycos.com","search.lycos.com"]},Magellan:{kw:["search"],tl:["magellan"]},"Metacrawler - Germany":{kw:["qry"],tl:["216.15.219.34","216.15.192.226"]},Metacrawler:{kw:["general","/search/web/"],tl:["www.metacrawler.com","search.metacrawler.com"]},"MetaDog.com":{kw:["search","keyword"],tl:["metapro.com","metadog.com"]},MetaGopher:{kw:["query"],tl:["metagopher.com"]},"MetaIQ.com":{kw:["search","qry"],tl:["metaiq"]},"Mobagee Search":{kw:["q"],tl:["s.mbga.jp"]},"Monster Crawler":{kw:["qry"],tl:["monstercrawler.com"]},"MSN - Austria":{kw:["q"],tl:["search.msn.at"]},"MSN - Belgium":{kw:["q"],tl:["search.msn.be"]},"MSN - Brazil":{kw:["q"],tl:["search.msn.com.br"]},"MSN - Canada":{kw:["q"],tl:["sympatico.msn.ca","search.fr.msn.ca"]},"MSN - Denmark":{kw:["q"],tl:["search.msn.dk"]},"MSN - France":{kw:["q"],tl:["search.msn.fr"]},"MSN - Germany":{kw:["q"],tl:["search.msn.de"]},"MSN - Hong Kong S.A.R.":{kw:["q"],tl:["search.msn.com.hk"]},"MSN - India (English)":{kw:["q"],tl:["search.msn.co.in"]},"MSN - Indonesia (English)":{kw:["q"],tl:["search.msn.co.id"]},"MSN - Ireland":{kw:["q"],tl:["search.msn.ie"]},"MSN - Isreal":{kw:["q"],tl:["search.msn.co.il"]},"MSN - Italy":{kw:["q"],tl:["search.msn.it"]},"MSN - Japan":{kw:["q"],tl:["search.msn.co.jp"]},"MSN - Korea":{kw:["q","query"],tl:["search.msn.co.kr"]},"MSN - Latin America":{kw:["q"],tl:["search.latam.msn.com"]},"MSN - Malaysia":{kw:["q"],tl:["search.msn.com.my"]},"MSN - Mexico":{kw:["q"],tl:["t1msn.com.mx","search.prodigy.msn.com"]},"MSN - Netherlands":{kw:["q"],tl:["search.msn.nl"]},"MSN - New Zealand":{kw:["q","mkt=en-nz"],tl:["msn.co.nz"]},"MSN - Norway":{kw:["q"],tl:["search.msn.no"]},"MSN - People's Republic of China":{kw:["q"],tl:["search.msn.com.cn"]},"MSN - Republic of the Phlippines":{kw:["q"],tl:["search.msn.com.ph"]},"MSN - Singapore":{kw:["q"],tl:["search.msn.com.sg"]},"MSN - South Africa":{kw:["q"],tl:["search.msn.co.za"]},"MSN - Spain":{kw:["q"],tl:["search.msn.es"]},"MSN - Sweden":{kw:["q"],tl:["search.msn.se"]},"MSN - Switzerland":{kw:["q"],tl:["search.msn.ch","fr.ch.msn.com"]},"MSN - Taiwan":{kw:["q"],tl:["search.msn.com.tw"]},"MSN - Turkey":{kw:["q"],tl:["search.msn.com.tr"]},"MSN - United Kingdom":{kw:["q"],tl:["uk.search.msn.com","msn.co.uk"]},"MSN LiveSearch Mobile":{kw:["q"],tl:["m.live.com"]},"MSN UK":{kw:["q"],tl:["msn.co.uk"]},myGO:{kw:["qry"],tl:["mygo.com"]},"My Web Search":{kw:["searchfor"],tl:["search.mywebsearch.com"]},"Nate.com":{kw:["query"],tl:["nate.com","search.nate.com"]},"National Directory":{kw:["query"],tl:["search.NationalDirectory.com"]},NBCi:{kw:["keyword","qkw"],tl:["nbci.com"]},NetSearch:{kw:["Terms","search"],tl:["netsearchvoyager.com","netsearch.org"]},"Nexet Open Directory":{kw:["SEARCH","q"],tl:["nexet.net"]},Nifty:{kw:["Text"],tl:["search.nifty.com"]},Nomade:{kw:["s","MT"],tl:["nomade.fr"]},"Northern Light":{kw:["qr"],tl:["www.northernlight.com"]},"Oh! New? Mobile":{kw:["k"],tl:["ohnew.co.jp"]},"Orbit.net":{kw:[""],tl:["orbit.net"]},Overture:{kw:['Keywords="'],tl:["overture.com"]},QuestFinder:{kw:["s"],tl:["questfinder.com","questfinder.net"]},"RageWorld.com":{kw:["search"],tl:["rageworld.com"]},"Rex Search":{kw:["terms"],tl:["rex-search.com","rex-search.com"]},"Search City":{kw:["search","keyword"],tl:["searchcity.co.uk"]},"Search King":{kw:["searchterm","keyword"],tl:["searchking.com"]},"Search Results":{kw:["q"],tl:["search-results.com"]},"Search.ch":{kw:["q"],tl:["search.ch"]},Searchalot:{kw:["query","q"],tl:["searchalot.com"]},SearchHound:{kw:["?"],tl:["searchhound.com"]},Searchteria:{kw:["p"],tl:["ad.searchteria.co.jp"]},"SmartPages.com":{kw:["QueryString"],tl:["smartpages.com"]},"So-net":{kw:["MT"],tl:["so-net.search.goo.ne.jp"]},TheYellowPages:{kw:["search"],tl:["theyellowpages.com"]},Thunderstone:{kw:["q"],tl:["thunderstone.com"]},"ToggleBot!":{kw:["search","query"],tl:["togglebot.com"]},"TopFile.com":{kw:["query"],tl:["www.topfile.com"]},"track.nl":{kw:["qr"],tl:["http://www.track.nl/"]},WAKWAK:{kw:["MT"],tl:["wakwak.com"]},"Web Trawler":{kw:[""],tl:["webtrawler.com"]},"Web.de":{kw:["su"],tl:["web.de"]},Webalta:{kw:["q"],tl:["webalta.ru"]},WebCrawler:{kw:["searchText","search"],tl:["www.webcrawler.com"]},"Web-Search":{kw:["q"],tl:["www.web-search.com"]},"Yahoo! - Argentina":{kw:["p"],tl:["ar.yahoo.com","ar.search.yahoo.com"]},"Yahoo! - Asia":{kw:["p"],tl:["asia.yahoo.com","asia.search.yahoo.com"]},"Yahoo! - Australia":{kw:["p"],tl:["au.yahoo.com","au.search.yahoo.com"]},"Yahoo! - Austria":{kw:["p"],tl:["at.search.yahoo.com"]},"Yahoo! - Brazil":{kw:["p"],tl:["br.yahoo.com","br.search.yahoo.com"]},"Yahoo! - Canada (French)":{kw:["p"],tl:["qc.yahoo.com","cf.search.yahoo.com"]},"Yahoo! - Canada":{kw:["p"],tl:["ca.yahoo.com","ca.search.yahoo.com"]},"Yahoo! - Catalan":{kw:["p"],tl:["ct.yahoo.com","ct.search.yahoo.com"]},"Yahoo! - China":{kw:["p"],tl:["cn.yahoo.com","search.cn.yahoo.com"]},"Yahoo! - Chinese (US)":{kw:["p"],tl:["chinese.yahoo.com"]},"Yahoo! - Denmark":{kw:["p"],tl:["dk.yahoo.com","dk.search.yahoo.com"]},"Yahoo! - Finland":{kw:["p"],tl:["fi.search.yahoo.com"]},"Yahoo! - France":{kw:["p"],tl:["fr.yahoo.com","fr.search.yahoo.com"]},"Yahoo! - Germany":{kw:["p"],tl:["de.yahoo.com","de.search.yahoo.com"]},"Yahoo! - Hong Kong":{kw:["p"],tl:["hk.yahoo.com","hk.search.yahoo.com"]},"Yahoo! - India":{kw:["p"],tl:["in.yahoo.com","in.search.yahoo.com"]},"Yahoo! - Indonesia":{kw:["p"],tl:["id.yahoo.com","id.search.yahoo.com"]},"Yahoo! - Italy":{kw:["p"],tl:["it.yahoo.com","it.search.yahoo.com"]},"Yahoo! - Japan":{kw:["p","va"],tl:["yahoo.co.jp","search.yahoo.co.jp"]},"Yahoo! - Kids":{kw:["p"],tl:["kids.yahoo.com","kids.yahoo.com/search"]},"Yahoo! - Korea":{kw:["p"],tl:["kr.yahoo.com","kr.search.yahoo.com"]},"Yahoo! - Malaysia":{kw:["p"],tl:["malaysia.yahoo.com","malaysia.search.yahoo.com"]},"Yahoo! - Mexico":{kw:["p"],tl:["mx.yahoo.com","mx.search.yahoo.com"]},"Yahoo! - Netherlands":{kw:["p"],tl:["nl.yahoo.com","nl.search.yahoo.com"]},"Yahoo! - New Zealand":{kw:["p"],tl:["nz.yahoo.com","nz.search.yahoo.com"]},"Yahoo! - Norway":{kw:["p"],tl:["no.yahoo.com","no.search.yahoo.com"]},"Yahoo! - Philippines":{kw:["p"],tl:["ph.yahoo.com","ph.search.yahoo.com"]},"Yahoo! - Russia":{kw:["p"],tl:["ru.yahoo.com","ru.search.yahoo.com"]},"Yahoo! - Singapore":{kw:["p"],tl:["sg.yahoo.com","sg.search.yahoo.com"]},"Yahoo! - Spain":{kw:["p"],tl:["es.yahoo.com","es.search.yahoo.com"]},"Yahoo! - Spanish (US : Telemundo)":{kw:["p"],tl:["telemundo.yahoo.com","espanol.search.yahoo.com"]},"Yahoo! - Sweden":{kw:["p"],tl:["se.yahoo.com","se.search.yahoo.com"]},"Yahoo! - Switzerland":{kw:["p"],tl:["ch.search.yahoo.com"]},"Yahoo! - Taiwan":{kw:["p"],tl:["tw.yahoo.com","tw.search.yahoo.com"]},"Yahoo! - Thailand":{kw:["p"],tl:["th.yahoo.com","th.search.yahoo.com"]},"Yahoo! - UK and Ireland":{kw:["p"],tl:["uk.yahoo.com","uk.search.yahoo.com"]},"Yahoo! - Viet Nam":{kw:["p"],tl:["vn.yahoo.com","vn.search.yahoo.com"]},"Yahoo!":{kw:["p"],tl:["yahoo.com","search.yahoo.com"]},"YahooJapan - Mobile":{kw:["p"],tl:["mobile.yahoo.co.jp"]},"zoeken.nl":{kw:["query"],tl:["http://www.zoeken.nl/"]}};

}

s.getDomain = function(ref) {
    var s = this;
    var url = "";
    var urlTemp = ref;
    var split = urlTemp.split("/");
    if(split[0].indexOf("http")===0)
        url = split[2];
    else 
        url = split[0];
    return url;
}

function get_tld(domain) {
    var urlTLD;
    if (domain == "" || domain == null)
        urlTLD = window.location.host;
    else
        urlTLD = domain;

    var temp = urlTLD.split(".");
    var result = "";
    if(temp.length>1)
        result = "." + temp[temp.length - 2] + "." + temp[temp.length - 1];
    else
        result = temp[temp.length - 1];

    return result;

}

s.BBTimeParting = function (conf) {
    var s = this;
    var total_var = conf.tot;
    var today = new Date();
    s.currentYear = today.getFullYear();
    var date = s._dstDates[s.currentYear];
    var timezone = conf.tz

    s.dstStart = date["start"] + "/" + s.currentYear;
    s.dstEnd = date["end"] + "/" + s.currentYear;
    s[total_var] = s.getTimeParting('h', timezone)+"/"+s.getTimeParting('d', timezone)+"/"+s.getTimeParting('w', timezone);
}

s.newVisit = function(cookieName,params) {
    if (s.c_r(cookieName) == "") {
        // New Visit Start
        //document.cookie = cookieName + "=New; domain=" + get_tld() + "; path=/";
        t=new Date;
        t.setTime(t.getTime()+1800000);
        s.c_w(cookieName,"New",t);
        return 1;
    } else {
        var newInternalLink = s.linkInternalFilters;
        var arr = newInternalLink.toLowerCase().split(",");
        var sonoInterno = 0;
        var refTLD = s.getDomain(document.referrer);
        if(refTLD != ""){
            for(var intL = 1 ; intL < arr.length ; intL++){
            
                if(refTLD.indexOf(arr[intL])>=0)sonoInterno = 1;
            
            }
            if(sonoInterno == 0)return 1;
        }
        for(var i=0;i<params.length;i++)
        {
            if(window.location.href.indexOf(params[i])>=0)
                return 1;
        }
        return 0;
    }
};

/*
 * Get visit start
 */
s.getVisitStart=new Function("c",""
+"var s=this,v=1,t=new Date;t.setTime(t.getTime()+1800000);if(s.c_r(c"
+")){v=0}if(!s.c_w(c,1,t)){s.c_w(c,1,0)}if(!s.c_r(c)){v=0}return v;");

// Track Troubles
s.trackTroubles = function () {
    var s = this;
    var arrayProblemi = [];

    if (!s.contextData["validationVar"]) {
        return;
    }

    s[s.contextData["validationVar"]] = "";

    for (var problema in s.contextData.troubles) {
        arrayProblemi.push(problema);
    }

    if (arrayProblemi.length > 0) {
        s[s.contextData["validationVar"]] = arrayProblemi.join("|");
    }

    // Se siamo in un Custom Link Tracking e ci sono problemi, aggiunge la varPerDebug all'elenco della linkTrackVars
    if (s._customLinkTrackingFlag && s[s.contextData["validationVar"]]) {
        if (s.linkTrackVars === "None") {
            s.linkTrackVars = "";
        }
        s.linkTrackVars = s.apl(s.linkTrackVars, s.varPerDebug, ',', 2);
    }
};

s.getPreviousValue=new Function("v","c","el",""
+"var s=this,t=new Date,i,j,r='';t.setTime(t.getTime()+1800000);if(el"
+"){if(s.events){i=s.split(el,',');j=s.split(s.events,',');for(x in i"
+"){for(y in j){if(i[x]==j[y]){if(s.c_r(c)) r=s.c_r(c);v?s.c_w(c,v,t)"
+":s.c_w(c,'no value',t);return r}}}}}else{if(s.c_r(c)) r=s.c_r(c);v?"
+"s.c_w(c,v,t):s.c_w(c,'no value',t);return r}");

/*
* Plugin: getNewRepeat 1.2 - Returns whether user is new or repeat
*/
s.getNewRepeat=new Function("d","cn",""
+"var s=this,e=new Date(),cval,sval,ct=e.getTime();d=d?d:30;cn=cn?cn:"
+"'s_nr';e.setTime(ct+d*24*60*60*1000);cval=s.c_r(cn);if(cval.length="
+"=0){s.c_w(cn,ct+'-New',e);return'New';}sval=s.split(cval,'-');if(ct"
+"-sval[0]<30*60*1000&&sval[1]=='New'){s.c_w(cn,ct+'-New',e);return'N"
+"ew';}else{s.c_w(cn,ct+'-Repeat',e);return'Repeat';}");
/*
 * Utility Function: split v1.5 (JS 1.0 compatible)
 */
s.split=new Function("l","d",""
+"var i,x=0,a=new Array;while(l){i=l.indexOf(d);i=i>-1?i:l.length;a[x"
+"++]=l.substring(0,i);l=l.substring(i+d.length);}return a");

s.getDaysSinceLastVisit=new Function("c",""
+"var s=this,e=new Date(),es=new Date(),cval,cval_s,cval_ss,ct=e.getT"
+"ime(),day=24*60*60*1000,f1,f2,f3,f4,f5;e.setTime(ct+3*365*day);es.s"
+"etTime(ct+30*60*1000);f0='Cookies Not Supported';f1='First Visit';f"
+"2='More than 30 days';f3='More than 7 days';f4='Less than 7 days';f"
+"5='Less than 1 day';cval=s.c_r(c);if(cval.length==0){s.c_w(c,ct,e);"
+"s.c_w(c+'_s',f1,es);}else{var d=ct-cval;if(d>30*60*1000){if(d>30*da"
+"y){s.c_w(c,ct,e);s.c_w(c+'_s',f2,es);}else if(d<30*day+1 && d>7*day"
+"){s.c_w(c,ct,e);s.c_w(c+'_s',f3,es);}else if(d<7*day+1 && d>day){s."
+"c_w(c,ct,e);s.c_w(c+'_s',f4,es);}else if(d<day+1){s.c_w(c,ct,e);s.c"
+"_w(c+'_s',f5,es);}}else{s.c_w(c,ct,e);cval_ss=s.c_r(c+'_s');s.c_w(c"
+"+'_s',cval_ss,es);}}cval_s=s.c_r(c+'_s');if(cval_s.length==0) retur"
+"n f0;else if(cval_s!=f1&&cval_s!=f2&&cval_s!=f3&&cval_s!=f4&&cval_s"
+"!=f5) return '';else return cval_s;");

//OPZIONALI PER stacking
/*
 *    Plug-in: crossVisitParticipation v1.7 - stacks values from
 *    specified variable in cookie and returns value
 */
s.crossVisitParticipation=new Function("v","cn","ex","ct","dl","ev","dv",""
+"var s=this,ce;if(typeof(dv)==='undefined')dv=0;if(s.events&&ev){var"
+" ay=s.split(ev,',');var ea=s.split(s.events,',');for(var u=0;u<ay.l"
+"ength;u++){for(var x=0;x<ea.length;x++){if(ay[u]==ea[x]){ce=1;}}}}i"
+"f(!v||v==''){if(ce){s.c_w(cn,'');return'';}else return'';}v=escape("
+"v);var arry=new Array(),a=new Array(),c=s.c_r(cn),g=0,h=new Array()"
+";if(c&&c!=''){arry=s.split(c,'],[');for(q=0;q<arry.length;q++){z=ar"
+"ry[q];z=s.repl(z,'[','');z=s.repl(z,']','');z=s.repl(z,\"'\",'');arry"
+"[q]=s.split(z,',')}}var e=new Date();e.setFullYear(e.getFullYear()+"
+"5);if(dv==0&&arry.length>0&&arry[arry.length-1][0]==v)arry[arry.len"
+"gth-1]=[v,new Date().getTime()];else arry[arry.length]=[v,new Date("
+").getTime()];var start=arry.length-ct<0?0:arry.length-ct;var td=new"
+" Date();for(var x=start;x<arry.length;x++){var diff=Math.round((td."
+"getTime()-arry[x][1])/86400000);if(diff<ex){h[g]=unescape(arry[x][0"
+"]);a[g]=[arry[x][0],arry[x][1]];g++;}}a.splice(0,a.length - 5);var data=s.join(a,{delim:',',"
+"front:'[',back:']',wrap:\"'\"});s.c_w(cn,data,e);var r=s.join(h,{deli"
+"m:dl});if(ce)s.c_w(cn,'');return r;");

/* 1.1.0.13 - getValOnce_v1.11*/
s.getValOnce=new Function("v","c","e","t",""
+"var s=this,a=new Date,v=v?v:'',c=c?c:'s_gvo',e=e?e:0,i=t=='m'?6000"
+"0:86400000,k=s.c_r(c);if(v){a.setTime(a.getTime()+e*i);s.c_w(c,v,e"
+"==0?0:a);}return v==k?'':v");

//setuplinktrack 
s.setupLinkTrack = function(vl, c , e){
  var s = this;
    var cv = s.c_r(c);
    if (vl) {
        var vla = vl.split(',');
    }
    if (cv != '') {
        var cva = s.split(cv, '^^');
        for (x in vla) {
            s[vla[x]] = cva[x];
            if (e) {
                s.events = s.apl(s.events, e, ',', 2);
            }
        }
    }
    s.c_w(c, '', 0);
    if (typeof s.linkObject != 'undefined') {
        s.lta = [];
        if (typeof s.pageName != 'undefined') s.lta[0] = s.pageName;
        if (typeof s.linkObject != null) {
            slo = s.linkObject;
			
            if (s.linkObject != 0) {
                if (s.linkObject.getAttribute('name') != null) {
                    var b = s.linkObject.getAttribute('name');
                    if (b.indexOf('&lpos=') > -1) {
                        s.lta[3] = b.match('\&lpos\=([^\&]*)')[1];
                    }
                    if (b.indexOf('&lid=') > -1) {
                        s.lta[1] = b.match('\&lid\=([^\&]*)')[1];
                    }
                }
            }
			
			if(s.hbx_lt != 'manual'){
				if (typeof s.lta[1] == 'undefined') {
					if (s.linkName != 0) {
						s.lta[1] = s.linkName;
					} else if (s.linkObject != 0) {
						if (s.linkObject.innerHTML.indexOf('<img') > -1) {
							s.lta[1] = s.linkObject.innerHTML.match('src=\"([^\"]*)')[1]
						} else {
							s.lta[1] = s.linkObject.innerHTML;
						}
					}
				}
			}
			s.lta[2] = s.pageName + ' | ' + s.lta[1];
        }
        if (s.linkType != 0) {
            for (var x = 0; x < vla.length; x++) {
                s[vla[x]] = s.lta[x];
                if (e) {
                    s.events = s.apl(s.events, e, ',', 2);
                    s.linkTrackVars = s.apl(s.linkTrackVars, 'events', ',', 2);
                }
            }
            s.linkTrackVars = s.apl(s.linkTrackVars, vl, ',', 2);
        } else {
            var tcv = '';
            for (var x = 0; x < s.lta.length; x++) {
                tcv += s.lta[x] + '^^'
            }
            s.c_w(c, tcv)
        }
        s.lta = null;
    }
	
}
/*
 * Plugin Utility: apl v1.1
 */
s.apl=new Function("l","v","d","u",""
+"var s=this,m=0;if(!l)l='';if(u){var i,n,a=s.split(l,d);for(i=0;i<a."
+"length;i++){n=a[i];m=m||(u==1?(n==v):(n.toLowerCase()==v.toLowerCas"
+"e()));}}if(!m)l=l?l+d+v:v;return l");
/* Plugin Utility: Replace v1.0
 */
s.repl=new Function("x","o","n",""
+"var i=x.indexOf(o),l=n.length;while(x&&i>=0){x=x.substring(0,i)+n+x."
+"substring(i+o.length);i=x.indexOf(o,i+l)}return x");

/*
 * s.join: 1.0 - s.join(v,p)
 *
 *  v - Array (may also be array of array)
 *  p - formatting parameters (front, back, delim, wrap)
 *
 */

s.join = new Function("v","p",""
+"var s = this;var f,b,d,w;if(p){f=p.front?p.front:'';b=p.back?p.back"
+":'';d=p.delim?p.delim:'';w=p.wrap?p.wrap:'';}var str='';for(var x=0"
+";x<v.length;x++){if(typeof(v[x])=='object' )str+=s.join( v[x],p);el"
+"se str+=w+v[x]+w;if(x<v.length-1)str+=d;}return f+str+b;");

/* GetTimeParting Config (Daylight Saving dates) */
s._tpDST = {
2012:'3/25,10/28',
2013:'3/31,10/27',
2014:'3/30,10/26',
2015:'3/29,10/25',
2016:'3/27,10/30',
2017:'3/26,10/29',
2018:'3/25,10/28',
2019:'3/31,10/27',
2020:'3/29,10/25',
2021:'3/28,10/31',
2022:'3/27,10/30'}
/* Plugin: getTimeParting 3.4
 * (1.2.0.0 JH: Updated from version 3.2, beware also needs do_plugin code
 * update and configuration settings. both done in this version) */
s.getTimeParting=new Function("h","z",""
+"var s=this,od;od=new Date('1/1/2000');if(od.getDay()!=6||od.getMont"
+"h()!=0){return'Data Not Available';}else{var H,M,D,W,U,ds,de,tm,tt,"
+"da=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Sa"
+"turday'],d=new Date(),a=[];z=z?z:0;z=parseFloat(z);if(s._tpDST){var"
+" dso=s._tpDST[d.getFullYear()].split(/,/);ds=new Date(dso[0]+'/'+d."
+"getFullYear());de=new Date(dso[1]+'/'+d.getFullYear());if(h=='n'&&d"
+">ds&&d<de){z=z+1;}else if(h=='s'&&(d>de||d<ds)){z=z+1;}}d=d.getTime"
+"()+(d.getTimezoneOffset()*60000);d=new Date(d+(3600000*z));H=d.getH"
+"ours();M=d.getMinutes();M=(M<10)?'0'+M:M;D=d.getDay();U='AM';W='Wee"
+"kday';if(H>=12){U='PM';H=H-12;}if(H==0){H=12;}if(D==6||D==0){W='Wee"
+"kend';}D=da[D];tm=H+':'+M+U;tt=H+':'+((M>30)?'30':'00')+U;a=[tm,tt,"
+"D,W];return a;}");
},
function(a,b){
var s = ucaa;

/*
 * Partner Plugin: ADSERV Check 1.0 - Restrict ADSERV calls to once a visit, per report suite, per click
 * through. Used in conjunction with genesis_event_config table. Deduplicates SCM hits.
 */
s.partnerADSERVCheck=new Function("cfg",""
+"var s=this,c=cfg.visitCookie,src=cfg.clickThroughParam,scp=cfg.searchCenterParam,tv=cfg.tEvar,dl=',',cr,nc,q,g,gs,i,j,k,fnd,v=1,"
+"t=new Date,cn=0,ca=new Array,aa=new Array,cs=new Array;t.setTime(t.getTime()+1800000);cr=s.c_r(c);if(cr){v=0;}ca=s.split(cr,dl);"
+"if(s.un)aa=s.split(s.un,dl);else aa=s.split(s.account,dl);for(i=0;i<aa.length;i++){fnd = 0;for(j=0;j<ca.length;j++){if(aa[i] == ca[j]){fnd=1;}}if(!fnd){cs[cn]=aa[i];c"
+"n++;}}if(cs.length){for(k=0;k<cs.length;k++){nc=(nc?nc+dl:'')+cs[k];}cr=(cr?cr+dl:'')+nc;v=1;}if(s.wd)q=s.wd.location.search.toLowerCase("
+");else q=s.w.location.search.toLowerCase();q=s.repl(q,'?','&');g=q.indexOf('&'+src.toLowerCase()+'=');gs=(scp)?q.indexOf('&'+scp.toLowerCase()+'='):-1;if(g>-1){v=1;}else i"
+"f(gs>-1){v=0;s.vpr(tv,'SearchCenter Visitors');}if(!s.c_w(c,cr,t)){s.c_w(c,cr,0);}if(!s.c_r(c)){v=0;}return v>=1;");

/* ADSERV Configuration (from wizard) */
var adservConfig = {
    tEvar:              'eVar81', // Transfer variable, typically the "View Through" eVar.
    aID:                '122001', // Advertiser ID
    cID:                '744376', // Conversion Tag ID
    gID:                'EB_ACM:', // Genesis ID
    requestURL:         "http://bs.serving-sys.com/BurstingPipe/ActivityServer.bs?cn=as&vn=omn&activityID=[cID]&advID=[aID]&var=[VAR]&rnd=[RAND]", // the Sizmek request URL
    maxDelay:           "750", // The maximum time to wait for ADSERV servers to respond, in milliseconds.
    visitCookie:        "s_adserv", // The name of the visitor cookie to use to restrict ADSERV calls to once per visit.
    clickThroughParam:  "ucid", // A query string paramter that will force the ADSERV call to occur.
    searchCenterParam:  undefined, // SearchCenter identifier.
};

s.maxDelay = adservConfig.maxDelay;
s.loadModule("Integrate")
s.Integrate.onLoad=function(s,m) {
    var adservCheck = s.partnerADSERVCheck(adservConfig);
    if (adservCheck) {
        s.Integrate.add("Sizmek_ACM");
        s.Integrate.Sizmek_ACM.tEvar=adservConfig.tEvar;
        s.Integrate.Sizmek_ACM.aID=adservConfig.aID;
        s.Integrate.Sizmek_ACM.cID=adservConfig.cID;
        s.Integrate.Sizmek_ACM.gID=adservConfig.gID;
        s.Integrate.Sizmek_ACM.tVar=adservConfig.tEvar;
        s.Integrate.Sizmek_ACM.get(adservConfig.requestURL);

        s.Integrate.Sizmek_ACM.setVars=function(s,p){
            var
                at=p.lastImpTime,
                a1=p.lastImpSId,
                a2=p.lastImpPId,
                a3=p.lastImpId,
                bt=p.lastClkTime,
                b1=p.lastClkSId,
                b2=p.lastClkPId,
                b3=p.lastClkId;

            if(((at&&a1&&a2&&a3)||(bt&&b1&&b2&&b3))&&!p.errorCode)s[p.tVar]=adservConfig.gID+(at?at:0)+":"+(a1?a1:0)+":"+(a2?a2:0)+":"+(a3?a3:0)+":"+(bt?bt:0)+":"+(b1?b1:0)+":"+(b2?b2:0)+":"+(b3?b3:0)
        }
    }
}
},
function(a,b){
ucaa.contextData["channelmanagerBB_switch"]="set"  ;

ucaa.trackDownloadLinks=true
ucaa.trackInlineStats=true
ucaa.linkDownloadFileTypes='exe,zip,wav,mp3,mov,mpg,avi,wmv,pdf,doc,docx,xls,xlsx,ppt,pptx,rtf'

ucaa._rwdBreakpoints = {	
	'phone': [0, 480],
        'phone tablet': [481, 767],
	'tablet': [768, 1024],	
	'desktop': [1025, 9999]
};

ucaa._rwdUseContextData = true;
ucaa._rwdNamespace = "rwd";
ucaa._rwdRenderedExperienceChangeEvent = "None";
ucaa._rwdLandscapeToPortraitEvent = "None";
ucaa._rwdPortraitToLandscapeEvent = "None";
ucaa._rwdDimensionsEVars = "";
ucaa._rwdDimensionsProps = "";
ucaa.smartResizeAdded = false;
ucaa.usePlugins = true;
function ucaa_doPlugins(s)
{ //remove engagements on login
  if(s.pageName.indexOf("ebank:")==0 && s.pageName.indexOf("login")>0)
  {
    s.list2 = "";
    s.events = s.events.replace(/,?event2,?/gi,"").replace(/,?prodView,?/gi,"");
    s.server = "ebank";
    s.products = "";
  }
  if(s.linkType!="o")
  {
  //s.rwdSetupSmartresize();
  s.rwdSetupTrack();
  
  if(s.pageName)
  { s.eVar1=s.eVar2=s.eVar3=s.eVar4=s.eVar5="";
    var split = s.pageName.split(":");
   for(var i=1;i<6;i++)
  {
    var index = i-1;
    if(split[index])
      {
        s["eVar"+i]=split[index];
        if(index==1)
         s["eVar"+i]=split[index-1]+":"+s["eVar"+i];
        if(index==2)
         s["eVar"+i]=split[index-2]+":"+split[index-1]+":"+s["eVar"+i];
        if(index==3)
         s["eVar"+i]=split[index-3]+":"+split[index-2]+":"+split[index-1]+":"+s["eVar"+i];
        if(index==4)
         s["eVar"+i]=split[index-4]+":"+split[index-3]+":"+split[index-2]+":"+split[index-1]+":"+s["eVar"+i];
      }
  }
  for(var ind=1;ind<6;ind++)
  {
    if(!s["eVar"+ind])
	  s["eVar"+ind]=s.pageName;
  }
}
  /* External Campaign Tracking */
  if(!s.campaign)
  {
    s.campaign=s.eVar39=s.Util.getQueryParam('ucid');
    s.campaign=s.getValOnce(s.campaign,'s_campaign',0);
  }
  //Last content page
  if ((!s.eVar9) && s.pageName && (s.server!="shop" || s.pageName.match(/^shop\:privati\:conto\+corrente\:/i)) && !s.pageName.match(/^ucfin\:richiedi\:/i) && !s.pageName.match(/^uc\+bvi\:privati\:negozio\+online\:/i)) 
  s.eVar9=s.pageName; 
  //Previous page
  if(s.pageName)
  s.prop10=s.getPreviousValue(s.pageName,"s_pv10");
  //New Returning visitor
  s.eVar14 = s.getNewRepeat(365);
  //Time parting
  var tpA = s.getTimeParting('n','+1');
  s.eVar29=tpA[0] + '|' + tpA[2];
  //Download link handler
  if (s.linkType=="d")
        s.url=s.linkURL; 
  if(s.url){
       s.linkTrackVars="prop19,eVar19";
       s.linkTrackEvents="event10";
       s.prop19=s.eVar19=s.url.substring(s.url.lastIndexOf("/")+1,s.url.length);
       //s.prop7=getPage + ':' + s.prop19;
       if (s.linkTrackVars == 'None')
            s.linkTrackVars="events";
        else
            s.linkTrackVars=s.apl(s.linkTrackVars,"events",",",1);
        if (s.linkTrackEvents == 'None')
            s.linkTrackEvents="event10";
        else
            s.linkTrackEvents=s.apl(s.linkTrackEvents,"event10",",",1);
        s.events=s.apl(s.events,"event10",",",1);
    }
    
   //Live Streaming Download Event
    try{
      if (s.linkType=="d" && s.linkURL && typeof jQuery != "undefined") {
	var downloadPath = s.eVar19;
	var b_copy = jQuery.extend(true, b, {"js_page.stream_trigger_download": "true", "js_page.stream_download_path": downloadPath});
	setTimeout(function(){ 
	  utag.link(b_copy, null, [58]);
	}, 2000);
      }
    } catch(e){}  
    
  //channel manager
  var channel_manager = s.channelManagerBB();
  s.eVar37 = channel_manager.name; 
  if(!s.eVar35 && s.eVar37 && s.eVar37!="Direct" && s.eVar37!="Referring Domains" && s.eVar37!="Social Networks" && s.eVar37!="Natural Search")
    s.eVar35 = channel_manager.campaign;
  s.eVar39 = "D=v35"; //Campagna con scadenza a 30 giorni
  if(!s.eVar34 && s.eVar37 && (s.eVar37=="Direct" || s.eVar37=="Referring Domains"  || s.eVar37=="Paid Search" || s.eVar37=="Social Networks" || s.eVar37=="Natural Search"))
    s.eVar34 = channel_manager.referrer;
  if(!s.eVar36 && s.eVar37 && (s.eVar37=="Paid Search" || s.eVar37=="Natural Search"))
    s.eVar36 = channel_manager.searchKeyword;
  if(!s.eVar38)
    s.eVar38 = s.crossVisitParticipation(s.eVar37, 'channel_stack', '30', '7', '>');  
  //rwd layout
  if(s.contextData['rwd.renderedExp'] && s.contextData['rwd.screenFormat'] && s.contextData['rwd.screenSize'])
    s.eVar71 = s.contextData['rwd.renderedExp']+"|"+s.contextData['rwd.screenFormat']+"|"+s.contextData['rwd.screenSize'];
  
  
  //Copying visitor Marketing Cloud Id
  if(typeof s.visitor!="undefined")
  {
    s.eVar41 = s.visitor.getMarketingCloudVisitorID();
  }
  //Dynamic Copies
  if(!s.prop1 && s.eVar1) s.prop1="D=v1";
  if(!s.prop2 && s.eVar2) s.prop2="D=v2";
  if(!s.prop3 && s.eVar3) s.prop3="D=v3";
  if(!s.prop4 && s.eVar4) s.prop4="D=v4";
  if(!s.prop5 && s.eVar5) s.prop5="D=v5";
  if(!s.prop14 && s.eVar14) s.prop14="D=v14";
  if(!s.prop29 && s.eVar29) s.prop29="D=v29";
  if(!s.prop71 && s.eVar71) s.prop71="D=v71";  
  
  //validazione DL
  s.trackTroubles();
  }
}
ucaa.doPlugins = ucaa_doPlugins;
},
function(a,b){ try{ if(1){
if(b["cp.UTOKEN"])
{
  var uTsplit = b["cp.UTOKEN"].split("_");
  if(uTSplit.length==2)
  {
    b.ext_uTokenId=uTSplit[0];
    b.ext_uTokenProfile=uTSplit[1];
  }
}

} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(b['page_site'].toString().toLowerCase()=='ucpublic'.toLowerCase()){b['ext_pageSite']='ucps'} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){b['ext_adobeURL']='D=g'} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(b['ut.event'].toString().indexOf('view')>-1){b['ext_customPageViewEvent']='true'} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if((typeof b['ext_bannerIds']!='undefined'&&b['ext_bannerIds']!=''&&b['ut.event']=='view')){b['ext_engagementImpression']='true'} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if((b['page_pathUrl']=='/content/ucpublic/it/contatti-e-agenzie/locator'&&b['ut.event']=='view')){b['ext_branchFinderEvent']='true'} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(typeof b['engClick_intcid']!='undefined'&&b['engClick_intcid']!=''){b['ext_engClickTotal']=b['engClick_intcid']} } catch(e){ utag.DB(e) }  },
function(a,b,c,d){ try{ if((typeof b['ext_engClickTotal']!='undefined'&&b['ext_engClickTotal']==''&&b['trackType'].toString().toLowerCase().indexOf('action'.toLowerCase())>-1&&typeof b['engClick_cmCode']!='undefined'&&b['engClick_cmCode']!='')||(typeof b['ext_engClickTotal']=='undefined'&&b['trackType'].toString().toLowerCase().indexOf('action'.toLowerCase())>-1&&typeof b['engClick_cmCode']!='undefined'&&b['engClick_cmCode']!='')){c=[b['engClick_cmDeliveryMode'],b['engClick_cmCode'],b['engClick_hashPage'],b['engClick_space'],b['engClick_id'],b['engClick_type'],b['engClick_cmChannel'],b['engClick_prodCode'],b['engClick_intcid']];b['ext_engClickTotal']=c.join(':')} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if((typeof b['engClick_prodCode']!='undefined'&&b['engClick_prodCode']!=''&&typeof b['engClick_intcid']!='undefined'&&b['engClick_intcid']=='')){b['ext_prefixProdCodeEng']='INT-RR'} } catch(e){ utag.DB(e) }  },
function(a,b,c,d){ try{ if((typeof b['engClick_prodCode']!='undefined'&&b['engClick_prodCode']!=''&&b['engClick_type'].toString().toLowerCase()!='sliderAlt'.toLowerCase()&&b['engClick_type'].toString().toLowerCase()!='slider'.toLowerCase()&&b['engClick_type'].toString().toLowerCase()!='heroBanner'.toLowerCase()&&b['engClick_type'].toString().toLowerCase()!='lineStrip'.toLowerCase()&&b['engClick_type'].toString().toLowerCase()!='overlayBanner'.toLowerCase()&&typeof b['engClick_intcid']!='undefined'&&b['engClick_intcid']=='')){c=[b['ext_prefixProdCodeEng'],b['engClick_prodCode']];b['ext_engClickTotal']=c.join('-')} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if((typeof b['ext_engClickTotal']!='undefined'&&b['ext_engClickTotal']!=''&&!/^product/i.test(b['engClick_type']))){b['ext_engClickEvent']='true';b['link_name']='Click on engagement'} } catch(e){ utag.DB(e) }  },
function(a,b){
if (typeof ucaa!="undefined")
{
  //TECH_ENVIRONMENT
  if(!utag.data.tech_environment)
    ucaa.contextData.troubles["NOVAL:tech_environment"] = true;
  else if (utag.data.tech_environment && utag.data.tech_environment!="dev" && utag.data.tech_environment!="test" && utag.data.tech_environment!="staging" && utag.data.tech_environment!="prod")
    ucaa.contextData.troubles["ERRVAL:tech_environment="+utag.data.tech_environment] = true;
  //TECH_PLATFORM
  if(!utag.data.tech_platform)
    ucaa.contextData.troubles["NOVAL:tech_platform"] = true;
  else if (utag.data.tech_platform && utag.data.tech_platform!="cqaut" && utag.data.tech_platform!="cqpub" && utag.data.tech_platform!="portal")
    ucaa.contextData.troubles["ERRVAL:tech_platform="+utag.data.tech_platform] = true;
  //PAGE_SITE
  if(!utag.data.page_site)
    ucaa.contextData.troubles["NOVAL:page_site"] = true;
  else if (utag.data.page_site && utag.data.page_site!="ucpublic" && utag.data.page_site!="ebank")
    ucaa.contextData.troubles["ERRVAL:page_site="+utag.data.page_site] = true;
  //PAGE_PATHURL
  if(!utag.data.page_pathUrl)
    ucaa.contextData.troubles["NOVAL:page_pathUrl"] = true;
  else if (utag.data.page_pathUrl && utag.data.page_pathUrl.indexOf("/content/ucpublic/it/")<0)
    ucaa.contextData.troubles["ERRVAL:page_pathUrl="+utag.data.page_pathUrl] = true;
  //PAGE_NAME TOO LONG
  if(utag.data.ext_pageName && utag.data.ext_pageName.length>100)
    ucaa.contextData.troubles["pageName>100"] = true;
  //SEARCH TERMS
  if(utag.data.page_pathUrl.indexOf("search-results")>-1 && !utag.data.search_terms && !utag.data.search_resultCount)
    ucaa.contextData.troubles["SEARCH:0"] = true;
  if(utag.data.page_pathUrl.indexOf("search-results")>-1 && utag.data.search_resultCount===0)
  {  
    if (!utag.data.search_terms)
    {b.search_terms="nokeyword";}
    b.search_resultCount="noresults";
  }
  
  //AENGAGEMENT
  if(typeof utag.data.aEngagement!="undefined")
  {
    for(var k=0;k<utag.data.aEngagement.length;k++)
    {
    if(!utag.data.aEngagement[k].type)
      ucaa.contextData.troubles["ENG01:_"+k] = true;
    if(!utag.data.aEngagement[k].intcid && !utag.data.aEngagement[k].cmCode)
      ucaa.contextData.troubles["ENG02:_"+k] = true;
     else if(!utag.data.aEngagement[k].intcid && utag.data.aEngagement[k].cmCode)
     {
       if(!utag.data.aEngagement[k].hashPage)
	 ucaa.contextData.troubles["ENG04:hashPage_"+k] = true;
       if(!utag.data.aEngagement[k].space)
	 ucaa.contextData.troubles["ENG04:space_"+k] = true;
       if(!utag.data.aEngagement[k].spaceFirstItem)
	 ucaa.contextData.troubles["ENG04:spaceFirstItem_"+k] = true;
       if(!utag.data.aEngagement[k].spaceItemPosition)
	 ucaa.contextData.troubles["ENG04:spaceItemPosition_"+k] = true;
       if(!utag.data.aEngagement[k].id)
	 ucaa.contextData.troubles["ENG04:id_"+k] = true;
       if(!utag.data.aEngagement[k].cmDeliveryMode)
	 ucaa.contextData.troubles["ENG04:cmDeliveryMode_"+k] = true;
     }
    else if(utag.data.aEngagement[k].intcid && utag.data.aEngagement[k].cmCode)
      ucaa.contextData.troubles["ENG03:_"+k] = true;
  }
  }
  //APRODUCT SU PAGINE PRODOTTO
  if((utag.data.page_template=="recommendedpage" || utag.data.page_template=="productpage") && typeof utag.data.aProduct=="undefined")
    ucaa.contextData.troubles["ERRPROD:aProduct undefined"] = true;
  else if((utag.data.page_template=="recommendedpage" || utag.data.page_template=="productpage") && !utag.data.aProduct[0].code)
    ucaa.contextData.troubles["ERRPROD:code"] = true;
  else if((utag.data.page_template=="recommendedpage" || utag.data.page_template=="productpage") && !utag.data.aProduct[0].category)
    ucaa.contextData.troubles["ERRPROD:category"] = true;
  else if((utag.data.page_template=="recommendedpage" || utag.data.page_template=="productpage") && !utag.data.aProduct[0].name)
    ucaa.contextData.troubles["ERRPROD:name"] = true;
}
},
function(a,b){ try{ if((typeof b['search_terms']!='undefined'&&b['search_terms']!=''&&b['ut.event']=='view')){b['ext_searchEvent']='true'} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){
if ((b.trackType=="ASYNC-EVENT" || b.trackType=="async-event") && typeof b.asyncEvent.id!="undefined" && b.asyncEvent.id=="login")
  return false;
} } catch(e){ utag.DB(e) }  }];

  u.send=function(a,b,c,d,e,f,g,h,ev){
    if(u.ev[a]||typeof u.ev.all!="undefined"){
      utag.DB("send:3");
      u.data={a:{}};
      u.a=a;
      b.sc_events=b.sc_events||{};

      u.addEvent = function (v, n) {
        var t = [];
        if (v instanceof Array) {
          t = v.slice(0);
        } else if (typeof n !== "undefined") {
          t.push(v + "=" + n);
        } else {
          t.push(v);
        }
        for (var i = 0; i < t.length; i++) {
          b.sc_events[t[i]] = 1;
          u.pushlt(u.lte, t[i].indexOf("=") > -1 ? t[i].split('=')[0] : t[i].split(':')[0]);
        }
        return b.sc_events;
      };

      u.addProduct = function (v) {
        u.data.sc_addProd = "";
        if (v instanceof Array) {
          u.data.sc_addProd = v.join(',');
        } else {
          u.data.sc_addProd = v;
        }
      };

      if (u.a === "link") {
        u.ltflag = true;
        if (typeof b.linkTrackVars === "undefined") { u.ltv = []; }
        if (typeof b.linkTrackEvents === "undefined") { u.lte = []; }
      }

      u.data.tagdevicetype = "standard";       // Dynamically override using extensions

      for(c=0;c<u.extend.length;c++){try{d=u.extend[c](a,b);if(d==false)return}catch(e){if(typeof utag_err!='undefined'){utag_err.push({e:'extension error:'+e,s:utag.cfg.path+'utag.'+id+'.js',l:c,t:'ex'})}}};

      // Mobile lifecycle var
      if (u.data.tagdevicetype === "mobile") {
        if (b.timestamp || b.timestamp_unix) {
          u.o.timestamp = b.timestamp || b.timestamp_unix;
        }
        u.data.a = {
          "AppID" : b.app_id || "",
          "CarrierName" : b.carrier || "",
          "DeviceName" : b.device || "",
          "HourOfDay" : b.lifecycle_hourofday_local || "",
          "DayOfWeek" : b.lifecycle_dayofweek_local || "",
          "OSVersion" : b.os_version || b.platform_version || "",
          "Resolution" : b.device_resolution || ""
        }
        if (b.lifecycle_type) {
          u.data.a.disable_wake_track = false;
          u.data.a.disable_sleep_track = false;
          u.data.a.DaysSinceFirstUse = b.lifecycle_dayssincelaunch || "";
          u.data.a.DaysSinceLastUpgrade = b.lifecycle_dayssinceupdate || "";
          u.data.a.DaysSinceLastUse = b.lifecycle_dayssincelastwake || "";
          u.data.a.Launches = b.lifecycle_launchcount || "";
          u.data.a.InstallDate =  b.lifecycle_firstlaunchdate_MMDDYYYY || "";
          u.data.a.UpgradeEvent = b.lifecycle_isfirstlaunchupdate || "";
          u.data.a.PrevSessionLength = b.lifecycle_priorsecondsawake || "";
        }
        if (b.lifecycle_isfirstlaunch) {
          u.data.a.InstallEvent = "InstallEvent";
        }
        if (b.lifecycle_diddetectcrash) {										
          u.data.a.CrashEvent = "CrashEvent";
        }
        if (b.lifecycle_type === "launch") {
          u.data.a.LaunchEvent = "LaunchEvent";
        }
        if (b.lifecycle_isfirslaunchupdate) {
          u.data.a.UpgradeEvent = "UpgradeEvent";
        }
      }

      for (e in utag.loader.GV(u.map)) {
        if (u.data.tagdevicetype === "mobile") {
          if (typeof b[e] != "undefined" && typeof u.map[e] == "string" && u.map[e].indexOf("contextData.a.") > -1) {
            f = u.map[e].split(",");
            for (g = 0; g < f.length; g++) {
              if (f[g].indexOf("contextData.a.") === 0){
                u.data.a[f[g].substring(14)] = b[e];
              }
            }
          }
        } else if (typeof b[e] != "undefined" && typeof u.map[e] == "string" && u.map[e].indexOf("PRODUCTS_") > -1) {
          f = u.map[e].split(",");
          for (g = 0; g < f.length; g++) {
            if(f[g].indexOf("PRODUCTS_id") || f[g].indexOf("PRODUCTS_category") || f[g].indexOf("PRODUCTS_quantity") || f[g].indexOf("PRODUCTS_price")){
              u.data[f[g].substring(9)]=b[e];
            }
          }
        }
      }

      //Check for disabled lifecycles

      if(u.data.a.disable_wake_track === true || u.data.a.disable_wake_track === "true") {
        if (b.lifecycle_type === "wake") {
          return false;
        }
      }
      if(u.data.a.disable_sleep_track === true || u.data.a.disable_sleep_track === "true") {
        if (b.lifecycle_type === "sleep") {
          return false;
        }
      }

      u.data.id = u.data.id || (typeof b._cprod != "undefined" ? b._cprod.slice(0) : []);
      u.data.category = u.data.category || (typeof b._ccat != "undefined" ? b._ccat.slice(0) : []);
      u.data.quantity = u.data.quantity || (typeof b._cquan != "undefined" ? b._cquan.slice(0) : []);
      u.data.price = u.data.price || (typeof b._cprice != "undefined" ? b._cprice.slice(0) : []);
      if(typeof u.data.id!="undefined"&&u.data.id!=""){
        c=[];d={};ev={};for(e in utag.loader.GV(u.map)){if(typeof b[e]!="undefined"&&typeof u.map[e]=="string"&&u.map[e].indexOf("PRODUCTS_")>-1){f=u.map[e].split(",");for( g=0;g<f.length;g++){
          var pv = f[g].substring(9);
          if(f[g].indexOf("PRODUCTS_evar")==0 || f[g].indexOf("PRODUCTS_eVar")==0){
            if (b[e] instanceof Array) {
              b.sc_prodevars = b.sc_prodevars || [];
              for (var i = 0; i < b[e].length; i++) {
                var prodvars = {};
                if(typeof b.sc_prodevars[i]!="undefined" && b.sc_prodevars[i]!=""){
                  b.sc_prodevars[i][pv]=b[e][i];
                }else{
                  prodvars[pv]=b[e][i];
                  b.sc_prodevars.push(prodvars);
                }
              }
            }else{
              d[pv] = (b[e]+"").split(",");
            }
          }else if(f[g].indexOf("PRODUCTS_event")==0){
            if(b[e] instanceof Array){
              b.sc_prodevents=b.sc_prodevents || [];
              for (var i = 0; i < b[e].length; i++) {
                var prodevents = {};
                if(typeof b.sc_prodevents[i]!="undefined" && b.sc_prodevents[i]!=""){
                  b.sc_prodevents[i][pv]=b[e][i];
                }else{
                  prodevents[pv]=b[e][i];
                  b.sc_prodevents.push(prodevents);
                }
              }
              u.addEvent(pv);
            }else if (b[e] !== ""){
              ev[pv]=b[e];
              u.addEvent(pv);
            }
          }
        }}}
        e="";for(f in utag.loader.GV(d)){for(g=0;g<d[f].length;g++){if(e!="")e+="|"+f+"="+d[f][g];else e=f+"="+d[f][g];}}
        h="";for(f in utag.loader.GV(ev)){if(h)h+="|"+f+"="+((isNaN(ev[f]))?"1":ev[f]);else h=f+"="+((isNaN(ev[f]))?"1":ev[f]);}
        b.sc_prodevents=b.sc_prodevents||[];
        b.sc_prodevars=b.sc_prodevars || [];
        for(d=0;d<u.data.id.length;d++){
          var h2=h;
          var h3=e;
          if(typeof b.sc_prodevents!="undefined"){
            for (f in b.sc_prodevents[d]) {
              if(typeof b.sc_prodevents[d][f]!="undefined"){
                var l =b.sc_prodevents[d][f];
                if(typeof l!="undefined" && l!="" && isNaN(l)==false){
                  if (h2){
                    h2 += "|" + f + '=' + l;
                  }else{
                    h2 = f + '=' + l;
                  }
                }
              }
            }
          }
          if(typeof b.sc_prodevars!="undefined"){
            for (f in b.sc_prodevars[d]) {
              if(typeof b.sc_prodevars[d][f]!="undefined"){
                var l =b.sc_prodevars[d][f];
                if(typeof l!="undefined" && l!=""){
                  if (h3){
                    h3 += "|" + f + '=' + l;
                  }else{
                    h3 = f + '=' + l;
                  }
                }
              }
            }
          }
          c.push((u.data.category[d]?u.data.category[d]:"")+";"+u.data.id[d]+";"+(u.data.quantity[d]?u.data.quantity[d]:"")+";"+(u.data.price[d]?((u.data.quantity[d]?parseInt(u.data.quantity[d]):1)*parseFloat(u.data.price[d])).toFixed(2):"")+";"+h2+";"+h3);
        }
        if (typeof u.data.sc_addProd !== "undefined" && u.data.sc_addProd) {
          c.push(u.data.sc_addProd);
        }
        u.o.products=c.join(",");
      } else {
        u.o.products = "";
      }

      // Mapping would be b.event_name ==> "prod:event3,click:event4"
      // Data layer variable b.event_name will contain "prod,click" and trigger both event3,event4
      // To serialize, this would be "prod:12345,click"
      var evt=/^event|prodView|scOpen|scAdd|scRemove|scView|scCheckout|purchase$/;
      for(c in utag.loader.GV(b)){
        if(b[c] !== ""){
          f=(""+b[c]).split(","); 
          for(g=0;g<f.length;g++){
            h=f[g].split(":");
            d=[];
            if(typeof u.map[c+":"+h[0]]!="undefined"){
              d=u.map[c+":"+h[0]].split(",");
            }else if(typeof u.map[c]!="undefined"){
              d=u.map[c].split(",");
            }
            for(e=0;e<d.length;e++){if(d[e]!="events"&&evt.test(d[e])){
              u.addEvent(d[e]+(h.length>1?":"+h[1]:""));
            }}
          }
        }
      }

      //Placing mobile data in contextData
      for (var m in u.data.a) {
      	u.o.contextData["a."+m] = u.data.a[m];
        u.pushlt(u.ltv, "contextData.a." + m);
      }

      for(c in utag.loader.GV(b)){if(typeof u.map[c]!="undefined"){d=u.map[c].split(",");for(e=0;e<d.length;e++){
        // map to VALUE_event51 for events = "event51=60"
        if(d[e].indexOf("VALUE_")==0){
          u.addEvent( d[e].substring(6), b[c] );
        }else if(d[e]=="doneAction"){
          b.doneAction=b[c];
          if(b.doneAction!="navigate"){
            b.doneAction=eval(b[c]);
          }
        }else if(d[e].indexOf("c.") == 0 || d[e].indexOf("contextData.") == 0){
          d[e]=d[e].replace("contextData.", "c.");
          if (d[e][2] !== "a" && d[e][3] !== ".") {   // Exclude mobile vars
            u.o.contextData[d[e].substring(2)] = b[c];			
            u.pushlt(u.ltv,"contextData."+d[e].substring(2))		
          }
        } else {
          if(c=="sc_events" || c=="sc_prodevents" || c=="sc_prodevars"){
            utag.DB("Error:3: Mapping reserved object name " + c)
          }else{
            u.o[d[e]]=b[c];
          }
          // if linkTrackVars is mapped then turn off auto-generation of linkTrackVars
          if(d[e]=="s_account"){
            u.o.account=b[c];
          }else if(d[e]=="linkTrackVars"){
            u.ltflag=false;
          }else{
             u.pushlt(u.ltv,d[e]);
          }
        }
      }}}
      d=[];for(c in utag.loader.GV(b.sc_events)){if(b.sc_events[c])d.push(c)};
      if(d.length>0){
        u.o.events=d.join(",");
        u.pushlt(u.lte,u.o.events);
      } else {
        u.o.events = "";
      }

      if(b._ccurrency){
        u.o.currencyCode=b._ccurrency;
      }

      if(b._corder){
        u.pushlt(u.lte,"purchase");
        u.pushlt(u.ltv,"purchaseID");
        u.o.purchaseID=((u.o.purchaseID)?u.o.purchaseID:b._corder);
        u.o.events=((u.o.events)?u.o.events:"purchase");
        if(u.o.events.indexOf("purchase")<0){u.o.events+=",purchase"};
      }

      if(u.a=="view"){
        var img = u.o.t();
        /* still track on user agents Adobe cannot detect */
        if(typeof img!="undefined" && img!=""){
          u.img=new Image();u.img.src=img.substring(img.indexOf("src=")+5,img.indexOf("width=")-2);
        }
      }else if(u.a=="link"){
        if(typeof u.ltv!="undefined" && u.ltflag){
          if(u.o.events){u.ltv.push("events")};
          if(u.o.products){u.ltv.push("products")};
          b.linkTrackVars=u.ltv.join(',')
        }
        if(typeof u.lte!="undefined" && u.ltflag)b.linkTrackEvents=u.lte.join(',');
        u.o.linkTrackVars = (b.linkTrackVars)?b.linkTrackVars:"None";
        u.o.linkTrackEvents = (b.linkTrackEvents)?b.linkTrackEvents:"None";

        if(!u.o.linkType)u.o.linkType='o';
        if(b.link_name)b.link_text=b.link_name;
        b.link_text=(b.link_text)?b.link_text:"no link_name";
        if(b.link_type=='exit link'){u.o.linkType='e'}
        else if(b.link_type=='download link')u.o.linkType='d';

        u.o.tl(((b.link_obj)?b.link_obj:true),u.o.linkType,b.link_text,null,(b.doneAction?b.doneAction:null));
      }

      /* clear variables */
      if("yes"=="yes"){
        u.o.clearVars();
        u.o.contextData = {};
      }

      utag.DB("send:3:COMPLETE");
    }
  }
  try{utag.o[loader].loader.LOAD(id)}catch(e){utag.loader.LOAD(id)}
})('3','unicredit.uc.it');
}catch(e){
  console.log(e);
};
//end tealium universal tag
