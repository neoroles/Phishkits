// FUNCTION SET ARRAY WITH COMPONENT FOR CHECK CRM, PRODUCT PLACEHOLDER
var arrLoadableComponent = {};
var arrLoadableComponentEsita = {};
var checkLoggedVar=undefined;
var crmPrivacyAccepted="";
var resultCrm="";
var chiaveCRM=true;
/*$(document).ready(function(){
    $('.loadableComponent').each(function(){
        arrLoadableComponent[$(this).attr('id')]=false;
    });
    console.log(arrLoadableComponent);
});*/

// FUNCTION END AJAX LOAD COMPONENT FOR CHECK CRM, PRODUCT PLACEHOLDER
function successAjaxComponent(idComponent,checkAll,esitazione){
    if(checkAll===undefined){
		checkAll=false;
    }

	if(checkAll){
		console.log("Chiamata successAjaxComponent per mettere tutto a true");
		$('.loadableComponent').each(function(){
			arrLoadableComponent[$(this).attr('id')]=true;
		});
		if(typeof resultCrm=="object"){
			console.log("Start funzione replace crm chiamata da success loadableComponent");
			replaceCrmPlaceholder("");
		}else if(resultCrm=="err"){
			console.log("Start funzione errorCrmReplace al success di loadableComponent #"+idComponent+", non abbiamo un oggetto valido");
			errorCrmReplace("");
		}
	}else{
		arrLoadableComponent[idComponent]=true;
		arrLoadableComponentEsita[idComponent]=esitazione;
		console.log("Finita ajax per componente con id "+idComponent);
		console.log(arrLoadableComponent);
		if(typeof resultCrm=="object"){
			console.log("Start funzione replace crm chiamata da success loadableComponent");
			replaceCrmPlaceholder("#"+idComponent);
		}else if(resultCrm=="err"){
			console.log("Start funzione errorCrmReplace al success di loadableComponent #"+idComponent+", non abbiamo un oggetto valido");
			errorCrmReplace("#"+idComponent);
		}
	}
	
	// START REPLACE PRD FOR PRODUCTS IN LOADABLECOMPONENT
	if($( 'prd' ).length != $( 'prd[state]' ).length ) {
		if(parseInt(segmentCode) !== parseInt(segmentCode, 10)){segmentCode=3;}
		if(typeof productCode!="string"){productCode="";}
		console.log("Start funzione replace prodotti dalla successAjaxComponent con segmento: "+segmentCode+" prodotto: "+productCode);
		replaceProductPlaceholder(segmentCode,productCode);
	}
}


// FUNCTION CHECK TO START CRM, PRODUCT PLACEHOLDER
function startCrmProduct(){
	var checkProductStart=true;
	var checkCrmStart=true;
	var checkCrmProductFinish=true;
	var checkCallCrm=true;
	arrLoadableComponent = {};
	arrLoadableComponentEsita = {};
	checkLoggedVar=undefined;
	crmPrivacyAccepted="";
	$('.loadableComponent').each(function(){
		if(arrLoadableComponent[$(this).attr('id')]!=true){
			arrLoadableComponent[$(this).attr('id')]=false;
		}
    });
    console.log(arrLoadableComponent);
	var tempTimer=0;


	var timerStartReplaceCrmProduct = setInterval(function(){
		tempTimer++;

        if(checkLoggedVar=="" || typeof checkLoggedVar=="undefined"){
            if(typeof getProfileType=="function"){
            	checkLoggedVar=getProfileType();
       		}
        }
		if(crmPrivacyAccepted==""){
            if(typeof isCustomerPrivacyAccepted=="function"){
            	crmPrivacyAccepted=isCustomerPrivacyAccepted();
       		}
        }
		
		
		if(checkProductStart){
            if(parseInt(segmentCode) !== parseInt(segmentCode, 10)){segmentCode=3;}
			if(typeof productCode!="string"){productCode="";}
			checkProductStart=false;
			console.log("Start funzione replace prodotti al "+tempTimer+" check con segmento: "+segmentCode+" prodotto: "+productCode);
			replaceProductPlaceholder(segmentCode,productCode);
		}
		
		
		
		
		//START CRM
		if(checkCrmStart){
			if(checkCallCrm){
				if(crmPrivacyAccepted==true && checkLoggedVar=="L"){
					console.log("Letto il cookie e siamo loggati");
					if(isAuthor==false || typeof isAuthor=="undefined" ){
						checkCallCrm=false;
						callGetSigePlaceholder();
					}else if(isAuthor==true){
						checkCallCrm=false;
						callLoadNdgPlaceholder();
					}
				}else if(crmPrivacyAccepted==false || checkLoggedVar=="R" || checkLoggedVar=="N" || checkLoggedVar=="I"){
					checkCrmStart=false;
					console.log("CRM non parte perchè Privacy "+crmPrivacyAccepted+" e UTOKEN "+checkLoggedVar);
					resultCrm="err";
					errorCrmReplace("");
				}
			}else{
				if(resultCrm=="err"){
					checkCrmStart=false;
					if(isAuthor==true){
						showComponentsPlaceholderNotError();
					}else{
						errorCrmReplace("");
					}
				}else if(resultCrm==""){
					
				}else if(typeof resultCrm=="object"){
					checkCrmStart=false;
					console.log("Start funzione replace crm al "+tempTimer+" check");
					replaceCrmPlaceholder("");
				}
			}
		}
		if(!checkCrmStart && !checkProductStart && checkCrmProductFinish){
			checkCrmProductFinish=false;
			console.log("Fine ciclo default replace al check "+tempTimer);
		}
		if(tempTimer==25){
			console.log("Stop interval replace a 5 secondi");
			clearInterval(timerStartReplaceCrmProduct);
			console.log("Metto tutti i loadableComponent a true perchè sono passati 5 secondi");
			$('.loadableComponent').each(function(){
				arrLoadableComponent[$(this).attr('id')]=true;
			});
			if(typeof resultCrm=="object"){
				console.log("Start funzione replace crm dopo 5 secondi per eventuali loadableComponent che non hanno risposto");
				replaceCrmPlaceholder("");
            }else{
                console.log("Start funzione errorCrmReplace dopo 5 secondi, non abbiamo un oggetto valido");
				errorCrmReplace("");
            }

            //FIX matchHeight pagine prodotti
            if(typeof matchHeightPws== "function")
            {
                console.log("matchHeightPws OK");
                matchHeightPws();
            }
            else
            {
                console.log("matchHeightPws KO");
                $(".pws_card_category .pws_cards_list .item").matchHeight({property: 'min-height'});
                $(".pws_card_category .pws_cards_list .item .item_in").matchHeight();
            }

			if($(".spinnerable").length){
				console.log("Stop spinnerable raggiunti 5 secondi");
				$(".spinnerable").css("height", "").children().css("display", "block");
				endSpinner($(".spinnerable"));
			}
			// START REPLACE PRD FOR PRODUCTS IN LOADABLECOMPONENT NOT RESPONSE
			if($( 'prd' ).length != $( 'prd[state]' ).length ) {
				if(parseInt(segmentCode) !== parseInt(segmentCode, 10)){segmentCode=3;}
				if(typeof productCode!="string"){productCode="";}
				console.log("Start funzione replace prodotti dopo 5 secondi per residui, con segmento: "+segmentCode+" prodotto: "+productCode);
				replaceProductPlaceholder(segmentCode,productCode);
			}
		}
		
		
	},200);
}



function replaceProductPlaceholder(idSegmento,codProdotto){
	var arrCodProdotto=new Array();
	$('prd[state!="done"]').each(function(){
		if($(this).attr('prod')){
			if($.inArray($(this).attr('prod'), arrCodProdotto) == -1){arrCodProdotto.push($(this).attr('prod'));}
		}else{
			if($.inArray(codProdotto, arrCodProdotto) == -1){arrCodProdotto.push(codProdotto);}
			$(this).attr('prod',codProdotto);
		}
		$(this).attr('state','ready');
	});

	ajaxForLoop(0,arrCodProdotto,idSegmento);


}

var ajaxForLoop= function(valueArr,arrCodProdotto,idSegmento){
	if (arrCodProdotto.length == valueArr) {
		console.log("Terminato replace placeholder prodotti, trovati: "+valueArr);
		return;
	}
	try {
        if(arrCodProdotto[valueArr]!='' && idSegmento!=''){
            $.ajax
                ({
                type: 'GET',
                url: '/content/ucpublic/it/common/replaceplaceholder.'+arrCodProdotto[valueArr]+'.'+idSegmento+'.html',
                data: {},
                success:function(dataProd){
                if(dataProd!='false')
                    {console.log('/content/ucpublic/it/common/replaceplaceholder.'+arrCodProdotto[valueArr]+'.'+idSegmento+'.html');
                     
                        try {
                            var tempArrDataProd;
                            var arrDataProd = $.parseJSON(dataProd);
                            $('prd[prod="'+arrCodProdotto[valueArr]+'"][state!="done"]').each(function(){
                                var tempValue='';
                                for(var kk in arrDataProd["values"]){
                                    if($(this).attr('attr')==arrDataProd["values"][kk]["attributeName"]){
                                        if(arrDataProd["values"][kk]["startDate"]=="" && arrDataProd["values"][kk]["endDate"]==""){
                                            tempValue=arrDataProd["values"][kk]["value"];
                                            break;
                                        }else if(todayBetweenTwoDate(arrDataProd["values"][kk]["startDate"],arrDataProd["values"][kk]["endDate"])){
                                            tempValue=arrDataProd["values"][kk]["value"];
                                        }
                                    }
                                }
                                if(tempValue==''){tempValue='<span style="display:none;">Placeholder product error no match: [attr:'+$(this).attr('attr')+' prod:'+arrCodProdotto[valueArr]+']</span>';}
                                $(this).html(tempValue);
								$(this).attr('state','done');
                            });
                        }catch(err) {
                            console.log(err.message);
                        }
                    }
                },
                error:function(){},
                complete: function() {
                    ajaxForLoop(++valueArr,arrCodProdotto,idSegmento);
                }});
        }else{
            console.log("Chiamata servizio Prodotti placeholder non effettuata causa CodProdotto : "+arrCodProdotto[valueArr]+" IdSegmento: "+idSegmento);
        }

	}catch(err) {
		console.log(err.message);
	}
};


// CHECK TODAY BETWEEN TWO DATE
function todayBetweenTwoDate(prdStartDate,prdEndDate){
	try{
		var today = new Date();
		var dateFrom = prdStartDate;
		var dateTo = prdEndDate;
		var dateCheck = today.getDate()+"-"+(today.getMonth()+1)+"-"+today.getFullYear();

		var d1 = dateFrom.split("-");
		var d2 = dateTo.split("-");
		var c = dateCheck.split("-");
		
		var from = new Date(d1[2], parseInt(d1[1])-1, d1[0]);  // -1 because months are from 0 to 11
		var to   = new Date(d2[2], parseInt(d2[1])-1, d2[0]);
		var check = new Date(c[2], parseInt(c[1])-1, c[0]);
		
		return (check >= from && check <= to);
	
	}catch(err){
		
		console.log(err);
		
	}
}



function callGetSigePlaceholder(){
    if(chiaveCRM && ($("body").hasClass("bvi") || $("body").hasClass("pri_to_bvi") || $("body").hasClass("pri_to_pub"))){
        if(resultCrm==""){
            try {
                $.ajax
                ({
                type: 'POST',
                url: '/EP6-PSA-CE/getsigeplaceholder',
                data: {},
                success:function(dataCrm){
                if(dataCrm!='false')
                    {console.log("Risposta servizio getsigeplaceholder");
                        try {
                            var arrReplaceCrmPlaceholder = $.parseJSON(dataCrm);
                            resultCrm = arrReplaceCrmPlaceholder;
                            console.log("Risposta servizio getsigeplaceholder typeof "+typeof resultCrm);
                        }catch(err) {
                            console.log("CRM placeholder risposta da getsigeplaceholder non Json quindi mando in errore tutti i crm");
                            resultCrm = "err";						
                        }   
                    }
                },
                error:function(){
                    console.log("CRM placeholder errore chiamata getsigeplaceholder quindi mando in errore tutti i crm");
                    resultCrm = "err";
                }
                });
            }catch(err) {
                console.log(err.message);
                console.log("CRM placeholder ajax getsigeplaceholder nemmeno partita quindi mando in errore tutti i crm");
                resultCrm = "err";
            }
        }
    }else{
		console.log("CRM placeholder risultiamo L ma non siamo sul sito privato");
		resultCrm = "err";
    }
}

function callLoadNdgPlaceholder(){
	console.log("Prima della chiamata a loadNDG");
	try {
		$.getJSON('/bin/gimb/servlet/loadNdg?op=sessionInfo', function(arrReplaceCrmPlaceholder) {
			try {
				resultCrm=arrReplaceCrmPlaceholder;
				console.log("Risposta servizio loadNdg typeof "+typeof resultCrm);
			}catch(err) {
				console.log("CRM placeholder risposta da loadNdg non Json quindi mando in errore tutti i crm");
				resultCrm = "err";
			} 
		});
	}catch(err) {
		console.log("CRM placeholder ajax loadNdg nemmeno partita quindi mando in errore tutti i crm");
		resultCrm = "err";
	}
}









// REPLACE CRM PLACEHOLDER
function replaceCrmPlaceholder(idLoadable){
	try {
		$(idLoadable+' crm[state!="done"]').each(function(){
			if($(this).attr('data') in resultCrm){
				if(resultCrm[$(this).attr('data')]!=""){
					console.log("CRM Sostituisco "+$(this).attr('data'));
					$(this).html(resultCrm[$(this).attr('data')]);
					$(this).attr('state','done');
				}else{
					console.log("CRM Mando in errore "+$(this).attr('data')+" perchè la corrispondenza nel json è vuota");
					$(this).html('<span style="display:none;">Placeholder crm error value empty: [data:'+$(this).attr('data')+']</span>');
					$(this).closest(".collapsePlaceholder").addClass('errorReplace');
					$(this).attr('state','done');
				}
			}else{
				if(isAuthor==true){
					console.log("CRM isAuthor è "+isAuthor+" Sostituisco "+$(this).attr('data')+" con non trovato");
					$(this).html($(this).attr('data'));
					$(this).attr('state','done');
				}else{
					console.log("CRM Mando in errore "+$(this).attr('data')+" perchè la corrispondenza non è stata trovata");
					$(this).html('<span style="display:none;">Placeholder crm error no match: [data:'+$(this).attr('data')+']</span>');
					$(this).closest(".collapsePlaceholder").addClass('errorReplace');
					$(this).attr('state','done');
				}
			}
		});
		showComponentsPlaceholderNotError();
		
	}catch(err) {
		console.log("Mando in errore tutti CRM perchè Funzione replace CRM "+err.message);
		errorCrmReplace("");
	}
 }

function errorCrmReplace(idLoadable){
	console.log("Mando in errore tutti i crm");
	$(idLoadable+' crm[state!="done"]').each(function(){
		$(this).html('<span style="display:none;">Placeholder crm error no match: [data:'+$(this).attr('data')+']</span>');
		$(this).closest(".collapsePlaceholder").addClass('errorReplace');
		$(this).attr('state','done');
	});
	if(crmPrivacyAccepted!=true || checkLoggedVar!="L"){
		$(".loadableComponent").each(function(){
			$(this).find(".multiprofile:not(.anonymous)").append('<div class="errorReplace collapsePlaceholder forcedErrorNotLOggedOrPivacy"></div>');
		});
	}
	showComponentsPlaceholderNotError();
}

function showComponentsPlaceholderNotError(){
	if(checkLoggedVar=="L" && chiaveCRM && ($("body").hasClass("bvi") || $("body").hasClass("pri_to_bvi") || $("body").hasClass("pri_to_pub"))){
		//Se siamo loggati ma la privacy è false non deve nemmeno aspettare i success, mando in errore tutti i multiprofile non anonymous
		if(crmPrivacyAccepted==false){
			$('.loadableComponent').each(function(){
				arrLoadableComponent[$(this).attr('id')]=true;
			});
		}
		$(".loadableComponent[state!='done']").each(function(){
			//FIX SITO PRIVATO SE NON AVVISA SUCCESS DEL MULTIPROFILE MA SONO VISIBILI GIà ERRORI CRM FORZO LA SUCCESS
			if($("#"+$(this).attr("id")+" .multiprofile:not(.anonymous)").find(".errorReplace").length>0){
				arrLoadableComponent[$(this).attr('id')]=true;
			}
			if(arrLoadableComponent[$(this).attr('id')]==true){
				var idLoadableComponent=$(this).attr("id");
				
				//FIX PER TUTTE LE CARTE
				if($("#"+idLoadableComponent).find(".cardLoggedNotExist").length){$("#"+idLoadableComponent).find(".cardLoggedNotExist").addClass("errorReplace collapsePlaceholder");}
				
				//CHECK ERRORI CRM DENTRO MULTIPROFILE E DENTRO MULTIPROFILE ANONYMOUS
				if($("#"+idLoadableComponent+" .multiprofile:not(.anonymous)").find(".errorReplace").length>0){
					$("#"+idLoadableComponent+" .multiprofile:not(.anonymous)").find(".errorReplace").each(function(){
						var tempDataCrm="";
						$(this).find("crm").each(function(){tempDataCrm+=$(this).attr('data')+", ";});
						$("#"+idLoadableComponent+" .multiprofile:not(.anonymous)").after('<span style="display:none;">Placeholder crm error no match: [data:'+tempDataCrm+']</span>');
					});
					$("#"+idLoadableComponent+" .multiprofile:not(.anonymous)").remove();
					if($("#"+idLoadableComponent+" .multiprofile.anonymous").find(".errorReplace").length==0){
						$("#"+idLoadableComponent+" .multiprofile.anonymous").css("display","block").find(".collapsePlaceholder:not(.errorReplace)").css("display","block");
					}else{
						$("#"+idLoadableComponent+" .multiprofile.anonymous").remove();
					}
				}else if($("#"+idLoadableComponent+" .multiprofile.anonymous").find(".errorReplace").length>0){
					$("#"+idLoadableComponent+" .multiprofile:not(.anonymous)").css("display","block").find(".collapsePlaceholder:not(.errorReplace)").css("display","block");
					$("#"+idLoadableComponent+" .multiprofile.anonymous").find(".errorReplace").each(function(){
						var tempDataCrm="";
						$(this).find("crm").each(function(){tempDataCrm+=$(this).attr('data')+", ";});
						$("#"+idLoadableComponent+" .multiprofile.anonymous").after('<span style="display:none;">Placeholder crm error no match: [data:'+tempDataCrm+']</span>');
					});
					$("#"+idLoadableComponent+" .multiprofile.anonymous").remove();
				}else{
					$("#"+idLoadableComponent+" .multiprofile:not(.anonymous)").css("display","block").find(".collapsePlaceholder:not(.errorReplace)").css("display","block");
					if($("#"+idLoadableComponent+" .multiprofile.anonymous").length && $("#"+idLoadableComponent+" .multiprofile:not(.anonymous)").length){
						$("#"+idLoadableComponent+" .multiprofile.anonymous").remove();
					}
				}
				$(this).attr("state","done");
				endSpinner($("#"+idLoadableComponent));
			}
		});
	}
	// FIX SPINNER PRODOTTI
	var tempCheckGo=true;
	$.each(arrLoadableComponent, function(index, value) {
		if(!value){tempCheckGo=false;}
	});
	if(tempCheckGo){
		if($(".spinnerable").length){console.log("Stop spinnerable per loadableComponent tutti true");$(".spinnerable").css("height", "").children().css("display", "block");endSpinner($(".spinnerable"));}
	}

    
	$(".collapsePlaceholder:not(.errorReplace)").each(function(){
		//DIV SHOW
		if(($(this).parent(".loadableComponent").length==0 && !$(this).hasClass("loadableComponent")) || ($(this).hasClass("loadableComponent") && arrLoadableComponent[$(this).attr('id')]==true && $(this).attr("id")!="cq-campaign-modal")){
			$(this).css("display","block");
			//ESITAZIONE VIEW
			if($(this).hasClass("loadableComponent") && arrLoadableComponent[$(this).attr('id')]==true){
				if(typeof esitazioniPWS=="object"){
					if(typeof arrLoadableComponentEsita[$(this).attr('id')]=="object") {
						esitazioniPWS.esita(arrLoadableComponentEsita[$(this).attr('id')].position, arrLoadableComponentEsita[$(this).attr('id')].ceId, arrLoadableComponentEsita[$(this).attr('id')].campaignId, 'VIEW', arrLoadableComponentEsita[$(this).attr('id')].ceType, '', '');
						console.log("Esitazione di " + $(this).attr('id'));
						console.log(arrLoadableComponentEsita[$(this).attr('id')]);
						arrLoadableComponentEsita[$(this).attr('id')]=true;
					}
				}

			}
		}
		//MODALE SHOW
		if($(this).hasClass("loadableComponent") && arrLoadableComponent[$(this).attr('id')]==true && $(this).attr("id")=="cq-campaign-modal" && $(this).find("#modal-campaign-inject").html()!="" && $(this).attr("open")!="open"){
			$(this).modal('show');
			$(this).attr("open","open");
			
			//ESITAZIONE VIEW
			if(typeof esitazioniPWS=="object"){
				if(typeof arrLoadableComponentEsita[$(this).attr('id')]=="object") {
					esitazioniPWS.esita(arrLoadableComponentEsita[$(this).attr('id')].position, arrLoadableComponentEsita[$(this).attr('id')].ceId, arrLoadableComponentEsita[$(this).attr('id')].campaignId, 'VIEW', arrLoadableComponentEsita[$(this).attr('id')].ceType, '', '');
					console.log("Esitazione di " + $(this).attr('id'));
					console.log(arrLoadableComponentEsita[$(this).attr('id')]);
					arrLoadableComponentEsita[$(this).attr('id')]=true;
				}
			}
		}
	});
	
	//FIX prefooter overlay
	if(typeof actionPreFooter== "function"){actionPreFooter();}
	
	//FIX matchHeight pagine prodotti
	if(typeof matchHeightPws== "function")
    {
        console.log("matchHeightPws OK");
        matchHeightPws();
    }
    else
    {
        console.log("matchHeightPws KO");
		$(".pws_card_category .pws_cards_list .item").matchHeight({property: 'min-height'});
		$(".pws_card_category .pws_cards_list .item .item_in").matchHeight();
    }
	if(typeof textOverflow== "function"){textOverflow();}
	if(typeof equalizeEachLine== "function"){equalizeEachLine();}
}

function checkLogged(){
	checkLoggedVar="call";
	$.ajax({
   					url: "/bin/gimb/servlet/loadNdg?op=profile",
    				success: function(result){
    					checkLoggedVar = result;
						if(getCookie("CEPvcWs")=="Y"){crmPrivacyAccepted=true;}
    				},
    				error: function(){
    					checkLoggedVar = 'N';
    				}
    		}
    	);
}


if(location.href.indexOf("bvi-light")>=0 && ($("body").hasClass("bvi") || $("body").hasClass("pri_to_pub") || $("body").hasClass("pri_to_bvi"))){startCrmProduct();}
