/* inject last-edit 21-10-2016 - ee34086  */
var SinglePageNav = (function(pageRoot, IdElementToInject, isPrivate){
	//mappa degli url per il check degli url corretti
	//NON USATA AL MOMENTO
	var pageMap = {
		'test':{url: 'prova.html' }
	};

	var _fragmentStart = "<!--FRG_INJECT_START-->";
	var _fragmentStop = "<!--FRG_INJECT_END-->";

	var pageRoot = pageRoot || '';
	pageRoot = pageRoot.replace(/.*?:\/\//g, '');

	var divIdToInject = IdElementToInject || 'injectedContent';

	//this check assigns false if the variabile is undefined
	var isPrivate = isPrivate || false;

	function _debugMessage(message){
		//try catch per evitare problemi con ie8
		try{
			console.log(message);
		}catch(err){
		}
	}
	function _getPageBody(content) {
		var x = content.indexOf("<body");
		if(x<0){
			return content;
		}
		x = content.indexOf(">", x);
		var y = content.lastIndexOf("</body>");
		if(y < x){
			content="";
			throw "Errore di rendering nella pagina, controllare la response - manca </body>"
		}
		content = content.substring(x + 1, y);
		content = _getPageFragment(content);
		return content;
	}

	function _getPageFragment(content) {

		var x = content.indexOf(_fragmentStart);
		if(x<0){
			return content;
		}
		x = content.indexOf(">", x);
		var y = content.lastIndexOf(_fragmentStop);
		if(y < x){
			content="";
			throw "Errore di rendering nella pagina, controllare la response - manca "+_fragmentStop;
		}
		content = content.substring(x + 1, y);
		return content;
	}

	function _getValidatedPageUrl(pageId){
		return pageId;
		//TODO da implementare logica per controllo url:
//			var pageObject = pageMap[pageId];
//			if(!pageObject ){
//				_debugMessage("url non presente, niente inject");
//				return false;
//			}
//			return pageObject.url;
	}
	function _goToPage(pageId, mode, noscroll_flg, 	// aggiunto flag per boccare scroll a inizio pagina (usato nelle faq) 15/06/2016 ee38938
					   concurrent 	// aggiunto flag consentire inject multiplo (usato nel tutorial 1� accesso) 13/07/2016 ee38938
	){
		var pageUrl = _getValidatedPageUrl(pageId);
		if(!pageUrl){
			return false;
		}
		if(mode!='modal'){
			_removeModal();
		}
		_injectData(pageUrl, divIdToInject, mode, concurrent);
		if ( !noscroll_flg ) // blocca scroll a inizio pagina (usato nelle faq) 15/06/2016 ee38938
			window.scrollTo(0, 0);
	}
	var request = null;
	function _pageInject(pageUrl, data, concurrent){

		_changePortalRootPath();

		/*
		 * inserts an empty object if 'data' variable is not defined
		 * 'data' variable must be used always as an object
		 * 'data' variable is dynamically translated to query string by
		 * jQuery.ajax() method
		 */
		var parameterContainer = data ||{};
		parameterContainer ['inject']='1';


		if(pageUrl.substring(0,1)!=='/'){
			pageUrl = '/'+pageUrl;
		}

		var pageUrlToGet = '';

		if(pageUrl.indexOf('/ucpublic/login/login')>=0){
			pageUrlToGet = '/wps/portal/retail/it/login/login/';
        }else if(pageUrl.indexOf('/login/pinrecovery')>=0){
        	pageUrlToGet = '/wps/portal/retail/it/login/pinrecovery/';
        }else{ 
			pageUrlToGet = (pageUrl.indexOf('/wps/wcm')==0?'':pageRoot)+pageUrl; // non usa root se trattasi di inject di wcm (per faq) 15/06/2016 ee38938
		}


		console.log('inject url:' +pageUrlToGet);

		var req = $.ajax({
			url: pageUrlToGet,
			data: parameterContainer,
			dataType: 'html',
			type: 'GET',
			cache: false,
            flg_concurrent: concurrent // flag per verifica se inject concorrente - 29/07/2016 ee38938
		});
		req.pageUrl = pageUrlToGet; // aggiunge url alla richiesta (solo a titolo informativo) 13/07/2016 ee38938
		req.concurrent = concurrent; //aggiunto per gestione concorrente inject - ee34086 - 21-10-2016
		return req;
	}
	function _insertDataToDom(dataHtml, idElement, mode){
		if(typeof idElement == 'undefined'){
			idElement = IdElementToInject;
		}
		if(mode == 'modal' && $().modal){
			_modalToDom(dataHtml);
			return;
		}

		if(mode == 'prewelcome' && $().modal){
			_prewelcomeModalToDom(dataHtml);
			return;
		}

		//default dom injection:
		$('#'+idElement).html(dataHtml);
	}

	function _removeModal(){
		var idModal = 'gimbModalWindow';
		var $modal = $({});
		var modalContainer = document.getElementById(idModal);

		if(modalContainer){
			$modal = $(modalContainer);
			$modal.modal('hide');
			$('.modal-backdrop').remove();
		}

	}


	function _modalToDom(dataHtml){
		var idModal = 'gimbModalWindow';
		var modalHtml = "";
		var modalContainer = document.getElementById(idModal);
		var $modal = $({});
		var $body = $('body');

		if(modalContainer){
			$modal = $(modalContainer);
//				$modal.modal('hide');
			$modal.remove();
			$('.modal-backdrop').remove();
		}
		modalHtml ='<div class="modal" id="'+idModal+'" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">'+
				'<div class="modal-dialog modal-login">'+
				'<a href="#" title="" class="logo-white"></a>'+
				'<a href="#" title="" class="ico-close" data-dismiss="modal" aria-label="Close"></a>'+

				'<div class="modal-content"><div class="modal-body">'+
//				'<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
				'<div id="modal-inner-body">'+
				dataHtml+
				'</div>'+
				'</div></div></div>'+
				'</div>';
		$body.append(modalHtml);
		$modal = $('#'+idModal);
		$modal.modal({show:true, keyboard:true, backdrop: 'static'});
		//this reset the inject when close the modal content
		$modal.off('hidden.bs.modal.inject');
		$modal.on('hidden.bs.modal.inject', function(){
			location.href="#modal-closed";
			$modal.remove();
		});
	}

	function _prewelcomeModalToDom(dataHtml){
		var idModal = 'gimbPrewelcomeModal';
		var modalHtml = "";
		var modalContainer = document.getElementById(idModal);
		var $modal = $({});
		var $body = $('body');

		if(modalContainer){
			$modal = $(modalContainer);
//				$modal.modal('hide');
			$modal.remove();
			$('.modal-backdrop').remove();
		}
		modalHtml ='<div class="modal" id="'+idModal+'" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">'+
				'<div class="modal-dialog modal-login">'+
//				'<a href="#" title="" class="logo-white"></a>'+
//				'<a href="#" title="" class="ico-close" data-dismiss="modal" aria-label="Close"></a>'+

				'<div class="modal-content"><div class="modal-body">'+
				'<button type="button" class="close" data-dismiss="modal" aria-label="Close">Chiudi</button>'+
				'<div id="modal-inner-body">'+
				dataHtml+
				'</div>'+
				'</div></div></div>'+
				'</div>';
		$body.append(modalHtml);
		$modal = $('#'+idModal);
		$modal.modal({show:true, keyboard:false, backdrop: 'static'});
		//this reset the inject when close the modal content
		$modal.off('hidden.bs.modal.inject');
		$modal.on('hidden.bs.modal.inject', function(){
//				location.href="#afterlogin";
			location.href="#";
			$modal.remove();
		});
		//add event listener on activate mobile app
//			$(document).on('mobileAppActivationUpdate',function(event){
//				location.href="#afterlogin";
//				$(document).off('mobileAppActivationUpdate');
//			});

	}

	// Gestione spinner e blocco click convulsivo 15/07/2016 ee38938
	function _manageSpinner(action,container,ismodal) {
		var iswelcom = (typeof spinnerComponent != 'object');
		switch (action) {
			case 'START':
				// verifica presenza spinner
				if ( $('.inject-spinner').length <= 0 ) {
					// aggiunge backplain per blocco click convulsivo della durata di due sec
					$('body').append('<div class="inject-lockclick"></div>');
					setTimeout(function(e){
						console.log('stop inject click-lock');
						$('.inject-lockclick').remove();
					},2000);
					console.log('add inject click-lock');
					$('.inject-lockclick').click(function (e) {
						e.stopImmediatePropagation();
					});
					// aggiunge spinner solo all'area della portlet con relativa gestione centratura in caso di scroll o resize
					//container.addClass('injectedContent-inject-spinner');
					container.append('<div class="inject-spinner-lockclick"></div>');
					$(ismodal||iswelcom?container:'#'+divIdToInject+' > .main_content:first').append('<div class="inject-spinner '+ (ismodal||iswelcom?'inject-spinner-fixed ':'inject-spinner-absolute ') + 'blue-spinner"></div>');
					if ( !ismodal && !iswelcom ) {
						$(document).ready(function(){
							$(window).scroll(function(){
								spinnerComponent.alignVertically(null,'footer.private',null,'.main_content .blue-spinner',0,610);
							});
							$(window).resize(function(){
								spinnerComponent.alignVertically(null,'footer.private',null,'.main_content .blue-spinner',0,610);
							});
						});
						spinnerComponent.alignVertically(null,'footer.private',null,'.main_content .blue-spinner',0,610);
					}

					$('.inject-spinner-lockclick').click(function (e) {
						e.stopImmediatePropagation();
					});
				}
				break;
			case 'STOP':
				// elimina backplain (con delay) per sbloccare click ed e chiudere spinner
				setTimeout(function(e){
					$('.inject-lockclick').remove();
					$('.inject-spinner-lockclick').remove();
					$('.inject-spinner').remove();
					container.removeClass('injectedContent-inject-spinner');
				},1000);
				break;
			case 'ABORT':
				// elimina backplain per sbloccare click ed e chiudere spinner
				$('.inject-lockclick').remove();
				$('.inject-spinner-lockclick').remove();
				$('.inject-spinner').remove();
				container.removeClass('injectedContent-inject-spinner');
				break;
		}
	}

	function _injectData(pageUrl, idElement, mode, concurrent){
		/* gestione prioritaria dell'ultimo inject (solo in caso di mancata indicazione esplicita per inject concorrenti)
		 abortendo quelli in corso  13/07/2016 ee38938 */
		if ( request != null && !concurrent && !request.concurrent ) {
			var url = request.pageUrl;
			request.abort();
			console.log('aborted url : '+ url + ' for new request');
		}
		var container, ismodal = false;
		request = _pageInject(pageUrl,undefined,concurrent);
		// verifica presenza di modale aperta sia bootstrap che primefaces 13/07/2016 ee38938
		if ( $('#gimbModalWindow:visible').length > 0 || $('.ui-dialog.ui-overlay-visible').length > 0 ) {
			container = $('.ui-dialog.ui-overlay-visible .modal-container, #gimbModalWindow .modal-body');
			ismodal = true;
		} else
			container = $('#'+divIdToInject);
		if ( !concurrent )
			_manageSpinner('START',container,ismodal); // avvia spinner

		request.done(function(dataHtml){
			_debugMessage('caricata pagina: '+pageUrl);

			try {
				dataHtml = _getPageBody(dataHtml);
				_insertDataToDom(dataHtml, idElement, mode);
			} catch (e) {
				console.log('****** insert dom crash: '+ e);
				console.log(e);
			}

			$(document).trigger('SinglePageNav.inject.done',pageUrl);
			if ( !this.flg_concurrent ) {
				_manageSpinner('STOP',container);
				request = null;
			}
		});

		request.fail(function( jqXHR, textStatus, errorThrown ) {
			console.log('errore pagina non caricata');
			console.log(textStatus);
			console.log(errorThrown);
			console.log(jqXHR);
			if ( !this.flg_concurrent ) {
				_manageSpinner('ABORT',container);
				request = null;
			}
		});
	}

	/*
	 * This method changes the 'myportal' string into the URL to 'portal'
	 * for avoiding to recall portal login for public pages
	 */
	function _changePortalRootPath(){
		if(!isPrivate){
			pageRoot = pageRoot.replace('myportal','portal');
		}
	}

	return {
		goTo: _goToPage,
		modalInject: function(url, 	noscroll_flg, 	// aggiunto flag per boccare scroll a inizio pagina (usato nelle faq) 15/06/2016 ee38938
							  concurrent 		// aggiunto flag consentire inject multiplo (usato nel tutorial 1� accesso) 13/07/2016 ee38938
		)
		{
			_goToPage(url, 'modal', noscroll_flg, concurrent);
		},
		prewelcomeInject: function(url){
			_goToPage(url, 'prewelcome');
		},
		injectData: _injectData,
		/* Esposizione metodo per gestione spinner per il page inject  18/07/2016 ee38938
		 * 	Parametri:
		 * 				action = START per avviare spinner.
		 * 						 STOP  per stoppare spinner con un dilay
		 * 						 ABORT per terminare immediatamente lo spinner
		 * 				container = oggetto jquery che rappresenta il container in aggiungere lo spinner
		 * 				ismodal   = true se lo spinner va visualizzato su una modale
		 */
		manageSpinner: _manageSpinner

	};

})(window.pageRoot, window.IdElementToInject, window.isPrivate);


function redirectToServlet(url){
	location.href=url;
}


/* Modal blur effect: */
//$(function(){
//	$(document).on('shown.bs.modal', '.modal.in', function(){
//		$('#center-content > section').addClass('blurred');
//		$('.sidebar').addClass('blurred');
//		$('header').addClass('blurred');
//	});
//	$(document).on('hide.bs.modal', '.modal.in', function(){
//		$('#center-content > section').removeClass('blurred');
//		$('.sidebar').removeClass('blurred');
//		$('header').removeClass('blurred');
//	});
//});

