//~~tv:20010.20140827
//~~tc: Tealium Custom Container

/*
  Tealium Custom Container Notes:
  - Add sending code between "Start Tag Sending Code" and "End Tag Sending Code".
  - Add JavaScript tag library code between "Start Tag Library Code" and "End Tag Library Code".
  - Add JavaScript code only, do not add HTML code in this file.
  - Remove any <script> and </script> tags from the code you place in this file.

  Loading external JavaScript files (Loader):
  - If you need to load an additional external JavaScript file, un-comment the singe-line JavaScript comments ("//") within the following Loader sections near the bottom of this file:
      - "Start Loader Function Call"
      - "End Loader Function Call"
      - "Start Loader Callback Function"
      - "End Loader Callback Function"
  - After un-commenting, insert the path to the external JavaScript file you want to load.
  - Finally, within the Loader callback function, insert the JavaScript code that should run after the external JavaScript file has loaded.
*/

/* Start Tag Library Code */
/* End Tag Library Code */

//tealium universal tag - utag.sender.custom_container ut4.0.201708300904, Copyright 2017 Tealium.com Inc. All Rights Reserved.
try {
  (function (id, loader) {
    var u = {};
    utag.o[loader].sender[id] = u;

    // Start Tealium loader 4.32
    // Please do not modify
    if (utag === undefined) { utag = {}; } if (utag.ut === undefined) { utag.ut = {}; } if (utag.ut.loader === undefined) { u.loader = function (o) { var a, b, c, l; a = document; if (o.type === "iframe") { b = a.createElement("iframe"); b.setAttribute("height", "1"); b.setAttribute("width", "1"); b.setAttribute("style", "display:none"); b.setAttribute("src", o.src); } else if (o.type === "img") { utag.DB("Attach img: " + o.src); b = new Image(); b.src = o.src; return; } else { b = a.createElement("script"); b.language = "javascript"; b.type = "text/javascript"; b.async = 1; b.charset = "utf-8"; b.src = o.src; } if (o.id) { b.id = o.id; } if (typeof o.cb === "function") { if (b.addEventListener) { b.addEventListener("load", function () { o.cb(); }, false); } else { b.onreadystatechange = function () { if (this.readyState === "complete" || this.readyState === "loaded") { this.onreadystatechange = null; o.cb(); } }; } } l = o.loc || "head"; c = a.getElementsByTagName(l)[0]; if (c) { utag.DB("Attach to " + l + ": " + o.src); if (l === "script") { c.parentNode.insertBefore(b, c); } else { c.appendChild(b); } } }; } else { u.loader = utag.ut.loader; }
    // End Tealium loader

    u.ev = {'view' : 1};

    u.initialized = false;

      u.map={};
  u.extend=[function(a,b){
var c_pagename = utag.data["js_page.s.pageName"] || utag.data["ext_pageName"];
var c_category = (typeof utag.data["flat_productCat"] != "undefined") ? utag.data["flat_productCat"] : "";
var c_code = (typeof utag.data["flat_productCode"] != "undefined") ? utag.data["flat_productCode"] : "";
var c_sitetype = (c_pagename.indexOf("ucm:")==0 || c_pagename.indexOf("mlanding:")==0) ? "m" : "d";
var c_product = "0";

//Start --> Device detection
var device = "desktop";
var ua=navigator.appVersion;
if(ua.match(/(iPad)/ig) != null){ device = "tablet"; }
else if(ua.match(/(iPhone)/ig) != null){ device = "mobile"; }
else if(ua.match(/(Android)/ig) != null){ if(ua.match(/(Mobile)/ig) != null){ device = "mobile";}else{device = "tablet";}}           
//End <-- Device detection

/*

1	CONTO (MY GENIUS)
4	MUTUI
5	FLEXIA *
6	CARTE (GENIUS CARD)
8	ASSICURAZIONI *
10	CESSIONE DEL QUINTO (presiti) *
11	PRESTITO

*/
if(new RegExp(/scoperto\+facile/gi).test(c_pagename) ||  c_code == "SCOPERTOFACILE" ) {
  c_product = "13";
}
else if(/conti|super\+genius|supergenius2|mygenius/g.test(c_pagename) || 
	c_category=="CONTI"){
  c_product = "1";
}
else if( (/carte/g.test(c_pagename) && /flexia/g.test(c_pagename)) ){
  c_product = "5";
}
else if(/assicurazioni/g.test(c_pagename) ){
  c_product = "8";
}
else if(/carte|geniuscard|genius\+card/g.test(c_pagename) || 
	c_category=="CARTE"){
  c_product = "6";
}
else if(/mutui/g.test(c_pagename) || 
	c_category=="MUTUI"){
  c_product = "4";
}
else if(/cessione\+del\+quinto|cessionedelquinto/g.test(c_pagename)){ //add flat_productCode
  c_product = "10";
}
else if(/prestiti:inprimopiano|creditexpress|prestito|credito\+su\+pegno/g.test(c_pagename) || 
	c_category=="PRESTITI"){
  c_product = "11";
}
else if(typeof utag.data["page_template"] != "undefined" && utag.data["page_template"].indexOf("homePage")>-1){
	c_product = "-1";	
}


if(c_product != "0"){

  
  //[SHOP] BASKET
    if(/:ins\+dati|:validazione$|metodo\+e\+validazione/g.test(c_pagename)){   
	  window.criteo_q = window.criteo_q || [];
	  window.criteo_q.push(
		{ event: "setAccount", account: 8686 },
		{ event: "setSiteType", type: c_sitetype },
		{ event: "viewSearch", nbrc: c_product, usdev: device },
		{ event: "viewBasket", item: [{ id: c_product, price: 1.00, quantity: 1 }]}		
	  );  
	
	//[SHOP] TYP      
	}else if(c_pagename.indexOf(":invio+dati")>-1 ){
		window.criteo_q = window.criteo_q || [];
		window.criteo_q.push(
		{ event: "setAccount", account: 8686 },
		{ event: "setSiteType", type: c_sitetype },	
		{ event: "setHashedEmail", email: "#MD5-hashed email address#" },
		{ event: "viewSearch", nbrc: c_product, usdev: device },		
		{ event: "trackTransaction" , id: utag.data["_corder"], new_customer: "1", item: [ { id: c_product, price: 1.00, quantity: 1 } ]}    
		);
		
	//[SHOP] LANDING	
	}else if(c_pagename.indexOf("landing")>-1 ){	
		window.criteo_q = window.criteo_q || [];
		window.criteo_q.push(  
				{ event: "setAccount", account: 8686 },
				{ event: "setSiteType", type: "d" },
				{ event: "viewHome"},
				{ event: "viewItem", item: c_product },
				{ event: "viewSearch", nbrp: c_product }
		);	
		
	 //[UC.IT] HOMEPAGE
     }else if(c_product == "-1"){
		 window.criteo_q = window.criteo_q || [];
		 window.criteo_q.push(
			{ event: "setAccount", account: 8686 },
			{ event: "setSiteType", type: c_sitetype },
		    { event: "viewHome" } );
			
	 //[UC.IT] PRODUCT
     }else if(c_category.length>0){
		 window.criteo_q = window.criteo_q || [];
		 window.criteo_q.push(
			{ event: "setAccount", account: 8686 },
			{ event: "setSiteType", type: c_sitetype },
			{ event: "viewSearch", nbrc: c_product },
		    { event: "viewItem", item: c_product });
	 }
	 
}
}];


    u.send = function(a, b) {
      if (u.ev[a] || u.ev.all !== undefined) {
        //##UTENABLEDEBUG##utag.DB("send:##UTID##");

        var c, d, e, f, i;

        u.data = {
          /* Initialize default tag parameter values here */
          /* Examples: */
          /* "account_id" : "1234567" */
          /* "base_url" : "//insert.your.javascript.library.url.here.js" */
          /* A value mapped to "account_id" or "base_url" in TiQ will replace these default values. */
        };


        /* Start Tag-Scoped Extensions Code */
        /* Please Do Not Edit This Section */
        for(c=0;c<u.extend.length;c++){try{d=u.extend[c](a,b);if(d==false)return}catch(e){if(typeof utag_err!='undefined'){utag_err.push({e:'extension error:'+e,s:utag.cfg.path+'utag.'+id+'.js',l:c,t:'ex'})}}};
        /* End Tag-Scoped Extensions Code */


        /* Start Mapping Code */
        for (d in utag.loader.GV(u.map)) {
          if (b[d] !== undefined && b[d] !== "") {
            e = u.map[d].split(",");
            for (f = 0; f < e.length; f++) {
              u.data[e[f]] = b[d];
            }
          }
        }
        /* End Mapping Code */


        /* Start Tag Sending Code */

          // Insert your tag sending code here.

        /* End Tag Sending Code */


        /* Start Loader Callback Function */
        /* Un-comment the single-line JavaScript comments ("//") to use this Loader callback function. */

        //u.loader_cb = function () {
          //u.initialized = true;
          /* Start Loader Callback Tag Sending Code */

            // Insert your post-Loader tag sending code here.

          /* End Loader Callback Tag Sending Code */
        //};

        /* End Loader Callback Function */


        /* Start Loader Function Call */
        /* Un-comment the single-line JavaScript comments ("//") to use Loader. */
	if (!u.initialized) {  
	  u.loader({"type" : "script", "src" : "//static.criteo.net/js/ld/ld.js", "cb" : u.loader_cb, "loc" : "script", "id" : 'utag_30' });
	} else {
	  u.loader_cb();
	}
          //if (!u.initialized) {
            //u.loader({"type" : "iframe", "src" : u.data.base_url + c.join(u.data.qsp_delim), "cb" : u.loader_cb, "loc" : "body", "id" : 'utag_30' });
            //u.loader({"type" : "script", "src" : u.data.base_url, "cb" : u.loader_cb, "loc" : "script", "id" : 'utag_30' });
          //} else {
            //u.loader_cb();
          //}

          //u.loader({"type" : "img", "src" : u.data.base_url + c.join(u.data.qsp_delim) });

        /* End Loader Function Call */


        //##UTENABLEDEBUG##utag.DB("send:##UTID##:COMPLETE");
      }
    };
    utag.o[loader].loader.LOAD(id);
  })("30", "unicredit.uc.it");
} catch (error) {
  utag.DB(error);
}
//end tealium universal tag

