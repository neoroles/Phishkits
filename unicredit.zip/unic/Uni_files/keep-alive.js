/*
 * keep-alive.js
 * version: 1.1.0
 */

var keepAliveTimeout = 2000;	// will logout if too many refresh before timeout delta
var keepAliveEpsilon = 2500;	// bit bigger because must considerate reloading page should not logout

function Timestamps () {
    this.currentTime = new Date().getTime();
    this.lastSavedTime = localStorage.getItem('lastSavedTime');
    this.saveCurrentTime = function(){
    	localStorage.setItem('lastSavedTime', this.currentTime);
    };
    this.isDeltaInInterval = function(){
    	var delta = this.currentTime - this.lastSavedTime;
    	return ( delta > (keepAliveTimeout - keepAliveEpsilon) && delta < (keepAliveTimeout + keepAliveEpsilon));
    };
    this.hasTimedOut = function(){
    	var savedTimeNull = (this.lastSavedTime == null);
    	var deltaOutOfInterval = !this.isDeltaInInterval();
    	console.log("[KEEPALIVE] timeout " + savedTimeNull + " - " + deltaOutOfInterval);
    	return savedTimeNull || deltaOutOfInterval;
    };
}

setInterval(function(){
	var keepAliveTimestamps = new Timestamps();
	if(location.href.indexOf('/wps/myportal/retail') > 0){
		//BVI
		keepAliveTimestamps.saveCurrentTime();
	}
	/*else{
		// PWS
		if(keepAliveTimestamps.lastSavedTime != null) // Needed for recover dirty situation
		{
			if(keepAliveTimestamps.lastSavedTime == '' || keepAliveTimestamps.isDeltaInInterval())
				keepAliveTimestamps.saveCurrentTime();
		}
	}*/
}, keepAliveTimeout);

// closing in anyway but crashes, delete session
/*window.addEventListener("beforeunload", function (e) {
	if(localStorage.getItem('lastSavedTime') != null)
		localStorage.setItem('lastSavedTime', '');
});*/

/*----------------------------------------------------------------------------------*/