//~~tv:20010.20140827
//~~tc: Tealium Custom Container

/*
  Tealium Custom Container Notes:
  - Add sending code between "Start Tag Sending Code" and "End Tag Sending Code".
  - Add JavaScript tag library code between "Start Tag Library Code" and "End Tag Library Code".
  - Add JavaScript code only, do not add HTML code in this file.
  - Remove any <script> and </script> tags from the code you place in this file.

  Loading external JavaScript files (Loader):
  - If you need to load an additional external JavaScript file, un-comment the singe-line JavaScript comments ("//") within the following Loader sections near the bottom of this file:
      - "Start Loader Function Call"
      - "End Loader Function Call"
      - "Start Loader Callback Function"
      - "End Loader Callback Function"
  - After un-commenting, insert the path to the external JavaScript file you want to load.
  - Finally, within the Loader callback function, insert the JavaScript code that should run after the external JavaScript file has loaded.
*/

/* Start Tag Library Code */
/* End Tag Library Code */

//tealium universal tag - utag.sender.custom_container ut4.0.201708300904, Copyright 2017 Tealium.com Inc. All Rights Reserved.
try {
  (function (id, loader) {
    var u = {};
    utag.o[loader].sender[id] = u;

    // Start Tealium loader 4.32
    // Please do not modify
    if (utag === undefined) { utag = {}; } if (utag.ut === undefined) { utag.ut = {}; } if (utag.ut.loader === undefined) { u.loader = function (o) { var a, b, c, l; a = document; if (o.type === "iframe") { b = a.createElement("iframe"); b.setAttribute("height", "1"); b.setAttribute("width", "1"); b.setAttribute("style", "display:none"); b.setAttribute("src", o.src); } else if (o.type === "img") { utag.DB("Attach img: " + o.src); b = new Image(); b.src = o.src; return; } else { b = a.createElement("script"); b.language = "javascript"; b.type = "text/javascript"; b.async = 1; b.charset = "utf-8"; b.src = o.src; } if (o.id) { b.id = o.id; } if (typeof o.cb === "function") { if (b.addEventListener) { b.addEventListener("load", function () { o.cb(); }, false); } else { b.onreadystatechange = function () { if (this.readyState === "complete" || this.readyState === "loaded") { this.onreadystatechange = null; o.cb(); } }; } } l = o.loc || "head"; c = a.getElementsByTagName(l)[0]; if (c) { utag.DB("Attach to " + l + ": " + o.src); if (l === "script") { c.parentNode.insertBefore(b, c); } else { c.appendChild(b); } } }; } else { u.loader = utag.ut.loader; }
    // End Tealium loader

    u.ev = {'view' : 1};

    u.initialized = false;

      u.map={};
  u.extend=[];


    u.send = function(a, b) {
      if (u.ev[a] || u.ev.all !== undefined) {
        //##UTENABLEDEBUG##utag.DB("send:##UTID##");

        var c, d, e, f, i;

        u.data = {
          /* Initialize default tag parameter values here */
          /* Examples: */
          /* "account_id" : "1234567" */
          /* "base_url" : "//insert.your.javascript.library.url.here.js" */
          /* A value mapped to "account_id" or "base_url" in TiQ will replace these default values. */
        };


        /* Start Tag-Scoped Extensions Code */
        /* Please Do Not Edit This Section */
        
        /* End Tag-Scoped Extensions Code */


        /* Start Mapping Code */
        for (d in utag.loader.GV(u.map)) {
          if (b[d] !== undefined && b[d] !== "") {
            e = u.map[d].split(",");
            for (f = 0; f < e.length; f++) {
              u.data[e[f]] = b[d];
            }
          }
        }
        /* End Mapping Code */


        /* Start Tag Sending Code */

    if (typeof sessionStorage === "undefined") {
    (function(p) {
        var o = p;
        try {
            while (o !== o.top) {
                o = o.top
            }
        } catch (q) {}
        var t = (function(a, b) {
            return {
                decode: function(f, d) {
                    return this.encode(f, d)
                },
                encode: function(i, m) {
                    for (var g = i.length, k = m.length, h = [], j = [], l = 0, A = 0, d = 0, f = 0, z; l < 256;
                        ++l) {
                        j[l] = l
                    }
                    for (l = 0; l < 256;
                        ++l) {
                        A = (A + (z = j[l]) + i.charCodeAt(l % g)) % 256;
                        j[l] = j[A];
                        j[A] = z
                    }
                    for (A = 0; d < k;
                        ++d) {
                        l = d % 256;
                        A = (A + (z = j[l])) % 256;
                        g = j[l] = j[A];
                        j[A] = z;
                        h[f++] = a(m.charCodeAt(d) ^ j[(g + z) % 256])
                    }
                    return h.join("")
                },
                key: function(d) {
                    for (var f = 0, g = []; f < d;
                        ++f) {
                        g[f] = a(1 + ((b() * 255) << 0))
                    }
                    return g.join("")
                }
            }
        })(p.String.fromCharCode, p.Math.random);
        var w = (function(d) {
            function b(f, g, h) {
                this._i = (this._data = h || "").length;
                if (this._key = g) {
                    this._storage = f
                } else {
                    this._storage = {
                        _key: f || ""
                    };
                    this._key = "_key"
                }
            }
            b.prototype.c = String.fromCharCode(1);
            b.prototype._c = ".";
            b.prototype.clear = function() {
                this._storage[this._key] = this._data
            };
            b.prototype.del = function(g) {
                var f = this.get(g);
                if (f !== null) {
                    this._storage[this._key] = this._storage[this._key].replace(a.call(this, g, f), "")
                }
            };
            b.prototype.escape = d.escape;
            b.prototype.get = function(i) {
                var g = this._storage[this._key],
                    f = this.c,
                    j = g.indexOf(i = f.concat(this._c, this.escape(i), f, f), this._i),
                    h = null;
                if (-1 < j) {
                    j = g.indexOf(f, j + i.length - 1) + 1;
                    h = g.substring(j, j = g.indexOf(f, j));
                    h = this.unescape(g.substr(++j, h))
                }
                return h
            };
            b.prototype.key = function() {
                var g = this._storage[this._key],
                    f = this.c,
                    k = f + this._c,
                    j = this._i,
                    h = [],
                    i = 0,
                    l = 0;
                while (-1 < (j = g.indexOf(k, j))) {
                    h[l++] = this.unescape(g.substring(j += 2, i = g.indexOf(f, j)));
                    j = g.indexOf(f, i) + 2;
                    i = g.indexOf(f, j);
                    j = 1 + i + 1 * g.substring(j, i)
                }
                return h
            };
            b.prototype.set = function(g, f) {
                this.del(g);
                this._storage[this._key] += a.call(this, g, f)
            };
            b.prototype.unescape = d.unescape;

            function a(h, g) {
                var f = this.c;
                return f.concat(this._c, this.escape(h), f, f, (g = this.escape(g)).length, f, g)
            }
            return b
        })(p);
        if (Object.prototype.toString.call(p.opera) === "[object Opera]") {
            history.navigationMode = "compatible";
            w.prototype.escape = p.encodeURIComponent;
            w.prototype.unescape = p.decodeURIComponent
        }

        function n() {
            function a() {
                k.cookie = ["sessionStorage=" + p.encodeURIComponent(r = t.key(128))].join(";");
                s = t.encode(r, s);
                w = new w(o, "name", o.name)
            }
            var h = o.name,
                k = o.document,
                g = /\bsessionStorage\b=([^;]+)(;|$)/,
                d = g.exec(k.cookie),
                b;
            if (d) {
                r = p.decodeURIComponent(d[1]);
                s = t.encode(r, s);
                w = new w(o, "name");
                for (var j = w.key(), b = 0, f = j.length, i = {}; b < f;
                    ++b) {
                    if ((d = j[b]).indexOf(s) === 0) {
                        v.push(d);
                        i[d] = w.get(d);
                        w.del(d)
                    }
                }
                w = new w.constructor(o, "name", o.name);
                if (0 < (this.length = v.length)) {
                    for (b = 0, f = v.length, c = w.c, d = []; b < f;
                        ++b) {
                        d[b] = c.concat(w._c, w.escape(j = v[b]), c, c, (j = w.escape(i[j])).length, c, j)
                    }
                    o.name += d.join("")
                }
            } else {
                a();
                if (!g.exec(k.cookie)) {
                    v = null
                }
            }
        }
        n.prototype = {
            length: 0,
            key: function(a) {
                if (typeof a !== "number" || a < 0 || v.length <= a) {
                    throw "Invalid argument"
                }
                return v[a]
            },
            getItem: function(a) {
                a = s + a;
                if (u.call(e, a)) {
                    return e[a]
                }
                var b = w.get(a);
                if (b !== null) {
                    b = e[a] = t.decode(r, b)
                }
                return b
            },
            setItem: function(a, b) {
                this.removeItem(a);
                a = s + a;
                w.set(a, t.encode(r, e[a] = "" + b));
                this.length = v.push(a)
            },
            removeItem: function(a) {
                var b = w.get(a = s + a);
                if (b !== null) {
                    delete e[a];
                    w.del(a);
                    this.length = v.remove(a)
                }
            },
            clear: function() {
                w.clear();
                e = {};
                v.length = 0
            }
        };
        var s = o.document.domain,
            v = [],
            e = {},
            u = e.hasOwnProperty,
            r;
        v.remove = function(b) {
            var a = this.indexOf(b);
            if (-1 < a) {
                this.splice(a, 1)
            }
            return this.length
        };
        if (!v.indexOf) {
            v.indexOf = function(b) {
                for (var a = 0, d = this.length; a < d;
                    ++a) {
                    if (this[a] === b) {
                        return a
                    }
                }
                return -1
            }
        }
        if (o.sessionStorage) {
            n = function() {};
            n.prototype = o.sessionStorage
        }
        n = new n;
        if (v !== null) {
            p.sessionStorage = n
        }
    })(window)
}

window.sbs_setCharAt = function(d, a, b) {
    if (a > d.length) {
        return d
    }
    return d.substr(0, a - 1) + b + d.substr(a)
}

window.sbs_getSection = function(e, a) {
    sbsPage = {
        casa: "c",
        "hi-tech": "h",
        lifestyle: "l",
        wellness: "w",
        business: "b"
    };
    var d = e.split(a + "/")[1];
    var b = d;
    if (d.indexOf("/") > -1) {
        b = d.substring(0, d.indexOf("/"))
    }
    return sbsPage[b]
}

window.getCookieValueInPos = function(a, b) {
    c_start = a.lastIndexOf("uni_navigation_int=") + 1;
    c_value = a.substring(c_start, a.length);
    type = c_value.substring(b - 1, b);
    if (type.lenght == 0 || !type) {
        type = "N"
    }
    return type
}

window.writeNavCookie = function(e, g, a, f, b, d) {
    if (arguments.length == 6) {
        if (b <= 3) {
            g = sbs_setCharAt(g, b, "Y");// + "-" + getCookieValueInPos(g, 5)
        } else {
            if (g.length < 5) {
                g = g.substring(0, 3) + "-" + d
            } else {
                g = sbs_setCharAt(g, b, d)
            }
        }
    }
    document.cookie = e + "=" + g + a + f + "; path=/"
}

window.readCookie = function(b) {
    var a = document.cookie.match(b + "=(.*?)(;|$)");
    if (a) {
        return (a[1])
    } else {
        return null
    }
}

window.isMultiProdPage = function(a, b) {
    c_start = currentPage.lastIndexOf("/") + 1;
    c_end = currentPage.lastIndexOf(".html", a) + 5;
    c_value = currentPage.substring(c_start, c_end);
    res = jQuery.inArray(c_value, b);
    return res
}



window.setNavigationCookie = function() {
    prestitiPage = [];
    prestitiPage[0] = "prestiti.html";
    prestitiPage[1] = "trovailtuoprestito.html";
    prestitiPage[2] = "creditexpressmini.html";
    prestitiPage[3] = "creditexpresspremium.html";
    prestitiPage[4] = "creditexpresstop.html";
    prestitiPage[5] = "creditmaxicasa.html";
    prestitiPage[6] = "creditminicasa.html";
    prestitiPage[7] = "creditexpressenergia.html";
    prestitiPage[8] = "finanziamentofotovoltaico.html";
    prestitiPage[9] = "superquintomef.html";
    prestitiPage[10] = "superquintoinps.html";
    prestitiPage[11] = "creditosupegno.html";
    currentPage = window.location.href;
	var pp = "PRESTITI";
    var j = "/content/unicredit/it/info/subitobancastore";
    var d = "";
    var s = "";
    var y = "";
    var l = "";
	var publishMode = true;
    if (publishMode) {
        s = "; Secure";
        l = document.domain.split(".");
        if (l.length > 2) {
            y = l[l.length - 2] + "." + l[l.length - 1]
        } else {
            y = document.domain
        }
        d = "; domain=." + y
    }
    var i = sessionStorage.getItem("cookie");
    var f = "dynamic_int";
    var x = "compact_int";
    var g = "multiprod_int";
    var b = "uni_navigation_int";
    var e = readCookie(b);
    var k = "NNN-N";
    if (e == null) {
        writeNavCookie(b, k, s, d);
        e = readCookie(b)
    }
    var a = "CREXP-CEDYNAMIC"; 
    var y = "CREXP-CECOMPACT";
    if (typeof utag.data["flat_productCode"] != "undefined" && utag.data["flat_productCode"].indexOf(a) != -1) {

            writeNavCookie(b, e, s, d, 1, "Y");
            sessionStorage.setItem("cookie", f)

    } else {
        if (typeof utag.data["flat_productCode"] != "undefined" &&utag.data["flat_productCode"].indexOf(y) != -1) {

                writeNavCookie(b, e, s, d, 2, "Y");
                sessionStorage.setItem("cookie", x)

        } else {
            if ( ( typeof utag.data["flat_productCat"] != "undefined" && (utag.data["flat_productCat"].indexOf(pp) != -1) ) || window.location.pathname == "/it/privati/prestiti/tutti-i-prestiti.html") {
                writeNavCookie(b, e, s, d, 3, "Y");
                sessionStorage.setItem("cookie", g)
            }
        }
    }

};
setNavigationCookie();
        /* End Tag Sending Code */


        /* Start Loader Callback Function */
        /* Un-comment the single-line JavaScript comments ("//") to use this Loader callback function. */

        //u.loader_cb = function () {
          //u.initialized = true;
          /* Start Loader Callback Tag Sending Code */

            // Insert your post-Loader tag sending code here.

          /* End Loader Callback Tag Sending Code */
        //};

        /* End Loader Callback Function */


        /* Start Loader Function Call */
        /* Un-comment the single-line JavaScript comments ("//") to use Loader. */

          //if (!u.initialized) {
            //u.loader({"type" : "iframe", "src" : u.data.base_url + c.join(u.data.qsp_delim), "cb" : u.loader_cb, "loc" : "body", "id" : 'utag_23' });
            //u.loader({"type" : "script", "src" : u.data.base_url, "cb" : u.loader_cb, "loc" : "script", "id" : 'utag_23' });
          //} else {
            //u.loader_cb();
          //}

          //u.loader({"type" : "img", "src" : u.data.base_url + c.join(u.data.qsp_delim) });

        /* End Loader Function Call */


        //##UTENABLEDEBUG##utag.DB("send:##UTID##:COMPLETE");
      }
    };
    utag.o[loader].loader.LOAD(id);
  })("23", "unicredit.uc.it");
} catch (error) {
  utag.DB(error);
}
//end tealium universal tag

