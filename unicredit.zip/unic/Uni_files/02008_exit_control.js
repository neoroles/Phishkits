var confirmExit = 'Non hai completato l\'acquisto; sei sicuro di voler abbandonare questa pagina? Clicca "Annulla" e inserisci la password per completarlo, Clicca "OK" per uscire';

function isIE() {
  var myNav = navigator.userAgent.toLowerCase();
  return (myNav.indexOf('msie') != -1) ? parseInt(myNav.split('msie')[1]) : false;
}

$(document).ready(function(){
    $('a').on('mousedown', stopNavigate);
    $('a').on('mouseleave', startNavigate);
});

function stopNavigate(){    
	if (isIE() == 8 || isIE() == 7) {
		window.onbeforeunload = null;
	} else {
		$(window).off('beforeunload');
	}	
}

function startNavigate(){
	if (isIE() == 8 || isIE() == 7) {
		window.onbeforeunload = function(){
			  return confirmExit;
	   };
	} else {
		
		$(window).on('beforeunload', function(){
			  return confirmExit;
	   });
	}	
}

function startNavigate1(){
	if (isIE() == 8 || isIE() == 7) {
		window.onbeforeunload = function(){
			  return confirmExit;
	   };
	} else {
		$(window).on('beforeunload', function(){
			  return confirmExit;
	   });
	}	
}

function startNavigate2(){
	if (isIE() == 8 || isIE() == 7) {
		window.onbeforeunload = function(){
			  return confirmExit;
	   };
	} else {
		$(window).on('beforeunload', function(){
			  return confirmExit;
	   });
	}	
}

function startNavigate3(){
	if (isIE() == 8 || isIE() == 7) {
		window.onbeforeunload = function(){
			  return confirmExit;
	   };
	} else {
		$(window).on('beforeunload', function(){
			  return confirmExit;
	   });
	}	
}



