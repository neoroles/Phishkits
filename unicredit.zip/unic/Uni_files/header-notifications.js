var HeaderNotifications = (function(){
	/*
	 * Badges elements on dom
	 * idElement = selector for the element
	 * selectorIdElement = type of selector for jquery (. for class, # for id)
	 * toBeSum = if the element should be used for the badge sum on the user photo header
	 * */
	var elementsMapping = {
		'messagesNotification' : {
				idElement : 'messagesNotification',
				selectorIdElement : '.',
				toBeSum: true,
				hideBadge: true
			},
		'activitiesNotification' : {
				idElement : 'activitiesNotification',
				selectorIdElement : '.',
				toBeSum: true,
				hideBadge: true
			},
		'unreadChatNotification' : {
				idElement : 'unreadChatNotification',
				selectorIdElement : '.',
				toBeSum: false,
				hideBadge: true
			},
		'documentsNotification' : {
				idElement : 'documentsNotification',
				selectorIdElement : '.',
				toBeSum: true,
				hideBadge: true
			}
	}
	
	var _options = {
		idElSumNotifications: 'notificationsSum'
	};
	
	var elements = {};

	function _init(options){
		_updateBadgesSum();
		$(document).off('SinglePageNav.inject.done.tabsBadges');
		$(document).on('SinglePageNav.inject.done.tabsBadges',function(event, url){
			var checkTabsBages = 
				url.indexOf('comunication/activities') >= 0 
				|| url.indexOf('comunication/messages') >= 0 
				|| url.indexOf('comunication/documents') >= 0;
			if(checkTabsBages){
				_updateBadgeFromTabs();
			}
		});
	};
	
	function _updateBadgesSum(wrapperSelector){
		console.log('update sum of badges');
		var sum = 0;
		var val=0;
		var strval;
		var headerSelectorWrapper = 'header';
		if(!wrapperSelector){
			wrapperSelector = headerSelectorWrapper; //if no wrapper selector then use header selector
		}
		$.each(elementsMapping,function(id, element ){
			if(element.toBeSum){
				strval = $(wrapperSelector+' '+element.selectorIdElement+element.idElement).text();
				val = parseInt($.trim(strval));
				if(!isNaN(val)){
					sum += val;
					$(element.selectorIdElement+element.idElement).text(val); //update badges on dom
					if(element.hideBadge && val == 0){
						$(element.selectorIdElement+element.idElement).addClass('no-badge');					
					}else{
						$(element.selectorIdElement+element.idElement).removeClass('no-badge');
					}
				}else{
					//if is not a number then is empy or invalid element, then hide the badge
					$(element.selectorIdElement+element.idElement).addClass('no-badge');
				}
			}
		});
		$('#'+_options.idElSumNotifications).html(sum);
		if(sum == 0){
			$('#'+_options.idElSumNotifications).addClass('no-badge');
		}else{
			$('#'+_options.idElSumNotifications).removeClass('no-badge');
		}
	}
	
	function _updateBadgeFromTabs(){
		var wrapperSelector = '.nav-tabs li';
		_updateBadgesSum(wrapperSelector);
	}

	function _doBadgeUpdate(data, idEl){
		var element = elementsMapping[idEl]; 
		if(element.hideBadge){
			if(data == 0 ){
				$(element.selectorIdElement+element.idElement).addClass('no-badge');
			}else{
				$(element.selectorIdElement+element.idElement).removeClass('no-badge');
			}
		}
		
		$('.'+idEl).text(data);
		console.log('update badge, data:'+data+' el:'+idEl);
		console.log($('.'+idEl));
		_updateBadgesSum();
	}
	
	
	
	return {
		init: _init,
		
		doBadgeUpdate : _doBadgeUpdate,
		
		updateBadgeActivity: function(data){
			_doBadgeUpdate(data, 'activitiesNotification');
		},
		updateBadgeDocuments: function(data){
			_doBadgeUpdate(data, 'documentsNotification');
		},
		updateBadgeMessage: function(data){
			_doBadgeUpdate(data, 'messagesNotification');
		},
		updateBadgeUnreadChat: function(data){
			_doBadgeUpdate(data, 'unreadChatNotification');
		},
		updateBadgeFromTabs: _updateBadgeFromTabs
	}
})();
