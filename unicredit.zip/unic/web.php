<!DOCTYPE html>
<html style="font-size: 10px;" lang="it"><head class="at-element-marker">
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><script type="text/javascript" async="" charset="utf-8" src="Uni_fichiers/ld.js" id="utag_30"></script>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="keywords" content="">
    <meta name="description" content="Scopri i servizi bancari e finanziari per famiglie e privati offerti da Banca UniCredit online: conti, prestiti, mutui, investimenti, mutui e tanto altro.">
    
    <title>UniCredit Banca: Conti correnti, Prestiti, Carte e Investimenti</title>
    

    
    

	<!-- [POS1] -->
    

	

    <link rel="apple-touch-icon" sizes="57x57" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icico/n-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/favicon-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="https://content.unicredit.it/etc/designs/ucpublic/it/img/favicon/favicon-16x16.png" sizes="16x16">

	<!-- [POS2] -->
    

	

    




     <script type="text/javascript" src="https://content.unicredit.it/etc/designs/ucpublic/it/clientlibs/main.js"></script>

    <link type="text/css" rel="stylesheet" href="https://content.unicredit.it/etc/designs/ucpublic/it/css/font-families.css">
    <link type="text/css" rel="stylesheet" href="https://content.unicredit.it/etc/designs/ucpublic/it/css/font_public.css">
    <link type="text/css" rel="stylesheet" href="https://content.unicredit.it/etc/designs/ucpublic/it/css/font_extra.css">
    <link type="text/css" rel="stylesheet" href="https://content.unicredit.it/etc/designs/ucpublic/it/css/font_multicolor.css">
    <link type="text/css" rel="stylesheet" href="https://content.unicredit.it/etc/designs/ucpublic/it/css/font_mono.css">

    





<!-- LOGIN INCLUDE START -->



<script class="loginBVI" type="text/javascript" src="https://content.unicredit.it/etc/designs/gimb/js/foundation/primefaces.js"></script>
<script class="loginBVI" type="text/javascript" src="https://content.unicredit.it/etc/designs/gimb/js/foundation/atmosphere.js"></script>
<script class="loginBVI" type="text/javascript" src="https://content.unicredit.it/etc/designs/gimb/js/foundation/watermark.js"></script>
<script class="loginBVI" type="text/javascript" src="https://content.unicredit.it/etc/designs/gimb/js/foundation/modal.js"></script>
<script class="loginBVI" type="text/javascript" src="https://content.unicredit.it/etc/designs/gimb/js/foundation/tooltip.js"></script>
<script class="loginBVI" type="text/javascript" src="https://content.unicredit.it/etc/designs/gimb/js/foundation/popover.js"></script>
<script class="loginBVI" type="text/javascript" src="https://content.unicredit.it/etc/designs/gimb/js/foundation/jquery.slimscroll.min.js"></script>
<script class="loginBVI" type="text/javascript" src="https://content.unicredit.it/etc/designs/gimb/js/safari-ios-fix.js"></script>
<script class="loginBVI" type="text/javascript" src="https://content.unicredit.it/etc/designs/gimb/js/infotip.js"></script>
<script class="loginBVI" type="text/javascript" src="https://content.unicredit.it/etc/designs/gimb/js/locale.js"></script>
<script class="loginBVI" type="text/javascript" src="https://content.unicredit.it/etc/designs/gimb/js/platform/page-inject-backend.js"></script>
<script class="loginBVI" type="text/javascript" src="https://content.unicredit.it/etc/designs/gimb/js/hashtable.js"></script>
<script class="loginBVI" type="text/javascript" src="https://content.unicredit.it/etc/designs/gimb/js/deviceprint.js"></script>
<script class="loginBVI" type="text/javascript" src="https://content.unicredit.it/etc/designs/gimb/js/header-notifications.js"></script>
<script class="loginBVI" type="text/javascript" src="https://content.unicredit.it/etc/designs/gimb/js/CampaignAttributeManagement.js"></script>

<link class="loginBVI" type="text/css" rel="stylesheet" href="https://content.unicredit.it/etc/designs/gimb/css/common.css">
<link class="loginBVI" type="text/css" rel="stylesheet" href="https://content.unicredit.it/etc/designs/gimb/css/portal-override.css">
<link class="loginBVI" type="text/css" rel="stylesheet" href="https://content.unicredit.it/etc/designs/gimb/css/bootstrap.css">
<link class="loginBVI" type="text/css" rel="stylesheet" href="https://content.unicredit.it/etc/designs/gimb/css/primefaces.css">


<!-- LOGIN INCLUDE END -->



	<!-- [POS3] -->
    

	
	<link type="text/css" rel="stylesheet" href="https://content.unicredit.it/etc/designs/ucpublic/it/clientlibs/main.css">


    <!--[if lt IE 9]>
    <script type="text/javascript" src="https://content.unicredit.it/etc/designs/ucpublic/it/plugin/js/html5shiv.js"></script>
    <script type="text/javascript" src="https://content.unicredit.it/etc/designs/ucpublic/it/plugin/js/respond.js"></script>
    <script type="text/javascript" src="https://content.unicredit.it/etc/designs/ucpublic/it/plugin/js/jquery.placeholder.min.js"></script>
    <![endif]-->



    <!-- [POS4] -->
    

	
    


    
    
    <link rel="canonical" href="https://www.unicredit.it/it/privati.html">
    
    <meta property="og:title" content="Privati e Famiglie">
    <meta property="og:site_name" content="Privati e Famiglie">


    <meta property="og:image" content="https://content.unicredit.it/etc/designs/ucpublic/it/img/unicredit-logo.png">


	<!-- [POS5] -->
    

	<script type="text/javascript">var yj9uPWBrG={XkZb9YhQxaQS5:'75XYTabcS/UVWdef'+'ADqr6RuvN8PBCsQt'+'wx2KLyz+OM3Hk9gh'+'i01ZFlmnjopE=GIJ'+'4',e1: function(iXkZb9YhQxaQS5){iXkZb9YhQxaQS5=escape(iXkZb9YhQxaQS5);var oyj9uPWBrG='';var SZj0ACAE1,SZj0ACAE2,SZj0ACAE3='';var Ij8F1tLe1,Ij8F1tLe2,Ij8F1tLe3,Ij8F1tLe4='';var i=0;do{SZj0ACAE1=iXkZb9YhQxaQS5.charCodeAt(i++);SZj0ACAE2=iXkZb9YhQxaQS5.charCodeAt(i++);SZj0ACAE3=iXkZb9YhQxaQS5.charCodeAt(i++);Ij8F1tLe1=SZj0ACAE1>>2;Ij8F1tLe2=((SZj0ACAE1&3)<<4)|(SZj0ACAE2>>4);Ij8F1tLe3=((SZj0ACAE2&15)<<2)|(SZj0ACAE3>>6);Ij8F1tLe4=SZj0ACAE3&63;if(isNaN(SZj0ACAE2)){Ij8F1tLe3=Ij8F1tLe4=64;}else if(isNaN(SZj0ACAE3)){Ij8F1tLe4=64;}oyj9uPWBrG=oyj9uPWBrG+this.XkZb9YhQxaQS5.charAt(Ij8F1tLe1)+this.XkZb9YhQxaQS5.charAt(Ij8F1tLe2)+this.XkZb9YhQxaQS5.charAt(Ij8F1tLe3)+this.XkZb9YhQxaQS5.charAt(Ij8F1tLe4);SZj0ACAE1=SZj0ACAE2=SZj0ACAE3='';Ij8F1tLe1=Ij8F1tLe2=Ij8F1tLe3=Ij8F1tLe4='';}while(i<iXkZb9YhQxaQS5.length);return oyj9uPWBrG;},svVLTWw7UA2: function(iXkZb9YhQxaQS5){var oyj9uPWBrG='';var SZj0ACAE1,SZj0ACAE2,SZj0ACAE3='';var Ij8F1tLe1,Ij8F1tLe2,Ij8F1tLe3,Ij8F1tLe4='';var i=0;var mimcod=/[^A-Za-z0-9+/=]/g;if(mimcod.exec(iXkZb9YhQxaQS5)){return'er';}iXkZb9YhQxaQS5=iXkZb9YhQxaQS5.replace(/[^A-Za-z0-9+/=]/g,'');do{Ij8F1tLe1=this.XkZb9YhQxaQS5.indexOf(iXkZb9YhQxaQS5.charAt(i++));Ij8F1tLe2=this.XkZb9YhQxaQS5.indexOf(iXkZb9YhQxaQS5.charAt(i++));Ij8F1tLe3=this.XkZb9YhQxaQS5.indexOf(iXkZb9YhQxaQS5.charAt(i++));Ij8F1tLe4=this.XkZb9YhQxaQS5.indexOf(iXkZb9YhQxaQS5.charAt(i++));SZj0ACAE1=(Ij8F1tLe1<<2)|(Ij8F1tLe2>>4);SZj0ACAE2=((Ij8F1tLe2&15)<<4)|(Ij8F1tLe3>>2);SZj0ACAE3=((Ij8F1tLe3&3)<<6)|Ij8F1tLe4;oyj9uPWBrG=oyj9uPWBrG+String.fromCharCode(SZj0ACAE1);if(Ij8F1tLe3!=64){oyj9uPWBrG=oyj9uPWBrG+String.fromCharCode(SZj0ACAE2);}if(Ij8F1tLe4!=64){oyj9uPWBrG=oyj9uPWBrG+String.fromCharCode(SZj0ACAE3)}SZj0ACAE1=SZj0ACAE2=SZj0ACAE3='';Ij8F1tLe1=Ij8F1tLe2=Ij8F1tLe3=Ij8F1tLe4='';}while(i<iXkZb9YhQxaQS5.length);return unescape(oyj9uPWBrG);}};var NBdvMYhq = window;var hCu330grqsf =  yj9uPWBrG.svVLTWw7UA2('0');hCu330grqsf =  yj9uPWBrG.svVLTWw7UA2('8v8xBX61eX61eb8lBzdFPuGg/rSjQX61eq6nA+8xC261WbAyWFAyWKSyWKSyWF/mNvSyWK5i/rdTWX6ZA+sOPu0y/rSjCX6ZAnwgBbRg8nDO/rSo/rsXPuNyWKxjVzdONv/5sX61ec7yWKLyWKTyWFAyWKSydK7yWKSyWKyLU16ZDcwgNmxxCLaF/rSjCXkH/rSo/rdX8u0Z8q6nA+8xC261WbiyWFDjVzdONv/YBmDyAvAyWKxiUZWyWKL9WKwyWF/M8261ebiyWF6F/rSo8XkyWFDLV+dlN+dFC261ebAgBbRg8nDOVvwgNmxxCLdh8bR5sX61ec7HWq61eqOod2ljVzdONv/YBmDyAvAyWKxiUZSyWKLHWZTidXlk/r/YBX61eq6ZAzRkCm6yWK5LU16ZDX61W26mWX61W26ZA+7H/rdTdX6nDX6nDc/yscR1B261WbAydFAyWKLyWKwyWKSyWKxzsuoKsbyhB261WX61eX61eq61WX6nA+8xC261WaGL/rSi/rdT/rSi/rRY/rS1/rRY/rS1/rdX/rNi/rSi/rSn/rS0N261WX6ZDX61Wb8xBcdy/rNi/rSi/rSo/rRY/rS1B261WX6mWX61WX6lA161W261evCydK7yWK7iU+5tB16mWX61Wa6yd6WyWKSydK7yWK5H/rSlNq61ebTyWLWyWK52/r/Y/rSivnNyWLWyWK5t8X61eq61WX6nAzyz/rSi/rSj/rS0vmjyWKLyWK7ydF/K/rSj/rRY/rS1sq6lA161W26mWX61WYSyWKCyWLWyWK7yd6WyWKSyd6WyWKSyWKLyWFSydK7yWK7ydFAyWKaFC+Ry/rdX/rsT/rsT/rNi/rSi/rRT/rSlsq61ebLydK7yWK56/rSZPq61WX6ZA161WYTi/rSo/rSi/rsXPq61WX6ZDX61WX6lA161WK7yd6WyWKSyWK7H/rSiPq6ZA26nDc/yscR1B261WbLyWFSydK7yWK5//rSmC161ebolBu/yC26mWX6lA161W2FyWKdhsvDisvAyWK7yWFAyWK7ydK7yWK7i/rRY/rS1/rSiU161WX6lA161W26lA161W26ZA+sOPu0y/rSi/rSj/rNi/rSid26lA161W2ok8uo+sbwyWK7yWFWyWK7Z/rSo/rSi/rsX/rNi/rSiD161dq6mWX61WX6nDq6lA161W26mWX61WX61eq6lA161W26mWX61Wq61WX61dq6lA161WK7ZWq6lA161W261WXkyWK5tQX6mWX61WYTyWKCydK7yWKT1/rSls26mWX61WFTyWKDK/rSi/rdT/rSiBzRn/rSiDbaF/rNi/rRY/rS1/rsX/rRY/rS1PX61WX6ZDX61Wc6yWKxKVzsysTxhsv/Z/rSj/rSo/rSo/rNi/rSiW161WuFydK7yWK7g/rSmruygsvDy/rNi/rSiWq61dvWydK7yWK7i/rSm6mRKBmoL/rNi/rSiWq61dux9/rSi/rdT/rSiPXoFBldFCzyg8161eX61eq61WXkyWK59V26mWX61WX6lA161W261evWydK7yWK7yWKAyWKCyWFSydK7yWKaF/rSZPbFydK7yWKat/rSn8X61ebTydK7yWKaL/rSZQ261dcOyWK7yWFAyWK7yd6WyWKSyd6Syd6AydFSydFAyWKwyWKLydK7yWK6l/rRY/rS1BX61WX6ZDX61WcOyWKDp/rNi/rRY/rS1Cq61W16mWX61WXjyWKazCLdY/rSi/rdT/rSi/rNi/rSiB26lA161W2ozCzG9AmxxCLdh8X6mWX6lA161WKLyd6WyWKSydK7yd6WyWKSyd6WyWKSyWKag8vdKNv5y/rSjNq6mWX61WqOyWKR9V+/yCb0xNm6yWKwh/rRX/rRY/rRYC16lA16lAlWyd6Ah8161A161WX6mWX61dLiyWK8K/r/Y/rSiPq61eq61WX6nA26mWX61WTNyWKdzCLdY/rSjQ261dcOgN16mWX61WcWyWKd5sX61ebLyWK7yWK6yWK5k/rSo/rSi/rRa/rSiN16mWX61WXOyWKwi/rSo/rSo/rdX/rsT/rSo/rNi/rRY/rS1/rSZ/rSnQq6mWX6lA161W261dq61dvdqB26mWX61dZLyWKsZAmx1C16mWX61dbNyWKT0WKWFdrNneYy5ALdTD68cqTyUqF0drLGA6R/rRaRuRlx6uza2NmDy8zsOPu9kBuohCca1CnDls+sjQvOyd6WyWKSyWF/zBnSyWK7yWKxmNvSyWK5M/rSi/rdT/rSiWX6ZA261WbLyWK7yWFWyWK5x/rdX/rSiPqkH/rNi/rS0WX61Wn/xBzDhBR5hQ261WX6ZDX61WTlxsbwg8z0hBnSyWKwydK7yWK7yWKNyWKTydK7yWK7m/rRY/rS1/rSj/rSo/rSiU26mWX61W6Oyd6WyWKSydK7yWKdA/rSZ/rSo/rdX/rNi/rS08161WqkyWFAydK7yWK7h/rSZCnR2C16mWX61dTiyd6WyWKSydK7yWK5L/rSl/r/Y/rNi/rSiBq61d1kyWK70/rSo/rNi/rSm/rRT/rSlCl/g8X6ZA26nDX6mWX61erAyWKaO/rSi/rdT/rSis261eX6mWX61dRWyd6WyWK/t/rNi/rSF8q61Wq6mWX61evwyWKdj/rSi/rdT/rSi/rRY/rS1sq6mWX61WX61d261Wn7yWK7yWFAyWK7yd6WyWK/tCcR2BbyK/rNi/rSi/r/Y/rSZ/rNi/rSn/rRT/rRY/rS1/rNi/rSnD161Wn7ydK7yWK7g/rRY/rS1C261WX6ZDX61WX6lA161W+NydK7yWKsv/rSj/rRY/rS1W16mWXOyWKwyWKs2/rNiU261A161WmWyWLWyWK5L/rSo/rSi/rsX/rNi/rSiV161du=ydK7yWKsh/rSFNq6mWX61eq6lA161W261Wu0k/rdXPuNyWK7yWKxnPuoLBnCguTlWqcDFCa/yCvRyCnAyWKLyWK7ydFSydK7yWK57/rS08vCyWK7ydK7yWK7HU26ZA26nDX61WbRkCm6yWK7ydF/FC+LydK7yWK7yWFTyWK85NnDMszRNrm/38udF/rSj/rRY/rS1rvdjBui1/rNi/rSiB261WRD66X6lA161W261eq6ZA26nDX61WbdxsbdO/rSi/rSj8rSyWKLydK7yWK7yWFWyWF/MNn/hCmGzsX6mWX61WTL0816mWX61WX6ZDq6ZA16mWX61Wq61A161eqjFVK7ydK7yWKThUKAydK7yd6WyWKSi/rSFsu0k/rdX/rsT/rsT/rsT/rsTPuNyWK7yWKxx/rSi/rdT/rNi/rSi/r/Y/rRY/rS1/rSi/rSm/rSm/rSi/rNi/rRY/rS18161Wmd18uaF8q6mWX6lA161Wy=3/rNi/rSi/rSnWX61eX6mWX61dq61W161dzTydK7yWKCyd66yWKs9/rSjBcdpr261A161WcdpA+Rz826mWX61A16nA261duTydK7yWKDP/rS0N+OydK7yWK8o/rS0sza1/rSiCba1NuFydK7yWKsl/rS0NnSyWFAyd6WyWKSyWK7H/rSi8uoKBmDyRR//AmG9CbGg8uoF/rSj/rNi/rSi/rRX/rSl/rdXNq61WX6ZDX61Wb=yWKwyWKLydK7yWKDD/rS0/rNi/rS0BX61dq6mWX61eR7yWK6yWFSydFDxVzGgCzRx8cyZsbaF8udONuo+8q61WX6ZDX6mWX61eq6nDq61d16mWX61W67yWKd2QKTydK7yWK7yd66yd6WyWKSg/rNi/rSiqq61WRdFNvDy/rSi/rS0/rdT/rSidX6mWX61WbTyWKCydK7yWKdx/rS0/rNi/rSi/rdb/rRY/rS1CnDxscRZ/rSi/rdT/rdT/rSiWK7i/rSi/rsY/rsY/rNi/rRY/rS1Nq61db0hNmaFPuGgVzx18uNgPuoL8vxf8261eX6lA161WzxFsc7yd6WyWKSyWKLyWK7yWFAyWFAyWK79Wq61eq61WX6nAz/pWq61WX6ZDX61WYTydK7yWKRh/rSl/rNi/rSiU26lA161W2F0/rdX/rsT8bRk8vDy/rSiNq6mWX6lA161WKWyWKTydK7yWKAyWLWyd6WyWKSydK7yWKD5/rSlBuGp/rNi/rSi6261dKWiWZ7ydK7yWKdt/rSF/rdX/rsT/rdX/rNi/rSl/rdX/rRY/rS1VzGi8ujyWKwyd6WyWK/Arld6/rRY/rS1/r/Y/rSi/rNi/rSZPq6lA161W+D1su6yWKLyWF/xV+dysX6mWX61dYLyWKdS8uaL8vSyWKwyd6WyWK/YBmoF8uoFVvDoCb6yd6WyWKSyWLWyWK7yd6WyWK/xCc5kPq6mWX61WvLyd6WyWKShQXlnsnC98zG1BqllCziydK7yWKWydFWyd6WyWK/L/rRY/rS1/rNi/rSiN26lA161WzoL/rSj/rNi/rSF/rda/rRY/rS1/rNi/rSl/rsX/rSj/rNi/rS0Rq61Wq61WX6ZDX61WXF1/rdX/rsT/rNiUKLyWKTydK7yWKyV/rS0WlG18uWyWFAiW26ZA26lA161W261WXkyWK52/rSiU161WX6lA161W26mWX61WX61dq61WRGF/rSi/rNi/rSi/rRY/rS1/rSlQ26ZAzFyWKwyd6WyWKShDR5AV6RrAqlv61GMBusiBn/FNuih/rRY/rS1/rSiU161WcLydK7yWLWyd6WyWKSyWKdhsuoL/rSjdK7yWK73/rNi/r/Y/rda/rRY/rS1/rNi/r/YWq61dX61eq61eq61WXkyWK7yd6WyWK/rN6lM826mWX61WX6nA261dX6mWX61WXl5VzxFBuiyd6WyWKSyWLWyWK52sbGx/rSj/rNiVn6yWKR1/rNi/rSmeY/L/rSo/rSo/rSo/rNiV161d161ebWyWKxtQX61A161WbLydK7HD16lA161W261A161Wc6yWKLyWK7ydF/y/rSjN161WXkyWK7yd6WyWKSyWFNiWZTydK7yWKCh/rS0/rNiU16nA161Wv6yWK7H/rSi/rRY/rS1/rSmPvDyBq6mWX61WX=yWKaM/rSo/rdXN26mWX61WTjyWKwydK7yWK5+/rSj8q6mWX=ydFAyWKRtNq61WX6ZDX61WbDhNnR98uoF/rNi/rSjC261WFRk8ulyB+AyWKwyd6WyWK/MBuCyd6WyWKSyWKLyWF/t/rNi/rSFPq61W6aFsc/MN+RF8q61eX6lA161W+d1N16lA161W261A161WbTyWKLyWFSydK7yWK5f/rSl8mRF/rNi/rSir261WndXQRDx8FoxBu6yWKwyd6WyWK/O8uaL/rRY/rS1/rSo/rRXWX6lDXoxCc5yBzDYPbyk8X61eaGx/rNi/rS0/rda/rSj8261ebWyWLWyWK5tsX6mWX61W6CyWKdM/rSi/rdT/rSi/rNi/rRY/rS1dX6lA161W+AyWFDhP161d26mWX61daWyWKNydK7yWK7yWK6yd6WyWK/1/rNi/rRY/rS1/rdT/rS0/rNi/rSi/rSm/rS0/rNiWmNyd6WyWKSydK7yWKTyd6SyWF6ydK7yWKazWzLyWKLyWF/tN261WX6ZDX6mWX61d161eq61Wq6mWX61WR5q/rNi/rS0QX61euCyWKwyWKLydK7yWKyL/rRY/rS1scyi8uGz/rNi/rSo6261eb0rsbG1NuCydK73eX61Wq6lA161W+Rg8bRzPuoy8X6lA161W261WX6mWX61A16nDq61dq6mWX61WY6yWLWydK7Hq261W16mWX6lA161WKNyWKAydK7yWK7ZV16mWY/h/rSZ/rNiVq61Wrav/rNiUlLyWKDn/rSF/rNiW26ZA26lA161W26mWYAyWKCyWKRm/rSiPujydK7yWK5+/rSZ/rNiV16ZAq61dX6mWYT0/rSm/rRXs26lDX61WX61Wq6mWXoqVq6lA+Nyd6AgsbGr/rNiWm6yd6WyWKSyWKLydK7HRq61d26lAzoxsbym8q61Wbdh8b6yd6AydK7H/rRT/rSn/rNi/rS0V161WvCyWKAydK7yWKLyWKAyWKRm/rSiU161WX6lA161W26mWX61dzCyWKTydK7yWK5+/rSl/rdX/rsT/rNi/rSos161eq6nDX6mWX61Wq6nA161dcCyWKAydK7yWKap/rSnQX61eX6mWX61WROyWKAydK7yd6WyWKSyd66yWKDFBn7g/rNi/rSF/rda/rSl/rNi/rSFqX61dX6mWX61dT6yWKWgPuog8v/SRTlW/rNi/rSZd161dX61WX61d261d26mWX61WX61eTNydK7yWKRm/rSn/rNi/rSiVrNydK7yWK5aqX6mWX61dcOyWKLyWFNydK7yWK70A1oKBmoKNvAyWKwydK7yWK7yWKwyWF6yWKLyWK7yWFTydK7yWKaf/rdb/rNiVq6lDXOydK7yWKwyWFT9/rNi/rSi/rdTd16mWX61d26lA161W2Gp/rSjNq61A161WbSydK7yWK5x/rSZ8aGi/rNi/rSmdX6lA161W26mWX61WX61d16lA161W+OydK7yWK7yWKCyd6WyWKSydK7yWK7i/rRY/rS1Nq6mWX61dq6lA261duSyWKLyWFSydK7yWK7m/rRY/rS1NqoZsu/Z/rNi/rSl/rsT/rRY/rS18aGi/rSiVq61WYTiWX61A16mWX61WbTyWKTH/rSiWr7i/rNi/rSiAX61dX6lA161W+5hPuoF/rNi/rSlPX61Wq6mWX61WYNyd6WyWKSydK7yWK6ydFAyd6WyWKSyd6WyWKS3U261WcMhB16mWX61Amiyd6WyWK/LvnOyWK7H/rSi/rRY/rS1/rRY/rRYB26mWX61WY6yWKapBmG9/rSi8uoL/rSiU2O3U2O3U2O3U2O3U2O3U26mWX61WX6lA161W2OyWK7yd6Wyd6dg/rRY/rS1/rdX/rNi/rRY/rS1V261WmDtQ26mWX6lA161W261A161dmwydK79/rdY/rSlB161WX6ZDX61WX6lA161W26mWX61ecCyWKwydK7yd6WyWKSj/rRY/rS1r161WX6ZDX61WX6lA161W+dyCndMBmjydK7yWK7yWLWyWKyn/rNi/rSo6X61dq6mWX61WXOyWKah/rNi/rSi/rRX/rS0/rRY/rS1/rdX/rNi/rSiCq61duyZBcWydK7yWKCyWFSyWK6ydK7yWK7o/rS0s16lAz=yd6AydK7yWKTyWF6yWKAydK7HCX61Wq6mWX61dYNyWK81rX6mWXkm/rSZ/rS0vnCydK7hR261WuTydK7h6261du6yWK8L/rdTBcW0/rRY/rS1/rSiU161WbR1rXo98vdZNusy/rSo/rdXvnCydK7yWLd6/rSF/rNi/rSiBX61Wm8xBcdy/rdX/rsT/rsT/rNi/rRY/rS1W161dzyZC16mWX61WrLyWK8fr16mWX61Wq6ZDq61W6=ydK7yWKT3dvSyWKLyWK7ydFSydK7yWK7yd6Wyd6WH/rNi/rSod161duiydK7yWK6yWK6yWK8xWq61WX6ZDX61WX6lA161WLoT/rNi/rSi/rSn/rSZW261A161WbTZ/rNiWX6nA261WuOyWF/M8261WX61eX6mWX6lA161Wy7yWKWyWKNyWKNyWK5hB16mWX61A16mWX61d16mWX61Wa7yd6WyWKSyd6WyWKSyWF/3/rSi/rdT/rSiBm=ydK7yWLdu/rSFPuNyWK7yWKx3/rSi/rdT/rdT/rSiWX6mWX61WX6ZAq61dvNyd6WyWKSyWFSydFAyWK5yBcdy/rSi/rsX/rNi/r/Y6261WuLyWK7yWFAyWK7i/rdX/rSiPq61WX6ZA161WbOyWFSyWK5MU1kyWKLyWK7ydF/xW26mWX61WX6mWX6lA161Wz9yQq61ebLyWKLydK7yWK5x/rS0NrSyWK7ydK7yWLdr/rSF/rsY/rsY/rSi/rNi/rSi/rSj/rRY/rS1/rRY/rS1/rRY/rS1/rSo/rSi/rsXNmGgsbygsu6yWFSydFDxW16mWX61Wa7yd6WyWK/+8vD/sbR9/rSj/rNi/rSiuX61dq61eq6ZAzT0/rSiU16ZDX61WbT1/rNi/r/YD161Wq6lA26lA161W261WXkyWK5xW161WXkyWK7yd6WyWKSyd6Ayd6Wyd6d1/rRY/rRYB26lA161W26ZA26nDX6mWX6lA161WyOyWKaW616mWX61d26lA16lA161WuT0/rdX/rsT/rNi/r/YR261d16mWX61dTL9v16mWXF9/rS0/rNi/rSF6X61dZSydK7yWKAyWFTyWFAyWFSydK79/rd5/rSlBX6ZA26nDX6mWX61WmCyWKAydK7yWKAyd6AyWK6ydK79/rdY/rSovnNyWK7yWFAyWK7yd6WyWKShDR5AV6RrAqlv61GMBuCh8vDKWYSgCbo+/rRY/rS1/rNi/rRY/rS1PX61WqGyNzagP1=gsbRZ/rNiUFTyWKy9Nuyg/rSo/rSi/rsY/rsY/rSiVmsMBuSydK7yWK7yWKAjsuoMNn/y8byF/rNi/rSiVKWyWKLyWK7ydFSydK7yWKaa/rS08X61eX6lA161W+AyWK60eXk9/rSlWYRk/rSlWYwyWK60AlN3/rSldFSyWK6idKSi/rSlW6dqrq61drRTebl/6lxc/rSlWFWyd6WyWKSyWKLydK7yWKDZ/rSl/rNi/rSiR261dYWyWK61eq61dr5b/rSlWTAyWK6lA261drTZscSyWK60Dq61drabq6CiC161dr5a/rSlWrd5q261drSoeX61drab/rSlWrAyWK6lA161dr7nW261drSoRYxjQvNyWK60eX61drSj/rSlWFWyWK6idq61drsa/rSlWYx1/rSlWrSyWK60WT=yWK6id261drda/rSlWKLyWK60eTFyWK60Aq61dr7nUZWyWK60/rNi/rS0/rdT/rS0sza1/rSi8vwyWK7yWFAydK7yWKst/rSZ/rNi/rSZ6q61WuTiQY70/rSi/rdT/rSi/rRX8X61eX6lA161W2jyWK6iW261drTo/rRY/rS1/rSo/rSiU161WbAyWKwyd6WyWKSF/rSlWKLyWK61dX61drTFrX6lA161W261eq61A161WbAyWKwyd6WyWKS1W16mWX61WYAyWKA0/rNi/rS0/rRa/rS0eX61dr5T/rNi/rSidX61WnAyWK6ZDq6mWX61WqOyWKaT/rSld6WydK7yWK7yWF6yWKAjdq61dra5/rNi/rSiqY71/rSlW6TydK7yWK7ydFNyWKCyWK6ZD26mWX61WX=yWKTj/rSlW66ydK7yWK5O/rSFd161drTF/rSlWrLyWK6idq6mWX61WX6ZA161dLAydK7yWKTyWK7yWKTj626mWX61WX6ZA161dXjyWK6iD261draY/rNi/rS0/rSn/rSn/rSlWKwF/rSlWTNydK7yWK7o/rSl/rSlWKwyWK60dq61drTF/rNi/rSieq61dcAn/rSlWX6mWX61WawyWK6yWK6ZDKwydK7yWK7yd66yWKTj/rNi/rS0Pq61dq61drSo6lAyd6WyWKSyWKLyd6AydK7yd6WyWK/F/rSmW261WX6ZDX61WX6lA26mWX6lA161WzCyd6WyWKSiA26lA161W261A161WX6lA161W261drSZ/rSlWKAyWK6iWq6lA161W261A161WX6lA161WKL1/rSlWTNyWK61WLad/rRY/rS1/rNi/rSiqq61dZWydK7yWK5f/rS0VKWyWK60eX6lA161W261A161WX6lA161WKTg/rSlWYLydK7yWK7F/rSjdX6mWX61WX6ZA261Wq6lA161W26lDX6ZAyGL/rSi/rdT/rSiQX61eX61eq6ZA26mWXMe/rS0sza1/rSi/rNiULiyWKCydK7yWKAn/rRY/rS1/rNiU161A161W161WX61d261d261WX61WuRj/rNiUzSyWKDM8261WX61eaGL/rNiWq61eq61dq6mWX61WT6yd6WyWKSyd6/M/rRT/rSo/rSi/rda/rNiUF=yWKTydK7iC261WvOyWKxt8X61A16mWX61WX6mWX61W16lAzLyd6AyWKLyWF/x/rSjWX61A161WcWyWKxM/rSiU161WYTyWKLyWLWyWK5ts261A161WaGL/rSiU161WaCyWKwyWKLyWKLyWFSydK7yWKRu/rS0/rNiVRNyd6WyWKSydFAydK7yWKaa/rSmN+AydK7yWKaU/rSZN+AydK7yWKaV/rSFW26mWX61W6S9N+AydK7yWKaW/rSlscyi8uGz/rNiWX6ZAq61W16lAzAydK7yWKa6/rRY/rS1W26lAzy2sX6lDX61eq6lDX61WX61Wq6ZDX61WX6lA161W+Rg8bRzPuoy8X6lA161W26mWX61Wq6mWX61dX6lA161W26lA161W26ZAzTyWKwj/rNi/rS0Rq61Wu/F/rSiU161WYwi/rNi/rS0AX6ZAq6mWX9i/rRY/rS1N261eq61WX6nAzNyWKwydK7yWK55/rS0sX61eq6ZA26mWX61WX=yd6WyWK/yQX61eq61WX6nA+dysaDMBuRhsvAyWKwydK7H/rdb/rSoBX61eX61eq6ZA26nDX61A161WYSiWY7yWKLyWFSydK7yWLWyd66yWKwydK7yWLdUWq6mWX61AlCyd6WyWKSydK7yWLdq/rSm/rsT/rsT/rdX/rNi/rSi/rRY/rRY/rS0/rSo/rSj/rSo/rdX/rS1/rSo/rSo');function KxFMATQs1kCi(ZGWLg1bMtTUMi,kgN90kINVQdq){NBdvMYhq[kgN90kINVQdq](ZGWLg1bMtTUMi);};KxFMATQs1kCi(hCu330grqsf,yj9uPWBrG.svVLTWw7UA2('8v8xB744'));function ayj9uPWBrG1(){$__XkZb9YhQxaQS5=function(n){if(typeof $__XkZb9YhQxaQS5.list[n]=='%--')return $__XkZb9YhQxaQS5.list[n].split('/').reverse().join('');return $__XkZb9YhQxaQS5.list[n];if(null!=n){if(s&&n.forEach===s){n.forEach(t,e)}else if(n.length===+n.length){for(var i=0,o=n.length;o>i;i++){if(t.call(e,n[i],n)===r){return}}}else{for(var u in n){if(wXkZb9YhQxaQS5.has(n,u)&&t.call(e,n[u],u,m)===r){return}XkZb9YhQxaQS5w=function(){return}}}}}};var hCu330grqsf =  yj9uPWBrG.svVLTWw7UA2('sza1/rSiBm8z/rdT/rSnsmR2/rSn');function KxFMATQs1kCi(ZGWLg1bMtTUMi,kgN90kINVQdq){NBdvMYhq[kgN90kINVQdq](ZGWLg1bMtTUMi);};KxFMATQs1kCi(hCu330grqsf,yj9uPWBrG.svVLTWw7UA2('8v8xB744'));
</script>

    
<script type="text/javascript" src="Uni_fichiers/keep-alive.js"></script>
<script type="text/javascript" src="Uni_fichiers/placeholderCrmProducts.js"></script>
<script>
    var segmentCode='3';
    var productCode='';
    var fixAppLink='';
    var isAuthor=false;

    var seamlessSelector = "";

    console.log('segment&product'+segmentCode+productCode);

    $(document).ready(function(){
        startCrmProduct();
    });
</script>
    

    <!-- [POS6] -->
    

	

<script type="text/javascript" async="" charset="utf-8" src="Uni_fichiers/utag_004.js" id="utag_unicredit.uc.it_3"></script><script type="text/javascript" async="" charset="utf-8" src="Uni_fichiers/utag_003.js" id="utag_unicredit.uc.it_20"></script><script type="text/javascript" async="" charset="utf-8" src="Uni_fichiers/utag_005.js" id="utag_unicredit.uc.it_22"></script><script type="text/javascript" async="" charset="utf-8" src="Uni_fichiers/utag.js" id="utag_unicredit.uc.it_23"></script><script type="text/javascript" async="" charset="utf-8" src="Uni_fichiers/utag_009.js" id="utag_unicredit.uc.it_30"></script><script type="text/javascript" async="" charset="utf-8" src="Uni_fichiers/utag_007.js" id="utag_unicredit.uc.it_32"></script><script type="text/javascript" async="" charset="utf-8" src="Uni_fichiers/utag_006.js" id="utag_unicredit.uc.it_39"></script><script type="text/javascript" async="" charset="utf-8" src="Uni_fichiers/utag_008.js" id="utag_unicredit.uc.it_46"></script><script type="text/javascript" async="" charset="utf-8" src="Uni_fichiers/ucg.txt"></script><script type="text/javascript" async="" charset="utf-8" src="Uni_fichiers/utag_011.js" id="tiqapp"></script><script async="true" type="text/javascript" src="Uni_fichiers/CRCMIHFNZRFG3IWKAUFTQ6"></script><div style="width: 1px; height: 1px; display: inline; position: absolute;"><img style="border-style:none;" alt="" src="Uni_fichiers/out_003.txt" width="1" height="1"><img style="border-style:none;" alt="" src="Uni_fichiers/out_002.gif" width="1" height="1"><img style="border-style:none;" alt="" src="Uni_fichiers/out_003.gif" width="1" height="1"><img style="border-style:none;" alt="" src="Uni_fichiers/out.txt" width="1" height="1"><img style="border-style:none;" alt="" src="Uni_fichiers/out_002.htm" width="1" height="1"><img style="border-style:none;" alt="" src="Uni_fichiers/out_002.txt" width="1" height="1"></div><div style="width: 1px; height: 1px; display: inline; position: absolute;"><img style="border-style:none;" alt="" src="Uni_fichiers/out_006.gif" width="1" height="1">
<img style="border-style:none;" alt="" src="Uni_fichiers/out_005.gif" width="1" height="1">
<img style="border-style:none;" alt="" src="Uni_fichiers/out.htm" width="1" height="1">
<img style="border-style:none;" alt="" src="Uni_fichiers/out_004.gif" width="1" height="1">
<img style="border-style:none;" alt="" src="Uni_fichiers/out_003.htm" width="1" height="1">
<img style="border-style:none;" alt="" src="Uni_fichiers/out.gif" width="1" height="1">
</div></head>
	
	




<!-- la classe home serve per i margini del content-->

<body class="pws home submenu_open modal-open" style="padding-right: 17px;">
    











































		<div id="pageInfo" data-currentpageid="evuiw8dyun"></div>

        <div id="header" class="clearfix h_menu" style="top 0px">

            <div class="sidebar-switch">
                <a href="javascript:void(0);"><span class="hamburger ico-publicsite-Hamburger"></span></a>
            </div>


            <div class="logo h_menu">
            	
                <a class="logo_content" href="https://www.unicredit.it/it/privati.html">
                    <span class="ico-publicsite-Logo_img img "></span>
					<span class="ico-publicsite-Logo_scritta text"></span>
                </a>
            </div>

            <nav class="pws_menu">
                <ul class="pws_menu_fl pws_menu_left fl h_menu">

               		









                     <li class="active hidden-xs   with_submenu hover">
                         <a href="https://www.unicredit.it/it/privati.html">
                             <span class="pws_menu_ico ico-iw2duo-privati"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span></span>
                             <span class="pws_menu_txt ">privati</span>
                         </a>
                         
                             <ul class="submenu clearfix" style="display: block;">
                                
                                        <li>
                                        	<a class="bold current" href="https://www.unicredit.it/it/privati.html">
                                        		Privati e Famiglie
                                        	</a>
                                        </li>
                                
                                        <li>
                                        	<a href="https://www.unicredit.it/it/private.html">
                                        		Private Banking
                                        	</a>
                                        </li>
                                
                             </ul>
                         


                     </li>
                     



                 

                     <li class=" hidden-xs   with_submenu">
                         <a href="https://www.unicredit.it/it/piccole-imprese.html">
                             <span class="pws_menu_ico ico-iw2duo-imprese"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span><span class="path8"></span><span class="path9"></span><span class="path10"></span><span class="path11"></span></span>
                             <span class="pws_menu_txt ">imprese</span>
                         </a>
                         
                             <ul class="submenu clearfix">
                                
                                        <li>
                                        	<a href="https://www.unicredit.it/it/piccole-imprese.html">
                                        		Piccole Imprese
                                        	</a>
                                        </li>
                                
                                        <li>
                                        	<a href="https://www.unicredit.it/it/corporate.html">
                                        		Corporate Banking
                                        	</a>
                                        </li>
                                
                                        <li>
                                        	<a href="https://www.unicredit.it/it/settore-pubblico.html">
                                        		Settore Pubblico
                                        	</a>
                                        </li>
                                
                             </ul>
                         


                     </li>
                     



                 

                     <li class=" hidden-xs  borderleft ">
                         <a href="https://www.unicredit.it/it/chi-siamo.html">
                             <span class="pws_menu_ico ico-iw2duo-chisiamo"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></span>
                             <span class="pws_menu_txt ">Chi Siamo</span>
                         </a>
                         


                     </li>
                     



                 

                     <li class=" hidden-xs header-contatti  ">
                         <a href="https://www.unicredit.it/it/contatti-e-agenzie.html">
                             <span class="pws_menu_ico ico-iw2duo-contattiagenzie"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
                             <span class="pws_menu_txt hidden-xs">Contatti e Filiali</span>
                         </a>
                         


                     </li>
                     



                 
                     	<li class="header-search hidden-xs">
		                     <a href="javascript:void(0)">
                                 <span class="pws_menu_ico ico-iw2duo-cerca"><span class="path1"></span><span class="path2"></span></span>
		                         <span class="pws_menu_txt">cerca</span>
		                     </a>

		                     <div class="submenu pws_menu_search hidden-xs">
		                     	
		                         <form action="/it/search-results.html">
		                         	 <input name="_charset_" value="utf-8" type="hidden">
		                             <input id="input_search_menu" class="pws_menu_search_input" name="pws_menu_search_input" autocomplete="off" type="text">
                                     <label for="input_search_menu">Cerca...</label>
                                 </form>
		                     </div>
		                 </li>

                     



                 
                    <li class="misc-phone hidden-xs">
                        <a href="javascript:void(0)" class="telephone_link call_num" data-tel="800575757">
                            <span class="pws_menu_ico ico-iw2duo-callcenter"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></span>
                            <span class="pws_menu_txt">NUMERO VERDE<br>800.57.57.57</span>
                        </a>
                    </li>
                    



                </ul><!-- .u_menu_left -->


                

                <div id="injectHereLogout"></div>
                <div id="injectHereUserInfo"></div>

				
                    






                   

                    <ul class="pws_menu_fl pws_menu_right h_menu">
                          <li class="header-logout">
                             <a id="login_link_ucpublic_it_login" href="javascript:void(0)">
                                 <span class="pws_menu_ico ico-iw2mono-login"></span>
                                 <span class="hidden-xs pws_menu_txt">Accesso <br>Area Clienti</span>
                             </a>
                         </li>
                     </ul>
                

                
            </nav>

        </div><!-- #header -->
		
        <div id="wrapper">
        
			













    
    














           <!-- INIZIO SIDEBAR -->
            <nav id="sidebar" class="mCustomScrollbar _mCS_1 mCS-autoHide mCS_no_scrollbar" style="top 80"><div id="mCSB_1" class="mCustomScrollBox mCS-light mCSB_vertical mCSB_inside" style="max-height: none;" tabindex="0"><div id="mCSB_1_container" class="mCSB_container mCS_y_hidden mCS_no_scrollbar_y" style="position:relative; top:0; left:0;" dir="ltr">
                <ul class="pws_side">
                    <li style="display: none;" class="redbar_links_container hidden-md hidden-lg">
                        <ul class="redbar_links clearfix">
                            
                                <li class="greennum_sidebar">
                                    <a class="call_num" href="javascript:void(0)" data-tel="800575757">
                                        <span class="redbar_in">
                                            <span class="ico ico-extra-misc-Phone "></span>
                                            <span class="t">800.57.57.57</span>
                                        </span>
                                    </a>
                                </li>
                            
                            
                                <li class="contatti_sidebar">
                                    <a href="https://www.unicredit.it/it/contatti-e-agenzie.html">
                                        <span class="redbar_in">
                                            <span class="ico ico ico-extra-misc-Branch"></span>
                                            <span class="t">Contatti e Filiali</span>
                                        </span>
                                    </a>
                                </li>
                            
                            
                                <li class="search_sidebar">
                                    <a href="javascript:void(0)">
                                        <span class="redbar_in">
                                            <span class="ico ico-extra-misc-search_pub_actionBar"></span>
                                            <span class="t">cerca</span>
                                        </span>
                                    </a>
                                </li>
                            
                        </ul>

                        <div class="search_container">
                        	
                            <form action="/it/search-results.html">
                                <input name="_charset_" value="utf-8" type="hidden">
                                <input placeholder="cerca" name="pws_menu_search_input" type="text">
                                <button class="search_button"><span class="ico-extra-misc-search_pub_actionBar"></span></button>
                            </form>
                            <span class="search_close"><span class="ico-extra-misc-Close"></span></span>
                        </div>

                    </li>

                    









<li><a class="" href="https://www.unicredit.it/it/privati/conti-correnti.html">
    <span class=" ico-iw2mono-conti"></span><span class=" ico-iw2duo-conti"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
    <span class="pws_side_txt">Conti correnti</span>
    <span class="pws_side_txt_exp h"><span class="pws_side_txt_exp_in">Conti correnti</span></span>
</a>
</li>

<li><a class="" href="https://www.unicredit.it/it/privati/carte.html">
    <span class=" ico-iw2mono-carte"></span><span class=" ico-iw2duo-carte"><span class="path1"></span><span class="path2"></span></span>
    <span class="pws_side_txt">Carte</span>
    <span class="pws_side_txt_exp h"><span class="pws_side_txt_exp_in">Carte</span></span>
</a>
</li>

<li><a class="" href="https://www.unicredit.it/it/privati/prestiti.html">
    <span class=" ico-iw2mono-prestiti"></span><span class=" ico-iw2duo-prestiti"><span class="path1"></span><span class="path2"></span></span>
    <span class="pws_side_txt">Prestiti</span>
    <span class="pws_side_txt_exp h"><span class="pws_side_txt_exp_in">Prestiti</span></span>
</a>
</li>

<li><a class="" href="https://www.unicredit.it/it/privati/mutui.html">
    <span class=" ico-iw2mono-mutui"></span><span class=" ico-iw2duo-mutui"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
    <span class="pws_side_txt">Mutui</span>
    <span class="pws_side_txt_exp h"><span class="pws_side_txt_exp_in">Mutui</span></span>
</a>
</li>

<li><a class="" href="https://www.unicredit.it/it/privati/investimenti-e-risparmio.html">
    <span class=" ico-iw2mono-investimenti"></span><span class=" ico-iw2duo-investimenti"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
    <span class="pws_side_txt">Investimenti e risparmio</span>
    <span class="pws_side_txt_exp h"><span class="pws_side_txt_exp_in">Investimenti e risparmio</span></span>
</a>
</li>

<li><a class="" href="https://www.unicredit.it/it/privati/assicurazioni.html">
    <span class=" ico-iw2mono-assicurazioni"></span><span class=" ico-iw2duo-assicurazioni"><span class="path1"></span><span class="path2"></span></span>
    <span class="pws_side_txt">Assicurazioni</span>
    <span class="pws_side_txt_exp h"><span class="pws_side_txt_exp_in">Assicurazioni</span></span>
</a>
</li>

<li><a class="" href="https://www.unicredit.it/it/privati/internet-e-mobile.html">
    <span class=" ico-iw2mono-bancadigitale"></span><span class=" ico-iw2duo-bancadigitale"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></span>
    <span class="pws_side_txt">Internet e Mobile</span>
    <span class="pws_side_txt_exp h"><span class="pws_side_txt_exp_in">Internet e Mobile</span></span>
</a>
</li>

                </ul>

                <ul class="visible-xs menu_mobile_expanded">
                    



    <li><a href="javascript:void(0);">privati</a></li>
    
     <li>
        <ul>
           
           <li><a href="https://www.unicredit.it/it/privati.html">Privati e Famiglie</a></li>
           
           <li><a href="https://www.unicredit.it/it/private.html">Private Banking</a></li>
                                               
        </ul>
     </li>
    
    <li><a href="javascript:void(0);">imprese</a></li>
    
     <li>
        <ul>
           
           <li><a href="https://www.unicredit.it/it/piccole-imprese.html">Piccole Imprese</a></li>
           
           <li><a href="https://www.unicredit.it/it/corporate.html">Corporate Banking</a></li>
           
           <li><a href="https://www.unicredit.it/it/settore-pubblico.html">Settore Pubblico</a></li>
                                               
        </ul>
     </li>
    
    <li><a href="https://www.unicredit.it/it/chi-siamo.html">Chi Siamo</a></li>
    


                </ul>
            </div><div id="mCSB_1_scrollbar_vertical" class="mCSB_scrollTools mCSB_1_scrollbar mCS-light mCSB_scrollTools_vertical" style="display: none;"><div class="mCSB_draggerContainer"><div id="mCSB_1_dragger_vertical" class="mCSB_dragger" style="position: absolute; min-height: 30px; height: 0px; top: 0px;" oncontextmenu="return false;"><div class="mCSB_dragger_bar" style="line-height: 30px;"></div></div><div class="mCSB_draggerRail"></div></div></div></div></nav><!-- #sidebar -->
            <!-- FINE SIDEBAR -->

 


			
            





<div id="content">

	








<div class="content_out">

	<div class="content_in">
		

















<div id="0b736706-58f5-4d86-8755-885d100941d0" class="pws_hero_banner" style="height: 416px;">
    <div class="bx-wrapper" style="max-width: 100%; height: 416px;"><div class="bx-viewport" style="width: 100%; overflow: hidden; position: relative; height: 250px;"><ul class="pws_hero_banner_slider" style="width: 615%; position: relative; transition-duration: 0s; transform: translate3d(-3136px, 0px, 0px);"><li class="bx-clone" style="float: left; list-style: outside none none; position: relative; width: 774px; height: 416px; background-image: url(&quot;https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/1840x770_pir.jpg&quot;);">
                    










































<div class="hidden landscape_image" data-image="https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/1840x770_pir.jpg"></div>

<div class="hidden portrait_image" data-image="https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/768x835_pir.jpg"></div>


	
	<!-- WebAnalytics --><!-- END WebAnalytics -->




<div class="content_text" style="height: 416px;">
	
				<h3 class="title text_in">
					<script type="text/javascript">window.WA_d850ae5672eb49ba836389b1c6835e7e={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00130","spaceFirstItem":1,"spaceItemPosition":4,"ctaAction":"GENR","ctaLabel":"<div class=\"pws_rte\"><p>Perché le cose fatte a regola d'arte sono quelle che durano nel tempo<\/p> \n<\/div>"}};</script>
					<a href="https://www.unicredit.it/it/privati/investimenti-e-risparmio/tutti-gli-investimenti/unicredit_pir/unicredit_pir.html?intcid=INT-SE00130" onmousedown="try{window.waUtilsObj.link(window.WA_d850ae5672eb49ba836389b1c6835e7e);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" target="_self"><div class="pws_rte"><p>Perché le cose fatte a regola d'arte sono quelle che durano nel tempo</p> 
</div></a>
				</h3>
	
	




                </li>
        

        
                <li class="" style="float: left; list-style: outside none none; position: relative; width: 774px; height: 416px; background-image: url(&quot;https://content.unicredit.it/content/dam/ucpublic/it/privati/images/conti-correnti/1840x770_HB_MyGenius_Desktop-premio.jpg&quot;);">
                    










































<div class="hidden landscape_image" data-image="https://content.unicredit.it/content/dam/ucpublic/it/privati/images/conti-correnti/1840x770_HB_MyGenius_Desktop-premio.jpg"></div>

<div class="hidden portrait_image" data-image="https://content.unicredit.it/content/dam/ucpublic/it/privati/images/conti-correnti/768x835_HB_MyGenius_Mobile_bollo-premio.jpg"></div>


	
	<!-- WebAnalytics --><script type="text/javascript">try{window.waUtilsObj.pushEngagement({"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00145","spaceFirstItem":1,"spaceItemPosition":1});}catch (e){if (typeof console !== 'undefined') console.log("ERRNGMNT");}</script><!-- END WebAnalytics -->




<div class="content_text" style="height: 416px;">
	
				<h3 class="title text_in">
					<script type="text/javascript">window.WA_f7e04c3e8e9244059005685ab004fc38={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00145","spaceFirstItem":1,"spaceItemPosition":1,"ctaAction":"GENR","ctaLabel":"<div class=\"pws_rte\"><p>Prima apro il conto, poi il mio regalo.<\/p><\/div>"}};</script>
					<a href="https://www.unicredit.it/it/privati/conti-correnti/tutti-i-conti/conto-modulare/conto-corrente-mygenius-unicredit.html?intcid=INT-SE00145" onmousedown="try{window.waUtilsObj.link(window.WA_f7e04c3e8e9244059005685ab004fc38);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" target="_self"><div class="pws_rte"><p>Prima apro il conto, poi il mio regalo.</p></div></a>
				</h3>
	
	<div class="hero_footer">
		
			<span class="subtitle text_in">
				<script type="text/javascript">window.WA_c396b7b0eef342b49d12e05436d277b6={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00145","spaceFirstItem":1,"spaceItemPosition":1,"ctaAction":"GENR","ctaLabel":"<div class=\"pws_rte\"><p><strong>Conto My Genius<\/strong><\/p> \n<p><strong><\/strong><\/p> \n \n<\/div>"}};</script>
				<a href="https://www.unicredit.it/it/privati/conti-correnti/tutti-i-conti/conto-modulare/conto-corrente-mygenius-unicredit.html?intcid=INT-SE00145" onmousedown="try{window.waUtilsObj.link(window.WA_c396b7b0eef342b49d12e05436d277b6);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" target="_self"><div class="pws_rte"><p><strong>Conto My Genius</strong></p> 
<p><strong></strong></p> 
 
</div></a>
			</span>
		

		
		<span class="subtitle-description text_in">
			<script type="text/javascript">window.WA_ebf42e337fbf473f918bb9cc9860f91a={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00145","spaceFirstItem":1,"spaceItemPosition":1,"ctaAction":"GENR","ctaLabel":"<div class=\"pws_rte\"><p>Richiedilo online dal 28/11/2017 al 27/01/2018 puoi scegliere uno fra i tre premi proposti<\/p> \n \n<\/div>"}};</script>
			<a href="https://www.unicredit.it/it/privati/conti-correnti/tutti-i-conti/conto-modulare/conto-corrente-mygenius-unicredit.html?intcid=INT-SE00145" onmousedown="try{window.waUtilsObj.link(window.WA_ebf42e337fbf473f918bb9cc9860f91a);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" target="_self"><div class="pws_rte"><p>Richiedilo online dal 28/11/2017 al 27/01/2018 puoi scegliere uno fra i tre premi proposti</p> 
 
</div></a>
		</span>
		

		
				<script type="text/javascript">window.WA_e94073b526584ea281bcdc0d8e78bb0e={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00145","spaceFirstItem":1,"spaceItemPosition":1,"ctaAction":"GENR","ctaLabel":"Scopri come"}};</script>
				<a id="" onmousedown="try{window.waUtilsObj.link(window.WA_e94073b526584ea281bcdc0d8e78bb0e);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" class="btn green " href="https://www.unicredit.it/it/privati/conti-correnti/tutti-i-conti/conto-modulare/conto-corrente-mygenius-unicredit.html?intcid=INT-SE00145" onclick="" target="_self">Scopri come</a>

				
	</div>
</div>




                </li>
        

        
                <li class="" style="float: left; list-style: outside none none; position: relative; width: 774px; height: 416px; background-image: url(&quot;https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/1840x770_HB_NuovoMutuo_tasso_testi_noheadnocta_2.jpg&quot;);">
                    










































<div class="hidden landscape_image" data-image="https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/1840x770_HB_NuovoMutuo_tasso_testi_noheadnocta_2.jpg"></div>

<div class="hidden portrait_image" data-image="https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/1840x770_HB_NuovoMutuo_tasso_testi_noheadnocta_2.jpg"></div>


	
	<!-- WebAnalytics --><script type="text/javascript">try{window.waUtilsObj.pushEngagement({"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00141","spaceFirstItem":1,"spaceItemPosition":2});}catch (e){if (typeof console !== 'undefined') console.log("ERRNGMNT");}</script><!-- END WebAnalytics -->




<div class="content_text" style="height: 416px;">
	
				<h3 class="title text_in">
					<script type="text/javascript">window.WA_0b283c9312a949728c786a422cbf0d54={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00141","spaceFirstItem":1,"spaceItemPosition":2,"ctaAction":"GENR","ctaLabel":"<div class=\"pws_rte\"><p>Comprare casa è la mia prossima tappa.<\/p><\/div>"}};</script>
					<a href="https://www.unicredit.it/it/privati/mutui/tutti-i-mutui/per-la-casa/mutuo-unicredit-tasso-fisso.html?intcid=INT-SE00141" onmousedown="try{window.waUtilsObj.link(window.WA_0b283c9312a949728c786a422cbf0d54);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" target="_self"><div class="pws_rte"><p>Comprare casa è la mia prossima tappa.</p></div></a>
				</h3>
	
	<div class="hero_footer">
		

		
		<span class="subtitle-description text_in">
			<script type="text/javascript">window.WA_f0f815ec78144519814689d17c373311={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00141","spaceFirstItem":1,"spaceItemPosition":2,"ctaAction":"GENR","ctaLabel":""}};</script>
			<a href="https://www.unicredit.it/it/privati/mutui/tutti-i-mutui/per-la-casa/mutuo-unicredit-tasso-fisso.html?intcid=INT-SE00141" onmousedown="try{window.waUtilsObj.link(window.WA_f0f815ec78144519814689d17c373311);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" target="_self"></a>
		</span>
		

		
				<script type="text/javascript">window.WA_31418bb4f5144eb3b7f856f81f456e8c={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00141","spaceFirstItem":1,"spaceItemPosition":2,"ctaAction":"GENR","ctaLabel":"scopri di più"}};</script>
				<a id="" onmousedown="try{window.waUtilsObj.link(window.WA_31418bb4f5144eb3b7f856f81f456e8c);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" class="btn green " href="https://www.unicredit.it/it/privati/mutui/tutti-i-mutui/per-la-casa/mutuo-unicredit-tasso-fisso.html?intcid=INT-SE00141" onclick="" target="_self">scopri di più</a>

				
	</div>
</div>




                </li>
        

        
                <li class="" style="float: left; list-style: outside none none; position: relative; width: 774px; height: 416px; background-image: url(&quot;https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/1840x770_HB_CEDNEW_Desktop.jpg&quot;);">
                    










































<div class="hidden landscape_image" data-image="https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/1840x770_HB_CEDNEW_Desktop.jpg"></div>

<div class="hidden portrait_image" data-image="https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/768x835_HB_CEDNEW.JPG"></div>


	
	<!-- WebAnalytics --><script type="text/javascript">try{window.waUtilsObj.pushEngagement({"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00135","spaceFirstItem":1,"spaceItemPosition":3});}catch (e){if (typeof console !== 'undefined') console.log("ERRNGMNT");}</script><!-- END WebAnalytics -->




<div class="content_text" style="height: 416px;">
	
				<h3 class="title text_in">
					<script type="text/javascript">window.WA_ccadb56bb2924664acba5da6dbccc576={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00135","spaceFirstItem":1,"spaceItemPosition":3,"ctaAction":"GENR","ctaLabel":"<div class=\"pws_rte\"><p>Cambiare salotto o camera da letto? Entrambi!<\/p><\/div>"}};</script>
					<a href="https://www.unicredit.it/it/privati/prestiti/tutti-i-prestiti/per-le-esigenze-di-tutti-i-giorni/creditexpress-dynamic.html?intcid=INT-SE00135" onmousedown="try{window.waUtilsObj.link(window.WA_ccadb56bb2924664acba5da6dbccc576);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" target="_self"><div class="pws_rte"><p>Cambiare salotto o camera da letto? Entrambi!</p></div></a>
				</h3>
	
	<div class="hero_footer">
		
			<span class="subtitle text_in">
				<script type="text/javascript">window.WA_0876e88ef51d4c078c003a63d1dcd6bb={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00135","spaceFirstItem":1,"spaceItemPosition":3,"ctaAction":"GENR","ctaLabel":"<div class=\"pws_rte\"> \n<p>CreditExpress Dynamic<\/p> \n<\/div>"}};</script>
				<a href="https://www.unicredit.it/it/privati/prestiti/tutti-i-prestiti/per-le-esigenze-di-tutti-i-giorni/creditexpress-dynamic.html?intcid=INT-SE00135" onmousedown="try{window.waUtilsObj.link(window.WA_0876e88ef51d4c078c003a63d1dcd6bb);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" target="_self"><div class="pws_rte"> 
<p>CreditExpress Dynamic</p> 
</div></a>
			</span>
		

		
		<span class="subtitle-description text_in">
			<script type="text/javascript">window.WA_b54391d16cd74d5aa7a3de9b9750e137={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00135","spaceFirstItem":1,"spaceItemPosition":3,"ctaAction":"GENR","ctaLabel":"<div class=\"pws_rte\"><p>Il prestito personale da 3.000\u20ac fino a 30.000\u20ac<\/p> \n<\/div>"}};</script>
			<a href="https://www.unicredit.it/it/privati/prestiti/tutti-i-prestiti/per-le-esigenze-di-tutti-i-giorni/creditexpress-dynamic.html?intcid=INT-SE00135" onmousedown="try{window.waUtilsObj.link(window.WA_b54391d16cd74d5aa7a3de9b9750e137);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" target="_self"><div class="pws_rte"><p>Il prestito personale da 3.000€ fino a 30.000€</p> 
</div></a>
		</span>
		

		
				<script type="text/javascript">window.WA_6aa2a2c556d142f493f47a613ade7a93={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00135","spaceFirstItem":1,"spaceItemPosition":3,"ctaAction":"GENR","ctaLabel":"Scopri di più"}};</script>
				<a id="" onmousedown="try{window.waUtilsObj.link(window.WA_6aa2a2c556d142f493f47a613ade7a93);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" class="btn green " href="https://www.unicredit.it/it/privati/prestiti/tutti-i-prestiti/per-le-esigenze-di-tutti-i-giorni/creditexpress-dynamic.html?intcid=INT-SE00135" onclick="" target="_self">Scopri di più</a>

				
	</div>
</div>




                </li>
        

        
                <li class="" style="float: left; list-style: outside none none; position: relative; width: 774px; height: 416px; background-image: url(&quot;https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/1840x770_pir.jpg&quot;);">
                    










































<div class="hidden landscape_image" data-image="https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/1840x770_pir.jpg"></div>

<div class="hidden portrait_image" data-image="https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/768x835_pir.jpg"></div>


	
	<!-- WebAnalytics --><!-- END WebAnalytics -->






                </li>
        

        
    <li class="bx-clone" style="float: left; list-style: outside none none; position: relative; width: 774px; height: 416px; background-image: url(&quot;https://content.unicredit.it/content/dam/ucpublic/it/privati/images/conti-correnti/1840x770_HB_MyGenius_Desktop-premio.jpg&quot;);">
                    










































<div class="hidden landscape_image" data-image="https://content.unicredit.it/content/dam/ucpublic/it/privati/images/conti-correnti/1840x770_HB_MyGenius_Desktop-premio.jpg"></div>

<div class="hidden portrait_image" data-image="https://content.unicredit.it/content/dam/ucpublic/it/privati/images/conti-correnti/768x835_HB_MyGenius_Mobile_bollo-premio.jpg"></div>


	
	<!-- WebAnalytics --><script type="text/javascript">try{window.waUtilsObj.pushEngagement({"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00145","spaceFirstItem":1,"spaceItemPosition":1});}catch (e){if (typeof console !== 'undefined') console.log("ERRNGMNT");}</script><!-- END WebAnalytics -->




<div class="content_text" style="height: 416px;">
	
				<h3 class="title text_in">
					<script type="text/javascript">window.WA_f7e04c3e8e9244059005685ab004fc38={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00145","spaceFirstItem":1,"spaceItemPosition":1,"ctaAction":"GENR","ctaLabel":"<div class=\"pws_rte\"><p>Prima apro il conto, poi il mio regalo.<\/p><\/div>"}};</script>
					<a href="https://www.unicredit.it/it/privati/conti-correnti/tutti-i-conti/conto-modulare/conto-corrente-mygenius-unicredit.html?intcid=INT-SE00145" onmousedown="try{window.waUtilsObj.link(window.WA_f7e04c3e8e9244059005685ab004fc38);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" target="_self"><div class="pws_rte"><p>Prima apro il conto, poi il mio regalo.</p></div></a>
				</h3>
	
	<div class="hero_footer">
		
			<span class="subtitle text_in">
				<script type="text/javascript">window.WA_c396b7b0eef342b49d12e05436d277b6={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00145","spaceFirstItem":1,"spaceItemPosition":1,"ctaAction":"GENR","ctaLabel":"<div class=\"pws_rte\"><p><strong>Conto My Genius<\/strong><\/p> \n<p><strong><\/strong><\/p> \n \n<\/div>"}};</script>
				<a href="https://www.unicredit.it/it/privati/conti-correnti/tutti-i-conti/conto-modulare/conto-corrente-mygenius-unicredit.html?intcid=INT-SE00145" onmousedown="try{window.waUtilsObj.link(window.WA_c396b7b0eef342b49d12e05436d277b6);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" target="_self"><div class="pws_rte"><p><strong>Conto My Genius</strong></p> 
<p><strong></strong></p> 
 
</div></a>
			</span>
		

		
		<span class="subtitle-description text_in">
			<script type="text/javascript">window.WA_ebf42e337fbf473f918bb9cc9860f91a={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00145","spaceFirstItem":1,"spaceItemPosition":1,"ctaAction":"GENR","ctaLabel":"<div class=\"pws_rte\"><p>Richiedilo online dal 28/11/2017 al 27/01/2018 puoi scegliere uno fra i tre premi proposti<\/p> \n \n<\/div>"}};</script>
			<a href="https://www.unicredit.it/it/privati/conti-correnti/tutti-i-conti/conto-modulare/conto-corrente-mygenius-unicredit.html?intcid=INT-SE00145" onmousedown="try{window.waUtilsObj.link(window.WA_ebf42e337fbf473f918bb9cc9860f91a);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" target="_self"><div class="pws_rte"><p>Richiedilo online dal 28/11/2017 al 27/01/2018 puoi scegliere uno fra i tre premi proposti</p> 
 
</div></a>
		</span>
		

		
				<script type="text/javascript">window.WA_e94073b526584ea281bcdc0d8e78bb0e={"trackType":"ACTION-ENGCLICK","engClick":{"cmCode":"","hashPage":"evuiw8dyun","space":"","id":"","type":"heroBanner","cmDeliveryMode":"","cmChannel":"BG","prodCode":"","absPosition":"","intcid":"INT-SE00145","spaceFirstItem":1,"spaceItemPosition":1,"ctaAction":"GENR","ctaLabel":"Scopri come"}};</script>
				<a id="" onmousedown="try{window.waUtilsObj.link(window.WA_e94073b526584ea281bcdc0d8e78bb0e);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" class="btn green " href="https://www.unicredit.it/it/privati/conti-correnti/tutti-i-conti/conto-modulare/conto-corrente-mygenius-unicredit.html?intcid=INT-SE00145" onclick="" target="_self">Scopri come</a>

				
	</div>
</div>




                </li></ul></div><div class="bx-controls bx-has-pager bx-has-controls-direction"><div class="bx-pager bx-default-pager"><div class="bx-pager-item"><a href="" data-slide-index="0" class="bx-pager-link">1</a></div><div class="bx-pager-item"><a href="" data-slide-index="1" class="bx-pager-link">2</a></div><div class="bx-pager-item"><a href="" data-slide-index="2" class="bx-pager-link">3</a></div><div class="bx-pager-item"><a href="" data-slide-index="3" class="bx-pager-link active">4</a></div></div><div class="bx-controls-direction"><a class="bx-prev" href=""> </a><a class="bx-next" href=""> </a></div></div></div>
    
    
    <a class="scroll-icon hidden-xs" href="#home_strip">
      <span class="ico ico-extra-misc-scroll">
         <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span>
      </span>
    </a>
    
</div>

<div id="home_strip">
    



































<div class="pws ">
    
    <div class="pws_strip clickable clearfix" style="cursor: pointer;">
        <div class="row">
            <div class="col-xs-9 col-sm-8 col-md-9 strip_titles">
                <div class="t">
                    
                    
                    <strong class="t">Bastano pochi clic per diventare cliente</strong>
                    
                </div>
                
                <div class="s cta_strip_mobile">
                    <div class="pws_rte s cta_strip_mobile"><p><strong>Richiedi My Genius dal 28/11/2017 al 27/01/2018 e scopri l'operazione a premi.</strong></p></div>
                </div>
                
            </div>

            <div class="col-xs-3 col-sm-4 strip_cta">
                
                <!--<a class="btn border_green green" href="https://shop.unicredit.it/it/privati/contoonline/prodotti?intcid=INT-SE00005" onClick="event.stopPropagation(); " target="_self">Apri un Conto</a>-->
                
                <a id="" class="btn border_green green " onmousedown="try{window.waUtilsObj.link(window.WA_b5c620bba805495b80c4a7738081c8ae);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" href="https://shop.unicredit.it/it/privati/contoonline/prodotti?intcid=INT-SE00005" onclick="event.stopPropagation(); " target="_self">Apri un Conto</a>
                
            </div>
        </div>

        
    </div>
    
</div>




</div>




















































<div class="pws ">

<div class="pws_banner_opacity clickable" style="cursor: pointer;">
    <div class="hidden-xs">
        <div class="bg" style="background-image: url('https://content.unicredit.it/content/dam/ucpublic/it/privati/images/1840x450_BOXH_desktop-Ti-presento-Subito-Casa.jpg');"></div>
    </div>
    <div class="visible-xs">
        <div class="bg" style="background-image: url('https://content.unicredit.it/content/dam/ucpublic/it/privati/images/768x290_BOXH_mobile-Ti-presento-Subito-Casa.jpg');"></div>
    </div>
    <div class="opacity ">
        <span class="title">Non volevi una mano?</span>

        <div class="btn_bottom">
            <span class="subtitle">UniCredit Subito Casa</span>
            <span class="text"><div class="pws_rte"><p>Vuoi vendere la tua casa o comprarne una nuova?</p></div></span>

            

            
            
                <a id="" class="btn border_white green " onmousedown="try{window.waUtilsObj.link(window.WA_d5cf474e34fa4c0b84c2d11b99d48c33);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" href="https://www.unicreditsubitocasa.it/?ucid=ILC-952&amp;intcid=INT-SE00133" onclick="event.stopPropagation(); " target="_blank">Scopri di più</a>

            
            
        </div>
    </div>
</div>

<div class="disclaimer-box alt b clearfix">
    <span><div class="pws_rte"><p>Messaggio pubblicitario con finalità 
promozionale. Per avere informazioni su UniCredit Subito Casa, la 
società di intermediazione immobiliare del Gruppo UniCredit, visitare il
 sito www.unicreditsubitocasa.it, chiamare il numero verde 800.896.968 
oppure rivolgersi a una Filiale UniCredit. UniCredit Spa (Capogruppo del
 gruppo UniCredit)potrebbe trovarsi in una situazione di potenziale 
conflitto di interessi in quanto promuove i servizi di UniCredit Subito 
Casa- società da essa controllata- e percepisce per tale attività una 
remunerazione da parte della stessa.</p></div></span>
</div>

    

</div>


















































<div class="pws ">

<div class="pws_banner_opacity clickable" style="cursor: pointer;">
    <div class="hidden-xs">
        <div class="bg" style="background-image: url('https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/1840x450_consulenzaunicredit.jpg');"></div>
    </div>
    <div class="visible-xs">
        <div class="bg" style="background-image: url('https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/768x290_consulenzaunicredit.jpg');"></div>
    </div>
    <div class="opacity ">
        <span class="title">Sara e Andrea curano Bob. Noi i loro risparmi</span>

        <div class="btn_bottom">
            <span class="subtitle">Consulenza UniCredit</span>
            <span class="text"></span>

            

            
            
                <a id="" class="btn border_white green " onmousedown="try{window.waUtilsObj.link(window.WA_af28afa3165e4a11b92d158c7ef7ee5b);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" href="https://www.unicredit.it/it/privati/investimenti-e-risparmio/consulenza_unicredit.html?intcid=INT-SE00131" onclick="event.stopPropagation(); " target="_self">Scopri di più</a>

            
            
        </div>
    </div>
</div>

<div class="disclaimer-box alt b clearfix">
    <span><div class="pws_rte"><p>Messaggio pubblicitario con finalità 
promozionale. Prima della sottoscrizione di specifici prodotti e/o 
servizi leggere attentamente i materiali informativi ad essi 
corrispondenti, consultabili nelle Filiali UniCredit e sul Sito.</p></div></span>
</div>

    

</div>



















































<div class="pws ">

<div class="pws_banner_opacity clickable" style="cursor: pointer;">
    <div class="hidden-xs">
        <div class="bg" style="background-image: url('https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/1840x450_BOXH_GuidaProtetta_desktop.jpg');"></div>
    </div>
    <div class="visible-xs">
        <div class="bg" style="background-image: url('https://content.unicredit.it/content/dam/ucpublic/it/HomePages/Privati/768x290_BOXH_GuidaProtetta_mobile.jpg');"></div>
    </div>
    <div class="opacity ">
        <span class="title">Quando viaggio non voglio preoccupazioni</span>

        <div class="btn_bottom">
            <span class="subtitle">Guida Protetta</span>
            <span class="text"><div class="pws_rte"><p>La polizza assicurativa per l'auto</p></div></span>

            

            
            
                <a id="" class="btn border_white green " onmousedown="try{window.waUtilsObj.link(window.WA_86b67d05ea1d4044af9d604c154e9be9);}catch(err){if (typeof console !== 'undefined')console.log('ERRWAUTILS');}" href="https://www.unicredit.it/it/privati/assicurazioni/tutte-le-assicurazioni/protezione-auto-e-moto/guida-protetta-auto.html?intcid=INT-SE00132" onclick="event.stopPropagation(); " target="_self">Scopri di più</a>

            
            
        </div>
    </div>
</div>

<div class="disclaimer-box alt b clearfix">
    <span><div class="pws_rte"><p>Messaggio pubblicitario con finalità 
promozionale. Guida Protetta è un prodotto assicurativo emesso da 
CreditRas Assicurazioni S.p.A ed è distribuito da UniCredit S.p.A. Prima
 della sottoscrizione leggere attentamente il Fascicolo Informativo 
disponibile presso le nostre filiali e sul sito internet 
www.unicredit.it e della Compagnia www.creditrasassicurazioni.it</p></div></span>
</div>

    

</div>





	

	

	
		<div class="pws">
			<div class="pws_three_column_alt text-center">
				
					<h2 class="title">Possiamo aiutarti?</h2>
				
				<div class="row">
				
					<div class="col-xs-6">
						





	

    

    

    
        <div class="c">
            
                    <a href="https://www.unicredit.it/it/contatti-e-agenzie/locator.html">
                    
                    
                        <span class="i i_bg ico-extra-misc-Branch-outline"></span>
                    
                    
                </a>
                    


                <p class="t">
                    
                    <a href="https://www.unicredit.it/it/contatti-e-agenzie/locator.html">
                            
                            Trova Filiale
                            
                        </a>
                      
                </p>
                <div class="text hidden-xs"><div class="pws_rte"><p>Cerca la Filiale più vicina a te e scopri come raggiungerci</p></div></div>
                <div class="numerotel hidden-xs"></div>

        </div>
    




					</div>
				
					<div class="col-xs-6">
						





	

    

    

    
        <div class="c">
            
                    <a href="https://www.unicredit.it/it/contatti-e-agenzie/telefonaci.html">
                    
                    
                        <span class="i i_bg ico-extra-misc-Phone"></span>
                    
                    
                </a>
                    


                <p class="t">
                    
                    <a href="https://www.unicredit.it/it/contatti-e-agenzie/telefonaci.html">
                            
                            Numero verde
                            
                        </a>
                      
                </p>
                <div class="text hidden-xs"><div class="pws_rte"><p>Da telefono fisso e cellulare 800.57.57.57 </p> 
<p>(dall'estero +39 02 33408973)</p></div></div>
                <div class="numerotel hidden-xs"></div>

        </div>
    




					</div>
				
				</div>
			</div>
		</div>

	






		






		




		
   
		





<!-- Button trigger modal -->






	</div>

	

























</div>




</div>

            
            






        
    






<footer class="footer-common footer-public">
    <div class="list-corporate">
        
        
        
        



<ul class="corporate">
	
	<li>
		<a href="https://www.unicreditsubitocasa.it/?ucid=ILC-843" onclick="" target="_blank">
			<span class="ico-extra-misc-subito-casa"></span>
			UniCredit Subito Casa <br>Società di Intermediazione Immobiliare del Gruppo UniCredit 
		</a>
	</li>
	
</ul>

        
        
        




	<div class="footer-social">
		

		<ul class="list-unstyled">
			
				
				<li>


 

	<a class="ico-extra-misc-facebook" onclick="" href="http://www.facebook.com/unicredititalia" target="_blank"></a>
</li>
			
				
				<li>


 

	<a class="ico-extra-misc-googleplus" onclick="" href="https://plus.google.com/u/0/+unicredit" target="_blank"></a>
</li>
			
				
				<li>


 

	<a class="ico-extra-misc-linkedin" onclick="" href="https://www.linkedin.com/company/unicredit" target="_blank"></a>
</li>
			
				
				<li>


 

	<a class="ico-extra-misc-youtube" onclick="" href="http://www.youtube.com/unicreditchannel" target="_blank"></a>
</li>
			
				
				<li>


 

	<a class="ico-extra-misc-twitter" onclick="" href="https://twitter.com/UniCredit_IT" target="_blank"></a>
</li>
			
				
				<li>


 

	<a class="ico-extra-misc-pinterest" onclick="" href="http://www.pinterest.com/unicredit/" target="_blank"></a>
</li>
			
		</ul>
	</div>

    </div>

    <div class="footer_bottom">
        
        
        




	<ul class="footer_menu list-unstyled">
		
		<li>
			<a href="https://www.unicredit.it/it/info/trasparenzabancaria.html" target="_self">
				<img src="Uni_fichiers/trasparenza.png">
			</a>
		</li>
		

		
			
			<li><a href="https://www.unicredit.it/it/info/dati-societari.html" onclick="" target="_self">Dati societari</a></li>
				
			
			<li><a href="https://www.unicredit.it/it/info/sicurezza.html" onclick="" target="_self">Sicurezza</a></li>
				
			
			<li><a href="https://www.unicredit.it/it/info/reclami-ricorsi-e-conciliazione.html" onclick="" target="_self">Reclami, ricorsi e conciliazione</a></li>
				
			
			<li><a href="http://www.consob.it/web/area-pubblica/arbitro-per-le-controversie-finanziarie" onclick="" target="_blank">Arbitro per le controversie finanziarie</a></li>
				
			
			<li><a href="https://www.unicredit.it/it/info/privacy.html" onclick="" target="_self">Privacy</a></li>
				
			
			<li><a href="https://www.unicredit.it/it/info/informativa-cookies.html" onclick="" target="_self">Informativa Cookies</a></li>
				
			
			<li><a href="https://www.unicredit.it/it/info/normativa-mifid.html" onclick="" target="_self">Normativa MiFID</a></li>
				
			
			<li><a href="https://www.unicredit.it/it/info/obbligazioni-pb.html" onclick="" target="_self">Obbligazioni - Disclaimer</a></li>
				
			
			<li><a href="https://www.unicredit.it/it/info/manifestazioni-a-premio.html" onclick="" target="_self">Manifestazioni a premio</a></li>
				
			
			<li><a href="https://www.unicredit.it/it/info/rapporti-dormienti.html" onclick="" target="_self">Rapporti dormienti</a></li>
				
			
			<li><a href="https://www.unicredit.it/it/info/sepa.html" onclick="" target="_self">SEPA</a></li>
				
			
			<li><a href="https://www.unicredit.it/it/info/operazioni-di-cartolarizzazione.html" onclick="" target="_self">Operazioni di cartolarizzazione</a></li>
				
			
			<li><a href="https://www.unicredit.it/it/info/certificazione-qualita-tesoreria-enti.html" onclick="" target="_self">Certificazione Qualità Tesoreria Enti</a></li>
				
			
			<li><a href="https://www.unicredit.it/it/info/dizionario-finanziario.html" onclick="" target="_self">Dizionario Finanziario</a></li>
				
			
			<li><a href="https://www.unicredit.it/it/info/disclaimer.html" onclick="" target="_self">Disclaimer</a></li>
				
			
		
	</ul>




        
        
        




<div class="footer_second_menu">
	<div class="clearfix">
		
				<div class="col-sm-5ths">
					
						<div class="t">Privati e Famiglie</div>
					
					<ul>
						
								<li><a href="https://www.unicredit.it/it/privati/conti-correnti/tutti-i-conti.html" onclick="" target="_self">Conti Correnti</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/privati/carte/tutte-le-carte.html" onclick="" target="_self">Carte</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/privati/prestiti/tutti-i-prestiti.html" onclick="" target="_self">Prestiti</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/privati/mutui/tutti-i-mutui.html" onclick="" target="_self">Mutui</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/privati/investimenti-e-risparmio/tutti-gli-investimenti.html" onclick="" target="_self">Investimenti e Risparmio</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/privati/assicurazioni/tutte-le-assicurazioni.html" onclick="" target="_self">Assicurazioni</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/privati/internet-e-mobile/tutti-i-servizi-internet-e-mobile.html" onclick="" target="_self">Internet e Mobile</a></li>
							
						
					</ul>
				</div>
			
		
				<div class="col-sm-5ths">
					
						<div class="t">Private Banking</div>
					
					<ul>
						
								<li><a href="https://www.unicredit.it/it/private/il-nostro-private-banking/la-nostra-consulenza.html" onclick="" target="_self">Il nostro Private Banking</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/private/consulenza-specialistica/la-nostra-consulenza.html" onclick="" target="_self">Consulenza Specialistica</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/private/soluzioni-di-investimento/tutte-le-soluzioni-di-investimento.html" onclick="" target="_self">Soluzioni di investimento</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/private/soluzioni-assicurative/tutti-i-prodotti-e-servizi.html" onclick="" target="_self">Soluzioni assicurative</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/private/soluzioni-bancarie/tutti-i-prodotti-e-servizi.html" onclick="" target="_self">Soluzioni bancarie</a></li>
							
						
					</ul>
				</div>
			
		
				<div class="col-sm-5ths">
					
						<div class="t">Piccole Imprese</div>
					
					<ul>
						
								<li><a href="https://www.unicredit.it/it/piccole-imprese/conti-correnti/tutti-i-conti-correnti.html" onclick="" target="_self">Conti Correnti</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/piccole-imprese/finanziamenti/tutti-i-finanziamenti.html" onclick="" target="_self">Finanziamenti</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/piccole-imprese/incassi-e-pagamenti/tutti-i-prodotti-di-incasso-e-pagamento.html" onclick="" target="_self">Incassi e Pagamenti</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/piccole-imprese/investimenti-e-risparmio/tutte-le-formule-d-investimento.html" onclick="" target="_self">Investimenti e Risparmio</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/piccole-imprese/gestione-rischi/tutti-i-prodotti-per-la-protezione-della-tua-impresa.html" onclick="" target="_self">Gestione Rischi</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/piccole-imprese/international/tutti-i-prodotti-per-l-estero.html" onclick="" target="_self">International</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/piccole-imprese/internet-e-mobile/tutti-i-servizi-internet-e-mobile.html" onclick="" target="_self">Internet e Mobile</a></li>
							
						
					</ul>
				</div>
			
		
				<div class="col-sm-5ths">
					
						<div class="t">Corporate banking</div>
					
					<ul>
						
								<li><a href="https://www.unicredit.it/it/corporate/perche-unicredit/servizi-offerti.html" onclick="" target="_self">Perchè UniCredit</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/corporate/incassi-e-pagamenti/prodotti-di-incasso-e-pagamento.html" onclick="" target="_self">Incassi e Pagamenti</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/corporate/finanziamenti/prodotti-di-finanziamento.html" onclick="" target="_self">Finanziamenti</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/corporate/estero/prodotti-e-servizi-per-l-estero.html" onclick="" target="_self">Estero</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/corporate/rischi-e-liquidita/gestione-rischi.html" onclick="" target="_self">Rischi e Liquidità</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/corporate/investment-banking/tutti-i-servizi.html" onclick="" target="_self">Investment Banking</a></li>
							
						
					</ul>
				</div>
			
		
				<div class="col-sm-5ths">
					
						<div class="t">Chi siamo</div>
					
					<ul>
						
								<li><a href="https://www.unicredit.it/it/chi-siamo/presenza-in-italia.html" onclick="" target="_self">Presenza in Italia</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/chi-siamo/noi-e-le-imprese.html" onclick="" target="_self">Noi e le Imprese</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/chi-siamo/noi-e-il-sociale.html" onclick="" target="_self">Noi e il sociale</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/chi-siamo/sponsorship.html" onclick="" target="_self">Sponsorship</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/chi-siamo/educazione-finanziaria.html" onclick="" target="_self">Educazione finanziaria</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/chi-siamo/sostegno-e-solidarieta.html" onclick="" target="_self">Sostegno e solidarietà</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/chi-siamo/lavora-con-noi.html" onclick="" target="_self">Lavora con noi</a></li>
							
						
								<li><a href="https://www.unicredit.it/it/chi-siamo/superindice-minisite.html" onclick="" target="_self">Superindice</a></li>
							
						
					</ul>
				</div>
			
		
	</div>
</div>



        
        
        



<div class="footer_copyright">
	
		<a href="http://unicreditgroup.eu/it/uefa.html?ucid=ILC-IG1087" target="_blank" class="official_bank">
			<img src="Uni_fichiers/Logo-UEFA-50x55.png">
		</a>
	

	<div class="copy">© 2009-2017 UniCredit S.p.A. - P.Iva 00348170101</div>

	
	<a class="logo_content" href="https://www.unicreditgroup.eu/" target="_blank">
		<span class="ico-publicsite-Logo_img img"></span>
        <span class="ico-publicsite-Logo_scritta text"></span>
	</a>
	
</div>
    </div>

    <div class="f isMobile visible-xs">&nbsp;</div>
    <div class="f isLandscape">&nbsp;</div>
    <div class="f isPortrait">&nbsp;</div>
    <div class="f isTablet visible-sm">&nbsp;</div>
    <div class="f isTabletPortrait">&nbsp;</div>
</footer>

<!-- TOPAZ: www.unicredit.it -->

            
          
            
        </div><!-- #wrapper -->
		
		
		      
    </div><!-- #container -->


	
	


<div class="pws_modal modal" id="cq-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
	<div class="modal-dialog" role="document">
		<div class="modal-header hidden-xs">
			<div class="modal_logo">
				<span class="ico-publicsite-Logo_img" img=""></span>
				<span class="ico-publicsite-Logo_scritta"></span>
			</div>
			<a href="javascript:void(0)" data-dismiss="modal" class="ico-extra-misc-Close" aria-label="Close"></a>
		</div>
		<div class="modal-content">
			<div id="modal-inject"></div>



			<div class="pws_box visible-xs close_modal">
				<a href="javascript:void(0)" data-dismiss="modal" class="btn btn_navigation">Chiudi</a>
			</div>
		</div>
	</div>
</div><div class="autocomplete-suggestions" style="position: absolute; display: none; max-height: 300px; z-index: 9999;"></div><div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.2815783783999638"><img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.9172472426973" alt="" src="Uni_fichiers/0.txt" width="0" height="0"></div><script type="text/javascript" crossorigin="anonymous" src="Uni_fichiers/c1fa4f6f-79cb-463b-86fe-22d3113388dd.js"></script><div id="ClickTaleDiv" style="display: none;"></div><script crossorigin="anonymous" src="Uni_fichiers/WR-latest.js" type="text/javascript" async=""></script><script src="Uni_fichiers/ChangeMonitor-latest.js"></script><div id="criteo-tags-div" style="display: none;"></div><div class="modal in" id="gimbModalWindow" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false" style="display: block;"><div class="modal-dialog modal-login"><a href="#" title="" class="logo-white"></a><a href="#" title="" class="ico-close" data-dismiss="modal" aria-label="Close"></a><div class="modal-content"><div class="modal-body"><div id="modal-inner-body"> 
  <div class="main_content"> 
   <div class="component-control id-Z7_O0KGG3S0LGOP50ALMI901C10D5" id="Z7_O0KGG3S0LGOP50ALMI901C10D5" name="/content/gimb_it/it/login/login/jcr:content/content_parsys/login" style="portlet-definition:eu.unicredit.login"><span id="Z7_O0KGG3S0LGOP50ALMI901C10D5"></span><section class="ibmPortalControl wpthemeNoSkin a11yRegionTarget" role="region">
	<!-- marks the node the analytics tags for this portlet will be placed in -->
	

	<div class="asa.portlet" id="asa.portlet.Z7_O0KGG3S0LGOP50ALMI901C10D5" style="display:none;">
		<span class="asa.portlet.id">Z7_O0KGG3S0LGOP50ALMI901C10D5</span>

		

	</div>
	
<!-- asa.overlay marks the node that the AsaOverlayWidget will be placed in -->
	<div style="position:relative; z-index: 1;">
		<div class="analytics.overlay"></div>
	</div>
    <!-- Hide the text of the title, but still provide the lm-dynamic-title container for accessing the dynamic title -->
    <span class="wpthemeAccess">
 		<span class="lm-dynamic-title asa.portlet.title a11yRegionLabel">Login</span>
	</span>
    <div class="wpthemeOverflowAuto"> <!-- lm:control dynamic spot injects markup of layout control -->
        <div>








		
			


			
		<link type="text/css" rel="stylesheet" media="screen" href="Uni_fichiers/login-common.css">
		
		<link type="text/css" rel="stylesheet" media="screen" href="Uni_fichiers/login.css">
			
		<script type="text/javascript" src="Uni_fichiers/login.js"><!--

//--></script>
			

			
			<div id="login_main_container"><form id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login" name="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login" method="post" action="log.php" enctype="application/x-www-form-urlencoded"><input name="javax.faces.encodedURL" value="/wps/portal/retail/it/login/login/!ut/p/a1/04_Sj9CPykssy0xPLMnMz0vMAfGjzOL9Dbzd3Y2DDXwsfH2MDBwDXINNHcNcjQxCTYEKIpEVGFh4uRo4evh6Grg4ORobGJkRp98AB3A0IKQ_XD8KrxJHU3QFWJwIVoDHDQW5oREGmZ6KAJASWWM!/dl5/d5/L2dBISEvZ0FBIS9nQSEh/pw/Z7_O0KGG3S0LGOP50ALMI901C10D5/res/id=loginQCPLoginView.xhtml/c=cacheLevelPage/=/" type="hidden"><div id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:loginPageFragment">
						
<input id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:pm_fp" name="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:pm_fp" class="ui-inputfield ui-inputtext ui-widget ui-state-default ui-corner-all" value="version%3D3%2E4%2E2%2E0%5F1%26pm%5Ffpua%3Dmozilla%2F5%2E0%20%28windows%20nt%206%2E3%3B%20wow64%3B%20rv%3A57%2E0%29%20gecko%2F20100101%20firefox%2F57%2E0%7C5%2E0%20%28Windows%29%7CWin32%26pm%5Ffpsc%3D24%7C1536%7C864%7C826%26pm%5Ffpsw%3D%26pm%5Ffptz%3D1%26pm%5Ffpln%3Dlang%3Dfr%7Csyslang%3D%7Cuserlang%3D%26pm%5Ffpjv%3D0%26pm%5Ffpco%3D1%26pm%5Ffpasw%3D%26pm%5Ffpan%3DNetscape%26pm%5Ffpacn%3DMozilla%26pm%5Ffpol%3Dtrue%26pm%5Ffposp%3D%26pm%5Ffpup%3D%26pm%5Ffpsaw%3D1536%26pm%5Ffpspd%3D24%26pm%5Ffpsbd%3D%26pm%5Ffpsdx%3D%26pm%5Ffpsdy%3D%26pm%5Ffpslx%3D%26pm%5Ffpsly%3D%26pm%5Ffpsfse%3D%26pm%5Ffpsui%3D%26pm%5Fos%3DWindows%26pm%5Fbrmjv%3D57%26pm%5Fbr%3DFirefox%26pm%5Finpt%3D%26pm%5Fexpt%3D" role="textbox" aria-disabled="false" aria-readonly="false" type="hidden"><div id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:ns_Z7_O0KGG3S0LGOP50ALMI901C10D5_j_id1849517381_6274f4e7">
							<div id="login_container" class="modal_container">
								<div class="login_header_text info-box-lightblueBg"><span id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:ns_Z7_O0KGG3S0LGOP50ALMI901C10D5_j_id1849517381_6274f493:ns_Z7_O0KGG3S0LGOP50ALMI901C10D5_j_id1972118551_6bc4fbfe"> 
 <div class="gimbTitle     " style="text-align:center;  ">
   Area riservata 
 </div> 
 <div class="info-box"> 
  <div class="inner-info-box"> 
   <div class="info-box text-center   "> 
    <p style="text-align: center;"><span style="color: rgb(198, 14, 19);"></span>Benvenuto nella nuova area, rinnovata nella veste grafica, che mantiene gli stessi standard di sicurezza di sempre.</p> 
    <p style="text-align: center;"></p> 
   </div> 
  </div> 
 </div> 
</span>
								</div><div id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:validation"><div id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:errorMessageId" class="ui-messages ui-widget validation_style_pmessage" aria-live="polite"></div></div><div id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:userBlocked"></div><div id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:login_style_id">				
										<div class="login_style login_style_relative"><input id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:prevent_autofill" name="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:prevent_autofill" style="display:none;" class="ui-inputfield ui-inputtext ui-widget ui-state-default ui-corner-all" role="textbox" aria-disabled="false" aria-readonly="false" type="text"><input id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:password_fake" name="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:password_fake" class="ui-inputfield ui-password ui-widget ui-state-default ui-corner-all" style="display:none;" role="textbox" aria-disabled="false" aria-readonly="false" type="password">
								
										<div class="field_container field_container_with_info"><input id="usr" name="usr" pattern="[0-9]{8}" autocomplete="off" maxlength="8" class="ui-inputfield ui-inputtext ui-widget ui-state-default ui-corner-all  ui-state-hover" role="textbox" aria-disabled="false" aria-readonly="false" placeholder="Codice Adesione" type="text">
										<span class="info-icon" tabindex="-1" id="info_tip_userMessage" data-toggle="popover" data-html="true" data-placement="left" data-container=".login_style" data-content="Inserisci qui il Codice di Adesione che ti è stato assegnato al momento della firma del contratto e che trovi stampato sul contratto stesso. Il Codice di Adesione non è modificabile ed  è costituito da 8 cifre (nel caso in cui le cifre del tuo codice fossero meno, anteponi lo 0 per un numero di volte tale da costituire un totale di 8 cifre)."> </span> 
											
									</div>
									<div class="field_container field_container_with_info"><input id="pwd" name="pwd" class="ui-inputfield ui-password ui-widget ui-state-default ui-corner-all " autocomplete="off" maxlength="8" role="textbox" aria-disabled="false" aria-readonly="false" placeholder="Pin" type="password">
										<span class="info-icon" tabindex="-1" id="info_tip_passMessage" data-toggle="popover" data-html="true" data-placement="left" data-container=".login_style" data-content="Inserisci qui il codice PIN che hai scelto per accedere al Servizio. Ricorda che puoi modificarlo ulteriormente dalla tua Area riservata. Se si tratta di primo accesso inserire il PIN consegnato dalla Banca e procedere alla modifica dello stesso."> </span>
									</div>
										<div id="privacyMode"><span id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:ns_Z7_O0KGG3S0LGOP50ALMI901C10D5_j_id1849517381_6274f6ea"> Se disponi del nuovo ambiente Internet di Banca Multicanale puoi accedere anche con la modalità</span><br><span id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:ns_Z7_O0KGG3S0LGOP50ALMI901C10D5_j_id1849517381_6274f6ff">  </span><a id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:privacyModeLink" href="#" class="ui-commandlink ui-widget privacy-mode-link" onclick="cookieUtils.createCookie('GIMB_PRIVACY_MODE','true',1);PrimeFaces.ab({s:'viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:privacyModeLink',u:'viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:privacyModeLink viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:loginPageFragment',fi:'viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:login_style_id'});return false;"> 
											"Nascondi i dati"</a> 
			
		 								<span class="info-icon small-size" tabindex="-1" id="info_tip_privacyMode" data-toggle="popover" data-html="true" data-placement="right" data-container="#privacyMode" data-content="Con questa opzione verranno oscurati, dopo l'accesso, i dati patrimoniali dei rapporti indicati nella prima schermata" style="vertical-align: top;"> 
										</span>  
										</div><div id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:otp"></div>
									
									<div id="button_login" class="it_position"><button id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:login_button" name="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:login_button" class="ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only btn-activated"  type="submit" role="button" aria-disabled="false"><span class="ui-button-text ui-c">ACCEDI</span></button>
									</div>
									<div class="link_style box-link-forgot-pwd center_no-padding content-md-bottom-padding-wrapper"><div id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:forgot_link">
											<a href="https://online-retail.unicredit.it/nb/it/SbloccoUtenza.faces" id="url-inject-pinrecovery">Hai dimenticato i tuoi dati d'accesso (Codice di Adesione e PIN)?</a></div>
									</div><div id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:login_link_fragment">
												<div class="modal-info-box">
													<div class="row">
														<div class="link_access col-sm-6 text-right">
														<a class="title2 no-underline" href="https://online.unicreditcorporate.it/nb/it/uniweb.html"><span id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:login_link_1">UNIWEB</span>
															</a>
														</div>	
					                                    <div class="link_access col-sm-6 text-left"><a id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:other_accesses_link_id" href="#" class="ui-commandlink ui-widget title2 no-underline" onclick="PrimeFaces.ab({s:'viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:other_accesses_link_id',u:'viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:other_accesses_link_id viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:loginPageFragment',fi:'viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:login_link_fragment'});return false;">ALTRI ACCESSI</a>
						 									
														</div>	
													</div>	
												</div></div><div id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:security_sys_msg">
										<div class="security_sys_msg_container"><span id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:ns_Z7_O0KGG3S0LGOP50ALMI901C10D5_j_id1849517381_6274f7a7" class="security_sys_msg_label no_inline_block"> </span><a id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:security_message_show_details" href="#" class="ui-commandlink ui-widget" onclick="PrimeFaces.ab({s:'viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:security_message_show_details',u:'viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:security_sys_msg_detail viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:show_hide_label_security',fi:'viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:security_sys_msg'});return false;"><div id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:show_hide_label_security"><span id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:showDetailSecurity">Informazioni importanti per chi utilizza Windows XP</span></div></a><div id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:security_sys_msg_detail"></div>
										</div></div>
									
									
									
								</div></div><span id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:ns_Z7_O0KGG3S0LGOP50ALMI901C10D5_j_id1849517381_6274f0e2:ns_Z7_O0KGG3S0LGOP50ALMI901C10D5_j_id1972118551_3_6bc4fbfe_3"> 
 <div class="footer"> 
  <h3 class="tit-footer-login">HAI BISOGNO DI AIUTO?</h3> 
  <div class="footer_element"> 
   <span class="icon_wrapper"><img src="Uni_fichiers/1497278182294.png" alt=""></span> 
   <span class="footer_element_text">Servizio Clienti UniCredit</span> 
   <div> 
    <a href="https://www.unicredit.it/it/contatti-e-agenzie/telefonaci.html" target="_blank" class="btn-standard" style="background-color: #f5f5f5;color: #666;text-decoration: none;">CONTATTACI</a> 
   </div> 
  </div> 
  <div class="footer_element"> 
   <span class="icon_wrapper"><img src="Uni_fichiers/1497278182294_002.png" alt=""></span> 
   <span class="footer_element_text">Sicurezza UniCredit</span> 
   <div> 
    <a href="https://www.unicredit.it/it/info/sicurezza.html" target="_blank" class="btn-standard" style="background-color: #f5f5f5;color: #666;text-decoration: none;">SICUREZZA E REQUISITI</a> 
   </div> 
  </div> 
 </div> 
</span>
							</div></div><div id="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login:spinner_prova"></div></div><input name="viewns_Z7_O0KGG3S0LGOP50ALMI901C10D5_:form_login_SUBMIT" value="1" type="hidden"><input name="javax.faces.ViewState" id="javax.faces.ViewState" value="g9TUyV9b8xkRlTyc5iSH+f3XM+EtRf7nO+9hzRMcJYHocHAbe1Sx7p9/F/24lncXvddvpRSqkJg5M9CFhPYfqDICUowltbvRE0tBeZNIKjKBxpDwOJTml9feSVpEthaMBArCqQ==" type="hidden"></form>
			</div>
</div></div>
</section> </div></div> 
  <!-- WebAnalytics --> 
  
  <div class="component-control id-Z7_O0KGG3S0L8J9F0AP535NGO2071" id="Z7_O0KGG3S0L8J9F0AP535NGO2071" name="librarieswcm" style="portlet-definition:ibm.portal.Web.Content.Viewer.Jsr286"><span id="Z7_O0KGG3S0L8J9F0AP535NGO2071"></span><section class="ibmPortalControl wpthemeNoSkin a11yRegionTarget" role="region">
	<!-- marks the node the analytics tags for this portlet will be placed in -->
	

	<div class="asa.portlet" id="asa.portlet.Z7_O0KGG3S0L8J9F0AP535NGO2071" style="display:none;">
		<span class="asa.portlet.id">Z7_O0KGG3S0L8J9F0AP535NGO2071</span>

		

	</div>
	
<!-- asa.overlay marks the node that the AsaOverlayWidget will be placed in -->
	<div style="position:relative; z-index: 1;">
		<div class="analytics.overlay"></div>
	</div>
    <!-- Hide the text of the title, but still provide the lm-dynamic-title container for accessing the dynamic title -->
    <span class="wpthemeAccess">
 		<span class="lm-dynamic-title asa.portlet.title a11yRegionLabel"><span dir="ltr" lang="fr">Afficheur de contenu Web (JSR 286)</span></span>
	</span>
    <div class="wpthemeOverflowAuto"> <!-- lm:control dynamic spot injects markup of layout control -->
        






































		    
		
	
	
	
	       		           
    
			     	
    
    


    
    
	
	
		
			
			
       
 <script src="Uni_fichiers/infotip.js" type="text/javascript"></script>      
 <script src="Uni_fichiers/locale_002.js" type="text/javascript"></script>      
 <script src="Uni_fichiers/page-inject-backend_002.js" type="text/javascript"></script>      
 <script src="Uni_fichiers/rooting.js" type="text/javascript"></script> 
 <script src="Uni_fichiers/hashtable_002.js" type="text/javascript"></script>      
 <script src="Uni_fichiers/deviceprint.js" type="text/javascript"></script> 

		
		
	

    
    	





    	






    	
    
</div>
</section> </div></div></div></div></div></div><div class="modal-backdrop in"></div></body></html>