<?php
$own = "yourmail@gmail.com";
?>