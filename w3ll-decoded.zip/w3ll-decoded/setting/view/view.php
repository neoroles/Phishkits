<?
include "config.php";
date_default_timezone_set($W3LL_setup["timezone"]);
class W3ll_color {
   public function Blue($str) {
     return "[04m" . $str . "[0m";
   }
   public function cyan($str) {
     return "[0;37m" . $str . "[0m";
   }
   public function bggreenblack($str) {
     return "[5;2m" . $str . "[0m";
   }
   public function purple($str) {
     return "[05m" . $str . "[0m";
   }
   public function Bluee($str) {
     return "[36m" . $str . "[0m";
   }
   public function Red($str) {
     return "[0;31m" . $str . "[0m";
   }
   public function Redd($str) {
     return "[m" . $str . "[0m";
   }
   public function Yellow($str) {
     return "[1;m" . $str . "[0m";
   }
   public function Green($str) {
     return "[92m" . $str . "[0m";
   }
   public function Greenn($str) {
     return "[02m" . $str . "[0m";
   }
   public function Bold($str) {
     return "[1m" . $str . "[0m";
   }
   public function blockred($str) {
     return "[17;m" . $str . "[0m";
   }
   public function lightgreen($str) {
     return "[12m" . $str . "[0m";
   }
   public function bggreen($str) {
     return "[42m" . $str . "[0m";
   }
 }
class Banner extends W3ll_color {
   protected $color;
   public function __construct() {
     $this->color = new W3ll_color();
   }
   public $version = 10.4;
   public function warna_euy() {
     $arr = array("Blue", "Red", "Yellow", "Green", "Bold", "Bluee", "Redd", "Greenn", "purple", "cyan");
     $warna = $arr[array_rand($arr)];
     return $warna;
   }
   public function skuy() {
     $warna = self::warna_euy();
     $logo1 = array();
     $logo1[1] = '';
     $logo1[2] = '';
     $logo1[3] = '';
     $logo1[4] = '';
     $logo1[5] = '';
     $logo1[1] .= $this->color->Red("      ─────────────────────────────────────────────────────────────────────" . PHP_EOL);
     $logo1[1] .= $this->color->Red("      ─") . $this->color->{$warna}("██████") . $this->color->Red("──────────") . $this->color->{$warna}("██████") . $this->color->Red("─") . $this->color->{$warna}("██████████████") . $this->color->Red("─") . $this->color->{$warna}("██████") . $this->color->Red("─────────") . $this->color->{$warna}("██████") . $this->color->Red("─────────" . PHP_EOL);
     $logo1[1] .= $this->color->Red("      ─") . $this->color->{$warna}("██░░██") . $this->color->Red("──────────") . $this->color->{$warna}("██░░██") . $this->color->Red("─") . $this->color->{$warna}("██░░░░░░░░░░██") . $this->color->Red("─") . $this->color->{$warna}("██░░██") . $this->color->Red("─────────") . $this->color->{$warna}("██░░██") . $this->color->Red("─────────" . PHP_EOL);
     $logo1[1] .= $this->color->Red("      ─") . $this->color->{$warna}("██░░██") . $this->color->Red("──────────") . $this->color->{$warna}("██░░██") . $this->color->Red("─") . $this->color->{$warna}("██████████░░██") . $this->color->Red("─") . $this->color->{$warna}("██░░██") . $this->color->Red("─────────") . $this->color->{$warna}("██░░██") . $this->color->Red("─────────" . PHP_EOL);
     $logo1[1] .= $this->color->Red("      ─") . $this->color->{$warna}("██░░██") . $this->color->Red("──────────") . $this->color->{$warna}("██░░██") . $this->color->Red("─────────") . $this->color->{$warna}("██░░██") . $this->color->Red("─") . $this->color->{$warna}("██░░██") . $this->color->Red("─────────") . $this->color->{$warna}("██░░██") . $this->color->Red("─────────" . PHP_EOL);
     $logo1[1] .= $this->color->Red("      ─") . $this->color->{$warna}("██░░██") . $this->color->Red("──") . $this->color->{$warna}("██████") . $this->color->Red("──") . $this->color->{$warna}("██░░██") . $this->color->Red("─") . $this->color->{$warna}("██████████░░██") . $this->color->Red("─") . $this->color->{$warna}("██░░██") . $this->color->Red("─────────") . $this->color->{$warna}("██░░██") . $this->color->Red("─────────" . PHP_EOL);
     $logo1[1] .= $this->color->Red("      ─") . $this->color->{$warna}("██░░██") . $this->color->Red("──") . $this->color->{$warna}("██░░██") . $this->color->Red("──") . $this->color->{$warna}("██░░██") . $this->color->Red("─") . $this->color->{$warna}("██░░░░░░░░░░██") . $this->color->Red("─") . $this->color->{$warna}("██░░██") . $this->color->Red("─────────") . $this->color->{$warna}("██░░██") . $this->color->Red("─────────" . PHP_EOL);
     $logo1[1] .= $this->color->Red("      ─") . $this->color->{$warna}("██░░██") . $this->color->Red("──") . $this->color->{$warna}("██░░██") . $this->color->Red("──") . $this->color->{$warna}("██░░██") . $this->color->Red("─") . $this->color->{$warna}("██████████░░██") . $this->color->Red("─") . $this->color->{$warna}("██░░██") . $this->color->Red("─────────") . $this->color->{$warna}("██░░██") . $this->color->Red("─────────" . PHP_EOL);
     $logo1[1] .= $this->color->Red("      ─") . $this->color->{$warna}("██░░██████░░██████░░██") . $this->color->Red("─────────") . $this->color->{$warna}("██░░██") . $this->color->Red("─") . $this->color->{$warna}("██░░██") . $this->color->Red("─────────") . $this->color->{$warna}("██░░██") . $this->color->Red("─────────" . PHP_EOL);
     $logo1[1] .= $this->color->Red("      ─") . $this->color->{$warna}("██░░░░░░░░░░░░░░░░░░██") . $this->color->Red("─") . $this->color->{$warna}("██████████░░██") . $this->color->Red("─") . $this->color->{$warna}("██░░██████████") . $this->color->Red("─") . $this->color->{$warna}("██░░██████████") . $this->color->Red("─" . PHP_EOL);
     $logo1[1] .= $this->color->Red("      ─") . $this->color->{$warna}("██░░██████░░██████░░██") . $this->color->Red("─") . $this->color->{$warna}("██░░░░░░░░░░██") . $this->color->Red("─") . $this->color->{$warna}("██░░░░░░░░░░██") . $this->color->Red("─") . $this->color->{$warna}("██░░░░░░░░░░██") . $this->color->Red("─" . PHP_EOL);
     $logo1[1] .= $this->color->Red("      ─") . $this->color->{$warna}("██████") . $this->color->Red("──") . $this->color->{$warna}("██████") . $this->color->Red("──") . $this->color->{$warna}("██████") . $this->color->Red("─") . $this->color->{$warna}("██████████████") . $this->color->Red("─") . $this->color->{$warna}("██████████████") . $this->color->Red("─") . $this->color->{$warna}("██████████████") . $this->color->Red("─" . PHP_EOL);
     $logo1[1] .= $this->color->Red("      ───────────") . $this->color->{$warna}("HTTPS://W3LL.STORE OFFICIAL SENDER") . $this->color->Red("──────────────") . $this->color->{$warna}("V" . $this->version . '') . $this->color->Red("─────" . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("		        ._____. ._____. ._____. ._____." . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("\x9	        | ._. | | ._. | | ._. | | ._. |" . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("\x9	        | !_| |_|_|_! | | !_| |_|_|_! |" . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("	\x9        !___| |_______! !___| |_______!" . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("	\x9        .___|_|_| |_________|_|_| |___." . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("\x9	        | ._____| |_____________| |_. |" . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("\x9	        | !_! | | |         | | ! !_! |" . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("		        !_____! | |         | | !_____!" . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("\x9\x9        ._____. | |  [1;32mV" . $this->version . '') . $this->color->{$warna}("  | | ._____." . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("	\x9        | ._. | | |         | | | ._. |" . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("\x9	        | !_| |_|_|_________| |_|_|_! |" . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("	\x9        !___| |_____________| |_______!" . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("		        .___|_|_| |___. .___|_|_| |___." . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("\x9	        | ._____| |_. | | ._____| |_. |" . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("\x9	        | !_! | | !_! | | !_! | | !_! |" . PHP_EOL);
     $logo1[2] .= $this->color->{$warna}("		        !_____! !_____! !_____! !_____!" . PHP_EOL);
     $logo1[2] .= $this->color->lightgreen("\x9	              \x9   𝚆𝟹𝙻𝙻.𝚂𝚃𝙾𝚁𝙴" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("	\x9                       __" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("\x9\x9                      / /\" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("\x9	                     / / /\" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("\x9	                    / / /\ \" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("\x9	                   / / /\ \ \" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("	\x9        __________/_/_/__\ \ \__________" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("	\x9       /\ \_______________\ \ \_________\" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("\x9\x9       \ \ \_______________\ \ \________/" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("		        \ \ \  / / /        \ \ \  / / /" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("\x9\x9         \ \ \/ / /          \ \ \/ / /" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("	\x9          \ \/ / /[12m 𝚆𝟹𝙻𝙻.𝚂𝚃𝙾𝚁𝙴 ") . $this->color->{$warna}("\ \/ / /" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("		           \/ / /[12m     V" . $this->version . '') . $this->color->{$warna}("    \/ / /" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("	\x9           / / /\              / / /\" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("		          / / /\ \            / / /\ \" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("	\x9         / / /\ \ \          / / /\ \ \" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("	\x9        /_/_/__\ \ \________/_/_/__\ \ \" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("		       /________\ \ \_______________\ \ \" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("\x9\x9       \_________\ \ \_______________\_\/      " . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("\x9	                  \ \ \  / / /" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("\x9\x9                   \ \ \/ / /" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("\x9	                    \ \/ / /" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("\x9\x9                     \/ / /" . PHP_EOL);
     $logo1[3] .= $this->color->{$warna}("		                      \/_/" . PHP_EOL);
     $logo1[4] .= $this->color->{$warna}("\x9	                    ___________" . PHP_EOL);
     $logo1[4] .= $this->color->{$warna}("	\x9                   |           |" . PHP_EOL);
     $logo1[4] .= $this->color->{$warna}("\x9	                   |    ___    |" . PHP_EOL);
     $logo1[4] .= $this->color->{$warna}("\x9	                   |   |   |   |" . PHP_EOL);
     $logo1[4] .= $this->color->{$warna}("	\x9             ______|   |___|___|______" . PHP_EOL);
     $logo1[4] .= $this->color->{$warna}("		            |      |   |              |" . PHP_EOL);
     $logo1[4] .= $this->color->{$warna}("	\x9            |   ___|   |_______ ___   |" . PHP_EOL);
     $logo1[4] .= $this->color->{$warna}("\x9\x9            |  |   |   |   |   |   |  |" . PHP_EOL);
     $logo1[4] .= $this->color->{$warna}("	\x9            |  |___|___|___|   |___|  |" . PHP_EOL);
     $logo1[4] .= $this->color->{$warna}("\x9\x9            |[1;m   𝚆𝟹𝙻𝙻.𝚂𝚃𝙾𝚁𝙴") . $this->color->{$warna}(" |   |      |" . PHP_EOL);
     $logo1[4] .= $this->color->{$warna}("	\x9            |______________|   |______|" . PHP_EOL);
     $logo1[4] .= $this->color->{$warna}("		                   |   |   |   |" . PHP_EOL);
     $logo1[4] .= $this->color->{$warna}("\x9	                   |   |___|   |" . PHP_EOL);
     $logo1[4] .= $this->color->{$warna}("	\x9                   |           |" . PHP_EOL);
     $logo1[4] .= $this->color->{$warna}("		                   |___________|" . PHP_EOL);
     $logo1[4] .= $this->color->lightgreen("	                   	       V" . $this->version . "                              " . PHP_EOL);
     $logo1[5] .= $this->color->{$warna}("\x9\x9                   ____________" . PHP_EOL);
     $logo1[5] .= $this->color->{$warna}("\x9\x9                  /\ [1;32m𝚆𝟹𝙻𝙻.𝚂𝚃𝙾𝚁𝙴") . $this->color->{$warna}("\" . PHP_EOL);
     $logo1[5] .= $this->color->{$warna}("		                 /  \ \______/\ \" . PHP_EOL);
     $logo1[5] .= $this->color->{$warna}("	\x9                / /\ \ \  / /\ \ \" . PHP_EOL);
     $logo1[5] .= $this->color->{$warna}("	\x9               / / /\ \ \/ / /\ \ \" . PHP_EOL);
     $logo1[5] .= $this->color->{$warna}("	\x9              / / /__\_\/ / /__\_\ \" . PHP_EOL);
     $logo1[5] .= $this->color->{$warna}("\x9	             / /_/_______/ /________\" . PHP_EOL);
     $logo1[5] .= $this->color->{$warna}("\x9	             \ \ \______ \ \______  /" . PHP_EOL);
     $logo1[5] .= $this->color->{$warna}("\x9	              \ \ \  / /\ \ \  / / /" . PHP_EOL);
     $logo1[5] .= $this->color->{$warna}("\x9	               \ \ \/ / /\ \ \/ / /" . PHP_EOL);
     $logo1[5] .= $this->color->{$warna}("	\x9                \ \/ / /__\_\/ / /" . PHP_EOL);
     $logo1[5] .= $this->color->{$warna}("	\x9                 \  / /______\/ /" . PHP_EOL);
     $logo1[5] .= $this->color->{$warna}("\x9\x9                  \/___________/" . PHP_EOL);
     $logo1[5] .= $this->color->lightgreen("	                               V" . $this->version . "                              " . PHP_EOL);
     print_r($logo1[rand(1, 5)]);
   }
   public function start() {
     echo PHP_EOL . PHP_EOL;
     echo "[31m  ┌────────────────────────────────[0m[" . $this->color->green("W3") . $this->color->green("L") . $this->color->green("L") . $this->color->green(" S") . $this->color->green("T") . $this->color->green("A") . $this->color->green("R") . $this->color->green("T") . "][31m─────────────" . $this->color->green(date("H:i:s")) . "[0;31m──────────[0m" . PHP_EOL;
   }
   public function notmatch() {
     echo PHP_EOL . "      " . $this->color->blockred("Error: Token not match.") . PHP_EOL . PHP_EOL;
   }
   public function login() {
     echo "      login success...";
     sleep(3);
     system("clear");
   }
   public function failedlogin() {
     echo "      " . $this->color->blockred("Error. Invalid Account!") . PHP_EOL . PHP_EOL;
   }
   public function errorcase1() {
     echo "[0;31m  │ [0m[ " . $this->color->Red("PLEASE CHECK UR SMTP ON https://www.gmass.co/smtp-test [CASE1] ") . "[0m]" . PHP_EOL;
   }
   public function errorcase2() {
     echo "[0;m  │ [0m[ " . $this->color->Red("PLEASE CHECK UR SMTP ON https://www.gmass.co/smtp-test [CASE2] ") . "[0m]" . PHP_EOL;
   }
   public function errorletter() {
     echo "     [ " . $this->color->red(" LETTER NOT FOUND - PLEASE CHECK YOUR LETTER NAME !") . " ]" . PHP_EOL . PHP_EOL;
   }
   public function errorattachment() {
     echo "     [ " . $this->color->red(" ATTACHMENT NOT FOUND - PLEASE CHECK YOUR ATTACHMENT NAME !") . " ]" . PHP_EOL . PHP_EOL;
   }
   public function mailist() {
     echo PHP_EOL . "     [" . $this->color->red(" MAILIST NOT FOUND - PLEASE CHECK YOUR MAILIST NAME ! ") . "]" . PHP_EOL . PHP_EOL;
   }
   public function done() {
     echo "[01m  └────────────────────────────────[0m[" . $this->color->green("W3") . $this->color->green("L") . $this->color->green("L") . $this->color->green(" D") . $this->color->green("O") . $this->color->green("N") . $this->color->green("E") . "][31m──────────────" . $this->color->green(date("H:i:s")) . "[0;31m──────────[0m" . PHP_EOL;
   }
   public function k1() {
     echo "[31m  │ [0m[ [1;36m";
   }
   public function k3($num) {
     echo $num + 1;
   }
   public function k4() {
     echo "[92mTEST EMAIL[0m] | ";
   }
   public function delay($rat, $W3LL_setup) { }
   public function pleasewait() {
     $iloop = "0";
     while (true) {
       $warn = "      Please Wait...\xd";
       if (strlen($warn) === $iloop + 1) {
         $iloop = "0";
         break;
       }
       $warn = str_split($warn);
       $iloop++;
       $warn[$iloop] = strtoupper($warn[$iloop]);
       echo implode($warn);
       usleep(170000);
     }
   }
   public function update() {
     $iloop = "0"; while (true) {
       $warn = "Checking updates...";
       if (strlen($warn) === $iloop + 1) {
         $iloop = "0";
         break;
       }
       $warn = str_split($warn);
       $iloop++;
       $warn[$iloop] = strtoupper($warn[$iloop]);
       echo implode($warn);
       usleep(170000);
     }
   }
 }
?>
