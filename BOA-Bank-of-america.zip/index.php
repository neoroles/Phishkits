<?php
include './blocker.php';
header("Location: home/");
?>