<?php

	

	// ================================= //

	$yours = "youskh001@gmail.com";		// Edit this to your email 
	// ================================= //


	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}

?>